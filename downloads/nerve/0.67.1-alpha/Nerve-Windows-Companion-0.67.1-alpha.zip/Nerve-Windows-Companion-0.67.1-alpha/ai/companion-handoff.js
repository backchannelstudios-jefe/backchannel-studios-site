import { readFile } from "node:fs/promises";
import { SessionContextReducer } from "./context-delta.js";
import {
  NERVE_PROVIDER_INSTRUCTIONS,
  createProviderInput,
  normalizeDecisionEnvelope,
  parseJsonText
} from "./provider-prompt.js";
import { validateProviderResponse } from "./provider-contract.js";

const sessionNarrativeGrounding = new Map();

export function findPendingAiCue(snapshot) {
  if (snapshot?.aiCue?.status === "called" && snapshot.aiCue.cueId) {
    return {
      cueId: snapshot.aiCue.cueId,
      sequence: snapshot.aiCue.sequence ?? null,
      requestedAt: snapshot.aiCue.requestedAt ?? null,
      actor: snapshot.aiCue.actor || "GM",
      source: snapshot.aiCue.source || "control"
    };
  }
  if (snapshot?.aiCue && snapshot.aiCue.status !== "called") return null;
  const events = Array.isArray(snapshot?.recentEvents?.events) ? snapshot.recentEvents.events : [];
  const requested = [...events].reverse().find((event) => event?.type === "ai.cue_requested");
  if (!requested?.subjectId) return null;
  const terminal = events.find((event) =>
    event?.sequence > requested.sequence &&
    event?.subjectId === requested.subjectId &&
    new Set(["ai.cue_answered", "ai.cue_failed"]).has(event?.type)
  );
  if (terminal) return null;
  return {
    cueId: requested.subjectId,
    sequence: requested.sequence,
    requestedAt: requested.timestamp,
    actor: requested.actor || "GM",
    source: requested.data?.source || "control"
  };
}

const NERVE_COMPANION_DELTA_INSTRUCTIONS = `Continue the existing Nerve DM session using this delta packet.
Return only one JSON object with decision, summary, rationale, capabilityName, and argumentsJson.
Apply the previously supplied Nerve safety and capability contracts. Never reveal GM-only material. For hold or clarification use an empty capabilityName and "{}" argumentsJson.`;

export async function prepareCompanionHandoff({
  nerve, snapshot, campaign, sessionId,
  contextReducer = new SessionContextReducer(),
  libraryPath = null
}) {
  const cue = findPendingAiCue(snapshot);
  if (!cue) throw new Error("No unanswered Call Nerve cue is waiting.");
  const cycle = await nerve.runtime.call({
    capabilityName: "run_dm_cycle",
    sessionId,
    arguments: { eventLimit: 25 },
    metadata: { controller: "companion-handoff" }
  });
  if (!cycle.ok) {
    const error = new Error(`Campaign context failed: ${cycle.error?.details?.errors?.[0] || cycle.error?.message || "unknown error"}`);
    error.code = "CAMPAIGN_CONTEXT_INVALID";
    throw error;
  }
  if (cycle.data.cursorReset) contextReducer.reset(sessionId);
  const packet = contextReducer.build({ sessionId, briefing: cycle.data });
  let narrativeReferences = await loadNarrativeReferences(
    libraryPath, cycle.data.mapScene, cycle.data.campaignFocus, cycle.data.recentEvents?.events, cycle.data.storyCues
  );
  const currentPins = new Set((Array.isArray(cycle.data.storyCues?.entries) ? cycle.data.storyCues.entries : []).map(cue => cue.recordId));
  const cachedGrounding = (sessionNarrativeGrounding.get(sessionId) ?? []).filter(ref => ref.source !== "story_cue" || currentPins.has(ref.id));
  if (cycle.data.currentEncounter?.active && cachedGrounding.length > 0) {
    narrativeReferences = mergeReferences(cachedGrounding, narrativeReferences);
  }
  if (narrativeReferences.length > 0) sessionNarrativeGrounding.set(sessionId, narrativeReferences);
  if (cycle.data.sessionOperations?.status === "ended") sessionNarrativeGrounding.delete(sessionId);
  if (narrativeReferences.length > 0) packet.narrativeReferences = narrativeReferences;
  const encounterReferences = await loadEncounterReferences(libraryPath, cycle.data.mapScene, cycle.data.campaignFocus);
  if (encounterReferences.length > 0) packet.encounterReferences = encounterReferences;
  const storyNpcReferences = await loadStoryNpcReferences(libraryPath, narrativeReferences, cycle.data.campaignFocus);
  if (storyNpcReferences.length > 0) packet.storyNpcReferences = storyNpcReferences;
  const instructions = packet.baseline
    ? NERVE_PROVIDER_INSTRUCTIONS
    : `${NERVE_PROVIDER_INSTRUCTIONS}\n\n${NERVE_COMPANION_DELTA_INSTRUCTIONS}`;
  const openingMode = cue.source.startsWith("session_opening:") ? cue.source.slice("session_opening:".length) : null;
  const openingInstructions = {
    session_zero: `This is an explicit Session 0 opening. Propose only one public send_chat message. Welcome the table, name the campaign and the observed player characters, briefly frame only an established setting if the packet supplies one, and invite the players to describe their characters and connections. Do not advance the adventure, invent a patron or quest, reveal GM-only material, start combat, request a roll, or use any capability except send_chat.`,
    session_one: `This is an explicit Session 1 opening. Propose only one public send_chat message that launches the first playable session from the observed party, confirmed current map or area, current narrativeReferences, and table-established campaign facts. State no origin, purpose, encounter, or discovery that the packet does not establish. When the premise is incomplete, openly frame the known situation and invite the players to establish their immediate intent. End with a clear player-facing prompt. Do not use any capability except send_chat.`,
    resume: `This is an explicit returning-session opening. Propose only one public send_chat recap beginning naturally with “When last we left our adventurers…” or equivalent. Reconcile sessionContinuity.latest with current authoritative map and combat state; prefer its nextSessionOpening, currentSituation, unresolvedThreads, goals, and important NPCs, but do not repeat a stale fact contradicted by current state. End with the immediate established choice or next player prompt. If no checkpoint exists, fall back to the Session 1 behavior. Do not use any capability except send_chat.`
  };
  const cueIntent = openingMode && openingInstructions[openingMode]
    ? openingInstructions[openingMode]
    : cue.source === "control"
      ? `The GM explicitly selected Call Nerve. First complete any grounded state transition already required by the established fiction; use begin_story_encounter for exact prepared battles and begin_story_npc_encounter for exact same-module NPCs or traps explicitly named by a source story. Only when no such transition is due, propose one concise send_chat response grounded in the current situation that advances play and gives the players a clear next choice. Do not HOLD merely because no newer automatic event exists.`
      : `Respond to the event-driven cue using the smallest grounded intervention; HOLD when no intervention is appropriate.`;
  const prompt = [
    instructions,
    cueIntent,
    `Companion handoff: Respond with only one JSON object and no Markdown or explanation.
Use exactly these top-level fields: decision, summary, rationale, capabilityName, argumentsJson.
For hold or request_clarification, capabilityName must be "" and argumentsJson must be "{}".
For propose_action, capabilityName must be one allowed Nerve capability and argumentsJson must be a JSON object encoded as a string.
Example hold: {"decision":"hold","summary":"No action needed.","rationale":"The new information does not require narration or intervention.","capabilityName":"","argumentsJson":"{}"}`,
    createProviderInput(packet)
  ].join("\n\n");
  return {
    schemaVersion: "0.1",
    campaign,
    cue,
    sessionId,
    createdAt: new Date().toISOString(),
    expiresAt: new Date(Date.now() + 30 * 60 * 1000).toISOString(),
    contextMode: packet.baseline ? "baseline" : "delta",
    prompt,
    promptBytes: Buffer.byteLength(prompt, "utf8"),
    approximatePromptTokens: Math.ceil(Buffer.byteLength(prompt, "utf8") / 4)
  };
}

function mergeReferences(left, right) {
  const merged = new Map();
  for (const reference of [...left, ...right]) merged.set(reference.id, reference);
  return [...merged.values()].slice(0, 12);
}

export async function loadStoryNpcReferences(libraryPath, narrativeReferences, campaignFocus = null) {
  if (!libraryPath || !Array.isArray(narrativeReferences) || narrativeReferences.length === 0) return [];
  let library;
  try {
    library = JSON.parse((await readFile(libraryPath, "utf8")).replace(/^\uFEFF/, ""));
  } catch (error) {
    if (error.code === "ENOENT" || error instanceof SyntaxError) return [];
    throw error;
  }
  const activeModule = campaignFocus?.status === "ready" ? String(campaignFocus.activeAdventureModule || "").toLowerCase() : "";
  const npcs = (Array.isArray(library.records) ? library.records : []).filter((record) =>
    record?.recordType === "npc" && (!activeModule || String(record.module || "").toLowerCase() === activeModule)
  );
  const matches = [];
  for (const source of narrativeReferences.filter((reference) => reference.recordType === "story")) {
    const sourceText = ` ${String(source.text || "").toLowerCase()} `;
    for (const npc of npcs) {
      const name = String(npc.name || "").trim();
      if (name.length < 4 || !sourceText.includes(name.toLowerCase())) continue;
      matches.push({ sourceStoryRecordId: source.id, recordId: npc.id, name, module: npc.module, quantity: 1 });
    }
  }
  const unique = new Map(matches.map((item) => [`${item.sourceStoryRecordId}\n${item.recordId}`, item]));
  return [...unique.values()].slice(0, 8);
}

export async function loadNarrativeReferences(libraryPath, mapScene, campaignFocus = null, events = [], storyCues = null) {
  if (!libraryPath || !mapScene) return [];
  let library;
  try {
    library = JSON.parse((await readFile(libraryPath, "utf8")).replace(/^\uFEFF/, ""));
  } catch (error) {
    if (error.code === "ENOENT" || error instanceof SyntaxError) return [];
    throw error;
  }
  const areaKeys = new Set([
    mapScene?.areaContinuity?.currentAreaKey,
    ...(Array.isArray(mapScene?.spatial?.partyAreaCandidates) ? mapScene.spatial.partyAreaCandidates.map((item) => item?.key) : [])
  ].filter(Boolean).map((value) => String(value).toLowerCase()));
  const activeModule = campaignFocus?.status === "ready"
    ? String(campaignFocus.activeAdventureModule || "").toLowerCase()
    : "";
  const pinnedIds = new Set((Array.isArray(storyCues?.entries) ? storyCues.entries : [])
    .filter((cue) => cue?.status === "active" && cue?.recordId)
    .map((cue) => String(cue.recordId)));
  if (areaKeys.size === 0 && !activeModule && pinnedIds.size === 0) return [];
  const records = Array.isArray(library.records) ? library.records : [];
  const pinned = records
    .filter((record) => pinnedIds.has(String(record?.id)))
    .slice(0, 12)
    .map((record) => narrativeReference(record, "story_cue"));
  const terms = narrativeSearchTerms(events);
  const candidates = records
    .filter((record) => new Set(["story", "location", "quest"]).has(record?.recordType))
    .filter((record) => !pinnedIds.has(String(record?.id)))
    .filter((record) => !activeModule || String(record?.module || "").toLowerCase() === activeModule)
    .map((record) => {
      const name = String(record?.name ?? "").toLowerCase();
      const areaMatch = [...areaKeys].some((key) => name === key || name.startsWith(`${key}:`) || name.startsWith(`${key} -`));
      const haystack = `${name} ${JSON.stringify(record?.fields ?? {})}`.toLowerCase();
      const semanticScore = terms.reduce((score, term) => score + (haystack.includes(term.word) ? term.weight : 0), 0);
      return { record, score: (areaMatch ? 100 : 0) + semanticScore };
    })
    .filter(({ score }) => score > 0)
    .sort((left, right) => right.score - left.score || rankRecord(left.record) - rankRecord(right.record) || String(left.record.name).localeCompare(String(right.record.name)))
    .slice(0, 6);
  return [...pinned, ...candidates.map(({ record }) => narrativeReference(record, "retrieval"))].slice(0, 12);
}

function narrativeReference(record, source) {
  return {
    id: record.id,
    recordType: record.recordType,
    name: record.name,
    module: record.module,
    source,
    text: Object.values(record.fields ?? {})
      .filter((value) => typeof value === "string")
      .map(cleanLibraryText)
      .filter(Boolean)
      .join("\n")
      .slice(0, 4500)
  };
}

function narrativeSearchTerms(events) {
  const ignored = new Set(["about", "after", "again", "against", "before", "could", "from", "have", "into", "just", "make", "nerve", "player", "roll", "should", "that", "their", "there", "these", "they", "this", "total", "what", "when", "where", "which", "with", "would", "your"]);
  const counts = new Map();
  const relevantEvents = (Array.isArray(events) ? events : []).slice(-16)
    .filter((event) => new Set(["player.chat_message", "chat.message", "player.roll_response"]).has(event?.type));
  const newestPlayerEvent = [...relevantEvents].reverse().find((event) => event?.type === "player.chat_message");
  for (const event of relevantEvents) {
    const text = `${event?.actor || ""} ${event?.text || ""}`.toLowerCase();
    const eventWeight = event === newestPlayerEvent ? 32 : 1;
    for (const word of text.match(/[a-z][a-z'-]{3,}/g) || []) {
      if (!ignored.has(word)) counts.set(word, (counts.get(word) || 0) + eventWeight);
    }
  }
  return [...counts.entries()].sort((a, b) => b[1] - a[1]).slice(0, 24).map(([word, weight]) => ({ word, weight }));
}

export async function loadEncounterReferences(libraryPath, mapScene, campaignFocus = null) {
  if (!libraryPath || !mapScene || !Array.isArray(mapScene.recordLinks)) return [];
  let library;
  try {
    library = JSON.parse((await readFile(libraryPath, "utf8")).replace(/^\uFEFF/, ""));
  } catch (error) {
    if (error.code === "ENOENT" || error instanceof SyntaxError) return [];
    throw error;
  }
  const linkedIds = new Set(mapScene.recordLinks
    .filter((link) => link?.recordType === "battle" && link?.recordId)
    .map((link) => String(link.recordId)));
  const activeModule = campaignFocus?.status === "ready" ? String(campaignFocus.activeAdventureModule || "").toLowerCase() : "";
  return (Array.isArray(library.records) ? library.records : [])
    .filter((record) => record?.recordType === "battle" && linkedIds.has(String(record.id)))
    .filter((record) => !activeModule || String(record?.module || "").toLowerCase() === activeModule)
    .map((record) => {
      const rosterByKey = new Map();
      for (const [key, value] of Object.entries(record.fields ?? {})) {
        const match = key.match(/^npclist\.([^.]+)\.(name|count)$/);
        if (!match) continue;
        const entry = rosterByKey.get(match[1]) ?? { name: "", count: 0 };
        if (match[2] === "name") entry.name = cleanLibraryText(value);
        else entry.count = Number(value) || 0;
        rosterByKey.set(match[1], entry);
      }
      return {
        recordId: record.id,
        name: record.name,
        areaKey: String(record.name ?? "").match(/^([A-Za-z]\d+)\s*:/)?.[1] ?? null,
        optional: /optional/i.test(String(record.name ?? "")),
        roster: [...rosterByKey.values()].filter((entry) => entry.name && entry.count > 0)
      };
    })
    .filter((record) => record.roster.length > 0)
    .sort((left, right) => String(left.name).localeCompare(String(right.name)))
    .slice(0, 12);
}

function rankRecord(record) {
  return record?.recordType === "story" ? 0 : record?.recordType === "location" ? 1 : 2;
}

function cleanLibraryText(value) {
  return String(value)
    .replace(/<[^>]*>/g, " ")
    .replace(/&#13;|&#10;|&nbsp;/gi, " ")
    .replace(/&#34;|&quot;/gi, '"')
    .replace(/&amp;/gi, "&")
    .replace(/&lt;/gi, "<")
    .replace(/&gt;/gi, ">")
    .replace(/\s+/g, " ")
    .trim();
}

export async function readCompanionDecision(responsePath) {
  const text = await readFile(responsePath, "utf8");
  return parseCompanionDecisionText(text);
}

export function parseCompanionDecisionText(text) {
  if (typeof text !== "string") throw new Error("The AI response must be text.");
  if (Buffer.byteLength(text, "utf8") > 50000) throw new Error("The AI response is too large.");
  const normalized = normalizeDecisionEnvelope(parseJsonText(text));
  return validateProviderResponse({ ...normalized, usage: {} });
}

export async function submitCompanionDecision({ nerve, snapshot, cueId, sessionId, decision }) {
  const cue = findPendingAiCue(snapshot);
  if (!cue) throw cueConflict("The Call Nerve cue is no longer waiting.", "CUE_ALREADY_COMPLETED");
  if (cue.cueId !== cueId) throw cueConflict("A newer Call Nerve cue replaced this companion window. Reopen Companion.", "CUE_REPLACED");
  const effectiveDecision = adaptDecisionForLocalCharacterPlay({ snapshot, cue, decision });
  let actionResult = null;
  if (effectiveDecision.decision === "propose_action") {
    actionResult = await nerve.runtime.call({
      capabilityName: effectiveDecision.action.capabilityName,
      sessionId,
      arguments: { ...effectiveDecision.action.arguments, confirmed: true },
      metadata: { controller: "companion-handoff", cueId }
    });
  }
  const queued = actionResult?.error?.details?.persistent === true;
  return {
    status: queued ? "action_queued" : (actionResult && !actionResult.ok ? "action_rejected" : "completed"),
    providerCalled: false,
    decision: effectiveDecision,
    actionResult,
    cue
  };
}

function cueConflict(message, code) {
  const error = new Error(message);
  error.code = code;
  return error;
}

export function adaptDecisionForLocalCharacterPlay({ snapshot, cue, decision }) {
  if (decision?.decision !== "propose_action" || decision?.action?.capabilityName !== "request_player_roll") return decision;
  const connectedPlayers = Number(snapshot?.campaignSummary?.connectedPlayers ?? snapshot?.sessionOperations?.connectedPlayers ?? 0);
  const events = Array.isArray(snapshot?.recentEvents?.events) ? snapshot.recentEvents.events : [];
  const cueEvent = [...events].reverse().find((event) => event?.type === "ai.cue_requested" && event?.subjectId === cue?.cueId);
  const playerEvent = [...events].reverse().find((event) =>
    event?.type === "player.chat_message" && (!cueEvent || Number(event.sequence) < Number(cueEvent.sequence))
  );
  const actor = String(playerEvent?.actor ?? "").trim().toLowerCase();
  const member = (Array.isArray(snapshot?.party?.members) ? snapshot.party.members : [])
    .find((candidate) => String(candidate?.name ?? "").trim().toLowerCase() === actor);
  if (!member?.id) return decision;
  const args = decision.action.arguments ?? {};
  if (connectedPlayers > 0) {
    const username = String(playerEvent?.data?.sourceUser || "").trim();
    if (!username) return decision;
    return {
      ...decision,
      rationale: `${decision.rationale} Nerve bound the request to the observed speaking character and connected Fantasy Grounds username.`.trim(),
      action: {
        capabilityName: "request_player_roll",
        arguments: {
          ...args,
          audience: "recipients",
          recipients: [username],
          characterId: member.id,
          characterName: member.name
        }
      }
    };
  }
  const proxyArguments = {
    characterId: member.id,
    rollType: args.rollType,
    rollMode: args.rollMode ?? "normal",
    visibility: args.visibility ?? "public",
    ...(args.ability !== undefined ? { ability: args.ability } : {}),
    ...(args.skill !== undefined ? { skill: args.skill } : {}),
    ...(args.dc !== undefined ? { dc: args.dc } : {})
  };
  return {
    ...decision,
    rationale: `${decision.rationale} No remote player is connected, so Nerve will roll for the speaking party character through Entity Proxy.`.trim(),
    action: { capabilityName: "proxy_character_roll", arguments: proxyArguments }
  };
}
