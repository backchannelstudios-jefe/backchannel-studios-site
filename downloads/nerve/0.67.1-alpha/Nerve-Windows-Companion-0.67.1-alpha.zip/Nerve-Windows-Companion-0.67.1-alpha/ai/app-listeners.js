import { spawn } from "node:child_process";
import { access, mkdir, readFile } from "node:fs/promises";
import { constants, existsSync } from "node:fs";
import { isAbsolute, join } from "node:path";
import { tmpdir } from "node:os";
import { createInterface } from "node:readline";
import { parseCompanionDecisionText } from "./companion-handoff.js";
import { CodexAppServerClient, NERVE_DECISION_OUTPUT_SCHEMA, findCodexExecutable, runCodexAppListener } from "./codex-app-listener.js";
import { fetchWithTransientRetry } from "./fetch-retry.js";

const APP_IDS = new Set(["codex", "antigravity", "claude", "grok", "custom"]);
const MAX_OUTPUT_BYTES = 100_000;
const DEFAULT_TIMEOUT_MS = 3 * 60_000;

export const APP_CONNECTORS = Object.freeze({
  codex: { id: "codex", label: "Codex / ChatGPT", listenerKind: "codex_app_server" },
  antigravity: { id: "antigravity", label: "Gemini (Antigravity)", listenerKind: "antigravity_cli" },
  claude: { id: "claude", label: "Claude", listenerKind: "claude_code_cli" },
  grok: { id: "grok", label: "Grok", listenerKind: "grok_build_cli" },
  custom: { id: "custom", label: "Custom AI App (Experimental)", listenerKind: "custom_ai_app" }
});

const SAFETY_PROMPT = `You are the private AI decision engine for Nerve, a guarded Fantasy Grounds assistant.
Use only the supplied Nerve handoff. Do not browse, run tools, inspect files, or change the workstation.
Return only one JSON object matching this schema, with no Markdown:
${JSON.stringify(NERVE_DECISION_OUTPUT_SCHEMA)}\n\n`;

export function normalizeAppConnector(value) {
  const id = String(value || "codex").trim().toLowerCase();
  if (!APP_IDS.has(id)) {
    const error = new Error(`Unsupported AI app connector: ${id}`);
    error.code = "APP_CONNECTOR_NOT_SUPPORTED";
    throw error;
  }
  return id;
}

export async function runConfiguredAppListener(options) {
  const appConnector = normalizeAppConnector(options.appConnector);
  if (appConnector === "codex") return runCodexAppListener(options);
  const adapter = appConnector === "custom"
    ? await loadCustomAdapter(options.customConfigPath)
    : builtInAdapter(appConnector, options);
  const workspacePath = options.workspacePath || join(tmpdir(), `Nerve-${appConnector}-Listener`);
  await mkdir(workspacePath, { recursive: true });
  return runCliAppListener({ ...options, workspacePath, adapter });
}

export async function checkConfiguredAppConnector(options = {}) {
  const appConnector = normalizeAppConnector(options.appConnector);
  const definition = APP_CONNECTORS[appConnector];
  const workspacePath = options.workspacePath || join(tmpdir(), `Nerve-${appConnector}-Connection-Test`);
  await mkdir(workspacePath, { recursive: true });
  const prompt = `${SAFETY_PROMPT}Connection test only. Return a hold decision with a short summary confirming that the signed-in AI app can answer Nerve.`;
  let raw;
  if (appConnector === "codex") {
    const command = options.codexPath || await findCodexExecutable({ env: options.env || process.env });
    const client = new CodexAppServerClient({ command, cwd: workspacePath, spawnImpl: options.spawnImpl || spawn });
    try {
      await client.start();
      raw = await client.runDecision(prompt);
    } finally {
      await client.close();
    }
  } else {
    const adapter = appConnector === "custom"
      ? await loadCustomAdapter(options.customConfigPath)
      : builtInAdapter(appConnector, options);
    await adapter.checkExecutable();
    raw = await adapter.runDecision(prompt, { spawnImpl: options.spawnImpl || spawn, cwd: workspacePath });
  }
  const decision = parseAppDecision(raw);
  if (decision.decision !== "hold") throw codedError(`${definition.label} did not return the safe connection-test decision.`, "APP_CONNECTION_TEST_INVALID");
  return {
    schemaVersion: "0.1",
    connected: true,
    appConnector,
    label: definition.label,
    decision: decision.decision,
    networkCalled: true,
    allowanceMayBeUsed: true
  };
}

export async function runCliAppListener({
  endpoint, token, signal, adapter, workspacePath, fetchImpl = fetch, spawnImpl = spawn,
  waitSeconds = 30, maxCues = Number.POSITIVE_INFINITY, onStatus = async () => {}
}) {
  let processed = 0;
  await onStatus({ listenerKind: adapter.listenerKind, listenerName: adapter.label, listenerPhase: "starting" });
  await adapter.checkExecutable();
  await onStatus({ listenerKind: adapter.listenerKind, listenerName: adapter.label, listenerPhase: "ready" });
  while (!signal?.aborted && processed < maxCues) {
    try {
      const response = await fetchWithTransientRetry(fetchImpl, `${endpoint}/v1/cues/next?waitSeconds=${waitSeconds}`, {
        headers: { authorization: `Bearer ${token}` }, signal
      }, { onRetry: async () => onStatus({ listenerKind: adapter.listenerKind, listenerName: adapter.label, listenerPhase: "reconnecting" }) });
      if (response.status === 204) continue;
      if (!response.ok) {
        let detail = {};
        try { detail = await response.json(); } catch {}
        const error = new Error(`Nerve connector cue request failed (${response.status}): ${String(detail.message || "No further detail available.").slice(0, 300)}`);
        error.code = detail.error === "CAMPAIGN_CONTEXT_INVALID" ? detail.error : "APP_LISTENER_FAILED";
        throw error;
      }
      const handoff = await response.json();
      await onStatus({ listenerKind: adapter.listenerKind, listenerName: adapter.label, listenerPhase: "responding", cueId: handoff.cue?.cueId ?? null });
      const heartbeat = setInterval(() => {
        void onStatus({ listenerKind:adapter.listenerKind, listenerName:adapter.label, listenerPhase:"responding", cueId:handoff.cue?.cueId ?? null, listenerLastSeenAt:new Date().toISOString(), listenerLastSeenAtEpoch:Math.floor(Date.now()/1000) }).catch(() => {});
      }, 10_000);
      heartbeat.unref();
      let raw;
      try { raw = await adapter.runDecision(`${SAFETY_PROMPT}${handoff.prompt}`, { signal, spawnImpl, cwd: workspacePath }); }
      finally { clearInterval(heartbeat); }
      const decision = parseAppDecision(raw);
      const submitted = await fetchWithTransientRetry(fetchImpl, `${endpoint}/v1/cues/${encodeURIComponent(handoff.cue.cueId)}/decision`, {
        method: "POST",
        headers: { authorization: `Bearer ${token}`, "content-type": "application/json" },
        body: JSON.stringify(toWireDecision(decision)), signal
      }, { onRetry: async () => onStatus({ listenerKind: adapter.listenerKind, listenerName: adapter.label, listenerPhase: "reconnecting", cueId: handoff.cue?.cueId ?? null }) });
      const body = await submitted.text();
      if (!submitted.ok && submitted.status !== 409) {
        throw new Error(`Nerve connector rejected the ${adapter.label} decision (${submitted.status}): ${body.slice(0, 200)}`);
      }
      processed += 1;
      await onStatus({ listenerKind: adapter.listenerKind, listenerName: adapter.label, listenerPhase: "ready", cueId: null });
    } catch (error) {
      if (signal?.aborted || error?.name === "AbortError") return { processed, stopped: true };
      throw error;
    }
  }
  return { processed, stopped: Boolean(signal?.aborted) };
}

function builtInAdapter(id, options) {
  const definitions = {
    antigravity: {
      command: options.antigravityPath || standardAntigravityPath(options.env || process.env) || "agy",
      args: ["--input-format", "stream-json", "--output-format", "stream-json", "--json-schema", JSON.stringify(NERVE_DECISION_OUTPUT_SCHEMA), "--sandbox"],
      encodeInput: (prompt) => `${JSON.stringify({ event: "user", message: { content: prompt } })}\n`
    },
    claude: {
      command: options.claudePath || standardClaudePath(options.env || process.env) || "claude",
      args: ["-p", "--output-format", "json"]
    },
    grok: { ...(options.grokPath ? { command: options.grokPath } : standardGrokLaunch(options.env || process.env)), acp: true }
  };
  return makeProcessAdapter({ ...APP_CONNECTORS[id], ...definitions[id] });
}

export function standardGrokLaunch(env = process.env, existsImpl = existsSync) {
  const entry = env.APPDATA ? join(env.APPDATA, "npm", "node_modules", "@xai-official", "grok", "bin", "grok") : null;
  if (entry && existsImpl(entry)) return { command: process.execPath, args: [entry] };
  return { command: "grok", args: [] };
}

function standardAntigravityPath(env) {
  return env.LOCALAPPDATA ? join(env.LOCALAPPDATA, "agy", "bin", "agy.exe") : null;
}

export function standardClaudePath(env, existsImpl = existsSync) {
  if (!env.APPDATA) return null;
  const path = join(env.APPDATA, "npm", "node_modules", "@anthropic-ai", "claude-code", "bin", "claude.exe");
  return existsImpl(path) ? path : null;
}

async function loadCustomAdapter(path) {
  if (!path) throw codedError("Custom AI App configuration is missing.", "CUSTOM_APP_CONFIG_MISSING");
  let config;
  try { config = JSON.parse((await readFile(path, "utf8")).replace(/^\uFEFF/, "")); }
  catch { throw codedError("Custom AI App configuration could not be read.", "CUSTOM_APP_CONFIG_INVALID"); }
  if (config.schemaVersion !== "0.1" || config.acknowledgedRisk !== true || !isAbsolute(config.executable || "")) {
    throw codedError("Custom AI App configuration must acknowledge risk and use an absolute executable path.", "CUSTOM_APP_CONFIG_INVALID");
  }
  if (!Array.isArray(config.args) || config.args.some((value) => typeof value !== "string") || config.args.length > 32) {
    throw codedError("Custom AI App arguments are invalid.", "CUSTOM_APP_CONFIG_INVALID");
  }
  if (config.inputMode !== "stdin" || config.outputMode !== "json") {
    throw codedError("Custom AI Apps must use JSON output and receive prompts on standard input.", "CUSTOM_APP_CONFIG_INVALID");
  }
  return makeProcessAdapter({
    ...APP_CONNECTORS.custom, command: config.executable, args: config.args,
    timeoutMs: Math.min(Math.max(Number(config.timeoutSeconds || 300), 10), 600) * 1000
  });
}

function makeProcessAdapter({ id, label, listenerKind, command, args = [], timeoutMs = DEFAULT_TIMEOUT_MS, encodeInput = (prompt) => prompt, acp = false }) {
  return {
    id, label, listenerKind,
    async checkExecutable() {
      if (!isAbsolute(command)) return;
      try { await access(command, constants.F_OK); }
      catch { throw codedError(`${label} is not installed at the configured location.`, `${id.toUpperCase()}_NOT_FOUND`); }
    },
    runDecision(prompt, { signal, spawnImpl, cwd }) {
      if (acp) return runGrokAcpDecision({ command, args, prompt, timeoutMs, signal, spawnImpl, label, cwd });
      return runJsonProcess({ command, args, prompt: encodeInput(prompt), timeoutMs, signal, spawnImpl, label, cwd });
    }
  };
}

function runJsonProcess({ command, args, prompt, timeoutMs, signal, spawnImpl, label, cwd }) {
  return new Promise((resolve, reject) => {
    const child = spawnImpl(command, args, { cwd, windowsHide: true, shell: false, stdio: ["pipe", "pipe", "pipe"] });
    let stdout = "";
    let stderr = "";
    let settled = false;
    const finish = (fn, value) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      signal?.removeEventListener("abort", abort);
      fn(value);
    };
    const abort = () => {
      child.kill();
      const error = codedError(`${label} was stopped.`, "APP_LISTENER_STOPPED");
      error.name = "AbortError";
      finish(reject, error);
    };
    const timer = setTimeout(() => {
      child.kill();
      finish(reject, codedError(`${label} did not answer before the local timeout.`, "APP_LISTENER_TIMEOUT"));
    }, timeoutMs);
    signal?.addEventListener("abort", abort, { once: true });
    child.once("error", (error) => finish(reject, codedError(`${label} could not start: ${error.message}`, "APP_LISTENER_START_FAILED")));
    child.stdin.on("error", () => { /* Exit/error handling reports the useful app failure. */ });
    child.stdout.on("data", (chunk) => {
      stdout += chunk;
      if (Buffer.byteLength(stdout, "utf8") > MAX_OUTPUT_BYTES) {
        child.kill();
        finish(reject, codedError(`${label} returned too much data.`, "APP_LISTENER_OUTPUT_TOO_LARGE"));
      }
    });
    child.stderr.on("data", (chunk) => { stderr = `${stderr}${chunk}`.slice(-2000); });
    child.once("exit", (code) => {
      if (code === 0) finish(resolve, stdout);
      else finish(reject, codedError(`${label} exited without a usable response (${code ?? "unknown"}). ${safeText(stderr)}`, "APP_LISTENER_EXITED"));
    });
    child.stdin.end(prompt);
  });
}

export function extractDecisionText(raw) {
  const text = String(raw || "").trim();
  if (!text) throw codedError("The AI app returned an empty response.", "APP_LISTENER_EMPTY_RESPONSE");
  if (text.includes("\n")) {
    const lines = text.split(/\r?\n/).filter(Boolean);
    for (let index = lines.length - 1; index >= 0; index -= 1) {
      try {
        const event = JSON.parse(lines[index]);
        if (event?.event === "result" && event.result) return extractDecisionText(JSON.stringify(event.result));
      } catch { /* A non-event line is handled by the normal parser below. */ }
    }
  }
  let value;
  try { value = JSON.parse(text); } catch {
    // ACP can emit progress prose before the final decision. Accept only a
    // complete trailing object, without guessing between multiple objects.
    const start = text.indexOf("{");
    if (start < 0) return text;
    try { value = JSON.parse(text.slice(start)); } catch { return text; }
    if (!value || typeof value.decision !== "string") return text;
  }
  if (value && typeof value === "object" && typeof value.decision === "string") return JSON.stringify(value);
  for (const key of ["structured_output", "structuredOutput", "result", "response", "output", "text", "content"]) {
    const candidate = value?.[key];
    if (candidate && typeof candidate === "object" && typeof candidate.decision === "string") return JSON.stringify(candidate);
    if (typeof candidate === "string" && candidate.trim()) return candidate.trim();
  }
  throw codedError("The AI app did not return a Nerve decision object.", "APP_LISTENER_INVALID_RESPONSE");
}

function runGrokAcpDecision({ command, args, prompt, timeoutMs, signal, spawnImpl, label, cwd }) {
  return new Promise((resolve, reject) => {
    const child = spawnImpl(command, [...args, "agent", "stdio"], { cwd, windowsHide: true, shell: false, stdio: ["pipe", "pipe", "pipe"] });
    const lines = createInterface({ input: child.stdout });
    const pending = new Map();
    let nextId = 1;
    let text = "";
    let settled = false;
    let stderr = "";
    const finish = (fn, value) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      signal?.removeEventListener("abort", abort);
      lines.close();
      child.stdin.end();
      if (child.exitCode === null) child.kill();
      fn(value);
    };
    const request = (method, params) => new Promise((requestResolve, requestReject) => {
      const id = nextId++;
      pending.set(id, { resolve: requestResolve, reject: requestReject });
      child.stdin.write(`${JSON.stringify({ jsonrpc: "2.0", id, method, params })}\n`);
    });
    const abort = () => { const error = codedError(`${label} was stopped.`, "APP_LISTENER_STOPPED"); error.name = "AbortError"; finish(reject, error); };
    const timer = setTimeout(() => finish(reject, codedError(`${label} did not answer before the local timeout.`, "APP_LISTENER_TIMEOUT")), timeoutMs);
    signal?.addEventListener("abort", abort, { once: true });
    child.stderr.on("data", (chunk) => { stderr = `${stderr}${chunk}`.slice(-2000); });
    child.stdin.on("error", () => {});
    child.once("error", (error) => finish(reject, codedError(`${label} could not start: ${error.message}`, "APP_LISTENER_START_FAILED")));
    child.once("exit", (code) => { if (!settled) finish(reject, codedError(`${label} exited unexpectedly (${code ?? "unknown"}). ${safeText(stderr)}`, "APP_LISTENER_EXITED")); });
    lines.on("line", (line) => {
      let message;
      try { message = JSON.parse(line); } catch { return; }
      if (message.method === "session/update") {
        const update = message.params?.update;
        if (update?.sessionUpdate === "agent_message_chunk" && typeof update.content?.text === "string") text += update.content.text;
        return;
      }
      const waiting = pending.get(message.id);
      if (!waiting) return;
      pending.delete(message.id);
      if (message.error) waiting.reject(codedError(message.error.message || `${label} ACP request failed.`, "APP_LISTENER_PROTOCOL_FAILED"));
      else waiting.resolve(message.result || {});
    });
    void (async () => {
      try {
        const initialized = await request("initialize", { protocolVersion: 1, clientCapabilities: { fs: { readTextFile: false, writeTextFile: false }, terminal: false } });
        const cached = (initialized.authMethods || []).find((method) => method.id === "cached_token");
        if (!cached) throw codedError("Grok is not signed in. Run grok login first.", "GROK_LOGIN_REQUIRED");
        await request("authenticate", { methodId: "cached_token", _meta: { headless: true } });
        const session = await request("session/new", { cwd, mcpServers: [] });
        if (!session.sessionId) throw codedError("Grok did not create a private Nerve session.", "APP_LISTENER_PROTOCOL_FAILED");
        await request("session/prompt", { sessionId: session.sessionId, prompt: [{ type: "text", text: prompt }] });
        await new Promise((done) => setTimeout(done, 200));
        finish(resolve, text);
      } catch (error) { finish(reject, error); }
    })();
  });
}

function toWireDecision(decision) {
  return {
    decision: decision.decision, summary: decision.summary, rationale: decision.rationale,
    capabilityName: decision.action?.capabilityName || "",
    argumentsJson: JSON.stringify(decision.action?.arguments || {})
  };
}

function codedError(message, code) { const error = new Error(message); error.code = code; return error; }
function safeText(value) { return /token|secret|authorization|bearer|key/i.test(value) ? "" : String(value || "").replace(/[\r\n]+/g, " ").slice(0, 200); }

function parseAppDecision(raw) {
  try { return parseCompanionDecisionText(extractDecisionText(raw)); }
  catch (error) {
    if (error.code) throw error;
    throw codedError("The AI app answered, but its response was not a valid Nerve decision. No action was submitted.", "APP_LISTENER_INVALID_RESPONSE");
  }
}
