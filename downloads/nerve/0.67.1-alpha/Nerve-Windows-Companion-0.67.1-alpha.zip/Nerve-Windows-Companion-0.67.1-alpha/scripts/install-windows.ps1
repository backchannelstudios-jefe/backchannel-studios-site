[CmdletBinding()]
param(
  [string]$Campaign,
  [string]$FantasyGroundsData,
  [ValidateSet("Auto", "GMHost", "PlayerCompanion")]
  [string]$Role = "Auto",
  [string]$ReportFolder,
  [string]$InstallRoot,
  [string]$ConfigRoot,
  [switch]$SkipProviderSetup,
  [switch]$SkipShortcuts,
  [switch]$SkipBackgroundControl,
  [switch]$NoPause
)

$ErrorActionPreference = "Stop"
$sourceRoot = Split-Path -Parent $PSScriptRoot
$runtimeRoot = $sourceRoot
. (Join-Path $PSScriptRoot "extension-ownership.ps1")
$entryPoint = Join-Path $runtimeRoot "bin\nerve.js"
$defaultReportRoot = if ($env:LOCALAPPDATA) { Join-Path $env:LOCALAPPDATA "Nerve\Install" } else { Join-Path $env:USERPROFILE "Documents\Nerve\Install" }
$reportFolder = if ($ReportFolder) { [IO.Path]::GetFullPath($ReportFolder) } else { $defaultReportRoot }
$reportPath = Join-Path $reportFolder "install-summary.txt"
$installRoot = if ($InstallRoot) { [IO.Path]::GetFullPath($InstallRoot) } elseif ($env:LOCALAPPDATA) { Join-Path $env:LOCALAPPDATA "Nerve\App\current" } else { Join-Path $env:USERPROFILE "Documents\Nerve\App\current" }
$configRoot = if ($ConfigRoot) { [IO.Path]::GetFullPath($ConfigRoot) } elseif ($env:LOCALAPPDATA) { Join-Path $env:LOCALAPPDATA "Nerve\Config" } else { Join-Path $env:USERPROFILE "Documents\Nerve\Config" }

function Step([string]$Text) { Write-Host ""; Write-Host $Text -ForegroundColor Cyan }
function Pass([string]$Text) { Write-Host ("PASS  {0}" -f $Text) -ForegroundColor Green }
function Wait-ForEnter([string]$Text) { if (-not $NoPause) { Read-Host $Text | Out-Null } }
function Read-YesNo([string]$Text, [bool]$Default) {
  if ($NoPause) { return $Default }
  $suffix = if ($Default) { "[Y/n]" } else { "[y/N]" }
  $answer = (Read-Host "$Text $suffix").Trim().ToLowerInvariant()
  if (-not $answer) { return $Default }
  return $answer -in @("y", "yes")
}
function Run-Node([string[]]$Arguments) {
  & $script:nodePath $entryPoint @Arguments
  if ($LASTEXITCODE -ne 0) { throw "Nerve command failed: $($Arguments -join ' ')" }
}
function Read-NerveCampaigns {
  $campaignJson = & $script:nodePath $entryPoint campaigns --fgu-data $FantasyGroundsData --json
  if ($LASTEXITCODE -ne 0) { throw "Nerve could not scan Fantasy Grounds campaigns." }
  return @(($campaignJson -join [Environment]::NewLine) | ConvertFrom-Json)
}
function Find-ReadyCampaign {
  for ($attempt = 1; $attempt -le 6; $attempt += 1) {
    $campaigns = Read-NerveCampaigns
    $ready = @()
    foreach ($candidate in $campaigns) {
      if ($candidate.snapshotAvailable -eq $true) { $ready += $candidate }
    }
    if ($ready.Count -eq 1) { return $ready[0].name }
    if ($ready.Count -gt 1) {
      $ordered = @($ready | Sort-Object generatedAt -Descending)
      Write-Host "More than one Nerve-enabled campaign was found:"
      for ($index = 0; $index -lt $ordered.Count; $index += 1) {
        $seen = if ($ordered[$index].generatedAt) { $ordered[$index].generatedAt } else { "time unknown" }
        Write-Host ("{0}. {1} (last observed {2})" -f ($index + 1), $ordered[$index].name, $seen)
      }
      if ($NoPause) { return $ordered[0].name }
      $selection = [int](Read-Host "Enter the number beside the campaign to use")
      if ($selection -ge 1 -and $selection -le $ordered.Count) { return $ordered[$selection - 1].name }
      Write-Host "That selection was not valid; scanning again." -ForegroundColor Yellow
      continue
    }
    Write-Host ""
    Write-Host "Nerve is installed, but no loaded campaign is publishing Nerve state yet." -ForegroundColor Yellow
    Write-Host "In Fantasy Grounds: return to the campaign launcher, enable 'Nerve Adapter' under Extensions, and load the campaign again."
    Write-Host "If the campaign was already open when installation began, it must be reloaded after enabling the extension."
    if ($NoPause) { throw "No Nerve-enabled loaded campaign was found." }
    Read-Host ("Press Enter to scan again (attempt {0} of 6)" -f $attempt) | Out-Null
  }
  throw "Nerve still cannot see a live campaign snapshot. Leave Fantasy Grounds open on the loaded campaign, then rerun Install-Nerve.cmd."
}
function Get-HostedCampaigns {
  $campaignRoot = Join-Path $FantasyGroundsData "campaigns"
  $hosted = @()
  if (Test-Path -LiteralPath $campaignRoot -PathType Container) {
    $hosted = @(Get-ChildItem -LiteralPath $campaignRoot -Directory -ErrorAction SilentlyContinue | Where-Object {
      Test-Path -LiteralPath (Join-Path $_.FullName "campaign.xml") -PathType Leaf
    })
  }
  return $hosted
}
function Resolve-InstallRole {
  $hosted = @(Get-HostedCampaigns)
  if ($Role -eq "GMHost" -and $hosted.Count -eq 0) {
    throw "GM Host setup was selected, but no locally hosted Fantasy Grounds campaigns were found. Choose Player Companion or host a campaign on this computer first."
  }
  if ($Role -eq "Auto") {
    if ($hosted.Count -gt 0) { return "GMHost" }
    return "PlayerCompanion"
  }
  return $Role
}
function Install-NerveApplication {
  if ([IO.Path]::GetFullPath($sourceRoot).TrimEnd('\') -eq [IO.Path]::GetFullPath($installRoot).TrimEnd('\')) { return }
  New-Item -ItemType Directory -Path $installRoot -Force | Out-Null
  foreach ($directory in @("adapters", "ai", "bin", "cli", "core", "docs", "link", "packaging", "playtest", "schemas", "scripts")) {
    $targetDirectory = Join-Path $installRoot $directory
    New-Item -ItemType Directory -Path $targetDirectory -Force | Out-Null
    Copy-Item -Recurse -Force -Path (Join-Path (Join-Path $sourceRoot $directory) "*") -Destination $targetDirectory
  }
  foreach ($file in @("README.md", "package.json", "Install-Nerve.cmd", "Update-Nerve-Player.cmd", "Collect-Nerve-Support.cmd", "Configure-Nerve-AI.cmd", "Start-Nerve.cmd", "Stop-Nerve.cmd", "Nerve-Supervisor.cmd", "Repair-Nerve-Player.cmd", "manifest.json", "CHECKSUMS.sha256", "distribution.json")) {
    $source = Join-Path $sourceRoot $file
    if (Test-Path -LiteralPath $source) { Copy-Item -Force -LiteralPath $source -Destination (Join-Path $installRoot $file) }
  }
}
function Stop-ExistingNerveSupervisor {
  $supervisorScript = [IO.Path]::GetFullPath((Join-Path $installRoot "scripts\nerve-supervisor.ps1"))
  $escapedSupervisorScript = [regex]::Escape($supervisorScript)
  $matches = @(Get-CimInstance Win32_Process -ErrorAction SilentlyContinue | Where-Object {
    $_.Name -match '^(powershell|pwsh)\.exe$' -and
    $_.CommandLine -match $escapedSupervisorScript
  })
  foreach ($process in $matches) {
    Stop-Process -Id $process.ProcessId -Force -ErrorAction Stop
  }
  return $matches.Count
}
function Move-LegacyPlayerExtension {
  $localExtension = Join-Path $FantasyGroundsData "extensions\Nerve"
  if (-not (Test-Path -LiteralPath $localExtension -PathType Container)) { return $null }
  if (Get-Process -Name "FantasyGrounds" -ErrorAction SilentlyContinue) {
    throw "An obsolete local Nerve extension is installed on this player computer. Close Fantasy Grounds, then run this installer again so it can be backed up safely."
  }
  $backupRoot = [IO.Path]::GetFullPath((Join-Path $configRoot "Backups"))
  $backupName = "player-extension-{0}-{1}" -f (Get-Date -Format "yyyyMMdd-HHmmss"), ([Guid]::NewGuid().ToString("N").Substring(0, 8))
  $backupPath = [IO.Path]::GetFullPath((Join-Path $backupRoot $backupName))
  if (-not $backupPath.StartsWith($backupRoot.TrimEnd('\') + '\', [StringComparison]::OrdinalIgnoreCase)) {
    throw "The player extension backup path was not safely contained under the Nerve configuration directory."
  }
  New-Item -ItemType Directory -Path $backupPath -Force | Out-Null
  Move-Item -LiteralPath $localExtension -Destination (Join-Path $backupPath "Nerve")
  return $backupPath
}
function Install-NerveShortcuts {
  if ($SkipShortcuts -or $NoPause -or -not $env:APPDATA) { return }
  $shell = New-Object -ComObject WScript.Shell
  $startMenu = Join-Path $env:APPDATA "Microsoft\Windows\Start Menu\Programs\Nerve"
  New-Item -ItemType Directory -Path $startMenu -Force | Out-Null
  foreach ($shortcutInfo in @(
    @{ Name = "Start Nerve"; Target = "Start-Nerve.cmd" },
    @{ Name = "Stop Nerve"; Target = "Stop-Nerve.cmd" },
    @{ Name = "Configure Nerve AI"; Target = "Configure-Nerve-AI.cmd" },
    @{ Name = "Collect Nerve Support"; Target = "Collect-Nerve-Support.cmd" }
  )) {
    $shortcut = $shell.CreateShortcut((Join-Path $startMenu "$($shortcutInfo.Name).lnk"))
    $shortcut.TargetPath = Join-Path $runtimeRoot $shortcutInfo.Target
    $shortcut.WorkingDirectory = $runtimeRoot
    $shortcut.Save()
  }
  if ($env:USERPROFILE) {
    $desktop = Join-Path $env:USERPROFILE "Desktop"
    if (Test-Path -LiteralPath $desktop) {
      $shortcut = $shell.CreateShortcut((Join-Path $desktop "Start Nerve.lnk"))
      $shortcut.TargetPath = Join-Path $runtimeRoot "Start-Nerve.cmd"
      $shortcut.WorkingDirectory = $runtimeRoot
      $shortcut.Save()
    }
  }
}

function Install-NerveSupervisor([bool]$RestartExisting) {
  if ($SkipBackgroundControl) { return }
  if (-not $env:APPDATA) { throw "Windows application data is unavailable; Nerve background control could not be registered." }
  $supervisorScript = Join-Path $runtimeRoot "scripts\nerve-supervisor.ps1"
  $bridgeLauncher = Join-Path $runtimeRoot "scripts\start-nerve-bridge.ps1"
  $powerShell = (Get-Command powershell.exe -ErrorAction Stop).Source
  # Register only a fixed local launcher. Deliberately omit %1: URLs must never
  # become PowerShell arguments or select an operation on the GM's computer.
  $protocolRoot = "HKCU:\Software\Classes\nerve-bridge"
  New-Item -Path "$protocolRoot\shell\open\command" -Force | Out-Null
  Set-Item -LiteralPath $protocolRoot -Value "URL:Nerve Bridge"
  New-ItemProperty -LiteralPath $protocolRoot -Name "URL Protocol" -Value "" -PropertyType String -Force | Out-Null
  $launchCommand = '"{0}" -NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File "{1}" -ConfigRoot "{2}"' -f $powerShell, $bridgeLauncher, $configRoot
  Set-Item -LiteralPath "$protocolRoot\shell\open\command" -Value $launchCommand
  $startup = Join-Path $env:APPDATA "Microsoft\Windows\Start Menu\Programs\Startup"
  New-Item -ItemType Directory -Path $startup -Force | Out-Null
  $shell = New-Object -ComObject WScript.Shell
  $shortcut = $shell.CreateShortcut((Join-Path $startup "Nerve Background Control.lnk"))
  $shortcut.TargetPath = $powerShell
  $shortcut.Arguments = ('-NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File "{0}" -ConfigRoot "{1}"' -f $supervisorScript, $configRoot)
  $shortcut.WorkingDirectory = $runtimeRoot
  $shortcut.Save()
  & $bridgeLauncher -ConfigRoot $configRoot
  Pass "Nerve background control installed and started"
}

try {
  Write-Host "NERVE EASY INSTALL" -ForegroundColor Cyan
  Write-Host "This guided installer detects whether this computer is a GM Host or Player Companion and installs the safe components for that role."

  Step "1 of 5 - Checking this computer"
  $node = Get-Command node -ErrorAction SilentlyContinue
  if (-not $node) { throw "Node.js was not found. Install Node.js 22 or newer from https://nodejs.org, then double-click Install-Nerve.cmd again." }
  $script:nodePath = $node.Source
  $version = (& $script:nodePath --version).Trim()
  $major = [int]($version.TrimStart("v").Split(".")[0])
  if ($major -lt 22) { throw "Nerve needs Node.js 22 or newer. This computer has $version." }
  Pass "Node.js $version"
  if ((Test-Path -LiteralPath (Join-Path $sourceRoot "manifest.json")) -and (Test-Path -LiteralPath (Join-Path $sourceRoot "CHECKSUMS.sha256"))) {
    Run-Node @("package-verify", "--input", $sourceRoot)
    Pass "Extracted Nerve package integrity"
  } else {
    Write-Host "Developer source tree detected; packaged manifest check skipped." -ForegroundColor Yellow
  }
  Run-Node @("provider-acceptance")
  Pass "OpenAI, Claude, Gemini, and Grok adapter contracts"

  if (-not $FantasyGroundsData) {
    if (-not $env:APPDATA) { throw "Windows APPDATA is unavailable. Pass -FantasyGroundsData with the Fantasy Grounds data folder." }
    $FantasyGroundsData = Join-Path $env:APPDATA "SmiteWorks\Fantasy Grounds"
  }
  $FantasyGroundsData = [IO.Path]::GetFullPath($FantasyGroundsData)
  if (-not (Test-Path -LiteralPath $FantasyGroundsData -PathType Container)) { throw "Fantasy Grounds data was not found at $FantasyGroundsData." }
  Pass "Fantasy Grounds data found"
  $installRole = Resolve-InstallRole
  if ($installRole -eq "GMHost") {
    Pass "GM Host role selected (locally hosted campaign found)"
  } else {
    Pass "Player Companion role selected (no locally hosted campaign found)"
  }

  $extensionOwner = Get-NerveExtensionOwner $sourceRoot
  # Preserve an established Forge owner even when a generic repair build is used.
  if ((Get-NerveExtensionOwner $installRoot) -eq 'forge' -and $extensionOwner -ne 'forge') { throw 'This installation is Forge-managed. Use the Forge companion download to repair or update it.' }
  if ($installRole -eq 'GMHost') {
    $extensionState = Get-NerveExtensionInstall $FantasyGroundsData
    if ($extensionState.archives.Count -gt 0 -and $extensionOwner -ne 'forge') { throw 'A packaged Nerve extension is installed. Use the Forge companion download; no extension was changed.' }
    if ($extensionOwner -eq 'forge') {
      if ($extensionState.localPresent) { throw 'A local extensions/Nerve folder conflicts with Forge ownership. Close Fantasy Grounds and move that folder to a backup outside extensions, then rerun. No extension was changed.' }
      if ($extensionState.archives.Count -ne 1) { throw 'Install exactly one Nerve extension through Fantasy Grounds Forge, run the Fantasy Grounds updater, then rerun this companion installer. No extension was changed.' }
    }
  }
  Step "2 of 6 - Installing Nerve"
  $restartSupervisorAfterInstall = (Stop-ExistingNerveSupervisor) -gt 0
  if ($restartSupervisorAfterInstall) { Pass "Previous Nerve background control stopped for update" }
  Install-NerveApplication
  $runtimeRoot = $installRoot
  $entryPoint = Join-Path $runtimeRoot "bin\nerve.js"
  Pass "Nerve application installed for this Windows user"
  if ($installRole -eq "GMHost") {
    if ($extensionOwner -eq 'forge') {
      Pass "Forge owns Nerve Adapter updates; companion left the extension unchanged"
    } else {
      Run-Node @("install-extension", "--fgu-data", $FantasyGroundsData)
      Pass "Authoritative Nerve Adapter installed or updated"
    }
  } else {
    Pass "Local Fantasy Grounds extension intentionally skipped"
    $legacyBackup = Move-LegacyPlayerExtension
    if ($legacyBackup) { Pass "Obsolete local player extension moved to recoverable backup: $legacyBackup" }
  }

  New-Item -ItemType Directory -Path $reportFolder -Force | Out-Null
  New-Item -ItemType Directory -Path $configRoot -Force | Out-Null
  if ($installRole -eq "PlayerCompanion") {
    [ordered]@{
      schemaVersion = "0.1"; role = $installRole; fantasyGroundsData = $FantasyGroundsData
      runtimeRoot = $runtimeRoot; installedAt = (Get-Date).ToUniversalTime().ToString("o")
      companionConnection = "not-yet-available"
    } | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $configRoot "installation.json") -Encoding UTF8
    @(
      "Nerve Player Companion installation completed"
      ("Date: {0}" -f (Get-Date).ToString("F"))
      "Role: Player Companion"
      ("Fantasy Grounds data: {0}" -f $FantasyGroundsData)
      ("Node.js: {0}" -f $version)
      "Provider acceptance: 4/4 passed without network access"
      ("Nerve application: {0}" -f $runtimeRoot)
      "Fantasy Grounds extension: not installed locally; the GM supplies the table extension"
      $(if ($legacyBackup) { "Obsolete local extension backup: $legacyBackup" } else { "Obsolete local extension backup: not needed" })
      "Personal-AI connection: groundwork installed; secure GM pairing is not available in this preview"
    ) | Set-Content -LiteralPath $reportPath -Encoding UTF8
    Write-Host ""
    Write-Host "Player Companion setup is complete." -ForegroundColor Green
    Write-Host "Fantasy Grounds will receive the table extension from the GM, avoiding version conflicts."
    Write-Host "This preview installs the companion groundwork; personal-AI pairing will be enabled in a later build."
    Write-Host ("Install report: {0}" -f $reportPath)
    Wait-ForEnter "Press Enter to close"
    exit 0
  }

  Step "3 of 6 - One short Fantasy Grounds step"
  Write-Host "Open Fantasy Grounds, select the campaign you want to use, enable 'Nerve Adapter' in Extensions, and load the campaign."
  Write-Host "Wait until chat says that Nerve Adapter loaded."
  Wait-ForEnter "Press Enter after the campaign is fully loaded"

  Step "4 of 6 - Finding the loaded campaign"
  if (-not $Campaign) {
    $Campaign = Find-ReadyCampaign
    Write-Host ("Found Nerve-enabled campaign: {0}" -f $Campaign)
  }
  & $script:nodePath $entryPoint doctor --campaign $Campaign --fgu-data $FantasyGroundsData
  if ($LASTEXITCODE -ne 0) {
    throw "The selected campaign is not publishing Nerve state. Reload it with 'Nerve Adapter' enabled, then rerun Install-Nerve.cmd."
  }
  Run-Node @("controller-preflight", "--campaign", $Campaign, "--fgu-data", $FantasyGroundsData, "--provider", "fake")
  Pass "Campaign connection and no-cost preflight"

  Step "5 of 6 - Saving ready-to-use settings"
  $configPath = Join-Path $reportFolder "ai-host-config.json"
  & $script:nodePath $entryPoint config --campaign $Campaign --fgu-data $FantasyGroundsData --expose-writes --allow-writes | Set-Content -LiteralPath $configPath -Encoding UTF8
  if ($LASTEXITCODE -ne 0) { throw "Nerve could not create the AI-host configuration." }
  [ordered]@{
    schemaVersion = "0.1"; role = $installRole; campaign = $Campaign; fantasyGroundsData = $FantasyGroundsData
    runtimeRoot = $runtimeRoot; installedAt = (Get-Date).ToUniversalTime().ToString("o")
  } | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $configRoot "installation.json") -Encoding UTF8
  Install-NerveShortcuts
  @(
    "Nerve installation completed"
    ("Date: {0}" -f (Get-Date).ToString("F"))
    ("Campaign: {0}" -f $Campaign)
    "Role: GM Host"
    ("Fantasy Grounds data: {0}" -f $FantasyGroundsData)
    ("Node.js: {0}" -f $version)
    "Provider acceptance: 4/4 passed without network access"
    ("Nerve application: {0}" -f $runtimeRoot)
    ("AI-host configuration: {0}" -f $configPath)
    "Next: configure a direct AI provider or connect Nerve from an external AI host."
  ) | Set-Content -LiteralPath $reportPath -Encoding UTF8
  Pass "Installation complete"
  Write-Host ""
  Write-Host ("Your install report and AI settings are in: {0}" -f $reportFolder) -ForegroundColor Green
  Write-Host "If support is ever needed, double-click Collect-Nerve-Support.cmd; no copy-and-paste is required."

  Step "6 of 6 - Choosing an AI"
  if (-not $SkipProviderSetup -and -not $NoPause -and (Read-YesNo "Configure OpenAI, Claude, Gemini, Grok, or offline mode now?" $true)) {
    & (Join-Path $runtimeRoot "scripts\configure-provider.ps1") -Campaign $Campaign -FantasyGroundsData $FantasyGroundsData -ConfigRoot $configRoot
    if ($LASTEXITCODE -ne 0) { Write-Host "Nerve is installed; AI setup can be resumed later with Configure-Nerve-AI.cmd." -ForegroundColor Yellow }
  } else {
    Write-Host "AI setup can be opened later with Configure-Nerve-AI.cmd."
  }
  Install-NerveSupervisor $restartSupervisorAfterInstall
} catch {
  Write-Host ""
  Write-Host "Nerve could not finish installation." -ForegroundColor Red
  Write-Host $_.Exception.Message -ForegroundColor Red
  Write-Host "Fix the item above and run Install-Nerve.cmd again. It is safe to rerun."
  Wait-ForEnter "Press Enter to close"
  exit 1
}

Wait-ForEnter "Press Enter to close"
exit 0
