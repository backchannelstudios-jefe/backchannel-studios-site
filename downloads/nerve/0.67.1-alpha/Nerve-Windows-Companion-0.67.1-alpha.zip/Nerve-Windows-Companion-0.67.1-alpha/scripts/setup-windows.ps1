[CmdletBinding()]
param(
  [string]$Campaign,
  [string]$FantasyGroundsData,
  [ValidateSet("Auto", "GMHost", "PlayerCompanion")]
  [string]$Role = "Auto",
  [ValidateSet("fake", "ollama", "openai", "chatgpt", "anthropic", "claude", "gemini", "xai", "grok")]
  [string]$Provider = "fake",
  [string]$Model,
  [int]$HardTokens = 50000,
  [int]$MaxOutputTokens = 600,
  [switch]$EnableWrites,
  [switch]$SkipExtensionInstall
)

$ErrorActionPreference = "Stop"
$repositoryRoot = Split-Path -Parent $PSScriptRoot
$entryPoint = Join-Path $repositoryRoot "bin\nerve.js"
$nodeCommand = Get-Command node -ErrorAction Stop
$nodeVersion = (& $nodeCommand.Source --version).TrimStart("v")
$nodeMajor = [int]($nodeVersion.Split(".")[0])
if ($nodeMajor -lt 22) { throw "Nerve requires Node.js 22 or newer; found $nodeVersion." }

$dataPath = $FantasyGroundsData
if (-not $dataPath) {
  if (-not $env:APPDATA) { throw "Fantasy Grounds data was not supplied and APPDATA is unavailable." }
  $dataPath = Join-Path $env:APPDATA "SmiteWorks\Fantasy Grounds"
}
$dataPath = [System.IO.Path]::GetFullPath($dataPath)
if (-not (Test-Path -LiteralPath $dataPath -PathType Container)) { throw "Fantasy Grounds data directory was not found: $dataPath" }

$campaignRoot = Join-Path $dataPath "campaigns"
$hostedCampaigns = @()
if (Test-Path -LiteralPath $campaignRoot -PathType Container) {
  $hostedCampaigns = @(Get-ChildItem -LiteralPath $campaignRoot -Directory -ErrorAction SilentlyContinue | Where-Object {
    Test-Path -LiteralPath (Join-Path $_.FullName "campaign.xml") -PathType Leaf
  })
}
if ($Role -eq "Auto") {
  $Role = if ($hostedCampaigns.Count -gt 0) { "GMHost" } else { "PlayerCompanion" }
}
if ($Role -eq "GMHost" -and $hostedCampaigns.Count -eq 0) {
  throw "GM Host setup was selected, but no locally hosted Fantasy Grounds campaigns were found."
}

Write-Host "Nerve setup"
Write-Host "Node.js: $nodeVersion"
Write-Host "Fantasy Grounds data: $dataPath"
Write-Host "Install role: $Role"

if ($Role -eq "GMHost" -and -not $SkipExtensionInstall) {
  & $nodeCommand.Source $entryPoint install-extension --fgu-data $dataPath
  if ($LASTEXITCODE -ne 0) { throw "Nerve extension installation failed." }
}

if ($Role -eq "PlayerCompanion") {
  Write-Host "Player Companion setup intentionally skipped the local Fantasy Grounds extension."
  Write-Host "The GM supplies the authoritative table extension. Secure personal-AI pairing is not available in this preview."
  & $nodeCommand.Source $entryPoint providers
  if ($LASTEXITCODE -ne 0) { throw "Provider discovery failed." }
  Write-Host "Setup checks completed. No AI provider request was made."
  exit 0
}

& $nodeCommand.Source $entryPoint campaigns --fgu-data $dataPath
if ($LASTEXITCODE -ne 0) { throw "Campaign discovery failed." }
& $nodeCommand.Source $entryPoint providers
if ($LASTEXITCODE -ne 0) { throw "Provider discovery failed." }

if ($Campaign) {
  & $nodeCommand.Source $entryPoint doctor --campaign $Campaign --fgu-data $dataPath
  if ($LASTEXITCODE -ne 0) { throw "Campaign doctor did not pass. Enable Nerve in Fantasy Grounds, load the campaign, and rerun setup." }

  $preflightArguments = @(
    $entryPoint, "controller-preflight", "--campaign", $Campaign, "--fgu-data", $dataPath,
    "--provider", $Provider, "--hard-tokens", "$HardTokens", "--max-output-tokens", "$MaxOutputTokens"
  )
  if ($Provider -ne "fake") {
    if (-not $Model) { throw "A model ID is required for provider $Provider." }
    $preflightArguments += @("--model", $Model)
  }
  if ($EnableWrites) { $preflightArguments += @("--expose-writes", "--allow-writes") }
  & $nodeCommand.Source @preflightArguments
  if ($LASTEXITCODE -ne 0) { throw "Controller preflight did not pass. No provider network call was made." }
}

Write-Host "Setup checks completed. No AI provider request was made."
Write-Host "Reload Fantasy Grounds only if the extension was installed or updated."
