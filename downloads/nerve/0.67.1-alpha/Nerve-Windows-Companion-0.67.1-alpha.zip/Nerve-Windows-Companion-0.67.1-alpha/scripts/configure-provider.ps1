[CmdletBinding()]
param(
  [string]$Campaign,
  [string]$FantasyGroundsData,
  [string]$ConfigRoot,
  [ValidateSet("connector", "manual", "companion", "fake", "ollama", "openai", "anthropic", "gemini", "xai")][string]$Provider,
  [ValidateSet("codex", "antigravity", "claude", "grok", "custom")][string]$AppConnector = "codex",
  [string]$Model,
  [ValidateSet("ask", "allow", "deny")][string]$GuardedActions = "ask",
  [ValidateSet("ask", "run", "skip")][string]$ConnectionCheck = "ask",
  [switch]$NoLiveCheck,
  [switch]$VerifiedConnection,
  [switch]$NoPause
)

$ErrorActionPreference = "Stop"
$runtimeRoot = Split-Path -Parent $PSScriptRoot
$entryPoint = Join-Path $runtimeRoot "bin\nerve.js"
$configRoot = if ($ConfigRoot) { [IO.Path]::GetFullPath($ConfigRoot) } elseif ($env:LOCALAPPDATA) { Join-Path $env:LOCALAPPDATA "Nerve\Config" } else { Join-Path $env:USERPROFILE "Documents\Nerve\Config" }
$profilePath = Join-Path $configRoot "provider.json"
$installPath = Join-Path $configRoot "installation.json"
$secretsRoot = Join-Path $configRoot "Secrets"
$setupLogPath = Join-Path $configRoot "provider-setup-last.log"

function Wait-ForEnter([string]$Text) { if (-not $NoPause) { Read-Host $Text | Out-Null } }
function Write-SetupLog([string]$Text) {
  try {
    $line = "{0} {1}{2}" -f (Get-Date).ToUniversalTime().ToString("o"), $Text, [Environment]::NewLine
    $utf8NoBom = New-Object System.Text.UTF8Encoding($false)
    [IO.File]::AppendAllText($setupLogPath, $line, $utf8NoBom)
  } catch { }
}
function Run-Node([string[]]$Arguments) {
  Write-SetupLog ("Running: nerve {0}" -f ($Arguments -join ' '))
  $commandOutput = @(& $script:nodePath $entryPoint @Arguments 2>&1)
  $exitCode = $LASTEXITCODE
  foreach ($line in $commandOutput) {
    $text = "$line"
    Write-Host $text
    Write-SetupLog $text
  }
  if ($exitCode -ne 0) { throw "Nerve command failed: $($Arguments -join ' ')" }
}
function Read-YesNo([string]$Prompt, [bool]$Default) {
  if ($NoPause) { return $Default }
  $suffix = if ($Default) { "[Y/n]" } else { "[y/N]" }
  $answer = (Read-Host "$Prompt $suffix").Trim().ToLowerInvariant()
  if (-not $answer) { return $Default }
  return $answer -in @("y", "yes")
}
function Protect-NerveCredential([Security.SecureString]$SecureValue) {
  Add-Type -AssemblyName System.Security -ErrorAction Stop
  $pointer = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($SecureValue)
  $plainBytes = $null
  $protectedBytes = $null
  try {
    $plain = [Runtime.InteropServices.Marshal]::PtrToStringBSTR($pointer)
    $plainBytes = [Text.Encoding]::UTF8.GetBytes($plain)
    $entropy = [Text.Encoding]::UTF8.GetBytes("Nerve.ProviderCredential.v1")
    $protectedBytes = [System.Security.Cryptography.ProtectedData]::Protect(
      $plainBytes, $entropy, [System.Security.Cryptography.DataProtectionScope]::CurrentUser
    )
    return "dpapi-v1:" + [Convert]::ToBase64String($protectedBytes)
  } finally {
    if ($pointer -ne [IntPtr]::Zero) { [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($pointer) }
    if ($plainBytes) { [Array]::Clear($plainBytes, 0, $plainBytes.Length) }
    if ($protectedBytes) { [Array]::Clear($protectedBytes, 0, $protectedBytes.Length) }
    $plain = $null
  }
}
function Read-NerveCredential([string]$EncryptedValue) {
  if ($EncryptedValue.StartsWith("dpapi-v1:")) {
    Add-Type -AssemblyName System.Security -ErrorAction Stop
    $cipherBytes = [Convert]::FromBase64String($EncryptedValue.Substring(9))
    $plainBytes = $null
    try {
      $entropy = [Text.Encoding]::UTF8.GetBytes("Nerve.ProviderCredential.v1")
      $plainBytes = [System.Security.Cryptography.ProtectedData]::Unprotect(
        $cipherBytes, $entropy, [System.Security.Cryptography.DataProtectionScope]::CurrentUser
      )
      return [Text.Encoding]::UTF8.GetString($plainBytes)
    } finally {
      if ($cipherBytes) { [Array]::Clear($cipherBytes, 0, $cipherBytes.Length) }
      if ($plainBytes) { [Array]::Clear($plainBytes, 0, $plainBytes.Length) }
    }
  }
  $securityManifest = Join-Path $PSHOME "Modules\Microsoft.PowerShell.Security\Microsoft.PowerShell.Security.psd1"
  Import-Module -Name $securityManifest -Force -ErrorAction Stop
  $secure = Microsoft.PowerShell.Security\ConvertTo-SecureString -String $EncryptedValue
  $pointer = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($secure)
  try { return [Runtime.InteropServices.Marshal]::PtrToStringBSTR($pointer) }
  finally { if ($pointer -ne [IntPtr]::Zero) { [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($pointer) } }
}
function Use-EncryptedCredential([string]$EnvironmentName, [string]$CredentialPath, [scriptblock]$Action) {
  $encrypted = (Get-Content -Raw -LiteralPath $CredentialPath).Trim()
  if ($encrypted.Length -gt 0 -and $encrypted[0] -eq [char]0xFEFF) { $encrypted = $encrypted.Substring(1).Trim() }
  try { $plain = Read-NerveCredential $encrypted }
  catch { throw "The encrypted API key could not be read. Run Configure-Nerve-AI.cmd and save the key again." }
  try {
    [Environment]::SetEnvironmentVariable($EnvironmentName, $plain, "Process")
    & $Action
  } finally {
    [Environment]::SetEnvironmentVariable($EnvironmentName, $null, "Process")
    $plain = $null
  }
}

try {
  New-Item -ItemType Directory -Path $configRoot -Force | Out-Null
  [IO.File]::WriteAllText($setupLogPath, "", (New-Object System.Text.UTF8Encoding($false)))
  Write-SetupLog "Nerve AI setup started. Secret values are not written to this log."
  Write-Host "NERVE AI SETUP" -ForegroundColor Cyan
  Write-Host "Choose the AI Nerve will use. Consumer chat subscriptions and API billing are separate; direct provider mode requires that provider's API key."
  $node = Get-Command node -ErrorAction SilentlyContinue
  if (-not $node) { throw "Node.js was not found. Run Install-Nerve.cmd first." }
  $script:nodePath = $node.Source

  if (Test-Path -LiteralPath $installPath) {
    $installation = Get-Content -Raw -LiteralPath $installPath | ConvertFrom-Json
    if (-not $Campaign) { $Campaign = $installation.campaign }
    if (-not $FantasyGroundsData) { $FantasyGroundsData = $installation.fantasyGroundsData }
  }
  if (-not $Campaign -or -not $FantasyGroundsData) { throw "Installation details were not found. Run Install-Nerve.cmd first." }

  $catalogJson = & $script:nodePath $entryPoint providers --json
  if ($LASTEXITCODE -ne 0) { throw "Nerve could not load its provider catalog." }
  $parsedCatalog = ($catalogJson -join [Environment]::NewLine) | ConvertFrom-Json
  $catalog = @()
  foreach ($catalogItem in $parsedCatalog) { $catalog += $catalogItem }
  if (-not $Provider) {
    Write-Host ""
    Write-Host "0. Automatic AI connector (recommended; no API key stored in Nerve)"
    Write-Host "1. Manual AI handoff (copy/paste compatibility fallback)"
    Write-Host "2. Offline test (no key and no AI charges)"
    Write-Host "3. Ollama local AI (no key and no provider charges)"
    Write-Host "4. OpenAI / ChatGPT API"
    Write-Host "5. Anthropic / Claude API"
    Write-Host "6. Google Gemini API"
    Write-Host "7. xAI / Grok API"
    $selection = (Read-Host "Enter 0, 1, 2, 3, 4, 5, 6, or 7").Trim()
    $Provider = switch ($selection) { "0" { "connector" } "1" { "manual" } "2" { "fake" } "3" { "ollama" } "4" { "openai" } "5" { "anthropic" } "6" { "gemini" } "7" { "xai" } default { throw "That provider selection was not recognized." } }
  }
  $providerInfo = $null
  foreach ($item in $catalog) { if ($item.id -eq $Provider) { $providerInfo = $item; break } }
  if ($Provider -in @("connector", "manual", "companion")) {
    $providerInfo = [pscustomobject]@{ displayName = $(if ($Provider -eq "connector") { "Automatic AI Connector" } else { "Manual AI Handoff" }); apiKeyEnvironment = $null; apiKeyUrl = $null; recommendedModel = $null }
  }
  if (-not $providerInfo) { throw "Provider '$Provider' is not available in this Nerve build." }

  if ($Provider -notin @("connector", "manual", "fake", "companion")) {
    if (-not $Model) {
      $suggested = $providerInfo.recommendedModel
      if ($NoPause) { $Model = $suggested } else {
        $enteredModel = (Read-Host "Model ID [$suggested]").Trim()
        $Model = if ($enteredModel) { $enteredModel } else { $suggested }
      }
    }
    if ($Model -notmatch '^[A-Za-z0-9._:-]{2,128}$') { throw "The model ID contains unsupported characters." }
  } else { $Model = $null }
  $maxOutputTokens = if ($Provider -eq "gemini") { 2400 } else { 800 }

  New-Item -ItemType Directory -Path $secretsRoot -Force | Out-Null
  $credentialPath = Join-Path $secretsRoot "$Provider.credential"
  if ($Provider -notin @("connector", "manual", "fake", "companion", "ollama")) {
    Write-Host "API key page: $($providerInfo.apiKeyUrl)"
    $replace = -not (Test-Path -LiteralPath $credentialPath)
    if (-not $replace) { $replace = Read-YesNo "Replace the encrypted API key already saved for this provider?" $false }
    if ($replace) {
      if ($NoPause) { throw "A saved credential is required for non-interactive provider setup." }
      $secureKey = Read-Host "Paste the API key (the text will be hidden)" -AsSecureString
      if ($secureKey.Length -lt 8) { throw "The API key was empty or too short." }
      $encryptedKey = Protect-NerveCredential $secureKey
      $utf8NoBom = New-Object System.Text.UTF8Encoding($false)
      [IO.File]::WriteAllText($credentialPath, $encryptedKey, $utf8NoBom)
      Write-Host "API key encrypted for this Windows user." -ForegroundColor Green
    }
  }

  $allowWrites = if ($GuardedActions -eq "allow") { $true } elseif ($GuardedActions -eq "deny") { $false } else { Read-YesNo "Allow Nerve to submit guarded actions and narration to Fantasy Grounds?" $true }
  $profile = [ordered]@{
    schemaVersion = "0.1"; campaign = $Campaign; fantasyGroundsData = [IO.Path]::GetFullPath($FantasyGroundsData)
    connectionMode = if ($Provider -eq "connector") { "connector" } elseif ($Provider -in @("manual", "companion")) { "manual" } elseif ($Provider -in @("fake", "ollama")) { "local" } else { "api" }
    provider = $(if ($Provider -eq "companion") { "manual" } else { $Provider }); appConnector = if ($Provider -eq "connector") { $AppConnector } else { $null }; model = if ($Model) { $Model } else { $null }; credentialFile = if ($Provider -in @("connector", "manual", "fake", "companion", "ollama")) { $null } else { $credentialPath }
    apiKeyEnvironment = $providerInfo.apiKeyEnvironment; allowWrites = $allowWrites
    maxOutputTokens = $maxOutputTokens; warningTokens = 100000; hardTokens = 150000; timeoutSeconds = 30; eventLimit = 25
    configuredAt = (Get-Date).ToUniversalTime().ToString("o")
    connectionVerified = [bool]($Provider -eq "connector" -and $VerifiedConnection)
  }
  New-Item -ItemType Directory -Path $configRoot -Force | Out-Null
  $profile | ConvertTo-Json | Set-Content -LiteralPath "$profilePath.tmp" -Encoding UTF8
  Move-Item -Force -LiteralPath "$profilePath.tmp" -Destination $profilePath

  if ($Provider -eq "connector") {
    Write-Host "Automatic connector saved for $AppConnector. Start it from Nerve Control; the signed-in AI app can then claim cues without copy/paste."
  } elseif ($Provider -in @("manual", "companion")) {
    Write-Host "Manual compatibility fallback saved. This mode uses the copy/paste handoff window."
  } else {
    $preflightArgs = @("controller-preflight", "--campaign", $Campaign, "--fgu-data", $FantasyGroundsData, "--provider", $Provider, "--hard-tokens", "150000", "--max-output-tokens", $maxOutputTokens)
    if ($Model) { $preflightArgs += @("--model", $Model) }
    if ($allowWrites) { $preflightArgs += @("--expose-writes", "--allow-writes") }
    if ($Provider -in @("fake", "ollama")) { Run-Node $preflightArgs } else { Use-EncryptedCredential $providerInfo.apiKeyEnvironment $credentialPath { Run-Node $preflightArgs } }
  }

  $runConnectionCheck = if ($NoLiveCheck -or $ConnectionCheck -eq "skip") { $false } elseif ($ConnectionCheck -eq "run") { $true } else { Read-YesNo "Make one small billed API request now to verify the key and model?" $false }
  if ($Provider -notin @("connector", "manual", "fake", "companion") -and $runConnectionCheck) {
    if ($Provider -eq "ollama") {
      Run-Node @("provider-check", "--provider", $Provider, "--model", $Model, "--max-output-tokens", $maxOutputTokens)
    } else {
      Use-EncryptedCredential $providerInfo.apiKeyEnvironment $credentialPath {
        Run-Node @("provider-check", "--provider", $Provider, "--model", $Model, "--max-output-tokens", $maxOutputTokens)
      }
    }
  }

  Write-Host ""
  Write-Host "Nerve AI setup complete." -ForegroundColor Green
  Write-Host "Provider: $($providerInfo.displayName)$(if ($Model) { " / $Model" })"
  Write-Host $(if ($Provider -in @("manual", "companion")) { "Fantasy Grounds is ready for the manual AI handoff fallback." } else { "The Fantasy Grounds Nerve Control window can now start and stop Nerve." })
  if (-not $NoPause) {
    $supervisor = Join-Path $runtimeRoot "scripts\nerve-supervisor.ps1"
    Start-Process -FilePath "powershell.exe" -ArgumentList @("-NoProfile", "-WindowStyle", "Hidden", "-ExecutionPolicy", "Bypass", "-File", $supervisor, "-ConfigRoot", $configRoot) -WindowStyle Hidden
  }
} catch {
  Write-SetupLog ("FAILED: {0}" -f $_.Exception.Message)
  Write-Host ""
  Write-Host "Nerve AI setup could not finish." -ForegroundColor Red
  Write-Host $_.Exception.Message -ForegroundColor Red
  Write-Host "Setup details were saved to: $setupLogPath" -ForegroundColor Yellow
  Wait-ForEnter "Press Enter to close"
  exit 1
}

Wait-ForEnter "Press Enter to close"
exit 0
