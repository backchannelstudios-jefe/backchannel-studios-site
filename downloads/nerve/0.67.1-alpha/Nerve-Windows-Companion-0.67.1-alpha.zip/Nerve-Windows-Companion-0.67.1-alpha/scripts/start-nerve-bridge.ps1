[CmdletBinding()]
param([string]$ConfigRoot)

$ErrorActionPreference = "Stop"
$bridgeScript = Join-Path $PSScriptRoot "nerve-supervisor.ps1"
$bridgeConfig = if ($ConfigRoot) { [IO.Path]::GetFullPath($ConfigRoot) } else { Join-Path $env:LOCALAPPDATA "Nerve\Config" }
# The URL handler supplies no URL arguments. It can only start this installed
# bridge; it cannot select a command, campaign, provider, or authentication action.
if (-not (Test-Path -LiteralPath $bridgeScript -PathType Leaf)) { throw "Nerve bridge is missing. Run Install-Nerve to repair the installation." }
if (-not (Test-Path -LiteralPath (Join-Path $bridgeConfig "installation.json") -PathType Leaf)) { throw "Nerve has not been installed for this Windows user. Run Install-Nerve once." }
$bridgeArguments = '-NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File "{0}" -ConfigRoot "{1}"' -f $bridgeScript, $bridgeConfig
Start-Process -FilePath (Join-Path $PSHOME "powershell.exe") -ArgumentList $bridgeArguments -WindowStyle Hidden | Out-Null
