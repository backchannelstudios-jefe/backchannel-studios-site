[CmdletBinding()]
param([string]$ConfigRoot, [string]$Campaign, [string]$FantasyGroundsData, [switch]$NoPause)
$ErrorActionPreference = "Stop"
$runtimeRoot = Split-Path -Parent $PSScriptRoot
$entryPoint = Join-Path $runtimeRoot "bin\nerve.js"
$configRoot = if ($ConfigRoot) { [IO.Path]::GetFullPath($ConfigRoot) } elseif ($env:LOCALAPPDATA) { Join-Path $env:LOCALAPPDATA "Nerve\Config" } else { Join-Path $env:USERPROFILE "Documents\Nerve\Config" }
$profilePath = Join-Path $configRoot "provider.json"
function Wait-ForEnter([string]$Text) { if (-not $NoPause) { Read-Host $Text | Out-Null } }
function Resolve-ActiveCampaign([string]$FguData, [string]$CampaignHint) {
  $campaignsRoot = Join-Path $FguData "campaigns"
  if (-not (Test-Path -LiteralPath $campaignsRoot -PathType Container)) { return $CampaignHint }
  $running = foreach ($directory in Get-ChildItem -LiteralPath $campaignsRoot -Directory -ErrorAction SilentlyContinue) {
    $statusPath = Join-Path $directory.FullName "nerve-host-status.json"
    if (-not (Test-Path -LiteralPath $statusPath -PathType Leaf)) { continue }
    try { $status = Get-Content -Raw -LiteralPath $statusPath | ConvertFrom-Json } catch { continue }
    if ($status.status -eq "running") {
      [pscustomobject]@{ name = $directory.Name; updated = (Get-Item -LiteralPath $statusPath).LastWriteTimeUtc }
    }
  }
  $selected = $running | Sort-Object updated -Descending | Select-Object -First 1
  if ($selected) { return [string]$selected.name }
  return $CampaignHint
}
function Read-NerveCredential([string]$EncryptedValue) {
  if ($EncryptedValue.StartsWith("dpapi-v1:")) {
    Add-Type -AssemblyName System.Security -ErrorAction Stop
    $cipherBytes = [Convert]::FromBase64String($EncryptedValue.Substring(9))
    $plainBytes = $null
    try {
      $entropy = [Text.Encoding]::UTF8.GetBytes("Nerve.ProviderCredential.v1")
      $plainBytes = [System.Security.Cryptography.ProtectedData]::Unprotect(
        $cipherBytes, $entropy, [System.Security.Cryptography.DataProtectionScope]::CurrentUser
      )
      return [Text.Encoding]::UTF8.GetString($plainBytes)
    } finally {
      if ($cipherBytes) { [Array]::Clear($cipherBytes, 0, $cipherBytes.Length) }
      if ($plainBytes) { [Array]::Clear($plainBytes, 0, $plainBytes.Length) }
    }
  }
  $securityManifest = Join-Path $PSHOME "Modules\Microsoft.PowerShell.Security\Microsoft.PowerShell.Security.psd1"
  Import-Module -Name $securityManifest -Force -ErrorAction Stop
  $secure = Microsoft.PowerShell.Security\ConvertTo-SecureString -String $EncryptedValue
  $pointer = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($secure)
  try { return [Runtime.InteropServices.Marshal]::PtrToStringBSTR($pointer) }
  finally { if ($pointer -ne [IntPtr]::Zero) { [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($pointer) } }
}
try {
  if (-not (Test-Path -LiteralPath $profilePath)) { throw "No AI provider is configured. Double-click Configure-Nerve-AI.cmd first." }
  $profile = Get-Content -Raw -LiteralPath $profilePath | ConvertFrom-Json
  if ($Campaign) { $profile | Add-Member -NotePropertyName campaign -NotePropertyValue $Campaign -Force }
  if ($FantasyGroundsData) { $profile | Add-Member -NotePropertyName fantasyGroundsData -NotePropertyValue ([IO.Path]::GetFullPath($FantasyGroundsData)) -Force }
  if (-not $Campaign) {
    $activeCampaign = Resolve-ActiveCampaign ([string]$profile.fantasyGroundsData) ([string]$profile.campaign)
    $profile | Add-Member -NotePropertyName campaign -NotePropertyValue $activeCampaign -Force
  }
  if ($profile.connectionMode -in @("manual", "companion") -or $profile.provider -in @("manual", "companion")) { throw "Manual AI handoff mode does not start a background controller. Use the handoff button in Fantasy Grounds." }
  $node = Get-Command node -ErrorAction SilentlyContinue
  if (-not $node) { throw "Node.js was not found. Run Install-Nerve.cmd again." }
  $effectiveMaxOutputTokens = [int]$profile.maxOutputTokens
  if ($profile.provider -eq "gemini" -and $effectiveMaxOutputTokens -lt 2400) {
    $effectiveMaxOutputTokens = 2400
  }
  $args = if ($profile.connectionMode -eq "connector" -or $profile.provider -eq "connector") {
    $appConnector = if ($profile.appConnector) { [string]$profile.appConnector } else { "codex" }
    $connectorArgs = @("connector-serve", "--campaign", $profile.campaign, "--fgu-data", $profile.fantasyGroundsData, "--token-file", (Join-Path $configRoot "Secrets\connector.token"), "--app-listener", $appConnector)
    if ($appConnector -eq "custom") { $connectorArgs += @("--app-listener-config", (Join-Path $configRoot "custom-ai-app.json")) }
    $connectorArgs
  } else {
    @("controller-start", "--campaign", $profile.campaign, "--fgu-data", $profile.fantasyGroundsData, "--provider", $profile.provider, "--max-output-tokens", "$effectiveMaxOutputTokens", "--timeout-seconds", "$($profile.timeoutSeconds)", "--event-limit", "$($profile.eventLimit)", "--warning-tokens", "$($profile.warningTokens)", "--hard-tokens", "$($profile.hardTokens)")
  }
  if ($profile.model) { $args += @("--model", $profile.model) }
  if ($profile.allowWrites) { $args += @("--expose-writes", "--allow-writes") }
  try {
    if ($profile.provider -notin @("fake", "connector", "ollama")) {
      if (-not (Test-Path -LiteralPath $profile.credentialFile)) { throw "The encrypted provider credential is missing. Run Configure-Nerve-AI.cmd again." }
      $encrypted = (Get-Content -Raw -LiteralPath $profile.credentialFile).Trim()
      if ($encrypted.Length -gt 0 -and $encrypted[0] -eq [char]0xFEFF) { $encrypted = $encrypted.Substring(1).Trim() }
      try { $plain = Read-NerveCredential $encrypted }
      catch { throw "The encrypted provider credential could not be read. Run Configure-Nerve-AI.cmd again." }
      [Environment]::SetEnvironmentVariable($profile.apiKeyEnvironment, $plain, "Process")
    }
    & $node.Source $entryPoint @args
    if ($LASTEXITCODE -ne 0) { throw "The Nerve controller did not start." }
  } finally {
    if ($profile.apiKeyEnvironment) { [Environment]::SetEnvironmentVariable($profile.apiKeyEnvironment, $null, "Process") }
    $plain = $null
  }
  Write-Host "Nerve is running for campaign $($profile.campaign)." -ForegroundColor Green
  Write-Host "Use Stop-Nerve.cmd to stop the controller cleanly."
} catch {
  Write-Host "Nerve could not start." -ForegroundColor Red
  Write-Host $_.Exception.Message -ForegroundColor Red
  Wait-ForEnter "Press Enter to close"
  exit 1
}
Wait-ForEnter "Press Enter to close"
exit 0
