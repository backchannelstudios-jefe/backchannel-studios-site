import { readFile, rename, unlink, writeFile } from "node:fs/promises";
import { basename, dirname, join } from "node:path";
import { NerveError } from "../../../core/errors.js";

export class FileFantasyGroundsBridge {
  #commandQueue = Promise.resolve();

  constructor({ snapshotPath, commandTimeoutMs = 60000, eventPollIntervalMs = 250, notifier = null }) {
    this.snapshotPath = snapshotPath;
    const campaignDirectory = dirname(snapshotPath);
    this.libraryPath = join(campaignDirectory, "nerve-library.json");
    this.commandPath = join(campaignDirectory, "nerve-command.json");
    this.commandResultPath = join(campaignDirectory, "nerve-command-result.json");
    this.commandTimeoutMs = commandTimeoutMs;
    this.eventPollIntervalMs = eventPollIntervalMs;
    this.campaign = basename(campaignDirectory);
    this.notifier = notifier;
  }

  async getCampaignSummary(_context) {
    const snapshot = await this.#readSnapshot();
    return snapshot.campaignSummary;
  }

  async getCombatTracker(_context) {
    const snapshot = await this.#readSnapshot();
    if (!new Set(["0.2", "0.3", "0.4", "0.5", "0.6", "0.7", "0.8", "0.9", "1.0", "1.1", "1.2", "1.3", "1.4"]).has(snapshot.schemaVersion) || !isPlainObject(snapshot.combatTracker)) {
      throw new NerveError(
        "FGU_CAPABILITY_UNAVAILABLE",
        "The loaded Fantasy Grounds extension does not publish combat tracker state.",
        { snapshotPath: this.snapshotPath, requiredSchemaVersion: "0.2" }
      );
    }
    return normalizeCombatTracker(snapshot.combatTracker);
  }

  async getParty(_context) {
    const snapshot = await this.#readSnapshot();
    if (!new Set(["0.3", "0.4", "0.5", "0.6", "0.7", "0.8", "0.9", "1.0", "1.1", "1.2", "1.3", "1.4"]).has(snapshot.schemaVersion) || !isPlainObject(snapshot.party)) {
      throw new NerveError(
        "FGU_CAPABILITY_UNAVAILABLE",
        "The loaded Fantasy Grounds extension does not publish party state.",
        { snapshotPath: this.snapshotPath, requiredSchemaVersion: "0.3" }
      );
    }
    return normalizeParty(snapshot.party);
  }

  async getCharacter(id, _context) {
    const snapshot = await this.#readSnapshot();
    if (!new Set(["0.4", "0.5", "0.6", "0.7", "0.8", "0.9", "1.0", "1.1", "1.2", "1.3", "1.4"]).has(snapshot.schemaVersion)) {
      throw capabilityUnavailable(this.snapshotPath, "character state", "0.4");
    }
    const characters = normalizeLuaArray(snapshot.characters);
    if (!Array.isArray(characters)) throw capabilityUnavailable(this.snapshotPath, "character state", "0.4");
    const character = characters.find((item) => item?.id === id);
    if (!character) {
      throw new NerveError("CHARACTER_NOT_FOUND", `Fantasy Grounds character not found: ${id}`, { id });
    }
    return normalizeCharacter(character);
  }

  async getCurrentEncounter(_context) {
    const tracker = await this.getCombatTracker(_context);
    return createCurrentEncounter(tracker);
  }

  async getRecentEvents({ afterSequence = 0, limit = 50, types } = {}, _context) {
    const snapshot = await this.#readSnapshot();
    if (!new Set(["0.4", "0.5", "0.6", "0.7", "0.8", "0.9", "1.0", "1.1", "1.2", "1.3", "1.4"]).has(snapshot.schemaVersion) || !isPlainObject(snapshot.recentEvents)) {
      throw capabilityUnavailable(this.snapshotPath, "recent event state", "0.4");
    }
    const state = structuredClone(snapshot.recentEvents);
    const typeSet = types ? new Set(types) : null;
    const events = normalizeLuaArray(state.events)
      .filter((event) => event.sequence > afterSequence)
      .filter((event) => !typeSet || typeSet.has(event.type))
      .slice(-limit);
    return { events, streamId: state.streamId, latestSequence: state.latestSequence, observedAt: state.observedAt };
  }

  async waitForEvents({ cursor, eventLimit = 25, timeoutMs = 30000, replayExisting = false } = {}, context) {
    const startedAt = Date.now();
    const initial = await this.getRecentEvents({ afterSequence: 0, limit: eventLimit }, context);
    const cursorReset = Boolean(cursor && cursor.streamId !== initial.streamId);

    if (replayExisting || cursorReset) {
      return createEventWaitResult(initial, cursorReset, false, Date.now() - startedAt);
    }

    const baselineSequence = cursor?.sequence ?? initial.latestSequence;
    const deadline = startedAt + timeoutMs;
    while (Date.now() < deadline) {
      let current;
      try {
        current = await this.getRecentEvents({ afterSequence: baselineSequence, limit: eventLimit }, context);
      } catch (error) {
        if (!isTransientSnapshotError(error)) throw error;
        await delay(Math.min(this.eventPollIntervalMs, Math.max(1, deadline - Date.now())));
        continue;
      }
      if (current.streamId !== initial.streamId) {
        const reset = await this.getRecentEvents({ afterSequence: 0, limit: eventLimit }, context);
        return createEventWaitResult(reset, true, false, Date.now() - startedAt);
      }
      if (current.events.length > 0) {
        return createEventWaitResult(current, false, false, Date.now() - startedAt);
      }
      await delay(Math.min(this.eventPollIntervalMs, Math.max(1, deadline - Date.now())));
    }

    let current;
    try {
      current = await this.getRecentEvents({ afterSequence: baselineSequence, limit: eventLimit }, context);
    } catch (error) {
      if (!isTransientSnapshotError(error)) throw error;
      current = { ...initial, events: [] };
    }
    return createEventWaitResult(current, false, current.events.length === 0, Date.now() - startedAt);
  }

  async getDmBriefing({ cursor, eventLimit = 25 } = {}, _context) {
    const snapshot = await this.#readSnapshot();
    if (!new Set(["0.4", "0.5", "0.6", "0.7", "0.8", "0.9", "1.0", "1.1", "1.2", "1.3", "1.4"]).has(snapshot.schemaVersion) || !isPlainObject(snapshot.recentEvents)) {
      throw capabilityUnavailable(this.snapshotPath, "DM briefing state", "0.4");
    }

    const combatTracker = normalizeCombatTracker(snapshot.combatTracker);
    const party = normalizeParty(snapshot.party);
    const state = structuredClone(snapshot.recentEvents);
    const cursorReset = Boolean(cursor && cursor.streamId !== state.streamId);
    const afterSequence = cursorReset ? 0 : (cursor?.sequence ?? 0);
    const events = normalizeLuaArray(state.events)
      .filter((event) => event.sequence > afterSequence)
      .slice(-eventLimit);
    const actionContext = createActionContext(snapshot.characters, combatTracker, events);

    return {
      campaignSummary: snapshot.campaignSummary,
      currentEncounter: createCurrentEncounter(combatTracker),
      combatTracker,
      party,
      mapScene: normalizeMapScene(snapshot.mapScene),
      campaignFocus: normalizeCampaignFocus(snapshot.campaignFocus),
      actionContext,
      questLog: normalizeQuestLog(snapshot.questLog),
      storyCues: normalizeStoryCues(snapshot.storyCues),
      sessionContinuity: normalizeSessionContinuity(snapshot.sessionContinuity),
      sessionOperations: normalizeSessionOperations(snapshot.sessionOperations, snapshot),
      recentEvents: {
        events,
        streamId: state.streamId,
        latestSequence: state.latestSequence,
        observedAt: state.observedAt
      },
      cursorReset,
      nextCursor: { streamId: state.streamId, sequence: state.latestSequence }
    };
  }

  async searchLibrary({ query = "", recordTypes, module = "", limit = 25 } = {}, _context) {
    const snapshot = await this.#readSnapshot();
    const library = await this.#readLibrary(snapshot);
    const queryText = query.toLocaleLowerCase();
    const moduleText = module.toLocaleLowerCase();
    const typeSet = recordTypes ? new Set(recordTypes) : null;
    const matched = library.records.filter((record) =>
      (!queryText || `${record.name} ${record.module} ${record.category}`.toLocaleLowerCase().includes(queryText)) &&
      (!moduleText || record.module.toLocaleLowerCase().includes(moduleText)) &&
      (!typeSet || typeSet.has(record.recordType))
    );
    return {
      records: matched.slice(0, limit).map(({ fields: _fields, ...record }) => record),
      matched: matched.length,
      indexed: library.records.length,
      truncated: library.truncated,
      observedAt: library.observedAt
    };
  }

  async getLibraryRecord(id, _context) {
    const snapshot = await this.#readSnapshot();
    const library = await this.#readLibrary(snapshot);
    const record = library.records.find((item) => item.id === id);
    if (!record) throw new NerveError("LIBRARY_RECORD_NOT_FOUND", `Fantasy Grounds library record not found: ${id}`, { id });
    return { ...structuredClone(record), observedAt: library.observedAt };
  }

  async getManualAdjudications(_context) {
    const snapshot = await this.#readSnapshot();
    if (!new Set(["0.6", "0.7", "0.8", "0.9", "1.0", "1.1", "1.2", "1.3", "1.4"]).has(snapshot.schemaVersion) || !isPlainObject(snapshot.manualAdjudications)) {
      throw capabilityUnavailable(this.snapshotPath, "manual adjudication state", "0.6");
    }
    const state = structuredClone(snapshot.manualAdjudications);
    state.tasks = normalizeLuaArray(state.tasks);
    return state;
  }

  async getSessionStatus(_context) {
    const snapshot = await this.#readSnapshot();
    if (!new Set(["0.7", "0.8", "0.9", "1.0", "1.1", "1.2", "1.3", "1.4"]).has(snapshot.schemaVersion) || !isPlainObject(snapshot.sessionOperations)) {
      throw capabilityUnavailable(this.snapshotPath, "live session operations", "0.7");
    }
    return normalizeSessionOperations(snapshot.sessionOperations, snapshot);
  }

  async getSessionContinuity(_context) {
    const snapshot = await this.#readSnapshot();
    return normalizeSessionContinuity(snapshot.sessionContinuity);
  }

  async getOpenMaps(_context) {
    const snapshot = await this.#readSnapshot();
    if (!new Set(["0.8", "0.9", "1.0", "1.1", "1.2", "1.3", "1.4"]).has(snapshot.schemaVersion) || !isPlainObject(snapshot.openMaps)) {
      throw capabilityUnavailable(this.snapshotPath, "open map state", "0.8");
    }
    const state = structuredClone(snapshot.openMaps);
    state.maps = normalizeLuaArray(state.maps).map((map) => ({ ...map, holders: normalizeLuaArray(map.holders) }));
    state.currentMapId ??= null;
    return state;
  }

  async getMapScene(_context) {
    const snapshot = await this.#readSnapshot();
    if (!new Set(["0.9", "1.0", "1.1", "1.2", "1.3", "1.4"]).has(snapshot.schemaVersion) || !isPlainObject(snapshot.mapScene)) {
      throw capabilityUnavailable(this.snapshotPath, "current map scene", "0.9");
    }
    return normalizeMapScene(snapshot.mapScene);
  }

  async sendChat(args, context) {
    return this.#enqueueCommand("send_chat", withoutConfirmation(args), context);
  }

  async requestVote(args, context) {
    return this.#enqueueCommand("request_vote", withoutConfirmation(args), context);
  }

  async requestPlayerInput(args, context) {
    return this.#enqueueCommand("request_player_input", withoutConfirmation(args), context);
  }

  async requestPlayerRoll(args, context) {
    return this.#enqueueCommand("request_player_roll", withoutConfirmation(args), context);
  }

  async proxyCharacterRoll(args, context) {
    return this.#enqueueCommand("proxy_character_roll", withoutConfirmation(args), context);
  }

  async proxyCharacterPowerAction(args, context) {
    return this.#enqueueCommand("proxy_character_power_action", withoutConfirmation(args), context);
  }

  async proxyCombatantAction(args, context) {
    return this.#enqueueCommand("proxy_combatant_action", withoutConfirmation(args), context);
  }

  async addLibraryNpc(args, context) {
    return this.#enqueueCommand("add_library_npc", withoutConfirmation(args), context);
  }

  async addLibraryEncounter(args, context) {
    return this.#enqueueCommand("add_library_encounter", withoutConfirmation(args), context);
  }

  async beginStoryEncounter(args, context) {
    return this.#enqueueCommand("begin_story_encounter", withoutConfirmation(args), context);
  }

  async beginStoryNpcEncounter(args, context) {
    return this.#enqueueCommand("begin_story_npc_encounter", withoutConfirmation(args), context);
  }

  async createQuest(args, context) {
    return this.#enqueueCommand("create_quest", withoutConfirmation(args), context);
  }

  async updateQuest(args, context) {
    return this.#enqueueCommand("update_quest", withoutConfirmation(args), context);
  }

  async openLibraryImage(args, context) {
    return this.#enqueueCommand("open_library_image", withoutConfirmation(args), context);
  }

  async setSpellSlotUsage(args, context) {
    return this.#enqueueCommand("set_spell_slot_usage", withoutConfirmation(args), context);
  }

  async advanceTurn(args, context) {
    return this.#enqueueCommand("advance_turn", withoutConfirmation(args), context);
  }

  async startEncounter(args, context) {
    return this.#enqueueCommand("start_encounter", withoutConfirmation(args), context);
  }

  async applyEffect(args, context) {
    return this.#enqueueCommand("apply_effect", withoutConfirmation(args), context);
  }

  async removeEffect(args, context) {
    return this.#enqueueCommand("remove_effect", withoutConfirmation(args), context);
  }

  async removeCombatant(args, context) {
    return this.#enqueueCommand("remove_combatant", withoutConfirmation(args), context);
  }

  async resolveManualAdjudication(args, context) {
    return this.#enqueueCommand("resolve_manual_adjudication", withoutConfirmation(args), context);
  }

  async setCombatantThreat(args, context) {
    return this.#enqueueCommand("set_combatant_threat", withoutConfirmation(args), context);
  }

  async setCombatantVisibility(args, context) {
    return this.#enqueueCommand("set_combatant_visibility", withoutConfirmation(args), context);
  }

  async recordSessionContinuity(args, context) {
    return this.#enqueueCommand("record_session_continuity", withoutConfirmation(args), context);
  }

  #enqueueCommand(capability, args, context) {
    const pending = this.#commandQueue.then(() => this.#executeCommand(capability, args, context));
    this.#commandQueue = pending.catch(() => undefined);
    return pending;
  }

  async #executeCommand(capability, args, context) {
    if (!context || typeof context.requestId !== "string" || !context.requestId ||
        typeof context.sessionId !== "string" || !context.sessionId) {
      throw new NerveError("FGU_COMMAND_CONTEXT_INVALID", "The Fantasy Grounds command context is incomplete.", {
        capability,
        hasRequestId: typeof context?.requestId === "string" && context.requestId.length > 0,
        hasSessionId: typeof context?.sessionId === "string" && context.sessionId.length > 0
      });
    }
    await this.#assertInboxAvailable();
    const command = {
      schemaVersion: "0.1",
      requestId: context.requestId,
      sessionId: context.sessionId,
      capability,
      arguments: args,
      requestedAt: new Date().toISOString(),
      expiresAtEpoch: Math.floor((Date.now() + 24 * 60 * 60 * 1000) / 1000)
    };
    const temporaryPath = `${this.commandPath}.${context.requestId}.tmp`;

    await runFileHandoffStage("clear_previous_result", () => retryFileOperation(
      () => unlink(this.commandResultPath), { ignoreNotFound: true }
    ), this.commandResultPath, capability);
    await runFileHandoffStage("write_temporary_command", () => retryFileOperation(
      () => writeFile(temporaryPath, JSON.stringify(command), "utf8")
    ), temporaryPath, capability);
    await runFileHandoffStage("clear_previous_command", () => retryFileOperation(
      () => unlink(this.commandPath), { ignoreNotFound: true }
    ), this.commandPath, capability);
    await runFileHandoffStage("publish_command", () => retryFileOperation(
      () => rename(temporaryPath, this.commandPath)
    ), this.commandPath, capability);
    await this.#notifyActionWaiting(capability);

    const deadline = Date.now() + this.commandTimeoutMs;
    let resolved = false;
    try {
      while (Date.now() < deadline) {
        const result = await readCommandResult(this.commandResultPath);
        if (result?.requestId === context.requestId) {
          resolved = true;
          if (!result.ok) {
            throw new NerveError(
              result.error?.code || "FGU_COMMAND_FAILED",
              result.error?.message || "Fantasy Grounds rejected the command.",
              result.error?.details
            );
          }
          return normalizeCommandResult(capability, result.data);
        }
        await delay(250);
      }
      throw new NerveError(
        "FGU_COMMAND_TIMEOUT",
        "The action remains in the persistent Fantasy Grounds Nerve inbox. Click the amber NERVE control or Check for Action to execute or deny it.",
        { capability, timeoutMs: this.commandTimeoutMs, persistent: true }
      );
    } finally {
      if (resolved) {
        await unlink(this.commandPath).catch(ignoreMissing);
        await unlink(this.commandResultPath).catch(ignoreMissing);
      }
    }
  }

  async #notifyActionWaiting(capability) {
    try {
      await this.notifier?.notifyActionWaiting?.({ capability, campaign: this.campaign });
    } catch {
      // Notifications are advisory. A desktop integration failure must never
      // prevent the persistent Action Inbox from receiving a guarded command.
    }
  }

  async #assertInboxAvailable() {
    let command;
    try {
      command = JSON.parse(stripByteOrderMark(await readFile(this.commandPath, "utf8")));
    } catch (error) {
      if (error.code === "ENOENT" || error instanceof SyntaxError) return;
      throw error;
    }
    const result = await readCommandResult(this.commandResultPath);
    if (result?.requestId === command.requestId || Number(command.expiresAtEpoch) < Math.floor(Date.now() / 1000)) {
      await unlink(this.commandPath).catch(ignoreMissing);
      await unlink(this.commandResultPath).catch(ignoreMissing);
      return;
    }
    throw new NerveError(
      "FGU_ACTION_PENDING",
      "Fantasy Grounds already has an unresolved Nerve action. Execute or deny it before sending another.",
      { requestId: command.requestId, capability: command.capability }
    );
  }

  async #readSnapshot() {
    for (let attempt = 0; attempt < 10; attempt += 1) {
      let text;
      try {
        text = await readFile(this.snapshotPath, "utf8");
      } catch (error) {
        if (error.code === "ENOENT") {
          throw new NerveError(
            "FGU_SNAPSHOT_NOT_FOUND",
            "No Fantasy Grounds snapshot is available. Load the campaign with the Nerve extension enabled.",
            { snapshotPath: this.snapshotPath }
          );
        }
        throw new NerveError("FGU_SNAPSHOT_READ_FAILED", "The Fantasy Grounds snapshot could not be read.", {
          snapshotPath: this.snapshotPath
        });
      }

      let snapshot;
      try {
        snapshot = JSON.parse(stripByteOrderMark(text));
      } catch {
        if (attempt < 9) {
          await new Promise((resolveDelay) => setTimeout(resolveDelay, 25));
          continue;
        }
        throw new NerveError("FGU_SNAPSHOT_INVALID", "The Fantasy Grounds snapshot is not valid JSON.", {
          snapshotPath: this.snapshotPath
        });
      }

      if (
        !new Set(["0.1", "0.2", "0.3", "0.4", "0.5", "0.6", "0.7", "0.8", "0.9", "1.0", "1.1", "1.2", "1.3", "1.4"]).has(snapshot?.schemaVersion) ||
        !isPlainObject(snapshot.campaignSummary)
      ) {
        throw new NerveError(
          "FGU_SNAPSHOT_INVALID",
          "The Fantasy Grounds snapshot does not match the supported bridge contract.",
          { snapshotPath: this.snapshotPath, supportedSchemaVersions: ["0.1", "0.2", "0.3", "0.4", "0.5", "0.6", "0.7", "0.8", "0.9", "1.0", "1.1", "1.2", "1.3", "1.4"] }
        );
      }

      return snapshot;
    }
  }

  async #readLibrary(snapshot) {
    let text;
    try {
      text = await readFile(this.libraryPath, "utf8");
    } catch (error) {
      if (error.code === "ENOENT") {
        if (isValidLibrary(snapshot.library, true)) return snapshot.library;
        throw capabilityUnavailable(this.libraryPath, "campaign library state", "0.1");
      }
      throw new NerveError("FGU_LIBRARY_READ_FAILED", "The Fantasy Grounds library index could not be read.", {
        libraryPath: this.libraryPath
      });
    }

    let library;
    try {
      library = JSON.parse(stripByteOrderMark(text));
    } catch {
      throw new NerveError("FGU_LIBRARY_INVALID", "The Fantasy Grounds library index is not valid JSON.", {
        libraryPath: this.libraryPath
      });
    }

    if (!isValidLibrary(library)) {
      throw new NerveError("FGU_LIBRARY_INVALID", "The Fantasy Grounds library index does not match the supported bridge contract.", {
        libraryPath: this.libraryPath,
        supportedSchemaVersion: "0.1"
      });
    }
    return library;
  }
}

function normalizeCampaignFocus(value) {
  const focus = isPlainObject(value) ? value : {};
  return {
    activeAdventureModule: String(focus.activeAdventureModule || ""),
    displayName: String(focus.displayName || ""),
    status: new Set(["ready", "not_selected", "source_unavailable"]).has(focus.status) ? focus.status : "not_selected",
    recordCount: Math.max(0, Number(focus.recordCount || 0)),
    confirmedAt: String(focus.confirmedAt || ""),
    suggestedModule: String(focus.suggestedModule || ""),
    creativeAuthority: focus.creativeAuthority === "module_strict" ? "module_strict" : "bounded_improvisation"
  };
}

function createActionContext(charactersValue, combatTracker, events) {
  const characters = normalizeLuaArray(charactersValue ?? []).map(normalizeCharacter);
  const relevant = [...events].reverse().find((event) =>
    new Set(["player.chat_message", "chat.message"]).has(event?.type) && (event?.actor || event?.text)
  );
  const actor = String(relevant?.actor || "");
  const triggerText = String(relevant?.text || relevant?.data?.text || "");
  const character = characters.find((item) => item.name.toLowerCase() === actor.toLowerCase())
    ?? characters.find((item) => triggerText.toLowerCase().includes(item.name.toLowerCase()))
    ?? null;
  const words = new Set((triggerText.toLowerCase().match(/[a-z][a-z'-]{2,}/g) || []));
  const powers = (character?.powers ?? []).filter((power) => {
    const nameWords = String(power.name || "").toLowerCase().match(/[a-z][a-z'-]{2,}/g) || [];
    return nameWords.length > 0 && nameWords.every((word) => words.has(word));
  }).slice(0, 8).map((power) => ({
    id: power.id, name: power.name, group: power.group, level: power.level, prepared: power.prepared,
    used: power.used, range: power.range, duration: power.duration, actions: power.actions.slice(0, 12)
  }));
  const targets = (combatTracker?.combatants ?? []).filter((item) => item.id && item.name && item.faction !== "friend")
    .slice(0, 20).map((item) => ({ id: item.id, name: item.name, faction: item.faction }));
  const targetMatch = triggerText.match(/\b(?:on|at|against)\s+(?:the\s+)?([^,.!?]+)(?:[,.!?]|$)/i);
  const unresolvedTarget = targetMatch && !targets.some((item) => targetMatch[1].toLowerCase().includes(item.name.toLowerCase()))
    ? targetMatch[1].trim().slice(0, 200) : null;
  return {
    actor, characterId: character?.id || "", triggerText: triggerText.slice(0, 1000), powers,
    spellSlots: (character?.spellSlots ?? []).slice(0, 9), targetCandidates: targets, unresolvedTarget
  };
}

function normalizeStoryCues(value) {
  const state = isPlainObject(value) ? value : {};
  return {
    entries: normalizeLuaArray(state.entries ?? []).slice(0, 12).map((entry) => ({
      id: String(entry?.id || ""), recordId: String(entry?.recordId || ""), recordType: String(entry?.recordType || ""),
      name: String(entry?.name || ""), module: String(entry?.module || ""),
      lifetime: new Set(["once", "scene", "session"]).has(entry?.lifetime) ? entry.lifetime : "scene",
      addedAt: String(entry?.addedAt || ""), status: entry?.status === "active" ? "active" : "inactive"
    })).filter((entry) => entry.recordId && entry.status === "active"),
    count: Math.max(0, Number(state.count || 0)),
    hostOnly: true,
    defaultLifetime: new Set(["once", "scene", "session"]).has(state.defaultLifetime) ? state.defaultLifetime : "scene"
  };
}

function normalizeQuestLog(value) {
  const state = isPlainObject(value) ? value : {};
  const statuses = new Set(["offered", "accepted", "active", "completed", "failed", "abandoned"]);
  const provenances = new Set(["module", "gm", "ai_improvised"]);
  const quests = normalizeLuaArray(state.quests ?? []).slice(0, 100).map((quest) => ({
    id: String(quest?.id || ""), name: String(quest?.name || ""), description: String(quest?.description || "").slice(0, 2000),
    status: statuses.has(quest?.status) ? quest.status : "active", giver: String(quest?.giver || ""),
    location: String(quest?.location || ""), reward: String(quest?.reward || ""),
    provenance: provenances.has(quest?.provenance) ? quest.provenance : "gm",
    sourceRecordId: String(quest?.sourceRecordId || ""), updatedAt: String(quest?.updatedAt || "")
  })).filter((quest) => /^id-[0-9]+$/.test(quest.id));
  return { quests, count: quests.length, activeCount: quests.filter((quest) => new Set(["accepted", "active"]).has(quest.status)).length };
}

function isTransientSnapshotError(error) {
  return error?.code === "FGU_SNAPSHOT_INVALID" || error?.code === "FGU_SNAPSHOT_NOT_FOUND";
}

function createEventWaitResult(recentEvents, cursorReset, timedOut, waitedMs) {
  return {
    recentEvents,
    cursorReset,
    timedOut,
    waitedMs,
    nextCursor: { streamId: recentEvents.streamId, sequence: recentEvents.latestSequence }
  };
}

function isPlainObject(value) {
  return value !== null && typeof value === "object" && !Array.isArray(value);
}

function stripByteOrderMark(text) {
  return text.charCodeAt(0) === 0xfeff ? text.slice(1) : text;
}

function normalizeCombatTracker(tracker) {
  const normalized = structuredClone(tracker);
  normalized.combatants = normalizeLuaArray(normalized.combatants);
  for (const combatant of normalized.combatants) {
    combatant.effects = normalizeLuaArray(combatant.effects);
    combatant.actions = normalizeLuaArray(combatant.actions ?? []);
    for (const action of combatant.actions) action.abilities = normalizeLuaArray(action.abilities ?? []);
    combatant.disposition ??= inferDisposition(combatant);
    combatant.threat ??= combatant.faction === "foe" && combatant.disposition === "active";
    combatant.playerVisible ??= combatant.faction === "friend";
  }
  return normalized;
}

function normalizeParty(party) {
  const normalized = structuredClone(party);
  normalized.members = normalizeLuaArray(normalized.members);
  return normalized;
}

function normalizeCharacter(character) {
  const normalized = structuredClone(character);
  for (const key of ["classes", "skills", "languages", "proficiencies", "automationNotes"]) {
    normalized[key] = normalizeLuaArray(normalized[key]);
  }
  normalized.powers = normalizeLuaArray(normalized.powers ?? []);
  normalized.spellSlots = normalizeLuaArray(normalized.spellSlots ?? []);
  normalized.referenceLinks = normalizeLuaArray(normalized.referenceLinks ?? []);
  normalized.proxyControl ??= { mode: "none" };
  for (const power of normalized.powers) {
    power.actions = normalizeLuaArray(power.actions ?? []);
    for (const action of power.actions) action.damage = normalizeLuaArray(action.damage ?? []);
  }
  for (const characterClass of normalized.classes) {
    if (Array.isArray(characterClass.hitDie)) characterClass.hitDie = characterClass.hitDie.join(",");
  }
  return normalized;
}

function normalizeMapScene(value) {
  const scene = isPlainObject(value) ? structuredClone(value) : {};
  scene.recordId = scene.recordId || null;
  scene.name ??= "";
  scene.panel ??= "none";
  scene.shareMode ??= "none";
  scene.holders = normalizeLuaArray(scene.holders ?? []);
  scene.playStyle ??= "mixed";
  scene.grid ??= { enabled: false, sizeX: 0, sizeY: 0, offsetX: 0, offsetY: 0, type: 0 };
  scene.viewport ??= { width: 0, height: 0 };
  scene.areaContinuity ??= { currentAreaKey: null, areas: [] };
  scene.areaContinuity.currentAreaKey ||= null;
  scene.areaContinuity.areas = normalizeLuaArray(scene.areaContinuity.areas ?? []);
  scene.recordLinks = normalizeLuaArray(scene.recordLinks ?? []).map((link) => ({
    ...link,
    areaKey: link.areaKey || null,
    x: link.x ?? null,
    y: link.y ?? null,
    gridX: link.gridX ?? null,
    gridY: link.gridY ?? null
  }));
  scene.spatial ??= {
    coordinateSystem: scene.grid.enabled ? "grid" : "pixels",
    partyTokenCount: 0, foeTokenCount: 0, neutralTokenCount: 0, unlinkedTokenCount: 0,
    partyCentroid: null, foeCentroid: null, nearestVisibleHostile: null,
    partyAreaCandidates: [], foeAreaCandidates: [],
    visionModel: "native_token_and_ct_visibility", limitations: [], placementWarnings: []
  };
  for (const key of ["partyCentroid", "foeCentroid", "nearestVisibleHostile"]) scene.spatial[key] ??= null;
  scene.spatial.partyAreaCandidates = normalizeLuaArray(scene.spatial.partyAreaCandidates ?? []);
  scene.spatial.foeAreaCandidates = normalizeLuaArray(scene.spatial.foeAreaCandidates ?? []);
  scene.spatial.limitations = normalizeLuaArray(scene.spatial.limitations ?? []);
  scene.spatial.placementWarnings = normalizeLuaArray(scene.spatial.placementWarnings ?? []);
  scene.tokens = normalizeLuaArray(scene.tokens ?? []).map((token) => ({
    ...token,
    combatantId: token.combatantId || null,
    gridX: token.gridX ?? null,
    gridY: token.gridY ?? null,
    distanceFromPartyGridUnits: token.distanceFromPartyGridUnits ?? null,
    areaCandidateKey: token.areaCandidateKey || null,
    areaCandidateRecordId: token.areaCandidateRecordId || null,
    distanceFromAreaMarkerGridUnits: token.distanceFromAreaMarkerGridUnits ?? null
  }));
  scene.observedAt ??= new Date(0).toISOString();
  return scene;
}

function normalizeSessionContinuity(value) {
  const state = isPlainObject(value) ? structuredClone(value) : {};
  state.history = normalizeLuaArray(state.history ?? []).map((checkpoint) => normalizeContinuityCheckpoint(checkpoint, false));
  state.latest = isPlainObject(state.latest) ? normalizeContinuityCheckpoint(state.latest) : (state.history[0] ?? null);
  state.available = Boolean(state.latest);
  state.observedAt ??= new Date(0).toISOString();
  return state;
}

function normalizeContinuityCheckpoint(value, includeDefaultFacts = true) {
  const checkpoint = structuredClone(value);
  checkpoint.unresolvedThreads = normalizeLuaArray(checkpoint.unresolvedThreads ?? []);
  checkpoint.partyGoals = normalizeLuaArray(checkpoint.partyGoals ?? []);
  checkpoint.importantNpcs = normalizeLuaArray(checkpoint.importantNpcs ?? []);
  checkpoint.partyOrigin ??= "";
  checkpoint.reasonHere ??= "";
  for (const key of ["locationsVisited", "npcsMet", "conversationHighlights", "discoveries", "completedObjectives"]) {
    checkpoint[key] = normalizeLuaArray(checkpoint[key] ?? []);
  }
  checkpoint.map ??= {};
  checkpoint.map.recordId = checkpoint.map.recordId || null;
  checkpoint.map.name ??= "";
  checkpoint.map.currentAreaKey = checkpoint.map.currentAreaKey || null;
  checkpoint.combat ??= { active: false, round: 0, activeCombatantId: null };
  checkpoint.combat.activeCombatantId = checkpoint.combat.activeCombatantId || null;
  if (!includeDefaultFacts && !isPlainObject(checkpoint.facts)) {
    delete checkpoint.facts;
    return checkpoint;
  }
  checkpoint.facts ??= { party: [], combatants: [], pendingAdjudications: [], recentEvents: [], scene: {}, sessionMetrics: {} };
  for (const key of ["party", "combatants", "pendingAdjudications", "recentEvents"]) {
    checkpoint.facts[key] = normalizeLuaArray(checkpoint.facts[key] ?? []);
  }
  if (checkpoint.facts.handoff) {
    checkpoint.facts.handoff.recentInteractions = normalizeLuaArray(checkpoint.facts.handoff.recentInteractions ?? []);
    checkpoint.facts.handoff.bookkeepingEvidence = normalizeLuaArray(checkpoint.facts.handoff.bookkeepingEvidence ?? []);
  }
  checkpoint.facts.scene ??= {};
  for (const key of ["partyAreaKeys", "foeAreaKeys", "placementWarnings"]) {
    checkpoint.facts.scene[key] = normalizeLuaArray(checkpoint.facts.scene[key] ?? []);
  }
  checkpoint.facts.sessionMetrics ??= { actionsProcessed: 0, approved: 0, denied: 0, failed: 0, sessionGrantExecutions: 0 };
  return checkpoint;
}

function defaultApprovalPolicy() {
  return {
    mode: "manual", narrativeFlow: false, proxyActions: false, combatPacing: false, entityProxy: false,
    automaticCapabilities: [],
    alwaysManualCapabilities: [
      "request_vote", "add_library_npc", "add_library_encounter",
      "open_library_image", "set_spell_slot_usage", "apply_effect", "remove_effect", "remove_combatant",
      "resolve_manual_adjudication", "set_combatant_threat", "set_combatant_visibility", "create_quest", "update_quest", "record_session_continuity"
    ]
  };
}

function normalizeSessionOperations(value, snapshot) {
  const state = structuredClone(value ?? {});
  state.playStyle ??= "mixed";
  state.resumedFromCheckpointId ??= "";
  state.approvalPolicy ??= defaultApprovalPolicy();
  state.approvalPolicy.automaticCapabilities = normalizeLuaArray(state.approvalPolicy.automaticCapabilities ?? []);
  state.approvalPolicy.alwaysManualCapabilities = normalizeLuaArray(state.approvalPolicy.alwaysManualCapabilities ?? []);
  state.snapshotBytes = Buffer.byteLength(JSON.stringify(snapshot), "utf8");
  state.approximateSnapshotTokens = Math.ceil(state.snapshotBytes / 4);
  return state;
}

function createCurrentEncounter(tracker) {
  const participants = tracker.combatants.map(({ id, name, faction, active, disposition, threat }) => ({ id, name, faction, active, disposition, threat }));
  const activeCombatant = participants.find((participant) => participant.active);
  const count = (faction) => participants.filter((participant) => participant.faction === faction).length;
  const activeFoeCount = participants.filter((participant) => participant.faction === "foe" && participant.threat).length;
  return {
    active: activeFoeCount > 0,
    id: activeFoeCount > 0 ? "combat-tracker" : null,
    round: tracker.round,
    activeCombatantId: activeCombatant?.id ?? null,
    participantCount: participants.length,
    friendlyCount: count("friend"),
    foeCount: count("foe"),
    activeFoeCount,
    neutralCount: count("neutral"),
    participants,
    observedAt: tracker.observedAt
  };
}

function inferDisposition(combatant) {
  const status = String(combatant.status ?? "").toLocaleLowerCase();
  if (status === "dead") return "dead";
  if (status === "unconscious") return "unconscious";
  if (status === "escaped") return "escaped";
  if (status === "dormant") return "dormant";
  if (status === "dying" || (combatant.hitPoints?.total > 0 && combatant.hitPoints.wounds >= combatant.hitPoints.total)) return "defeated";
  return "active";
}

function capabilityUnavailable(snapshotPath, stateName, requiredSchemaVersion) {
  return new NerveError(
    "FGU_CAPABILITY_UNAVAILABLE",
    `The loaded Fantasy Grounds extension does not publish ${stateName}.`,
    { snapshotPath, requiredSchemaVersion }
  );
}

function isValidLibrary(library, allowLegacy = false) {
  return isPlainObject(library) &&
    (new Set(["0.1", "0.2", "0.3"]).has(library.schemaVersion) || (allowLegacy && library.schemaVersion === undefined)) &&
    Array.isArray(library.records) &&
    typeof library.truncated === "boolean" &&
    typeof library.observedAt === "string";
}

function normalizeLuaArray(value) {
  if (Array.isArray(value)) return value;
  if (isPlainObject(value) && Object.keys(value).length === 0) return [];
  return value;
}

function normalizeCommandResult(capability, value) {
  const result = isPlainObject(value) ? structuredClone(value) : value;
  if (!isPlainObject(result)) return result;

  const arrayFields = {
    send_chat: ["recipients"],
    request_player_input: ["recipients"],
    request_player_roll: ["recipients"],
    proxy_character_power_action: ["targetCombatantIds"],
    proxy_combatant_action: ["targetCombatantIds"],
    add_library_npc: ["combatants"],
    add_library_encounter: ["combatants", "maps"],
    begin_story_encounter: ["encounters", "addedCombatants", "initiativeOrder"],
    start_encounter: ["initiativeOrder"],
    advance_turn: ["skippedCombatantIds"],
    record_session_continuity: ["unresolvedThreads", "partyGoals", "importantNpcs", "locationsVisited", "npcsMet", "conversationHighlights", "discoveries", "completedObjectives"]
  };
  for (const field of arrayFields[capability] ?? []) {
    if (result[field] !== undefined) result[field] = normalizeLuaArray(result[field]);
  }
  return result;
}

function withoutConfirmation(args) {
  const { confirmed: _confirmed, ...commandArgs } = args;
  return commandArgs;
}

async function readCommandResult(path) {
  try {
    const text = await retryFileOperation(() => readFile(path, "utf8"), {
      ignoreNotFound: true
    });
    if (text === undefined) return null;
    return JSON.parse(stripByteOrderMark(text));
  } catch (error) {
    if (error.code === "ENOENT" || error instanceof SyntaxError) return null;
    throw error;
  }
}

async function retryFileOperation(operation, { ignoreNotFound = false, attempts = 8, delayMs = 25 } = {}) {
  let lastError;
  for (let attempt = 0; attempt < attempts; attempt += 1) {
    try {
      return await operation();
    } catch (error) {
      if (ignoreNotFound && error?.code === "ENOENT") return undefined;
      lastError = error;
      if (!new Set(["EACCES", "EBUSY", "EPERM", "EMFILE", "ENFILE"]).has(error?.code) || attempt === attempts - 1) {
        throw error;
      }
      await delay(delayMs * (attempt + 1));
    }
  }
  throw lastError;
}

async function runFileHandoffStage(stage, operation, path, capability) {
  try {
    return await operation();
  } catch (error) {
    if (error instanceof NerveError) throw error;
    throw new NerveError("FGU_COMMAND_HANDOFF_FAILED", "Nerve could not deliver the action to Fantasy Grounds.", {
      capability,
      stage,
      path,
      fileErrorCode: error?.code || "UNKNOWN"
    });
  }
}

function ignoreMissing(error) {
  if (error.code !== "ENOENT") throw error;
}

function delay(milliseconds) {
  return new Promise((resolve) => setTimeout(resolve, milliseconds));
}
