local ADAPTER_VERSION = "0.67.1"
local NERVE_SIDEBAR_RECORD_TYPE = "nervecontrol"
local SNAPSHOT_FILENAME = "nerve-state.json"
local LIBRARY_FILENAME = "nerve-library.json"
local COMMAND_FILENAME = "nerve-command.json"
local COMMAND_RESULT_FILENAME = "nerve-command-result.json"
local OOB_MSGTYPE_PLAYER_PROMPT = "nerve_player_prompt"
local OOB_MSGTYPE_PLAYER_PROMPT_RESPONSE = "nerve_player_prompt_response"
OOB_MSGTYPE_PLAYER_PROMPT_RECEIPT = "nerve_player_prompt_receipt"
local OOB_MSGTYPE_REMOTE_ROLL_RESULT = "nerve_remote_roll_result"
local OOB_MSGTYPE_AI_CUE = "nerve_ai_cue"
local OOB_MSGTYPE_AI_CUE_STATUS = "nerve_ai_cue_status"
OOB_MSGTYPE_OOC_QUESTION = "nerve_ooc_question"
local snapshotSequence = 0
local eventSequence = 0
local recentEvents = {}
local lastStateEventEpochs = {}
local eventStreamId = nil
local pulseCombatState = { initialized = false, round = 0, activeId = nil, combatants = {} }
local MAX_RECENT_EVENTS = 100
MAX_CAMPAIGN_MEMORY_INTERACTIONS = 200
local STATE_EVENT_COALESCE_SECONDS = 2
local COALESCED_STATE_EVENT_TYPES = {
  ["party.changed"] = true,
  ["character.changed"] = true,
  ["users.changed"] = true,
  ["map.tokens_changed"] = true
}
AUTOMATIC_CONNECTOR_CUE_EVENT_TYPES = {
  ["player.chat_message"] = true,
  ["gm.guidance"] = true,
  ["player.prompt_response"] = true,
  ["player.roll_response"] = true,
  ["player.roll_declined"] = true,
  ["player.prompt_timeout"] = true,
  ["player.roll_timeout"] = true,
  ["combat.turn_started"] = true,
  ["roll.attack"] = true,
  ["roll.save"] = true,
  ["roll.skill"] = true,
  ["roll.check"] = true,
  ["power.action_outcome"] = true,
  ["combatant.action_outcome"] = true,
  ["ooc.question"] = true
}
automaticConnectorCueTrigger = nil
pendingResumedCombatTurnCue = false
local handlersRegistered = false
local lastSnapshotFingerprint = nil
local lastProcessedRequestId = nil
local pendingCommand = nil
local awaitingVoteCommand = nil
local lastPrivateNerveMessageText = nil
local lastPrivateNerveMessageEpoch = 0
local suppressNerveWhisperCallbacks = 0
local pendingPlayerPrompts = {}
local playerPromptOrder = {}
local clientPromptQueue = {}
local activeClientPrompt = nil
local pendingClientRoll = nil
suppressNextPromptRollCueActor = nil
suppressNextPromptRollCueEpoch = 0
local clientDiceHandlerRegistered = false
local recentRemoteRolls = {}
local completeClientPrompt
local writeCommandResult
local recordDecision
local deliverNerveWhisper
local refreshNerveControlWindows
local decisionHistory = {}
local sessionGrants = { send_chat = false, proxy_actions = false, combat_pacing = false }
local priorThreatFactions = {}
local playerProxyMode = "all"
local suppressCombatStateChanged = false
local activeNervePowerContext = nil
local pendingNerveSaveContexts = {}
local pendingNerveSaveContextOrder = {}
local pendingNervePowerFollowUps = {}
local pendingNerveCombatantFollowUps = {}
local resolveNerveAutoFailSave
publishNervePowerFollowUpOutcome = nil
publishNerveCombatantFollowUpOutcome = nil
localPowerCorrelationSequence = 0
local NERVE_FOLLOW_UP_SECONDS = 900
local MAX_DECISION_HISTORY = 20
local MAX_LIBRARY_FIELDS = 24
local MAX_LIBRARY_FIELD_LENGTH = 4000
local MAX_MAP_RECORD_LINKS = 50
local LIBRARY_RECORD_TYPES = { "location", "story", "quest", "battle", "image", "table", "treasureparcel", "vehicle", "item", "npc" }
STORY_CUE_RECORD_TYPES = { story = true, quest = true, npc = true, image = true, battle = true, location = true, table = true, treasureparcel = true, item = true, vehicle = true }
MAX_STORY_CUES = 12
local LIBRARY_TYPE_LIMITS = { location = 300, story = 800, quest = 150, battle = 300, image = 750, table = 300, treasureparcel = 300, vehicle = 200, item = 600, npc = 600 }
local LIBRARY_TEXT_FIELDS = {
  name = true, title = true, text = true, description = true, summary = true,
  readaloud = true, notes = true, type = true, subtype = true, rarity = true,
  cost = true, weight = true, cr = true, level = true, source = true,
  count = true, number = true, quantity = true,
  image = true, picture = true, token = true
}
local libraryCatalog = nil
local currentMapId = nil
local suppressImageWindowEvent = false
local activeManualAdjudicationId = nil
local clientAiCueStatus = "idle"
local clientAiCueLatencySeconds = nil
local TRACKED_COMBATANT_FIELDS = {
  "name", "type", "friendfoe", "initresult", "active", "status",
  "hp", "hptotal", "hptemp", "wounds"
}
local TRACKED_EFFECT_FIELDS = {
  "label", "duration", "init", "isactive", "isgmonly"
}
local COMBATANT_ACTION_SECTIONS = { "actions", "bonusactions", "reactions", "legendaryactions", "lairactions", "innatespells", "spells" }
local COMBATANT_ACTION_TYPES = { attack = true, powersave = true, damage = true, heal = true, effect = true }
local TRACKED_PARTY_FIELDS = {
  "link", "name", "race", "classlevel", "ac", "perception", "senses",
  "strength", "strbonus", "dexterity", "dexbonus", "constitution", "conbonus",
  "intelligence", "intbonus", "wisdom", "wisbonus", "charisma", "chabonus",
  "exp", "expneeded", "hd", "hdused", "hptotal", "wounds"
}
local TRACKED_CHARACTER_PATHS = {
  "name", "race", "background", "alignment", "deity", "level", "profbonus",
  "exp", "expneeded", "inspiration", "size", "senses", "defenses.ac.total",
  "hp.total", "hp.temporary", "hp.wounds", "hp.deathsavesuccess", "hp.deathsavefail",
  "initiative.total", "speed.total"
}
local TRACKED_ABILITY_FIELDS = { "score", "bonus", "save", "saveprof" }
local TRACKED_CLASS_FIELDS = { "name", "level", "hddie", "hdused" }
local TRACKED_SKILL_FIELDS = { "name", "stat", "total", "prof" }
local TRACKED_POWER_FIELDS = {
  "name", "group", "level", "prepared", "cast", "castingtime", "range", "duration", "ritual", "school"
}
local TRACKED_POWER_ACTION_FIELDS = { "type", "order", "atktype", "savetype", "onmissdamage", "label", "targeting", "durmod", "durunit" }

local function getNerveSidebarLink()
  return "nerve_approval", ""
end

local function registerNerveSidebar()
  RecordDataManager.setRecordTypeData(NERVE_SIDEBAR_RECORD_TYPE, {
    sSidebarCategory = "nerve",
    aDataMap = { "nerve" },
    fGetLink = getNerveSidebarLink,
    tDisplayText = {
      sDisplayText = "Nerve Control",
      sSingleDisplayText = "Nerve Control"
    },
    tOptions = {
      bNoCategories = true,
      bNoCreate = true,
      bNoDelete = true,
      bNoExport = true,
      bNoLock = true,
      bNoShare = true
    }
  })
  DesktopManager.rebuildSidebar()
end

local function countEntries(values)
  local count = 0
  if values then
    for _ in pairs(values) do
      count = count + 1
    end
  end
  return count
end

local function createManualAdjudicationState()
  local tasks = {}
  for _, nodeTask in pairs(DB.getChildren("nerve.manualadjudications") or {}) do
    if DB.getValue(nodeTask, "status", "pending") == "pending" then
      table.insert(tasks, {
        id = DB.getName(nodeTask), correlationId = DB.getValue(nodeTask, "correlationid", ""),
        sourceCombatantId = DB.getValue(nodeTask, "sourceid", ""), sourceName = DB.getValue(nodeTask, "sourcename", ""),
        targetCombatantId = DB.getValue(nodeTask, "targetid", ""), targetName = DB.getValue(nodeTask, "targetname", ""),
        actionName = DB.getValue(nodeTask, "actionname", ""), text = DB.getValue(nodeTask, "text", ""),
        createdAt = DB.getValue(nodeTask, "createdat", "")
      })
    end
  end
  table.sort(tasks, function(left, right) return left.createdAt > right.createdAt end)
  while #tasks > 50 do table.remove(tasks) end
  return { tasks = tasks, observedAt = os.date("!%Y-%m-%dT%H:%M:%SZ") }
end

local function imagePanelName(windowClass)
  if windowClass == "imagebackpanel" then return "back" end
  if windowClass == "imagemaxpanel" then return "max" end
  if windowClass == "imagefullpanel" then return "full" end
  return "window"
end

local function createOpenMapState()
  local maps = {}
  local seen = {}
  for _, imageControl in ipairs(ImageManager.getActiveImages() or {}) do
    if #maps >= 20 then break end
    local nodeImage = imageControl.getDatabaseNode and imageControl.getDatabaseNode() or nil
    local nodeRecord = nodeImage and DB.getParent(nodeImage) or nil
    local recordId = nodeRecord and DB.getPath(nodeRecord) or ""
    if recordId ~= "" and not seen[recordId] then
      local topWindow = WindowManager.getTopWindow(imageControl)
      local windowClass = topWindow and topWindow.getClass and topWindow.getClass() or "imagewindow"
      local access, holders = UtilityManager.getNodeAccessLevel(nodeRecord)
      holders = holders or {}
      table.sort(holders)
      table.insert(maps, {
        recordId = recordId,
        name = DB.getValue(nodeRecord, "name", DB.getValue(nodeRecord, "title", "")),
        panel = imagePanelName(windowClass),
        shareMode = access == 2 and "all" or (access == 1 and "specific" or "none"),
        holders = holders,
        current = recordId == currentMapId
      })
      seen[recordId] = true
    end
  end
  if currentMapId and not seen[currentMapId] then currentMapId = nil end
  if not currentMapId and #maps > 0 then
    currentMapId = maps[#maps].recordId
    maps[#maps].current = true
  end
  table.sort(maps, function(left, right) return string.lower(left.name) < string.lower(right.name) end)
  return {
    maps = maps,
    currentMapId = currentMapId,
    observedAt = os.date("!%Y-%m-%dT%H:%M:%SZ")
  }
end

local function getScenePlayStyle()
  local style = DB.getValue("nerve.sessionoperations.playstyle", "mixed")
  if style ~= "map" and style ~= "theater_of_mind" then return "mixed" end
  return style
end

local function moduleFromRecordId(recordId)
  if type(recordId) ~= "string" then return "" end
  return string.match(recordId, "@(.+)$") or ""
end

local function areaKeyFromName(name)
  if type(name) ~= "string" then return "" end
  return string.upper(string.match(name, "^%s*([A-Za-z]+%d+)%s*[:%-]?%s+") or "")
end

NerveMapContext = NerveMapContext or {}

function NerveMapContext.findShortcutValue(value, names, depth)
  if type(value) ~= "table" or depth > 6 then return nil end
  for key, candidate in pairs(value) do
    if names[string.lower(tostring(key))] and type(candidate) ~= "table" then return candidate end
  end
  for _, candidate in pairs(value) do
    local nested = NerveMapContext.findShortcutValue(candidate, names, depth + 1)
    if nested ~= nil then return nested end
  end
  return nil
end

function NerveMapContext.collectImageShortcutLinks(value, links, seen, grid, depth)
  if type(value) ~= "table" or depth > 12 or #links >= MAX_MAP_RECORD_LINKS then return end
  if string.lower(tostring(value.type or "")) == "shortcut" then
    local recordId = tostring(NerveMapContext.findShortcutValue(value, {
      recordname = true, record = true, recordid = true, linkrecord = true
    }, 0) or "")
    local windowClass = tostring(NerveMapContext.findShortcutValue(value, {
      class = true, windowclass = true, linkclass = true
    }, 0) or "")
    if recordId ~= "" and not seen[recordId] then
      local x = tonumber(NerveMapContext.findShortcutValue(value, { x = true, positionx = true }, 0))
      local y = tonumber(NerveMapContext.findShortcutValue(value, { y = true, positiony = true }, 0))
      local target = DB.findNode(recordId)
      local name = target and DB.getValue(target, "name", DB.getValue(target, "title", "")) or ""
      local recordType = RecordDataManager.getRecordTypeFromRecordPath(recordId) or
        RecordDataManager.getRecordTypeFromDisplayClass(windowClass) or "unknown"
      table.insert(links, {
        source = "native_map_shortcut", class = windowClass, recordId = recordId,
        recordType = recordType, name = string.sub(tostring(name or ""), 1, MAX_LIBRARY_FIELD_LENGTH), areaKey = areaKeyFromName(name),
        x = x, y = y,
        gridX = x and grid.enabled and ((x - grid.offsetX) / grid.sizeX) or nil,
        gridY = y and grid.enabled and ((y - grid.offsetY) / grid.sizeY) or nil
      })
      seen[recordId] = true
    end
  end
  for _, child in pairs(value) do NerveMapContext.collectImageShortcutLinks(child, links, seen, grid, depth + 1) end
end

function NerveMapContext.canonicalImageRecordId(recordId)
  if type(recordId) ~= "string" then return "" end
  return (string.gsub(recordId, "%.image(@.+)$", "%1"))
end

function NerveMapContext.collectEncounterPlacementLinks(mapRecordId, links, grid)
  local canonicalMapId = NerveMapContext.canonicalImageRecordId(mapRecordId)
  local focusModule = moduleFromRecordId(canonicalMapId)
  local seen = {}
  for _, mapping in ipairs(RecordDataManager.getDataPaths("battle") or {}) do
    for _, nodeBattle in pairs(DB.getChildrenGlobal(mapping) or {}) do
      if #links >= MAX_MAP_RECORD_LINKS then return end
      if focusModule == "" or (DB.getModule(nodeBattle) or "") == focusModule then
        local battleId = DB.getPath(nodeBattle)
        local battleName = DB.getValue(nodeBattle, "name", "")
        local areaKey = areaKeyFromName(battleName)
        local listPath = RecordDataManager.getCustomData("battle", "npclist", "npclist")
        for _, nodeEntry in ipairs(DB.getChildList(nodeBattle, listPath) or {}) do
          local entry = CombatRecordManager.getBattleEntryData(nodeEntry)
          for _, placement in ipairs(entry and entry.tAllPlacements or {}) do
            local x, y = tonumber(placement.imagex), tonumber(placement.imagey)
            local placementMapId = NerveMapContext.canonicalImageRecordId(placement.imagelink)
            local key = battleId .. ":" .. tostring(x) .. ":" .. tostring(y)
            if placementMapId == canonicalMapId and x and y and not seen[key] then
              table.insert(links, {
                source = "native_encounter_placement", class = "battle", recordId = battleId,
                recordType = "battle", name = string.sub(tostring(battleName or ""), 1, MAX_LIBRARY_FIELD_LENGTH),
                areaKey = areaKey, x = x, y = y,
                gridX = grid.enabled and ((x - grid.offsetX) / grid.sizeX) or nil,
                gridY = grid.enabled and ((y - grid.offsetY) / grid.sizeY) or nil
              })
              seen[key] = true
              if #links >= MAX_MAP_RECORD_LINKS then return end
            end
          end
        end
      end
    end
  end
end

local function createMapSceneState(openMaps)
  local scene = {
    recordId = "", name = "", panel = "none", shareMode = "none", holders = {},
    playStyle = getScenePlayStyle(),
    grid = { enabled = false, sizeX = 0, sizeY = 0, offsetX = 0, offsetY = 0, type = 0 },
    viewport = { width = 0, height = 0 },
    areaContinuity = { currentAreaKey = DB.getValue("nerve.areacontinuity.currentarea", ""), areas = {} },
    spatial = {
      coordinateSystem = "pixels", partyTokenCount = 0, foeTokenCount = 0, neutralTokenCount = 0,
      unlinkedTokenCount = 0, visionModel = "native_token_and_ct_visibility",
      partyAreaCandidates = {}, foeAreaCandidates = {},
      limitations = {
        "Coordinates do not prove line of sight, reach, adjacency, discovery, or a traversable route.",
        "Native masks, fog, walls, doors, lighting, token vision, and player viewport remain authoritative."
      }, placementWarnings = {}
    },
    recordLinks = {}, tokens = {},
    observedAt = os.date("!%Y-%m-%dT%H:%M:%SZ")
  }
  for _, nodeArea in pairs(DB.getChildren("nerve.areacontinuity") or {}) do
    local key = DB.getName(nodeArea)
    if key ~= "currentarea" then
      local status = DB.getValue(nodeArea, "status", "unknown")
      if status ~= "visited" and status ~= "resolved" and status ~= "bypassed" and status ~= "current" then status = "unknown" end
      table.insert(scene.areaContinuity.areas, { key = key, status = status })
    end
  end
  table.sort(scene.areaContinuity.areas, function(left, right) return left.key < right.key end)
  if not openMaps.currentMapId then return scene end

  local current
  for _, map in ipairs(openMaps.maps or {}) do
    if map.recordId == openMaps.currentMapId then current = map break end
  end
  if not current then return scene end
  scene.recordId = current.recordId
  scene.name = current.name
  scene.panel = current.panel
  scene.shareMode = current.shareMode
  scene.holders = current.holders

  local imageControl
  for _, candidate in ipairs(ImageManager.getActiveImages() or {}) do
    local nodeImage = candidate.getDatabaseNode and candidate.getDatabaseNode() or nil
    local nodeRecord = nodeImage and DB.getParent(nodeImage) or nil
    if nodeRecord and DB.getPath(nodeRecord) == current.recordId then imageControl = candidate break end
  end
  if not imageControl then return scene end
  local nodeImage = imageControl.getDatabaseNode()
  local imageData = DB.getValue(nodeImage) or {}
  local gridX = tonumber(imageData.gridsizex) or 0
  local gridY = tonumber(imageData.gridsizey) or 0
  scene.grid = {
    enabled = gridX > 0 and gridY > 0,
    sizeX = gridX, sizeY = gridY,
    offsetX = tonumber(imageData.gridoffsetx) or 0,
    offsetY = tonumber(imageData.gridoffsety) or 0,
    type = tonumber(imageData.gridtype) or 0
  }
  NerveMapContext.collectImageShortcutLinks(imageData, scene.recordLinks, {}, scene.grid, 0)
  NerveMapContext.collectEncounterPlacementLinks(current.recordId, scene.recordLinks, scene.grid)
  table.sort(scene.recordLinks, function(left, right)
    if left.areaKey ~= right.areaKey then return left.areaKey < right.areaKey end
    return string.lower(left.name) < string.lower(right.name)
  end)
  if scene.grid.enabled then scene.spatial.coordinateSystem = "grid" end
  if imageControl.getSize then
    local width, height = imageControl.getSize()
    scene.viewport = { width = tonumber(width) or 0, height = tonumber(height) or 0 }
  end
  for _, token in ipairs(imageControl.getTokens() or {}) do
    if #scene.tokens >= 200 then break end
    local nodeCT = CombatManager.getCTFromToken(token)
    local x, y = token.getPosition()
    local pixelX, pixelY = tonumber(x) or 0, tonumber(y) or 0
    local faction = nodeCT and DB.getValue(nodeCT, "friendfoe", "") or "unknown"
    if faction ~= "friend" and faction ~= "foe" and faction ~= "neutral" then faction = "unknown" end
    local visible = token.isVisible and token.isVisible() or true
    local playerVisible = nodeCT and ActorManager.isVisible(nodeCT) or visible ~= false
    local gridPositionX = scene.grid.enabled and ((pixelX - scene.grid.offsetX) / scene.grid.sizeX) or nil
    local gridPositionY = scene.grid.enabled and ((pixelY - scene.grid.offsetY) / scene.grid.sizeY) or nil
    table.insert(scene.tokens, {
      tokenId = tostring(token.getId()),
      name = nodeCT and DB.getValue(nodeCT, "name", "") or (token.getPrototype and token.getPrototype() or ""),
      combatantId = nodeCT and DB.getName(nodeCT) or "",
      faction = faction, x = pixelX, y = pixelY,
      gridX = gridPositionX, gridY = gridPositionY,
      playerVisible = playerVisible == true
    })
  end
  local friendTokens = {}
  local foeTokens = {}
  local neutralTokens = {}
  for _, token in ipairs(scene.tokens) do
    if token.combatantId == "" then scene.spatial.unlinkedTokenCount = scene.spatial.unlinkedTokenCount + 1 end
    if token.faction == "friend" then table.insert(friendTokens, token)
    elseif token.faction == "foe" then table.insert(foeTokens, token)
    elseif token.faction == "neutral" then table.insert(neutralTokens, token) end
  end
  scene.spatial.partyTokenCount = #friendTokens
  scene.spatial.foeTokenCount = #foeTokens
  scene.spatial.neutralTokenCount = #neutralTokens
  local function centroid(tokens)
    if #tokens == 0 then return nil end
    local x, y, gridPositionX, gridPositionY = 0, 0, 0, 0
    for _, token in ipairs(tokens) do
      x = x + token.x; y = y + token.y
      gridPositionX = gridPositionX + (token.gridX or 0); gridPositionY = gridPositionY + (token.gridY or 0)
    end
    return {
      x = x / #tokens, y = y / #tokens,
      gridX = scene.grid.enabled and (gridPositionX / #tokens) or nil,
      gridY = scene.grid.enabled and (gridPositionY / #tokens) or nil
    }
  end
  scene.spatial.partyCentroid = centroid(friendTokens)
  scene.spatial.foeCentroid = centroid(foeTokens)
  local nearest
  if scene.grid.enabled and #friendTokens > 0 then
    for _, token in ipairs(scene.tokens) do
      local minimum
      for _, friend in ipairs(friendTokens) do
        local dx, dy = token.gridX - friend.gridX, token.gridY - friend.gridY
        local distance = math.sqrt(dx * dx + dy * dy)
        if not minimum or distance < minimum then minimum = distance end
      end
      token.distanceFromPartyGridUnits = minimum
      if token.faction == "foe" and token.playerVisible and (not nearest or minimum < nearest.distanceGridUnits) then
        nearest = { tokenId = token.tokenId, combatantId = token.combatantId, name = token.name, distanceGridUnits = minimum }
      end
    end
  end
  scene.spatial.nearestVisibleHostile = nearest
  local partyAreaCandidates, foeAreaCandidates = {}, {}
  local function assignAreaCandidate(token, destination)
    local nearestArea
    for _, link in ipairs(scene.recordLinks) do
      if link.areaKey ~= "" and link.gridX and link.gridY and token.gridX and token.gridY then
        local dx, dy = token.gridX - link.gridX, token.gridY - link.gridY
        local distance = math.sqrt(dx * dx + dy * dy)
        if distance <= 6 and (not nearestArea or distance < nearestArea.distanceGridUnits) then
          nearestArea = { key = link.areaKey, name = link.name, recordId = link.recordId, distanceGridUnits = distance }
        end
      end
    end
    if nearestArea then
      token.areaCandidateKey = nearestArea.key
      token.areaCandidateRecordId = nearestArea.recordId
      token.distanceFromAreaMarkerGridUnits = nearestArea.distanceGridUnits
      destination[nearestArea.key] = nearestArea
    end
  end
  for _, token in ipairs(friendTokens) do assignAreaCandidate(token, partyAreaCandidates) end
  for _, token in ipairs(foeTokens) do assignAreaCandidate(token, foeAreaCandidates) end
  scene.spatial.partyAreaCandidates = {}
  scene.spatial.foeAreaCandidates = {}
  for _, candidate in pairs(partyAreaCandidates) do table.insert(scene.spatial.partyAreaCandidates, candidate) end
  for _, candidate in pairs(foeAreaCandidates) do table.insert(scene.spatial.foeAreaCandidates, candidate) end
  table.sort(scene.spatial.partyAreaCandidates, function(left, right) return left.key < right.key end)
  table.sort(scene.spatial.foeAreaCandidates, function(left, right) return left.key < right.key end)
  if #scene.recordLinks > 0 then
    table.insert(scene.spatial.limitations, "Nearest native map shortcuts and encounter placements are area candidates only; they do not prove room membership, encounter activation, or discovery.")
  end
  local areasDiffer = #scene.spatial.partyAreaCandidates > 0 and #scene.spatial.foeAreaCandidates > 0
  if areasDiffer then
    for key in pairs(partyAreaCandidates) do if foeAreaCandidates[key] then areasDiffer = false break end end
  end
  if areasDiffer then
    local partyKeys, foeKeys = {}, {}
    for key in pairs(partyAreaCandidates) do table.insert(partyKeys, key) end
    for key in pairs(foeAreaCandidates) do table.insert(foeKeys, key) end
    table.sort(partyKeys); table.sort(foeKeys)
    table.insert(scene.spatial.placementWarnings,
      "Party and hostile tokens have different native linked-area candidates (party " ..
      table.concat(partyKeys, "/") .. "; foes " .. table.concat(foeKeys, "/") .. ").")
  end
  if #friendTokens == 0 and (#foeTokens > 0 or #neutralTokens > 0) then
    table.insert(scene.spatial.placementWarnings, "No friendly party token is present on the current map; spatial relationships are incomplete.")
  elseif nearest and nearest.distanceGridUnits > 12 then
    table.insert(scene.spatial.placementWarnings, "The nearest player-visible hostile is more than 12 grid units from the party; confirm token placement and scene identity.")
  end
  table.sort(scene.tokens, function(left, right)
    if left.name == right.name then return left.tokenId < right.tokenId end
    return string.lower(left.name) < string.lower(right.name)
  end)
  return scene
end

local function persistManualAdjudication(context, sourceName, targetId, targetName, actionName, description)
  for _, nodeTask in pairs(DB.getChildren("nerve.manualadjudications") or {}) do
    if DB.getValue(nodeTask, "correlationid", "") == context.requestId and
        DB.getValue(nodeTask, "targetid", "") == targetId then return DB.getName(nodeTask) end
  end
  local nodeRoot = DB.createNode("nerve.manualadjudications")
  local nodeTask = nodeRoot and DB.createChild(nodeRoot) or nil
  if not nodeTask then return "" end
  DB.setValue(nodeTask, "correlationid", "string", context.requestId)
  DB.setValue(nodeTask, "sourceid", "string", context.combatantId)
  DB.setValue(nodeTask, "sourcename", "string", sourceName)
  DB.setValue(nodeTask, "targetid", "string", targetId)
  DB.setValue(nodeTask, "targetname", "string", targetName)
  DB.setValue(nodeTask, "actionname", "string", actionName)
  DB.setValue(nodeTask, "text", "string", string.sub(description, 1, 1000))
  DB.setValue(nodeTask, "status", "string", "pending")
  DB.setValue(nodeTask, "createdat", "string", os.date("!%Y-%m-%dT%H:%M:%SZ"))
  return DB.getName(nodeTask)
end

local function boundedString(value)
  local text = tostring(value or "")
  if #text > MAX_LIBRARY_FIELD_LENGTH then
    return string.sub(text, 1, MAX_LIBRARY_FIELD_LENGTH)
  end
  return text
end

local function collectLibraryFields(node, prefix, fields, state, depth)
  if depth > 5 or state.count >= MAX_LIBRARY_FIELDS then return end
  for _, child in pairs(DB.getChildren(node) or {}) do
    if state.count >= MAX_LIBRARY_FIELDS then return end
    local childName = DB.getName(child)
    local path = prefix == "" and childName or (prefix .. "." .. childName)
    local childType = DB.getType(child)
    if LIBRARY_TEXT_FIELDS[childName] and childType ~= "node" then
      local value = DB.getValue(child, "", "")
      if value ~= nil and tostring(value) ~= "" then
        fields[path] = boundedString(value)
        state.count = state.count + 1
      end
    end
    if childType == "windowreference" and state.count + 2 <= MAX_LIBRARY_FIELDS then
      local windowClass, recordId = DB.getValue(child, "", "", "")
      if type(recordId) == "string" and recordId ~= "" then
        fields[path .. ".class"] = boundedString(windowClass)
        fields[path .. ".record"] = boundedString(recordId)
        state.count = state.count + 2
      end
    end
    if childType == "node" then
      collectLibraryFields(child, path, fields, state, depth + 1)
    end
  end
end

local createCharacters

local function createLibraryCatalog(focusModule, characters)
  local records = {}
  local recordIds = {}
  local truncated = false
  for _, recordType in ipairs(LIBRARY_RECORD_TYPES) do
    local typeCount, candidates, seen = 0, {}, {}
    local typeLimit = LIBRARY_TYPE_LIMITS[recordType]
    for _, mapping in ipairs(RecordDataManager.getDataPaths(recordType) or {}) do
      for _, node in pairs(DB.getChildrenGlobal(mapping) or {}) do
        local id = DB.getPath(node)
        if not seen[id] then table.insert(candidates, node); seen[id] = true end
      end
    end
    table.sort(candidates, function(left, right)
      local leftModule, rightModule = DB.getModule(left) or "", DB.getModule(right) or ""
      local leftPriority = leftModule == focusModule and 0 or (leftModule == "" and 1 or 2)
      local rightPriority = rightModule == focusModule and 0 or (rightModule == "" and 1 or 2)
      if leftPriority ~= rightPriority then return leftPriority < rightPriority end
      local leftName = DB.getValue(left, "name", DB.getValue(left, "title", ""))
      local rightName = DB.getValue(right, "name", DB.getValue(right, "title", ""))
      return string.lower(leftName) < string.lower(rightName)
    end)
    if #candidates > typeLimit then truncated = true end
    for index = 1, math.min(#candidates, typeLimit) do
      local node, fields = candidates[index], {}
      collectLibraryFields(node, "", fields, { count = 0 }, 0)
      local name = DB.getValue(node, "name", DB.getValue(node, "title", ""))
      table.insert(records, {
        id = DB.getPath(node), name = boundedString(name), recordType = recordType,
        module = DB.getModule(node) or "", category = DB.getCategory(node) or "", fields = fields
      })
      recordIds[DB.getPath(node)] = true
      typeCount = typeCount + 1
    end
  end
  local referencedCount = 0
  for _, character in ipairs(characters or {}) do
    for _, link in ipairs(character.referenceLinks or {}) do
      if referencedCount >= 200 then break end
      local node = NerveCharacterContext.allowedRecordTypes[link.recordType] and
        not recordIds[link.recordId] and DB.findNode(link.recordId) or nil
      if node then
        local fields = {}
        collectLibraryFields(node, "", fields, { count = 0 }, 0)
        table.insert(records, {
          id = link.recordId, name = boundedString(link.name), recordType = link.recordType,
          module = link.module, category = DB.getCategory(node) or "", fields = fields
        })
        recordIds[link.recordId] = true
        referencedCount = referencedCount + 1
      end
    end
  end
  for _, cueNode in pairs(DB.getChildren("nerve.storycues.entries") or {}) do
    local cueRecordId = DB.getValue(cueNode, "recordid", "")
    local cueRecordType = DB.getValue(cueNode, "recordtype", "")
    local node = cueRecordId ~= "" and not recordIds[cueRecordId] and DB.findNode(cueRecordId) or nil
    if node and LIBRARY_TYPE_LIMITS[cueRecordType] then
      local fields = {}
      collectLibraryFields(node, "", fields, { count = 0 }, 0)
      table.insert(records, { id = cueRecordId, name = boundedString(DB.getValue(node, "name", cueRecordId)), recordType = cueRecordType, module = DB.getModule(node) or "", category = DB.getCategory(node) or "", fields = fields })
      recordIds[cueRecordId] = true
    end
  end
  table.sort(records, function(left, right)
    if left.name == right.name then return left.id < right.id end
    return string.lower(left.name) < string.lower(right.name)
  end)
  return {
    schemaVersion = "0.3",
    focusModule = focusModule or "",
    characterReferenceRecords = referencedCount,
    records = records,
    truncated = truncated,
    observedAt = os.date("!%Y-%m-%dT%H:%M:%SZ")
  }
end

preferredAdventureLabel = function(counts, moduleId)
  local label, count = moduleId, -1
  for candidate, candidateCount in pairs(counts or {}) do
    if candidateCount > count or (candidateCount == count and #candidate > #label) then
      label, count = candidate, candidateCount
    end
  end
  return label
end

function getAdventureSourceOptions()
  local byModule = {}
  local seen = {}
  for _, recordType in ipairs({ "story", "quest", "battle", "image" }) do
    for _, mapping in ipairs(RecordDataManager.getDataPaths(recordType) or {}) do
      for _, node in pairs(DB.getChildrenGlobal(mapping) or {}) do
        local recordId = DB.getPath(node)
        local moduleId = DB.getModule(node) or ""
        if moduleId ~= "" and not seen[recordId] then
          seen[recordId] = true
          local option = byModule[moduleId] or { moduleId = moduleId, recordCount = 0, labels = {} }
          option.recordCount = option.recordCount + 1
          local category = DB.getCategory(node) or ""
          if category ~= "" then option.labels[category] = (option.labels[category] or 0) + 1 end
          byModule[moduleId] = option
        end
      end
    end
  end
  local options = {}
  for moduleId, option in pairs(byModule) do
    option.displayName = preferredAdventureLabel(option.labels, moduleId)
    option.labels = nil
    table.insert(options, option)
  end
  table.sort(options, function(left, right)
    if left.recordCount ~= right.recordCount then return left.recordCount > right.recordCount end
    return string.lower(left.displayName) < string.lower(right.displayName)
  end)
  return options
end

createCampaignFocusState = function(mapScene)
  local moduleId = DB.getValue("nerve.campaignfocus.module", "")
  local displayName = DB.getValue("nerve.campaignfocus.displayname", "")
  local count = 0
  for _, record in ipairs(libraryCatalog and libraryCatalog.records or {}) do
    if record.module == moduleId then count = count + 1 end
  end
  return {
    activeAdventureModule = moduleId,
    displayName = displayName,
    status = moduleId == "" and "not_selected" or (count > 0 and "ready" or "source_unavailable"),
    recordCount = count,
    confirmedAt = DB.getValue("nerve.campaignfocus.confirmedat", ""),
    suggestedModule = moduleFromRecordId(mapScene and mapScene.recordId or ""),
    creativeAuthority = DB.getValue("nerve.campaignfocus.creativeauthority", "bounded_improvisation")
  }
end

function getAdventureSourceState()
  return createCampaignFocusState(createMapSceneState(createOpenMapState()))
end

function setAdventureSource(moduleId, displayName, creativeAuthority)
  if not Session.IsHost then return false end
  moduleId = tostring(moduleId or "")
  displayName = tostring(displayName or "")
  creativeAuthority = creativeAuthority == "module_strict" and "module_strict" or "bounded_improvisation"
  local valid = moduleId == ""
  for _, option in ipairs(getAdventureSourceOptions()) do
    if option.moduleId == moduleId then valid = true; displayName = option.displayName; break end
  end
  if not valid then ChatManager.SystemMessage("Nerve: that adventure source is not currently available."); return false end
  DB.setValue("nerve.campaignfocus.module", "string", moduleId)
  DB.setValue("nerve.campaignfocus.displayname", "string", displayName)
  DB.setValue("nerve.campaignfocus.confirmedat", "string", moduleId ~= "" and os.date("!%Y-%m-%dT%H:%M:%SZ") or "")
  DB.setValue("nerve.campaignfocus.creativeauthority", "string", creativeAuthority)
  libraryCatalog = createLibraryCatalog(moduleId, createCharacters())
  local encoded = Utility.encodeJSON(libraryCatalog)
  if encoded then File.saveTextFile(File.getCampaignFolder() .. "/" .. LIBRARY_FILENAME, encoded) end
  publishSnapshot("adventure-source-changed", {
    type = "campaign.focus_changed", actor = "GM", visibility = "gm", subjectId = moduleId,
    text = moduleId ~= "" and ("Active adventure set to " .. displayName .. ".") or "Active adventure cleared.",
    data = { moduleId = moduleId, displayName = displayName, creativeAuthority = creativeAuthority }
  })
  ChatManager.SystemMessage(moduleId ~= "" and ("Nerve active adventure: " .. displayName .. ".") or "Nerve active adventure cleared.")
  refreshNerveControlWindows()
  return true
end

function storyCueNodes()
  local nodes = {}
  for _, node in pairs(DB.getChildren("nerve.storycues.entries") or {}) do table.insert(nodes, node) end
  table.sort(nodes, function(left, right) return DB.getValue(left, "sequence", 0) < DB.getValue(right, "sequence", 0) end)
  return nodes
end

function getStoryCueState()
  local entries = {}
  for _, node in ipairs(storyCueNodes()) do
    table.insert(entries, {
      id = DB.getName(node), recordId = DB.getValue(node, "recordid", ""), recordType = DB.getValue(node, "recordtype", ""),
      name = DB.getValue(node, "name", "Untitled record"), module = DB.getValue(node, "module", ""),
      lifetime = DB.getValue(node, "lifetime", "scene"), addedAt = DB.getValue(node, "addedat", ""), status = DB.getValue(node, "status", "active")
    })
  end
  return { entries = entries, count = #entries, hostOnly = true, defaultLifetime = DB.getValue("nerve.storycues.defaultlifetime", "scene") }
end

function createQuestLogState()
  local quests = {}
  local activeCount = 0
  for _, node in pairs(DB.getChildren("quest") or {}) do
    local status = DB.getValue(node, "nerve.status", "active")
    if status ~= "offered" and status ~= "accepted" and status ~= "active" and status ~= "completed" and status ~= "failed" and status ~= "abandoned" then status = "active" end
    if status == "accepted" or status == "active" then activeCount = activeCount + 1 end
    table.insert(quests, {
      id = DB.getName(node), name = string.sub(tostring(DB.getValue(node, "name", "Untitled Quest")), 1, 200),
      description = string.sub(tostring(DB.getValue(node, "description", "")), 1, 2000), status = status,
      giver = string.sub(tostring(DB.getValue(node, "nerve.giver", "")), 1, 200), location = string.sub(tostring(DB.getValue(node, "nerve.location", "")), 1, 200),
      reward = string.sub(tostring(DB.getValue(node, "nerve.reward", "")), 1, 300), provenance = DB.getValue(node, "nerve.provenance", "gm"),
      sourceRecordId = string.sub(tostring(DB.getValue(node, "nerve.sourcerecordid", "")), 1, 512), updatedAt = DB.getValue(node, "nerve.updatedat", "")
    })
  end
  table.sort(quests, function(left, right) return string.lower(left.name) < string.lower(right.name) end)
  while #quests > 100 do table.remove(quests) end
  return { quests = quests, count = #quests, activeCount = activeCount }
end

function getStoryCueText()
  local state = getStoryCueState()
  if #state.entries == 0 then return "Drop a Story, Quest, NPC, Image, Battle, or other supported record here.\nCues are private to the GM and guide the AI without revealing or executing the record." end
  local lines = {}
  for index, cue in ipairs(state.entries) do table.insert(lines, string.format("%d. [%s] %s · %s", index, string.upper(cue.lifetime), cue.name, cue.recordType)) end
  return table.concat(lines, "\n")
end

function getStoryCueLifetimeText()
  local labels = { once = "Next answer", scene = "Current scene", session = "This session" }
  return labels[DB.getValue("nerve.storycues.defaultlifetime", "scene")] or "Current scene"
end

function cycleStoryCueLifetime()
  if not Session.IsHost then return end
  local current = DB.getValue("nerve.storycues.defaultlifetime", "scene")
  DB.setValue("nerve.storycues.defaultlifetime", "string", current == "once" and "scene" or (current == "scene" and "session" or "once"))
end

function addStoryCue(recordType, recordId)
  if not Session.IsHost then ChatManager.SystemMessage("Nerve Story Cues are available only on the GM host."); return false end
  recordType = tostring(recordType or "")
  recordId = tostring(recordId or "")
  recordType = RecordDataManager.getRecordTypeFromRecordPath(recordId) or
    RecordDataManager.getRecordTypeFromDisplayClass(recordType) or recordType
  if not STORY_CUE_RECORD_TYPES[recordType] or recordId == "" then ChatManager.SystemMessage("Nerve: unsupported link type " .. recordType .. ". Drag the record link icon from a Story, Quest, NPC, Image, or Battle entry."); return false end
  local nodeRecord = DB.findNode(recordId)
  if not nodeRecord then ChatManager.SystemMessage("Nerve: that record is not currently available."); return false end
  for _, node in ipairs(storyCueNodes()) do
    if DB.getValue(node, "recordid", "") == recordId then ChatManager.SystemMessage("Nerve: that story cue is already pinned."); return false end
  end
  local sequence = DB.getValue("nerve.storycues.nextsequence", 0) + 1
  DB.setValue("nerve.storycues.nextsequence", "number", sequence)
  local root = DB.createNode("nerve.storycues.entries")
  local node = root and DB.createChild(root, string.format("cue-%06d", sequence)) or nil
  if not node then return false end
  DB.setValue(node, "sequence", "number", sequence)
  DB.setValue(node, "recordid", "string", recordId)
  DB.setValue(node, "recordtype", "string", recordType)
  DB.setValue(node, "name", "string", DB.getValue(nodeRecord, "name", recordId))
  DB.setValue(node, "module", "string", DB.getModule(nodeRecord) or "")
  DB.setValue(node, "lifetime", "string", DB.getValue("nerve.storycues.defaultlifetime", "scene"))
  DB.setValue(node, "status", "string", "active")
  DB.setValue(node, "addedat", "string", os.date("!%Y-%m-%dT%H:%M:%SZ"))
  local nodes = storyCueNodes()
  if #nodes > MAX_STORY_CUES then DB.deleteNode(DB.getPath(nodes[1])) end
  libraryCatalog = createLibraryCatalog(DB.getValue("nerve.campaignfocus.module", ""), createCharacters())
  local libraryEncoded = Utility.encodeJSON(libraryCatalog)
  if libraryEncoded then File.saveTextFile(File.getCampaignFolder() .. "/" .. LIBRARY_FILENAME, libraryEncoded) end
  publishSnapshot("story-cue-added", { type = "story.cue_added", actor = "GM", text = "Private story reference pinned: " .. DB.getValue(node, "name", recordId), visibility = "gm", subjectId = recordId, data = { recordType = recordType, lifetime = DB.getValue(node, "lifetime", "scene") } })
  ChatManager.SystemMessage("Nerve Story Cue pinned privately: " .. DB.getValue(node, "name", recordId) .. ".")
  return true
end

function clearStoryCues()
  if not Session.IsHost then return false end
  local root = DB.findNode("nerve.storycues.entries")
  if root then for _, node in pairs(DB.getChildren(root) or {}) do DB.deleteNode(DB.getPath(node)) end end
  publishSnapshot("story-cues-cleared", { type = "story.cues_cleared", actor = "GM", text = "Private story cues cleared.", visibility = "gm" })
  return true
end

function consumeOneShotStoryCues(cueId)
  local used = {}
  for _, node in ipairs(storyCueNodes()) do
    if DB.getValue(node, "status", "active") == "active" then
      table.insert(used, DB.getValue(node, "recordid", ""))
      if DB.getValue(node, "lifetime", "scene") == "once" then DB.deleteNode(DB.getPath(node)) end
    end
  end
  DB.setValue("nerve.storycues.lastanswercueid", "string", cueId or "")
  DB.setValue("nerve.storycues.lastanswerrecords", "string", Utility.encodeJSON(used) or "[]")
  return used
end

function expireStoryCues(lifetimes)
  for _, node in ipairs(storyCueNodes()) do
    if lifetimes[DB.getValue(node, "lifetime", "scene")] then DB.deleteNode(DB.getPath(node)) end
  end
end

function openStoryCueTower()
  if not Session.IsHost then ChatManager.SystemMessage("Nerve Story Cues are available only on the GM host."); return end
  Interface.openWindow("nerve_story_cues", "")
end

local function getPendingPlayerResponseCount()
  local now = os.time()
  local count = 0
  for _, prompt in pairs(pendingPlayerPrompts) do
    for username, status in pairs(prompt.statuses or {}) do
      if (status == "sent" or status == "received" or status == "displayed" or status == "pending") and now > prompt.deadlineEpoch then
        prompt.statuses[username] = "timed_out"
        status = "timed_out"
      end
      if status == "sent" or status == "received" or status == "displayed" or status == "pending" then count = count + 1 end
    end
  end
  return count
end

local function sessionMetric(name)
  return DB.getValue("nerve.sessionoperations." .. name, 0)
end

local function incrementSessionMetric(name)
  if DB.getValue("nerve.sessionoperations.status", "not_started") ~= "active" then return end
  DB.setValue("nerve.sessionoperations." .. name, "number", sessionMetric(name) + 1)
end

local function createApprovalPolicyState()
  local automaticCapabilities = {}
  if sessionGrants.send_chat then
    table.insert(automaticCapabilities, "send_chat")
    table.insert(automaticCapabilities, "request_player_input")
    table.insert(automaticCapabilities, "request_player_roll")
  end
  if sessionGrants.proxy_actions and playerProxyMode == "all" then
    table.insert(automaticCapabilities, "proxy_character_roll")
    table.insert(automaticCapabilities, "proxy_character_power_action")
    table.insert(automaticCapabilities, "proxy_combatant_action")
  end
  if sessionGrants.combat_pacing then
    table.insert(automaticCapabilities, "start_encounter")
    table.insert(automaticCapabilities, "begin_story_encounter")
    table.insert(automaticCapabilities, "begin_story_npc_encounter")
    table.insert(automaticCapabilities, "advance_turn")
  end
  local grantCount = (sessionGrants.send_chat and 1 or 0) + (sessionGrants.proxy_actions and 1 or 0) +
    (sessionGrants.combat_pacing and 1 or 0)
  local mode = grantCount == 0 and "manual" or (grantCount == 3 and "flow" or "custom")
  return {
    mode = mode,
    narrativeFlow = sessionGrants.send_chat == true,
    proxyActions = sessionGrants.proxy_actions == true,
    combatPacing = sessionGrants.combat_pacing == true,
    entityProxy = playerProxyMode == "all",
    automaticCapabilities = automaticCapabilities,
    alwaysManualCapabilities = {
      "request_vote", "add_library_npc",
      "add_library_encounter", "open_library_image", "set_spell_slot_usage", "apply_effect",
      "remove_effect", "remove_combatant", "resolve_manual_adjudication", "set_combatant_threat",
      "set_combatant_visibility", "create_quest", "update_quest", "record_session_continuity"
    }
  }
end

local function createSessionOperationsState(summary, tracker, party)
  local status = DB.getValue("nerve.sessionoperations.status", "not_started")
  local held = DB.getValue("nerve.sessionoperations.held", 0) == 1
  local actionCount = sessionMetric("actionsprocessed")
  local approved = sessionMetric("approved")
  local denied = sessionMetric("denied")
  local failed = sessionMetric("failed")
  local grantExecutions = sessionMetric("sessiongrantexecutions")
  local pendingAdjudications = #createManualAdjudicationState().tasks
  local pendingResponses = getPendingPlayerResponseCount()
  local summaryText
  if status == "active" then
    summaryText = string.format(
      "Session active%s. %d action(s): %d approved, %d denied, %d failed; %d via session grants.",
      held and " and HELD" or "", actionCount, approved, denied, failed, grantExecutions
    )
  elseif status == "ended" then
    summaryText = string.format(
      "Session ended. %d action(s): %d approved, %d denied, %d failed; %d via session grants.",
      actionCount, approved, denied, failed, grantExecutions
    )
  else
    summaryText = "Session tracking is off; approvals remain available."
  end
  return {
    status = status,
    held = held,
    playStyle = getScenePlayStyle(),
    sessionId = DB.getValue("nerve.sessionoperations.sessionid", ""),
    startedAt = DB.getValue("nerve.sessionoperations.startedat", ""),
    endedAt = DB.getValue("nerve.sessionoperations.endedat", ""),
    resumedFromCheckpointId = DB.getValue("nerve.sessionoperations.resumedfromcheckpointid", ""),
    openingMode = DB.getValue("nerve.sessionoperations.openingmode", ""),
    openingStatus = DB.getValue("nerve.sessionoperations.openingstatus", ""),
    actionsProcessed = actionCount,
    approved = approved,
    denied = denied,
    failed = failed,
    sessionGrantExecutions = grantExecutions,
    approvalPolicy = createApprovalPolicyState(),
    connectedPlayers = summary.connectedPlayers or 0,
    partyMembers = #(party.members or {}),
    combatants = #(tracker.combatants or {}),
    libraryIndexed = libraryCatalog and #(libraryCatalog.records or {}) or 0,
    pendingPlayerResponses = pendingResponses,
    pendingManualAdjudications = pendingAdjudications,
    summary = summaryText,
    observedAt = os.date("!%Y-%m-%dT%H:%M:%SZ")
  }
end

local function isDefeatedCombatant(nodeCombatant)
  local total = DB.getValue(nodeCombatant, "hptotal", DB.getValue(nodeCombatant, "hp", 0))
  local wounds = DB.getValue(nodeCombatant, "wounds", 0)
  if total > 0 and wounds >= total then return true end
  local status = string.lower(DB.getValue(nodeCombatant, "status", ""))
  return status == "dead" or status == "dying" or status == "unconscious" or status == "escaped" or status == "dormant"
end

local function getCombatState()
  local combatants = DB.getChildren("combattracker.list") or {}
  local activeThreats = 0
  local activeId = nil

  for _, nodeCombatant in pairs(combatants) do
    if DB.getValue(nodeCombatant, "friendfoe", "") == "foe" and not isDefeatedCombatant(nodeCombatant) then
      activeThreats = activeThreats + 1
    end
    if DB.getValue(nodeCombatant, "active", 0) == 1 then
      activeId = DB.getName(nodeCombatant)
    end
  end

  return activeThreats > 0, activeId
end

local function createCampaignSummary()
  local inCombat = getCombatState()
  local activeUsers = User.getActiveUsers() or {}

  return {
    campaignId = User.getCampaignName(),
    name = User.getCampaignName(),
    ruleset = User.getRulesetName(),
    connectedPlayers = countEntries(activeUsers),
    inCombat = inCombat,
    activeEncounterId = inCombat and "combat-tracker" or nil,
    observedAt = os.date("!%Y-%m-%dT%H:%M:%SZ")
  }
end

local function normalizeFaction(value)
  if value == "friend" or value == "foe" or value == "neutral" then
    return value
  end
  return "unknown"
end

local function combatantDisposition(nodeCombatant, totalHitPoints, wounds, status)
  local lowered = string.lower(status or "")
  if lowered == "dead" then return "dead" end
  if lowered == "dying" then return "defeated" end
  if lowered == "unconscious" then return "unconscious" end
  if lowered == "escaped" then return "escaped" end
  if lowered == "dormant" then return "dormant" end
  if totalHitPoints > 0 and wounds >= totalHitPoints then return "defeated" end
  return "active"
end

local function createEffects(nodeCombatant)
  local effects = {}
  local nodeEffects = DB.getChild(nodeCombatant, "effects")
  local effectNodes = nodeEffects and DB.getChildren(nodeEffects) or {}

  for _, nodeEffect in pairs(effectNodes) do
    table.insert(effects, {
      id = DB.getName(nodeEffect),
      label = DB.getValue(nodeEffect, "label", ""),
      duration = DB.getValue(nodeEffect, "duration", 0),
      initiative = DB.getValue(nodeEffect, "init", 0),
      active = DB.getValue(nodeEffect, "isactive", 0) ~= 0,
      gmOnly = DB.getValue(nodeEffect, "isgmonly", 0) ~= 0
    })
  end

  table.sort(effects, function(left, right)
    return left.id < right.id
  end)
  return effects
end

local function parseCombatantAction(nodeAction, section)
  local value = DB.getValue(nodeAction, "value", "")
  if value == "" then return nil end
  local parsed = CombatManager2.parseAttackLine(value)
  if not parsed then return nil end
  local abilities = {}
  for index, ability in ipairs(parsed.aAbilities or {}) do
    if COMBATANT_ACTION_TYPES[ability.sType] then
      local summary = ""
      if ability.nStart and ability.nEnd then
        summary = string.sub(value, math.max(1, ability.nStart - 1), math.min(#value, ability.nEnd + 1))
      end
      table.insert(abilities, { index = index, type = ability.sType, summary = summary })
    end
  end
  if #abilities == 0 then return nil end
  local hasSave = false
  local hasStructuredFollowUp = false
  for _, ability in ipairs(parsed.aAbilities or {}) do
    if ability.sType == "powersave" then hasSave = true end
    if ability.sType == "damage" or ability.sType == "effect" then hasStructuredFollowUp = true end
  end
  local result = {
    section = section,
    id = DB.getName(nodeAction),
    name = DB.getValue(nodeAction, "name", parsed.name or ""),
    description = DB.getValue(nodeAction, "desc", ""),
    value = value,
    manualAdjudicationOnFailure = hasSave and not hasStructuredFollowUp and DB.getValue(nodeAction, "desc", "") ~= "",
    abilities = abilities
  }
  local rechargeThreshold = tonumber(string.match(value, "%[R:(%d)%]"))
  if rechargeThreshold and rechargeThreshold >= 2 and rechargeThreshold <= 6 then
    result.usage = { type = "recharge", threshold = rechargeThreshold, used = parsed.sUsage == "USED" }
  end
  return result
end

local function createCombatantActions(nodeCombatant)
  local actions = {}
  for _, section in ipairs(COMBATANT_ACTION_SECTIONS) do
    for _, nodeAction in ipairs(DB.getChildList(nodeCombatant, section) or {}) do
      local action = parseCombatantAction(nodeAction, section)
      if action then table.insert(actions, action) end
    end
  end
  table.sort(actions, function(left, right)
    if left.section == right.section then return left.id < right.id end
    return left.section < right.section
  end)
  return actions
end

local function createCombatTracker()
  local combatants = {}
  local combatantNodes = DB.getChildren("combattracker.list") or {}

  for _, nodeCombatant in pairs(combatantNodes) do
    local totalHitPoints = DB.getValue(nodeCombatant, "hptotal", 0)
    if totalHitPoints == 0 then
      totalHitPoints = DB.getValue(nodeCombatant, "hp", 0)
    end

    local status = DB.getValue(nodeCombatant, "status", "")
    local wounds = DB.getValue(nodeCombatant, "wounds", 0)
    local disposition = combatantDisposition(nodeCombatant, totalHitPoints, wounds, status)
    table.insert(combatants, {
      id = DB.getName(nodeCombatant),
      name = DB.getValue(nodeCombatant, "name", ""),
      type = DB.getValue(nodeCombatant, "type", ""),
      faction = normalizeFaction(DB.getValue(nodeCombatant, "friendfoe", "")),
      initiative = DB.getValue(nodeCombatant, "initresult", 0),
      active = DB.getValue(nodeCombatant, "active", 0) == 1,
      status = status,
      disposition = disposition,
      threat = normalizeFaction(DB.getValue(nodeCombatant, "friendfoe", "")) == "foe" and disposition == "active",
      playerVisible = ActorManager.isVisible(nodeCombatant),
      hitPoints = {
        total = totalHitPoints,
        temporary = DB.getValue(nodeCombatant, "hptemp", 0),
        wounds = wounds
      },
      effects = createEffects(nodeCombatant),
      actions = createCombatantActions(nodeCombatant)
    })
  end

  table.sort(combatants, function(left, right)
    if left.initiative == right.initiative then
      return left.id < right.id
    end
    return left.initiative > right.initiative
  end)

  return {
    round = DB.getValue("combattracker.round", 0),
    combatants = combatants,
    observedAt = os.date("!%Y-%m-%dT%H:%M:%SZ")
  }
end

local function createAbility(nodeMember, scoreField, modifierField)
  return {
    score = DB.getValue(nodeMember, scoreField, 0),
    modifier = DB.getValue(nodeMember, modifierField, 0)
  }
end

local function getCharacterId(nodeMember)
  local _, recordName = DB.getValue(nodeMember, "link", "", "")
  if recordName and recordName ~= "" then
    return string.match(recordName, "([^%.]+)$") or recordName
  end
  return DB.getName(nodeMember)
end

local function createParty()
  local members = {}
  local memberNodes = DB.getChildren("partysheet.partyinformation") or {}

  for _, nodeMember in pairs(memberNodes) do
    table.insert(members, {
      id = getCharacterId(nodeMember),
      name = DB.getValue(nodeMember, "name", ""),
      race = DB.getValue(nodeMember, "race", ""),
      classLevel = DB.getValue(nodeMember, "classlevel", ""),
      armorClass = DB.getValue(nodeMember, "ac", 0),
      passivePerception = DB.getValue(nodeMember, "perception", 0),
      abilities = {
        strength = createAbility(nodeMember, "strength", "strbonus"),
        dexterity = createAbility(nodeMember, "dexterity", "dexbonus"),
        constitution = createAbility(nodeMember, "constitution", "conbonus"),
        intelligence = createAbility(nodeMember, "intelligence", "intbonus"),
        wisdom = createAbility(nodeMember, "wisdom", "wisbonus"),
        charisma = createAbility(nodeMember, "charisma", "chabonus")
      },
      experience = {
        current = DB.getValue(nodeMember, "exp", 0),
        nextLevel = DB.getValue(nodeMember, "expneeded", 0)
      },
      hitDice = {
        total = DB.getValue(nodeMember, "hd", 0),
        used = DB.getValue(nodeMember, "hdused", 0)
      },
      hitPoints = {
        total = DB.getValue(nodeMember, "hptotal", 0),
        wounds = DB.getValue(nodeMember, "wounds", 0)
      },
      senses = DB.getValue(nodeMember, "senses", "")
    })
  end

  table.sort(members, function(left, right)
    local leftName = string.lower(left.name or "")
    local rightName = string.lower(right.name or "")
    if leftName == rightName then
      return left.id < right.id
    end
    return leftName < rightName
  end)

  return {
    members = members,
    observedAt = os.date("!%Y-%m-%dT%H:%M:%SZ")
  }
end

local function createCharacterAbilities(nodeCharacter)
  local abilities = {}
  for _, abilityName in ipairs({ "strength", "dexterity", "constitution", "intelligence", "wisdom", "charisma" }) do
    local path = "abilities." .. abilityName
    abilities[abilityName] = {
      score = DB.getValue(nodeCharacter, path .. ".score", 0),
      modifier = DB.getValue(nodeCharacter, path .. ".bonus", 0),
      save = DB.getValue(nodeCharacter, path .. ".save", 0),
      saveProficient = DB.getValue(nodeCharacter, path .. ".saveprof", 0) ~= 0
    }
  end
  return abilities
end

local function createCharacterClasses(nodeCharacter)
  local classes = {}
  local nodeClasses = DB.getChild(nodeCharacter, "classes")
  local nodes = nodeClasses and DB.getChildren(nodeClasses) or {}
  for _, nodeClass in pairs(nodes) do
    local hitDice = DB.getValue(nodeClass, "hddie", {})
    local hitDie = ""
    if type(hitDice) == "table" then
      hitDie = table.concat(hitDice, ",")
    elseif hitDice then
      hitDie = tostring(hitDice)
    end
    table.insert(classes, {
      name = DB.getValue(nodeClass, "name", ""),
      level = DB.getValue(nodeClass, "level", 0),
      hitDie = hitDie,
      usedHitDice = DB.getValue(nodeClass, "hdused", 0)
    })
  end
  table.sort(classes, function(left, right) return left.name < right.name end)
  return classes
end

local function createCharacterSkills(nodeCharacter)
  local skills = {}
  local nodeSkills = DB.getChild(nodeCharacter, "skilllist")
  local nodes = nodeSkills and DB.getChildren(nodeSkills) or {}
  for _, nodeSkill in pairs(nodes) do
    table.insert(skills, {
      name = DB.getValue(nodeSkill, "name", ""),
      ability = DB.getValue(nodeSkill, "stat", ""),
      modifier = DB.getValue(nodeSkill, "total", 0),
      proficiency = DB.getValue(nodeSkill, "prof", 0)
    })
  end
  table.sort(skills, function(left, right) return left.name < right.name end)
  return skills
end

local function createNamedList(nodeCharacter, childName)
  local values = {}
  local nodeList = DB.getChild(nodeCharacter, childName)
  local nodes = nodeList and DB.getChildren(nodeList) or {}
  for _, nodeValue in pairs(nodes) do
    local name = DB.getValue(nodeValue, "name", "")
    if name ~= "" then table.insert(values, name) end
  end
  table.sort(values)
  return values
end

local function diceText(value)
  if type(value) == "table" then
    local parts = {}
    for _, die in ipairs(value) do table.insert(parts, tostring(die)) end
    return table.concat(parts, "+")
  end
  return value and tostring(value) or ""
end

local function createPowerActions(nodePower)
  local actions = {}
  local nodeActions = DB.getChild(nodePower, "actions")
  for _, nodeAction in pairs(nodeActions and DB.getChildren(nodeActions) or {}) do
    local damage = {}
    local nodeDamageList = DB.getChild(nodeAction, "damagelist")
    for _, nodeDamage in pairs(nodeDamageList and DB.getChildren(nodeDamageList) or {}) do
      table.insert(damage, {
        dice = diceText(DB.getValue(nodeDamage, "dice", {})),
        bonus = DB.getValue(nodeDamage, "bonus", 0),
        damageType = DB.getValue(nodeDamage, "type", "")
      })
    end
    table.insert(actions, {
      id = DB.getName(nodeAction),
      type = DB.getValue(nodeAction, "type", ""),
      order = DB.getValue(nodeAction, "order", 0),
      attackType = DB.getValue(nodeAction, "atktype", ""),
      saveType = DB.getValue(nodeAction, "savetype", ""),
      halfOnSave = string.lower(DB.getValue(nodeAction, "onmissdamage", "")) == "half",
      label = DB.getValue(nodeAction, "label", ""),
      targeting = DB.getValue(nodeAction, "targeting", ""),
      duration = DB.getValue(nodeAction, "durmod", 0),
      durationUnit = DB.getValue(nodeAction, "durunit", ""),
      damage = damage
    })
  end
  table.sort(actions, function(left, right) return left.order < right.order end)
  return actions
end

local function createCharacterPowers(nodeCharacter)
  local powers = {}
  local nodePowers = DB.getChild(nodeCharacter, "powers")
  for _, nodePower in pairs(nodePowers and DB.getChildren(nodePowers) or {}) do
    table.insert(powers, {
      id = DB.getName(nodePower),
      name = DB.getValue(nodePower, "name", ""),
      group = DB.getValue(nodePower, "group", ""),
      level = DB.getValue(nodePower, "level", 0),
      prepared = DB.getValue(nodePower, "prepared", 0) ~= 0,
      used = DB.getValue(nodePower, "cast", 0),
      castingTime = DB.getValue(nodePower, "castingtime", ""),
      range = DB.getValue(nodePower, "range", ""),
      duration = DB.getValue(nodePower, "duration", ""),
      ritual = DB.getValue(nodePower, "ritual", 0) ~= 0,
      school = DB.getValue(nodePower, "school", ""),
      actions = createPowerActions(nodePower)
    })
  end
  table.sort(powers, function(left, right)
    if left.group == right.group then
      if left.level == right.level then return left.name < right.name end
      return left.level < right.level
    end
    return left.group < right.group
  end)
  return powers
end

local function createSpellSlots(nodeCharacter)
  local slots = {}
  for level = 1, 9 do
    local path = "powermeta.spellslots" .. tostring(level)
    local maximum = DB.getValue(nodeCharacter, path .. ".max", 0)
    local used = DB.getValue(nodeCharacter, path .. ".used", 0)
    if maximum > 0 or used > 0 then
      table.insert(slots, { level = level, maximum = maximum, used = used, available = math.max(0, maximum - used) })
    end
  end
  return slots
end

NerveCharacterContext = NerveCharacterContext or {}
NerveCharacterContext.allowedRecordTypes = {
  background = true, class = true, class_specialization = true, feat = true,
  race = true, race_subrace = true, spell = true
}

function NerveCharacterContext.collectReferenceLinks(node, links, seen, depth)
  if not node or depth > 8 or #links >= 40 then return end
  for _, child in pairs(DB.getChildren(node) or {}) do
    if #links >= 40 then return end
    local childType = DB.getType(child)
    if childType == "windowreference" then
      local windowClass, recordId = DB.getValue(child, "", "", "")
      if type(recordId) == "string" and string.find(recordId, "@", 1, true) and not seen[recordId] then
        local target = DB.findNode(recordId)
        local parent = DB.getParent(child)
        local recordType = RecordDataManager.getRecordTypeFromRecordPath(recordId) or
          RecordDataManager.getRecordTypeFromDisplayClass(windowClass) or "unknown"
        local fallbackName = parent and DB.getValue(parent, "name", DB.getValue(parent, "title", "")) or ""
        table.insert(links, {
          class = tostring(windowClass or ""), recordId = recordId, recordType = recordType,
          name = target and DB.getValue(target, "name", DB.getValue(target, "title", fallbackName)) or fallbackName,
          module = moduleFromRecordId(recordId), available = target ~= nil
        })
        seen[recordId] = true
      end
    elseif childType == "node" then
      NerveCharacterContext.collectReferenceLinks(child, links, seen, depth + 1)
    end
  end
end

function NerveCharacterContext.createReferenceLinks(nodeCharacter)
  local links = {}
  NerveCharacterContext.collectReferenceLinks(nodeCharacter, links, {}, 0)
  table.sort(links, function(left, right)
    if left.recordType == right.recordType then return left.recordId < right.recordId end
    return left.recordType < right.recordType
  end)
  return links
end

NerveContinuity = NerveContinuity or {}

function NerveContinuity.emptyFacts()
  return {
    party = {}, combatants = {}, pendingAdjudications = {}, recentEvents = {},
    scene = { partyAreaKeys = {}, foeAreaKeys = {}, placementWarnings = {} },
    sessionMetrics = { actionsProcessed = 0, approved = 0, denied = 0, failed = 0, sessionGrantExecutions = 0 }
  }
end

function NerveContinuity.createHandoff()
  local handoff = {
    recentInteractions = NerveCampaignMemory.readInteractions(30),
    lastGMGuidance = { type = "gm.guidance", actor = "GM", visibility = "gm",
      text = DB.getValue("nerve.campaignmemory.lastgmguidance", ""), timestamp = DB.getValue("nerve.campaignmemory.lastgmguidanceat", "") },
    questLog = createQuestLogState(), bookkeepingEvidence = {},
    lastResolvedCheck = Utility.decodeJSON(DB.getValue("nerve.campaignmemory.lastresolvedcheck", "{}")) or {}
  }
  for _, interaction in ipairs(NerveCampaignMemory.readInteractions(200)) do
    local text = string.lower(interaction.text or "")
    if string.find(text, "inventory", 1, true) or string.find(text, "coin", 1, true) or
        string.find(text, "rations", 1, true) or string.find(text, "purchase", 1, true) or string.find(text, "gold", 1, true) then
      table.insert(handoff.bookkeepingEvidence, interaction)
    end
  end
  while #handoff.bookkeepingEvidence > 20 do table.remove(handoff.bookkeepingEvidence, 1) end
  return handoff
end

function NerveContinuity.createFacts(mapScene, tracker, party, pending)
  local facts = NerveContinuity.emptyFacts()
  facts.handoff = NerveContinuity.createHandoff()
  local tokenByCombatant, tokenByName = {}, {}
  for _, token in ipairs(mapScene.tokens or {}) do
    if token.combatantId and token.combatantId ~= "" then tokenByCombatant[token.combatantId] = token end
    if token.name and token.name ~= "" then tokenByName[string.lower(token.name)] = token end
  end
  for _, member in ipairs(party.members or {}) do
    -- Party-sheet and combat-tracker IDs are independent FGU namespaces.
    -- Prefer the exact displayed character name before considering an ID match.
    local token = tokenByName[string.lower(member.name or "")] or tokenByCombatant[member.id]
    table.insert(facts.party, {
      id = member.id, name = member.name, classLevel = member.classLevel,
      hitPoints = { total = member.hitPoints.total, wounds = member.hitPoints.wounds },
      areaKey = token and token.areaCandidateKey or "",
      gridX = token and token.gridX or nil, gridY = token and token.gridY or nil
    })
  end
  for _, combatant in ipairs(tracker.combatants or {}) do
    if #facts.combatants >= 50 then break end
    local token = tokenByCombatant[combatant.id] or tokenByName[string.lower(combatant.name or "")]
    table.insert(facts.combatants, {
      id = combatant.id, name = combatant.name, faction = combatant.faction,
      disposition = combatant.disposition, status = combatant.status, active = combatant.active,
      playerVisible = combatant.playerVisible,
      hitPoints = { total = combatant.hitPoints.total, temporary = combatant.hitPoints.temporary, wounds = combatant.hitPoints.wounds },
      areaKey = token and token.areaCandidateKey or "",
      gridX = token and token.gridX or nil, gridY = token and token.gridY or nil
    })
  end
  for index, task in ipairs(pending.tasks or {}) do
    if index > 20 then break end
    table.insert(facts.pendingAdjudications, {
      id = task.id, sourceName = task.sourceName, targetName = task.targetName,
      actionName = task.actionName, text = task.text
    })
  end
  for index = math.max(1, #recentEvents - 19), #recentEvents do
    local event = recentEvents[index]
    if event then table.insert(facts.recentEvents, {
      sequence = event.sequence, type = event.type, actor = event.actor,
      text = event.text, visibility = event.visibility, subjectId = event.subjectId
    }) end
  end
  for _, area in ipairs(mapScene.spatial.partyAreaCandidates or {}) do table.insert(facts.scene.partyAreaKeys, area.key) end
  for _, area in ipairs(mapScene.spatial.foeAreaCandidates or {}) do table.insert(facts.scene.foeAreaKeys, area.key) end
  for _, warning in ipairs(mapScene.spatial.placementWarnings or {}) do table.insert(facts.scene.placementWarnings, warning) end
  facts.sessionMetrics = {
    actionsProcessed = sessionMetric("actionsprocessed"), approved = sessionMetric("approved"),
    denied = sessionMetric("denied"), failed = sessionMetric("failed"),
    sessionGrantExecutions = sessionMetric("sessiongrantexecutions")
  }
  return facts
end

function NerveContinuity.automaticText(sessionId, mapScene, tracker, facts)
  local location = mapScene.name ~= "" and mapScene.name or "no open map"
  if #facts.scene.partyAreaKeys > 0 then location = location .. " near " .. table.concat(facts.scene.partyAreaKeys, "/") end
  local threats = 0
  for _, combatant in ipairs(tracker.combatants or {}) do if combatant.threat then threats = threats + 1 end end
  local summary = string.format("Automatic factual checkpoint for %s: %d party member(s) at %s; %d active threat(s).",
    sessionId, #facts.party, location, threats)
  local situation = threats > 0 and string.format("Combat is active at round %d with %d combatant(s) and %d active threat(s).", tracker.round, #facts.combatants, threats) or
    string.format("Combat is not active; %d inactive combatant record(s) remain on the tracker and %d adjudication(s) remain pending.", #facts.combatants, #facts.pendingAdjudications)
  return summary, situation
end

createCharacters = function()
  local characters = {}
  local nodes = DB.getChildren("charsheet") or {}
  for _, nodeCharacter in pairs(nodes) do
    table.insert(characters, {
      id = DB.getName(nodeCharacter),
      name = DB.getValue(nodeCharacter, "name", ""),
      race = DB.getValue(nodeCharacter, "race", ""),
      background = DB.getValue(nodeCharacter, "background", ""),
      alignment = DB.getValue(nodeCharacter, "alignment", ""),
      deity = DB.getValue(nodeCharacter, "deity", ""),
      level = DB.getValue(nodeCharacter, "level", 0),
      proficiencyBonus = DB.getValue(nodeCharacter, "profbonus", 0),
      armorClass = DB.getValue(nodeCharacter, "defenses.ac.total", 0),
      initiative = DB.getValue(nodeCharacter, "initiative.total", 0),
      speed = DB.getValue(nodeCharacter, "speed.total", 0),
      inspiration = DB.getValue(nodeCharacter, "inspiration", 0) ~= 0,
      size = DB.getValue(nodeCharacter, "size", ""),
      senses = DB.getValue(nodeCharacter, "senses", ""),
      experience = {
        current = DB.getValue(nodeCharacter, "exp", 0),
        nextLevel = DB.getValue(nodeCharacter, "expneeded", 0)
      },
      hitPoints = {
        total = DB.getValue(nodeCharacter, "hp.total", 0),
        temporary = DB.getValue(nodeCharacter, "hp.temporary", 0),
        wounds = DB.getValue(nodeCharacter, "hp.wounds", 0),
        deathSaveSuccesses = DB.getValue(nodeCharacter, "hp.deathsavesuccess", 0),
        deathSaveFailures = DB.getValue(nodeCharacter, "hp.deathsavefail", 0)
      },
      abilities = createCharacterAbilities(nodeCharacter),
      classes = createCharacterClasses(nodeCharacter),
      skills = createCharacterSkills(nodeCharacter),
      languages = createNamedList(nodeCharacter, "languagelist"),
      proficiencies = createNamedList(nodeCharacter, "proficiencylist"),
      powers = createCharacterPowers(nodeCharacter),
      spellSlots = createSpellSlots(nodeCharacter),
      referenceLinks = NerveCharacterContext.createReferenceLinks(nodeCharacter),
      automationNotes = {
        "Use saving-throw controls for spell saves; an ability-score roll is published as a check.",
        "Verify spell slots and limited-use powers after use because custom Fantasy Grounds actions may not consume them automatically."
      },
      proxyControl = { mode = playerProxyMode }
    })
  end
  table.sort(characters, function(left, right) return left.id < right.id end)
  return characters
end

local function decodeContinuityList(value)
  local decoded = type(value) == "string" and Utility.decodeJSON(value) or nil
  return type(decoded) == "table" and decoded or {}
end

local function readContinuityCheckpoint(node, includeFacts)
  if not node then return nil end
  local checkpoint = {
    id = DB.getName(node),
    sessionId = DB.getValue(node, "sessionid", ""),
    source = DB.getValue(node, "source", "automatic"),
    createdAt = DB.getValue(node, "createdat", ""),
    summary = DB.getValue(node, "summary", ""),
    currentSituation = DB.getValue(node, "currentsituation", ""),
    unresolvedThreads = decodeContinuityList(DB.getValue(node, "unresolvedthreads", "[]")),
    partyGoals = decodeContinuityList(DB.getValue(node, "partygoals", "[]")),
    importantNpcs = decodeContinuityList(DB.getValue(node, "importantnpcs", "[]")),
    partyOrigin = DB.getValue(node, "partyorigin", ""),
    reasonHere = DB.getValue(node, "reasonhere", ""),
    locationsVisited = decodeContinuityList(DB.getValue(node, "locationsvisited", "[]")),
    npcsMet = decodeContinuityList(DB.getValue(node, "npcsmet", "[]")),
    conversationHighlights = decodeContinuityList(DB.getValue(node, "conversationhighlights", "[]")),
    discoveries = decodeContinuityList(DB.getValue(node, "discoveries", "[]")),
    completedObjectives = decodeContinuityList(DB.getValue(node, "completedobjectives", "[]")),
    nextSessionOpening = DB.getValue(node, "nextsessionopening", ""),
    sourceEventSequence = DB.getValue(node, "sourceeventsequence", 0),
    map = {
      recordId = DB.getValue(node, "map.recordid", ""),
      name = DB.getValue(node, "map.name", ""),
      currentAreaKey = DB.getValue(node, "map.currentareakey", "")
    },
    combat = {
      active = DB.getValue(node, "combat.active", 0) == 1,
      round = DB.getValue(node, "combat.round", 0),
      activeCombatantId = DB.getValue(node, "combat.activecombatantid", "")
    }
  }
  if includeFacts ~= false then
    local facts = Utility.decodeJSON(DB.getValue(node, "facts", "{}"))
    if type(facts) ~= "table" then facts = NerveContinuity.emptyFacts() end
    facts.party = type(facts.party) == "table" and facts.party or {}
    facts.combatants = type(facts.combatants) == "table" and facts.combatants or {}
    facts.pendingAdjudications = type(facts.pendingAdjudications) == "table" and facts.pendingAdjudications or {}
    facts.recentEvents = type(facts.recentEvents) == "table" and facts.recentEvents or {}
    facts.scene = type(facts.scene) == "table" and facts.scene or { partyAreaKeys = {}, foeAreaKeys = {}, placementWarnings = {} }
    facts.scene.partyAreaKeys = type(facts.scene.partyAreaKeys) == "table" and facts.scene.partyAreaKeys or {}
    facts.scene.foeAreaKeys = type(facts.scene.foeAreaKeys) == "table" and facts.scene.foeAreaKeys or {}
    facts.scene.placementWarnings = type(facts.scene.placementWarnings) == "table" and facts.scene.placementWarnings or {}
    facts.sessionMetrics = type(facts.sessionMetrics) == "table" and facts.sessionMetrics or NerveContinuity.emptyFacts().sessionMetrics
    checkpoint.facts = facts
  end
  return checkpoint
end

local function createSessionContinuityState()
  local history = {}
  for _, node in pairs(DB.getChildren("nerve.sessioncontinuity.checkpoints") or {}) do
    local checkpoint = readContinuityCheckpoint(node, false)
    if checkpoint then table.insert(history, checkpoint) end
  end
  table.sort(history, function(left, right) return left.createdAt > right.createdAt end)
  while #history > 10 do table.remove(history) end
  for _, checkpoint in ipairs(history) do
    local saved = readContinuityCheckpoint(DB.findNode("nerve.sessioncontinuity.checkpoints." .. checkpoint.id), true)
    checkpoint.facts = NerveContinuity.emptyFacts()
    checkpoint.facts.recentEvents = saved and saved.facts and saved.facts.recentEvents or {}
  end
  local latest = history[1] and readContinuityCheckpoint(DB.findNode("nerve.sessioncontinuity.checkpoints." .. history[1].id), true) or nil
  if latest and latest.facts then latest.facts.handoff = NerveContinuity.createHandoff() end
  return {
    available = #history > 0,
    latest = latest,
    history = history,
    observedAt = os.date("!%Y-%m-%dT%H:%M:%SZ")
  }
end

NerveCampaignMemory = NerveCampaignMemory or {}

function NerveCampaignMemory.truncate(value, limit)
  local text = tostring(value or "")
  -- Lua patterns do not define %r or %n as line-break escapes; using those
  -- pattern classes removes the ordinary letters r and n from saved text.
  text = string.gsub(text, "\r", " ")
  text = string.gsub(text, "\n", " ")
  text = string.gsub(text, "%s+", " ")
  if #text <= limit then return text end
  return string.sub(text, 1, math.max(1, limit - 3)) .. "..."
end

function NerveCampaignMemory.joinList(values, emptyText)
  if type(values) ~= "table" or #values == 0 then return emptyText or "None recorded" end
  local parts = {}
  for index = 1, math.min(#values, 4) do
    table.insert(parts, NerveCampaignMemory.truncate(values[index], 100))
  end
  if #values > 4 then table.insert(parts, "+" .. tostring(#values - 4) .. " more") end
  return table.concat(parts, "  •  ")
end

function NerveCampaignMemory.sentenceCase(value)
  local text = NerveCampaignMemory.truncate(value, 500)
  text = string.gsub(text, "%f[%a]i%f[%A]", "I")
  local first = string.find(text, "%a")
  if first then text = string.sub(text, 1, first - 1) .. string.upper(string.sub(text, first, first)) .. string.sub(text, first + 1) end
  return text
end

function NerveCampaignMemory.getCheckpoint(index)
  local state = createSessionContinuityState()
  local entry = state.history[tonumber(index) or 1]
  if not entry then return nil end
  return readContinuityCheckpoint(DB.findNode("nerve.sessioncontinuity.checkpoints." .. entry.id), true)
end

function NerveCampaignMemory.persistInteraction(event)
  if not Session.IsHost or type(event) ~= "table" then return end
  if event.type == "gm.guidance" then
    DB.setValue("nerve.campaignmemory.lastgmguidance", "string", tostring(event.text or ""))
    DB.setValue("nerve.campaignmemory.lastgmguidanceat", "string", event.timestamp or os.date("!%Y-%m-%dT%H:%M:%SZ"))
    return
  end
  local isPlayer = event.type == "player.chat_message"
  local isPublicNerve = event.type == "chat.message" and event.actor == "Nerve" and event.visibility == "all"
  if not isPlayer and not isPublicNerve then return end
  local text = NerveCampaignMemory.truncate(event.text, 500)
  if text == "" then return end

  local nextId = DB.getValue("nerve.campaignmemory.nextinteractionid", 0) + 1
  DB.setValue("nerve.campaignmemory.nextinteractionid", "number", nextId)
  local root = DB.createNode("nerve.campaignmemory.interactions")
  local node = root and DB.createChild(root, string.format("interaction-%08d", nextId)) or nil
  if not node then return end
  DB.setValue(node, "createdat", "string", event.timestamp or os.date("!%Y-%m-%dT%H:%M:%SZ"))
  DB.setValue(node, "actor", "string", event.actor or (isPlayer and "Player" or "Nerve"))
  DB.setValue(node, "text", "string", text)
  DB.setValue(node, "type", "string", event.type or "chat.message")

  local entries = {}
  for _, candidate in pairs(DB.getChildren("nerve.campaignmemory.interactions") or {}) do table.insert(entries, candidate) end
  table.sort(entries, function(left, right) return DB.getName(left) > DB.getName(right) end)
  for entryIndex = MAX_CAMPAIGN_MEMORY_INTERACTIONS + 1, #entries do DB.deleteNode(DB.getPath(entries[entryIndex])) end
end

function NerveCampaignMemory.readInteractions(limit)
  local entries = {}
  for _, node in pairs(DB.getChildren("nerve.campaignmemory.interactions") or {}) do
    table.insert(entries, {
      id = DB.getName(node),
      type = DB.getValue(node, "type", "chat.message"),
      visibility = "all",
      createdAt = DB.getValue(node, "createdat", ""),
      actor = DB.getValue(node, "actor", "Unknown"),
      text = DB.getValue(node, "text", "")
    })
  end
  table.sort(entries, function(left, right) return left.id < right.id end)
  while #entries > (tonumber(limit) or 7) do table.remove(entries, 1) end
  return entries
end

function NerveCampaignMemory.repairLegacySanitizer()
  if not Session.IsHost or DB.getValue("nerve.campaignmemory.sanitizerfixversion", 0) >= 1 then return end
  local snapshotText = File.openTextFile(File.getCampaignFolder() .. "/" .. SNAPSHOT_FILENAME)
  local snapshot = snapshotText and snapshotText ~= "" and Utility.decodeJSON(snapshotText) or nil
  local events = type(snapshot) == "table" and type(snapshot.recentEvents) == "table" and snapshot.recentEvents.events or nil
  if type(events) == "table" then
    local root = DB.findNode("nerve.campaignmemory.interactions")
    if root then
      for _, node in pairs(DB.getChildren(root) or {}) do DB.deleteNode(DB.getPath(node)) end
    end
    DB.setValue("nerve.campaignmemory.nextinteractionid", "number", 0)
    for _, event in ipairs(events) do NerveCampaignMemory.persistInteraction(event) end
  end
  DB.setValue("nerve.campaignmemory.sanitizerfixversion", "number", 1)
end

function NerveContinuity.automaticNarrative(sessionId, mapScene, tracker, facts)
  local summary, situation = NerveContinuity.automaticText(sessionId, mapScene, tracker, facts)
  local interactions = NerveCampaignMemory.readInteractions(30)
  local latestPlayer, latestNerve = nil, nil
  local highlights = {}
  local seenHighlights = {}
  local partyNames = {}
  local importantNpcs, seenNpcs = {}, {}
  local npcRequests = {}
  local knownNpcNames = {}
  for _, record in ipairs(libraryCatalog and libraryCatalog.records or {}) do
    if record.recordType == "npc" and type(record.name) == "string" and #record.name >= 4 then table.insert(knownNpcNames, record.name) end
  end
  for _, member in ipairs(facts.party or {}) do partyNames[string.lower(tostring(member.name or ""))] = true end
  for _, interaction in ipairs(interactions) do
    local actor = tostring(interaction.actor or "")
    local text = NerveCampaignMemory.sentenceCase(interaction.text)
    text = NerveCampaignMemory.truncate(text, 220)
    if text ~= "" then
      if actor == "Nerve" then
        latestNerve = text
        local padded = " " .. string.lower(text) .. " "
        for _, npcName in ipairs(knownNpcNames) do
          local key = string.lower(npcName)
          if not seenNpcs[key] and string.find(padded, " " .. key .. " ", 1, true) then table.insert(importantNpcs, npcName); seenNpcs[key] = true end
        end
      else latestPlayer = actor .. ": " .. text end
      local actorKey = string.lower(actor)
      if actor ~= "" and actor ~= "Nerve" and actor ~= "GM" and not partyNames[actorKey] and not seenNpcs[actorKey] then
        table.insert(importantNpcs, actor)
        seenNpcs[actorKey] = true
      end
      if actor ~= "" and actor ~= "Nerve" and not partyNames[actorKey] and
          (string.find(string.lower(text), "i'd like you", 1, true) or string.find(string.lower(text), "i need you", 1, true) or string.find(string.lower(text), "in exchange", 1, true)) then
        table.insert(npcRequests, actor .. ": " .. text)
      end
      if actor == "Nerve" and (string.find(string.lower(text), "asks you", 1, true) or string.find(string.lower(text), "needs you", 1, true) or string.find(string.lower(text), "task", 1, true)) then table.insert(npcRequests, text) end
      local highlight = actor .. ": " .. text
      local key = string.lower(string.gsub(highlight, "%s+", " "))
      if #highlights < 6 and not seenHighlights[key] then
        table.insert(highlights, highlight)
        seenHighlights[key] = true
      end
    end
  end

  local location = mapScene.name ~= "" and mapScene.name or "the current scene"
  local areaKeys = facts.scene.partyAreaKeys or {}
  if #areaKeys > 0 then location = location .. " near " .. table.concat(areaKeys, "/") end
  if latestNerve then summary = "At " .. location .. ", " .. latestNerve end
  if latestPlayer then summary = summary .. " Latest player intent: " .. latestPlayer end

  local unresolved = {}
  if #facts.pendingAdjudications > 0 then
    table.insert(unresolved, tostring(#facts.pendingAdjudications) .. " manual adjudication(s) remain unresolved.")
  end
  if latestNerve and string.find(latestNerve, "?", 1, true) then
    table.insert(unresolved, "The party has not yet answered: " .. latestNerve)
  end
  local acceptedTask = latestPlayer and (string.find(string.lower(latestPlayer), "deal", 1, true) or
    string.find(string.lower(latestPlayer), "agree", 1, true) or string.find(string.lower(latestPlayer), "accept", 1, true))
  local goals = {}
  if acceptedTask and #npcRequests > 0 then
    local task = NerveCampaignMemory.truncate(npcRequests[#npcRequests], 240)
    table.insert(unresolved, task)
    table.insert(goals, task)
  end

  local locations = {}
  if mapScene.name and mapScene.name ~= "" then table.insert(locations, location) end
  local discoveries = {}
  if latestNerve then
    local established = string.match(latestNerve, "^(.-%.)%s") or (not string.find(latestNerve, "?", 1, true) and latestNerve or "")
    if established ~= "" then table.insert(discoveries, "Publicly established: " .. established) end
  end
  local nextOpening = latestNerve or ("Resume at " .. location .. " from the current Fantasy Grounds state.")
  if latestNerve then situation = "Current public scene: " .. latestNerve end
  if latestPlayer then situation = situation .. " Latest player intent: " .. latestPlayer end

  return {
    summary = summary, currentSituation = situation, unresolvedThreads = unresolved,
    partyGoals = goals, importantNpcs = importantNpcs, partyOrigin = "", reasonHere = "",
    locationsVisited = locations, npcsMet = importantNpcs, conversationHighlights = highlights,
    discoveries = discoveries, completedObjectives = {}, nextSessionOpening = nextOpening
  }
end

function getCampaignMemoryCheckpointCount()
  return #createSessionContinuityState().history
end

function getCampaignMemoryCurrentStateText()
  if not Session.IsHost then return "Campaign Memory is available on the GM host." end
  local summary = createCampaignSummary()
  local tracker = createCombatTracker()
  local party = createParty()
  local scene = createMapSceneState(createOpenMapState())
  local area = scene.areaContinuity and scene.areaContinuity.currentAreaKey or ""
  local combatText = summary.inCombat and ("Combat active · round " .. tostring(tracker.round or 0) .. " · " .. tostring(#(tracker.combatants or {})) .. " combatants") or "No active combat"
  local linked, seen = {}, {}
  for _, record in ipairs(scene.recordLinks or {}) do
    local recordType = tostring(record.recordType or "")
    local name = tostring(record.name or "")
    if name ~= "" and not seen[recordType .. "|" .. name] and
        (recordType == "location" or recordType == "quest" or recordType == "story" or recordType == "battle") then
      table.insert(linked, recordType .. ": " .. name)
      seen[recordType .. "|" .. name] = true
      if #linked >= 4 then break end
    end
  end
  local focus = createCampaignFocusState(scene)
  local adventure = focus.status == "ready" and focus.displayName or (focus.status == "source_unavailable" and "SOURCE NOT LOADED" or "not selected")
  return "Adventure: " .. adventure .. " · Map: " .. ((scene.name and scene.name ~= "") and scene.name or "none open") ..
    " · Area: " .. ((area and area ~= "") and area or "not keyed") ..
    "\nParty: " .. tostring(#(party.members or {})) .. " member(s) · " .. combatText ..
    "\nScene style: " .. tostring(scene.playStyle or "mixed") .. " · Map sharing: " .. tostring(scene.shareMode or "none") ..
    "\nMap-linked references: " .. (#linked > 0 and table.concat(linked, "  •  ") or "none") .. " (reference hints only)"
end

function getCampaignMemoryCheckpointMetaText(index)
  local checkpoint = NerveCampaignMemory.getCheckpoint(index)
  if not checkpoint then return "No durable checkpoint exists yet. End a tracked session to create one automatically." end
  return tostring(checkpoint.createdAt or "Unknown time") .. " · " .. tostring(checkpoint.source or "automatic") ..
    " · " .. ((checkpoint.map and checkpoint.map.name ~= "") and checkpoint.map.name or "No saved map")
end

function getCampaignMemoryBriefingText(index)
  local checkpoint = NerveCampaignMemory.getCheckpoint(index)
  if not checkpoint then
    return "Nerve will build a resume briefing from confirmed session continuity, the current map, combat state, and recent public interactions."
  end
  return "SUMMARY: " .. NerveCampaignMemory.truncate(checkpoint.summary, 260) ..
    "\n\nCURRENT SITUATION: " .. NerveCampaignMemory.truncate(checkpoint.currentSituation, 260) ..
    "\n\nUNRESOLVED: " .. NerveCampaignMemory.joinList(checkpoint.unresolvedThreads) ..
    "\n\nPARTY GOALS: " .. NerveCampaignMemory.joinList(checkpoint.partyGoals) ..
    "\n\nIMPORTANT NPCS: " .. NerveCampaignMemory.joinList(checkpoint.importantNpcs) ..
    "\n\nNEXT OPENING: " .. NerveCampaignMemory.truncate(checkpoint.nextSessionOpening, 220)
end

function getCampaignMemoryJourneyText(index)
  local checkpoint = NerveCampaignMemory.getCheckpoint(index)
  if not checkpoint then
    return "Journey details will appear after Nerve records the first table-established campaign checkpoint."
  end
  local origin = checkpoint.partyOrigin ~= "" and NerveCampaignMemory.truncate(checkpoint.partyOrigin, 260) or "None recorded"
  local reason = checkpoint.reasonHere ~= "" and NerveCampaignMemory.truncate(checkpoint.reasonHere, 260) or "None recorded"
  return "WHERE THE PARTY CAME FROM: " .. origin ..
    "\n\nWHY THEY ARE HERE: " .. reason ..
    "\n\nLOCATIONS VISITED: " .. NerveCampaignMemory.joinList(checkpoint.locationsVisited) ..
    "\n\nNPCS MET: " .. NerveCampaignMemory.joinList(checkpoint.npcsMet) ..
    "\n\nIMPORTANT CONVERSATIONS: " .. NerveCampaignMemory.joinList(checkpoint.conversationHighlights) ..
    "\n\nDISCOVERIES: " .. NerveCampaignMemory.joinList(checkpoint.discoveries) ..
    "\n\nCOMPLETED OBJECTIVES: " .. NerveCampaignMemory.joinList(checkpoint.completedObjectives)
end

function getCampaignMemoryInteractionText()
  local entries = NerveCampaignMemory.readInteractions(6)
  if #entries == 0 then return "No public player/Nerve interactions have been recorded yet." end
  local lines = {}
  for _, entry in ipairs(entries) do
    local stamp = #entry.createdAt >= 16 and string.sub(entry.createdAt, 12, 16) or "--:--"
    table.insert(lines, stamp .. "  " .. NerveCampaignMemory.truncate(entry.actor, 35) .. ": " .. NerveCampaignMemory.truncate(entry.text, 150))
  end
  return table.concat(lines, "\n")
end

function openCampaignMemory()
  if not Session.IsHost then ChatManager.SystemMessage("Nerve Campaign Memory is available on the GM host."); return end
  Interface.openWindow("nerve_campaign_memory", "")
end

function openAdventureSourceSetup()
  if not Session.IsHost then ChatManager.SystemMessage("Nerve adventure selection is available only on the GM host."); return end
  Interface.openWindow("nerve_adventure_source", "")
end

function getPartyAreaKey()
  return DB.getValue("nerve.areacontinuity.currentarea", "")
end

function setPartyAreaKey(value)
  if not Session.IsHost then ChatManager.SystemMessage("Nerve party area can be set only on the GM host."); return false end
  local key = string.upper(tostring(value or ""))
  key = string.gsub(key, "^%s+", "")
  key = string.gsub(key, "%s+$", "")
  if key ~= "" and not string.match(key, "^[A-Z]+%d+$") then
    ChatManager.SystemMessage("Nerve: enter a short map area key such as J1, or leave it blank to clear the current area.")
    return false
  end
  local previous = DB.getValue("nerve.areacontinuity.currentarea", "")
  local root = DB.createNode("nerve.areacontinuity")
  if not root then ChatManager.SystemMessage("Nerve could not save the party area."); return false end
  if previous ~= "" and previous ~= key and DB.getValue(root, previous .. ".status", "") == "current" then
    DB.setValue(root, previous .. ".status", "string", "visited")
  end
  if previous ~= key then expireStoryCues({ scene = true }) end
  DB.setValue("nerve.areacontinuity.currentarea", "string", key)
  if key ~= "" then DB.setValue(root, key .. ".status", "string", "current") end
  publishSnapshot("map-area-keyed", {
    type = "map.area_keyed", actor = "GM", text = key ~= "" and ("Party area set to " .. key .. ".") or "Party area cleared.",
    visibility = "gm", subjectId = key, data = { areaKey = key, previousAreaKey = previous }
  })
  ChatManager.SystemMessage(key ~= "" and ("Nerve party area set to " .. key .. ".") or "Nerve party area cleared.")
  refreshNerveControlWindows()
  return true
end

function openPartyAreaSetup()
  if not Session.IsHost then ChatManager.SystemMessage("Nerve party area can be set only on the GM host."); return end
  Interface.openWindow("nerve_party_area", "")
end

local function persistSessionContinuity(args, source)
  local sessionId = DB.getValue("nerve.sessionoperations.sessionid", "")
  if args.sessionId ~= sessionId or sessionId == "" then
    return nil, "SESSION_STALE", "The continuity checkpoint does not match the current tracked session."
  end
  local createdAt = os.date("!%Y-%m-%dT%H:%M:%SZ")
  local checkpointId = "checkpoint-" .. string.gsub(createdAt, "[^0-9]", "")
  local root = DB.createNode("nerve.sessioncontinuity.checkpoints")
  local node = root and DB.createChild(root, checkpointId) or nil
  if not node then return nil, "CONTINUITY_WRITE_FAILED", "Fantasy Grounds could not create the continuity checkpoint." end
  local openMaps = createOpenMapState()
  local mapScene = createMapSceneState(openMaps)
  local tracker = createCombatTracker()
  local party = createParty()
  local pending = createManualAdjudicationState()
  local facts = NerveContinuity.createFacts(mapScene, tracker, party, pending)
  local activeCombatantId = ""
  for _, combatant in ipairs(tracker.combatants or {}) do
    if combatant.active then activeCombatantId = combatant.id break end
  end
  DB.setValue(node, "sessionid", "string", sessionId)
  DB.setValue(node, "source", "string", source)
  DB.setValue(node, "createdat", "string", createdAt)
  DB.setValue(node, "summary", "string", args.summary or "")
  DB.setValue(node, "currentsituation", "string", args.currentSituation or "")
  DB.setValue(node, "unresolvedthreads", "string", Utility.encodeJSON(args.unresolvedThreads or {}) or "[]")
  DB.setValue(node, "partygoals", "string", Utility.encodeJSON(args.partyGoals or {}) or "[]")
  DB.setValue(node, "importantnpcs", "string", Utility.encodeJSON(args.importantNpcs or {}) or "[]")
  DB.setValue(node, "partyorigin", "string", args.partyOrigin or "")
  DB.setValue(node, "reasonhere", "string", args.reasonHere or "")
  DB.setValue(node, "locationsvisited", "string", Utility.encodeJSON(args.locationsVisited or {}) or "[]")
  DB.setValue(node, "npcsmet", "string", Utility.encodeJSON(args.npcsMet or {}) or "[]")
  DB.setValue(node, "conversationhighlights", "string", Utility.encodeJSON(args.conversationHighlights or {}) or "[]")
  DB.setValue(node, "discoveries", "string", Utility.encodeJSON(args.discoveries or {}) or "[]")
  DB.setValue(node, "completedobjectives", "string", Utility.encodeJSON(args.completedObjectives or {}) or "[]")
  DB.setValue(node, "nextsessionopening", "string", args.nextSessionOpening or "")
  DB.setValue(node, "sourceeventsequence", "number", tonumber(args.sourceEventSequence or eventSequence) or eventSequence)
  DB.setValue(node, "map.recordid", "string", mapScene.recordId or "")
  DB.setValue(node, "map.name", "string", mapScene.name or "")
  DB.setValue(node, "map.currentareakey", "string", DB.getValue("nerve.areacontinuity.currentarea", ""))
  DB.setValue(node, "combat.active", "number", createCampaignSummary().inCombat and 1 or 0)
  DB.setValue(node, "combat.round", "number", tracker.round or 0)
  DB.setValue(node, "combat.activecombatantid", "string", activeCombatantId)
  DB.setValue(node, "facts", "string", Utility.encodeJSON(facts) or "{}")
  DB.setValue("nerve.sessioncontinuity.latestid", "string", checkpointId)
  local checkpoints = {}
  for _, candidate in pairs(DB.getChildren("nerve.sessioncontinuity.checkpoints") or {}) do table.insert(checkpoints, candidate) end
  table.sort(checkpoints, function(left, right)
    return DB.getValue(left, "createdat", "") > DB.getValue(right, "createdat", "")
  end)
  for index = 11, #checkpoints do DB.deleteNode(DB.getPath(checkpoints[index])) end
  return readContinuityCheckpoint(node)
end

function NerveContinuity.refreshFacts(checkpointId)
  local node = checkpointId and checkpointId ~= "" and DB.findNode("nerve.sessioncontinuity.checkpoints." .. checkpointId) or nil
  if not node then return false end
  local openMaps = createOpenMapState()
  local mapScene = createMapSceneState(openMaps)
  local tracker = createCombatTracker()
  local facts = NerveContinuity.createFacts(mapScene, tracker, createParty(), createManualAdjudicationState())
  local activeCombatantId = ""
  for _, combatant in ipairs(tracker.combatants or {}) do if combatant.active then activeCombatantId = combatant.id break end end
  DB.setValue(node, "map.recordid", "string", mapScene.recordId or "")
  DB.setValue(node, "map.name", "string", mapScene.name or "")
  DB.setValue(node, "map.currentareakey", "string", DB.getValue("nerve.areacontinuity.currentarea", ""))
  DB.setValue(node, "combat.active", "number", createCampaignSummary().inCombat and 1 or 0)
  DB.setValue(node, "combat.round", "number", tracker.round or 0)
  DB.setValue(node, "combat.activecombatantid", "string", activeCombatantId)
  DB.setValue(node, "facts", "string", Utility.encodeJSON(facts) or "{}")
  return true
end

local function appendRecentEvent(eventType, actor, text, visibility, subjectId, data)
  local now = os.time()
  eventSequence = eventSequence + 1
  local event = {
    sequence = eventSequence,
    type = eventType,
    timestamp = os.date("!%Y-%m-%dT%H:%M:%SZ"),
    actor = actor or "",
    text = text or "",
    visibility = visibility or "gm",
    subjectId = subjectId or "",
    data = data or {}
  }
  if string.match(eventType or "", "^roll%.") or eventType == "power.action_outcome" or eventType == "combatant.action_outcome" then
    DB.setValue("nerve.campaignmemory.lastresolvedcheck", "string", Utility.encodeJSON(event) or "{}")
  end
  NerveCampaignMemory.persistInteraction(event)
  local lastStateEpoch = lastStateEventEpochs[eventType] or 0
  local shouldCoalesce = COALESCED_STATE_EVENT_TYPES[eventType] and
    now - lastStateEpoch <= STATE_EVENT_COALESCE_SECONDS
  if shouldCoalesce then
    for index = #recentEvents, 1, -1 do
      if recentEvents[index].type == eventType then
        table.remove(recentEvents, index)
        break
      end
    end
  end
  table.insert(recentEvents, event)
  local suppressPromptRollCue = string.sub(eventType, 1, 5) == "roll." and
    suppressNextPromptRollCueActor and string.lower(tostring(actor or "")) == string.lower(suppressNextPromptRollCueActor) and
    now - suppressNextPromptRollCueEpoch <= 3
  if suppressPromptRollCue then
    suppressNextPromptRollCueActor = nil
    suppressNextPromptRollCueEpoch = 0
  elseif AUTOMATIC_CONNECTOR_CUE_EVENT_TYPES[eventType] then
    automaticConnectorCueTrigger = { type = eventType, actor = actor or "", subjectId = subjectId or "" }
  end
  if COALESCED_STATE_EVENT_TYPES[eventType] then
    lastStateEventEpochs[eventType] = now
  end
  while #recentEvents > MAX_RECENT_EVENTS do table.remove(recentEvents, 1) end
end

local function aiCuePath(field)
  return "nerve.aicue." .. field
end

local function getAiCueId()
  return DB.getValue(aiCuePath("cueid"), "")
end

function isAiCueWaiting()
  if not Session.IsHost then return clientAiCueStatus == "called" end
  return DB.getValue(aiCuePath("status"), "idle") == "called"
end

function formatAiCueDuration(seconds)
  local duration = math.max(0, tonumber(seconds) or 0)
  if duration < 120 then return tostring(math.floor(duration)) .. "s" end
  if duration < 7200 then return tostring(math.floor(duration / 60)) .. "m" end
  return string.format("%dh %dm", math.floor(duration / 3600), math.floor((duration % 3600) / 60))
end

function getAiCueStatusText()
  local status = Session.IsHost and DB.getValue(aiCuePath("status"), "idle") or clientAiCueStatus
  if status == "called" then
    local source = Session.IsHost and DB.getValue(aiCuePath("source"), "") or ""
    if string.sub(source, 1, 10) == "automatic:" then return "AUTO CUE · WAITING FOR AI" end
    local actor = DB.getValue(aiCuePath("actor"), "GM")
    local count = DB.getValue(aiCuePath("requestcount"), 1)
    return string.format("WAITING FOR AI · %s%s", actor, count > 1 and (" x" .. tostring(count)) or "")
  end
  if status == "answered" then
    local latency = Session.IsHost and DB.getValue(aiCuePath("latencyseconds"), -1) or clientAiCueLatencySeconds
    if latency and latency >= 0 then return "Answered in " .. formatAiCueDuration(latency) end
    return "Answered " .. DB.getValue(aiCuePath("answeredat"), "")
  end
  if status == "failed" then
    local latency = Session.IsHost and DB.getValue(aiCuePath("latencyseconds"), -1) or clientAiCueLatencySeconds
    if latency and latency >= 0 then return "AI failed after " .. formatAiCueDuration(latency) end
    return "AI response failed"
  end
  return "Idle"
end

function getAiCueButtonText()
  local status = Session.IsHost and DB.getValue(aiCuePath("status"), "idle") or clientAiCueStatus
  if status == "called" then
    local source = Session.IsHost and DB.getValue(aiCuePath("source"), "") or ""
    return string.sub(source, 1, 10) == "automatic:" and "AUTO WAITING..." or "WAITING..."
  end
  if status == "answered" then return "ANSWERED" end
  if status == "failed" then return "FAILED" end
  return "CALL NERVE"
end

function getControllerSupervisorState()
  if not Session.IsHost then return { status = "host_only", controllerStatus = "unknown" } end
  local text = File.openTextFile(File.getCampaignFolder() .. "/nerve-supervisor-status.json")
  if not text or text == "" then return { status = "offline", controllerStatus = "stopped" } end
  local state = Utility.decodeJSON(text)
  if type(state) ~= "table" or state.schemaVersion ~= "0.1" then
    return { status = "invalid", controllerStatus = "stopped", errorCode = "SUPERVISOR_STATUS_INVALID" }
  end
  if type(state.updatedAtEpoch) ~= "number" or os.time() - state.updatedAtEpoch > 15 then
    state.status = "offline"
  end
  return state
end

function getControllerStatusText()
  local state = getControllerSupervisorState()
  if state.status == "host_only" then return "Controller: managed by the GM host" end
  if state.status == "offline" then return "Controller: supervisor offline — run Nerve setup/repair" end
  if state.status == "invalid" then return "Controller: invalid supervisor status" end
  if state.configured == false then return "Controller: NOT CONFIGURED" end
  if state.controllerStatus == "stopping" or (DB.getValue("nerve.sessionoperations.status", "not_started") == "ended" and (state.controllerStatus == "running" or state.controllerStatus == "starting")) then return "Connector: SHUTTING DOWN · final session state is safe" end
  if state.connectionMode == "connector" or state.provider == "connector" then
    local controller = type(state.controllerStatus) == "string" and state.controllerStatus or "stopped"
    if controller == "failed" then return "Connector: FAILED · " .. tostring(state.listenerMessage or state.listenerErrorCode or "Open AI Setup") end
    if controller == "running" then
      local listening = state.listenerState == "connected"
      local listenerName = type(state.listenerName) == "string" and state.listenerName or (type(state.appConnector) == "string" and state.appConnector or "AI app")
      if state.listenerPhase == "failed" then
        local code = type(state.listenerErrorCode) == "string" and state.listenerErrorCode or "APP_LISTENER_FAILED"
        return "Connector: " .. string.upper(listenerName) .. " FAILED · " .. code
      end
      if state.listenerPhase == "starting" then return "Connector: STARTING " .. string.upper(listenerName) .. "..." end
      local listenerLabel = listenerName .. " connected"
      if hasPendingCommand() then return "Connector: AWAITING YOUR APPROVAL" end
      if isAiCueWaiting() then
        local elapsed = math.max(0, os.time() - DB.getValue(aiCuePath("requestedepoch"), os.time()))
        -- A resumed cue keeps its original request time. Response timing must
        -- describe the current listener attempt, not time spent stopped.
        if state.aiResponseState == "responding" or state.aiResponseState == "overdue" then
          elapsed = math.max(0, math.floor(tonumber(state.cueClaimAgeSeconds) or 0))
        end
        local timing = " (" .. tostring(elapsed) .. "s)"
        if state.aiResponseState == "awaiting_approval" then return "Connector: APPLYING / AWAITING APPROVAL" .. timing end
        if state.aiResponseState == "responding" then return "Connector: " .. string.upper(listenerName) .. " RESPONDING" .. timing end
        if state.aiResponseState == "overdue" then return "Connector: RESPONSE SLOW" .. timing .. " · Stop Nerve cancels; then Start to retry" end
        return listening and ("Connector: QUEUED" .. timing .. " · " .. listenerLabel) or ("Connector: STALLED" .. timing .. " · no AI listener")
      end
      local readyText = listening and ("Connector: READY · " .. listenerLabel) or "Connector: READY · no AI listener"
      if type(state.installHealth) == "table" and state.installHealth.status == "reload_required" then return readyText .. " · RELOAD NEEDED" end
      if type(state.installHealth) == "table" and state.installHealth.status == "repair_required" then return readyText .. " · REPAIR NEEDED" end
      return readyText
    end
    return "Connector: STOPPED · start before play"
  end
  if state.connectionMode == "manual" or state.connectionMode == "companion" or state.provider == "manual" or state.provider == "companion" then
    return isAiCueWaiting() and "Manual fallback: RESPONSE NEEDED" or "Manual fallback: IDLE"
  end
  local provider = type(state.provider) == "string" and state.provider or "not configured"
  local controller = type(state.controllerStatus) == "string" and state.controllerStatus or "unknown"
  local lastResult = type(state.lastResult) == "table" and state.lastResult or nil
  if controller == "running" and type(lastResult) == "table" and lastResult.status == "provider_failed" and lastResult.transient == true and tonumber(lastResult.httpStatus) == 429 then
    local seconds = math.max(1, math.ceil((tonumber(lastResult.retryAfterMs) or 65000) / 1000))
    return "Controller: GEMINI FREE-TIER COOLDOWN · retrying in about " .. tostring(seconds) .. "s"
  end
  if type(lastResult) == "table" and lastResult.status == "provider_rate_limited" then
    return "Controller: STOPPED · Gemini free-tier limit reached · restart later"
  end
  local suffix = type(state.errorCode) == "string" and state.errorCode ~= "" and (" · " .. state.errorCode) or ""
  local usageSuffix = ""
  if type(state.usage) == "table" and type(state.usage.totalTokens) == "number" then
    usageSuffix = " · " .. tostring(state.usage.totalTokens) .. " tokens"
  end
  local healthSuffix = ""
  if type(state.installHealth) == "table" and state.installHealth.status == "reload_required" then healthSuffix = " · RELOAD NEEDED"
  elseif type(state.installHealth) == "table" and state.installHealth.status == "repair_required" then healthSuffix = " · REPAIR NEEDED" end
  return "Controller: " .. string.upper(controller) .. " · " .. provider .. usageSuffix .. suffix .. healthSuffix
end

function getControllerButtonText()
  local pending = File.openTextFile(File.getCampaignFolder() .. "/nerve-supervisor-control.json")
  if pending and pending ~= "" then return "REQUESTED..." end
  local state = getControllerSupervisorState()
  if state.configured == false then return "Configure AI" end
  if state.controllerStatus == "stopping" then return "Stopping..." end
  if state.connectionMode == "manual" or state.connectionMode == "companion" or state.provider == "manual" or state.provider == "companion" then return "Open Manual Handoff" end
  if state.controllerStatus == "running" or state.controllerStatus == "starting" or state.controllerStatus == "stopping" then
    return "Stop Nerve"
  end
  return "Start Nerve"
end

NerveBridgeSetup = {}

function setSetupDraftApp(app)
  NerveBridgeSetup.draftApp = app
end

function getSetupDraftApp()
  return NerveBridgeSetup.draftApp
end

function isSetupReadyToStart()
  local state = getControllerSupervisorState()
  if state.connectionMode ~= "connector" then return true end
  if state.setupBusy == true or state.connectionVerified ~= true or (NerveBridgeSetup.draftApp and NerveBridgeSetup.draftApp ~= state.appConnector) or hasPendingNerveRequest("nerve-setup-control.json") then
    ChatManager.SystemMessage("Nerve: finish Test + Use for your chosen AI in Settings before starting.")
    openAiSetup()
    return false
  end
  return true
end

function reconnectNerveBridge()
  if not Session.IsHost then return false end
  if getControllerSupervisorState().status == "online" then
    ChatManager.SystemMessage("Nerve is connected. Continue with your setup or session.")
    return true
  end
  if not NerveBridgeSetup.requestedAt or os.time() - NerveBridgeSetup.requestedAt >= 15 then
    NerveBridgeSetup.requestedAt = os.time()
    Interface.openWindow("url", "nerve-bridge://start")
  end
  ChatManager.SystemMessage("Nerve reconnect requested. Allow Windows to open Nerve if prompted, then press Refresh. If Windows cannot open Nerve, run Install-Nerve once to register it.")
  return false
end

function requireNerveBridge()
  if getControllerSupervisorState().status == "online" then return true end
  reconnectNerveBridge()
  ChatManager.SystemMessage("The action has not been queued. Once Nerve is connected, press the action again.")
  return false
end

function hasPendingNerveRequest(filename)
  local text = File.openTextFile(File.getCampaignFolder() .. "/" .. filename)
  if not text or text == "" then return false end
  local ok, request = pcall(Utility.decodeJSON, text)
  return ok and type(request) == "table" and type(request.expiresAtEpoch) == "number" and request.expiresAtEpoch > os.time()
end

function requestControllerOperation(operation)
  if not Session.IsHost then ChatManager.SystemMessage("Nerve controller operations are available only on the GM host."); return false end
  if operation ~= "start" and operation ~= "stop" and operation ~= "open_companion" and operation ~= "collect_support" and operation ~= "system_check" then return false end
  if not requireNerveBridge() then return false end
  if operation == "start" and not isSetupReadyToStart() then return false end
  if hasPendingNerveRequest("nerve-supervisor-control.json") then
    ChatManager.SystemMessage("Nerve: a controller request is queued. Press Refresh to check progress.")
    return false
  end
  if operation == "start" and not isNerveSessionActive() then
    ChatManager.SystemMessage("Nerve: start tracking before starting the AI controller.")
    return false
  end
  local sequence = DB.getValue("nerve.supervisor.requestsequence", 0) + 1
  DB.setValue("nerve.supervisor.requestsequence", "number", sequence)
  local request = Utility.encodeJSON({
    schemaVersion = "0.1", operation = operation,
    requestId = string.format("fgu-control-%06d-%d", sequence, os.time()),
    campaign = User.getCampaignName(), requestedAtEpoch = os.time(), expiresAtEpoch = os.time() + 120
  })
  if not request then ChatManager.SystemMessage("Nerve: controller request could not be encoded."); return false end
  File.saveTextFile(File.getCampaignFolder() .. "/nerve-supervisor-control.json", request)
  if operation == "open_companion" then
    ChatManager.SystemMessage("Nerve Companion requested on the GM computer.")
  elseif operation == "collect_support" then
    ChatManager.SystemMessage("Nerve is creating one redacted support bundle in Documents\\Nerve Support. Refresh in a few seconds to confirm completion.")
  elseif operation == "system_check" then
    ChatManager.SystemMessage("Nerve system check requested. Refresh in a few seconds to see the verified result.")
  else
    ChatManager.SystemMessage("Nerve " .. operation .. " requested. Refresh Nerve Control in a few seconds to confirm status.")
  end
  return true
end

function collectSupportBundleFromFgu()
  return requestControllerOperation("collect_support")
end

function runSystemCheckFromFgu()
  return requestControllerOperation("system_check")
end

function reportSupervisorOperationResult()
  if not Session.IsHost then return end
  local state = getControllerSupervisorState()
  if type(state.lastRequestId) ~= "string" or state.lastRequestId == "" then return end
  if DB.getValue("nerve.supervisor.lastreportedrequestid", "") == state.lastRequestId then return end
  DB.setValue("nerve.supervisor.lastreportedrequestid", "string", state.lastRequestId)
  if type(state.errorCode) == "string" and state.errorCode ~= "" then
    ChatManager.SystemMessage("Nerve request failed (" .. state.errorCode .. "). " .. tostring(state.message or "Open Support Bundle for diagnostics."))
  elseif type(state.message) == "string" and state.message ~= "" then
    ChatManager.SystemMessage("Nerve: " .. state.message)
  end
end

function toggleControllerFromFgu()
  if not requireNerveBridge() then return false end
  if hasPendingNerveRequest("nerve-supervisor-control.json") then
    ChatManager.SystemMessage("Nerve: a controller request is already waiting for the supervisor.")
    return false
  end
  local state = getControllerSupervisorState()
  if state.configured == false then openAiSetup(); return true end
  if state.connectionMode == "manual" or state.connectionMode == "companion" or state.provider == "manual" or state.provider == "companion" then return requestControllerOperation("open_companion") end
  local running = state.controllerStatus == "running" or state.controllerStatus == "starting" or state.controllerStatus == "stopping"
  return requestControllerOperation(running and "stop" or "start")
end

function beginNerveSession()
  if not Session.IsHost then ChatManager.SystemMessage("Nerve sessions can be started only on the GM host."); return false end
  if isNerveSessionActive() then ChatManager.SystemMessage("Nerve: this session is already running."); return false end
  if not requireNerveBridge() then return false end
  if not isSetupReadyToStart() then return false end
  if hasPendingNerveRequest("nerve-supervisor-control.json") then ChatManager.SystemMessage("Nerve: wait for the current controller request to finish."); return false end
  local state = getControllerSupervisorState()
  if state.configured == false then openAiSetup(); return false end
  if state.controllerStatus == "stopping" then ChatManager.SystemMessage("Nerve: the AI controller is still stopping. Try Begin Session again in a few seconds."); return false end
  if not startNerveSession() then return false end
  local running = state.controllerStatus == "running" or state.controllerStatus == "starting"
  if not running then
    local manual = state.connectionMode == "manual" or state.connectionMode == "companion" or state.provider == "manual" or state.provider == "companion"
    if not requestControllerOperation(manual and "open_companion" or "start") then return false end
  end
  if not isFlowModeActive() then toggleFlowMode() end
  ChatManager.SystemMessage("Nerve session launch requested. Tracking, Flow Mode, and the configured AI connection are being prepared automatically.")
  refreshNerveControlWindows()
  return true
end

function getAiProviderDefaults()
  return {
    connector = { label = "AI App Connector", model = "" },
    manual = { label = "Manual Handoff", model = "" },
    companion = { label = "Manual Handoff", model = "" },
    fake = { label = "Offline Test", model = "" },
    ollama = { label = "Ollama Local AI", model = "qwen3:4b" },
    openai = { label = "OpenAI / ChatGPT", model = "gpt-5.6-luna" },
    anthropic = { label = "Anthropic / Claude", model = "claude-sonnet-5" },
    gemini = { label = "Google Gemini", model = "gemini-3.7-flash" },
    xai = { label = "xAI / Grok", model = "grok-4.6" }
  }
end

function getAiSetupStatusText()
  local state = getControllerSupervisorState()
  if state.status == "offline" then return "Nerve is disconnected. Click Reconnect Nerve, then Refresh. First time on this computer? Run Install-Nerve once to enable connection from Fantasy Grounds." end
  if state.status == "invalid" then return "The local Nerve bridge returned an invalid status." end
  if hasPendingNerveRequest("nerve-setup-control.json") then return "Setup request queued with Nerve. Press Refresh to check progress; no provider window has been confirmed yet." end
  if state.configured then
    if state.connectionMode == "connector" or state.provider == "connector" then
      local running = state.controllerStatus == "running"
      if not running then return "AI App Connector is saved but STOPPED. Use Start Nerve in Nerve Control before play." end
      if state.aiResponseState == "responding" then return "The AI has claimed the current cue and is preparing its response. No GM action is needed." end
      if state.aiResponseState == "overdue" then return "The AI claimed the cue but did not answer within five minutes. Restart or reconnect the AI listener; the cue remains available." end
      local listenerName = type(state.listenerName) == "string" and state.listenerName or (type(state.appConnector) == "string" and state.appConnector or "AI app")
      if state.listenerPhase == "failed" then return listenerName .. " could not start (" .. tostring(state.listenerErrorCode or "APP_LISTENER_FAILED") .. "). Run System Check or Support Bundle for details." end
      if state.listenerPhase == "starting" then return "Nerve is starting " .. listenerName .. ". Refresh in a few seconds." end
      if state.listenerState == "connected" then return "AI App Connector is READY with " .. listenerName .. ". Cues and responses are automatic; no API key or copy/paste is needed." end
      if state.listenerState == "connected" then return "AI App Connector is READY and an AI listener is connected. Flow Mode can deliver event-driven cues automatically." end
      return "AI App Connector is READY, but no AI listener is connected. Start Nerve to launch the built-in signed-in Codex listener."
    end
    if state.connectionMode == "manual" or state.connectionMode == "companion" or state.provider == "manual" or state.provider == "companion" then
      return "Manual compatibility fallback is configured. It requires copy/paste and is not the recommended automatic path."
    end
    local provider = type(state.provider) == "string" and state.provider or "unknown"
    local model = type(state.model) == "string" and state.model ~= "" and (" / " .. state.model) or ""
    return "Configured: " .. provider .. model .. ". You can save below to change it."
  end
  if state.setupStatus == "secure_prompt_opened" then return "Secure key window opened on this GM computer. Finish that window, then Refresh." end
  if state.setupStatus == "failed" then return "Setup failed: " .. (state.errorCode or "SETUP_OPERATION_FAILED") end
  return "Not configured yet. AI App Connector is the no-copy integration path but requires a compatible AI listener; Direct API is unattended but requires a provider API key."
end

function getAppConnectorStatusText(appConnector)
  local state = getControllerSupervisorState()
  if state.status ~= "online" then return "Connect Nerve first using Reconnect Nerve below, then Refresh and retry your setup step." end
  local connectors = type(state.appConnectors) == "table" and state.appConnectors or {}
  local app = type(connectors[appConnector]) == "table" and connectors[appConnector] or nil
  if not app then return "Status is not available yet. Press Refresh after the local Nerve bridge updates." end
  local label = type(app.label) == "string" and app.label or appConnector
  if app.lastStatus == "working" and app.lastOperation == "signin" then return label .. ": sign-in app opened. Once signed in, use Test + Use below." end
  if app.lastStatus == "working" then return label .. ": testing/saving. This window updates automatically." end
  if app.lastStatus == "failed" then return label .. ": setup failed (" .. tostring(app.lastCode or "APP_CONNECTOR_OPERATION_FAILED") .. "). Use Install / Repair or Support Bundle." end
  if app.lastStatus == "ready" then return label .. ": INSTALLED, SIGNED IN, and connection tested. Ready to use." end
  if app.lastStatus == "signin_complete" then return label .. ": sign-in finished but not yet verified. Use Test Connection when ready." end
  if app.installed == true then return label .. ": INSTALLED. Sign in, then use Test Connection. The test may use provider allowance." end
  return label .. ": NOT INSTALLED. Use Install / Repair for guided setup."
end

function requestAppConnectorOperation(operation, appConnector, allowWrites)
  if not Session.IsHost then ChatManager.SystemMessage("Nerve Settings is available only on the GM host."); return false end
  if operation ~= "install" and operation ~= "signin" and operation ~= "test" and operation ~= "connect" then return false end
  local allowed = { codex = true, antigravity = true, claude = true, grok = true, custom = true }
  if not allowed[appConnector] then ChatManager.SystemMessage("Nerve: choose a supported AI app."); return false end
  if not requireNerveBridge() then return false end
  local supervisor = getControllerSupervisorState()
  if supervisor.controllerStatus == "starting" or supervisor.controllerStatus == "running" or supervisor.controllerStatus == "stopping" then
    ChatManager.SystemMessage("Nerve: stop the AI controller before installing, signing in, or testing an AI app.")
    return false
  end
  if hasPendingNerveRequest("nerve-setup-control.json") then ChatManager.SystemMessage("Nerve: a setup step is queued internally. Press Refresh to check progress; this does not mean an authentication window is open."); return false end
  local sequence = DB.getValue("nerve.supervisor.setupsequence", 0) + 1
  DB.setValue("nerve.supervisor.setupsequence", "number", sequence)
  local request = Utility.encodeJSON({
    schemaVersion = "0.1", operation = "app_" .. operation,
    requestId = string.format("fgu-app-setup-%06d-%d", sequence, os.time()),
    campaign = User.getCampaignName(), appConnector = appConnector, allowWrites = allowWrites == true,
    requestedAtEpoch = os.time(), expiresAtEpoch = os.time() + 300
  })
  if not request then ChatManager.SystemMessage("Nerve: the AI app request could not be encoded."); return false end
  File.saveTextFile(File.getCampaignFolder() .. "/nerve-setup-control.json", request)
  if operation == "install" then
    ChatManager.SystemMessage("Nerve guided install requested. The installer will identify its official source and ask before downloading provider software.")
  elseif operation == "signin" then
    ChatManager.SystemMessage("Nerve provider sign-in requested. Authentication stays with the provider; Nerve does not receive your password or OAuth token.")
  elseif operation == "connect" then
    ChatManager.SystemMessage("Nerve will test and save " .. appConnector .. ". This test may use provider account allowance. Wait for the saved-provider confirmation before starting.")
  else
    ChatManager.SystemMessage("Nerve connection test requested. This small provider request may use account allowance.")
  end
  return true
end

function requestAiConfiguration(provider, model, allowWrites, liveCheck, appConnector)
  if not Session.IsHost then ChatManager.SystemMessage("Nerve AI setup is available only on the GM host."); return false end
  if not requireNerveBridge() then return false end
  local supervisor = getControllerSupervisorState()
  if supervisor.controllerStatus == "starting" or supervisor.controllerStatus == "running" or supervisor.controllerStatus == "stopping" then
    ChatManager.SystemMessage("Nerve: stop the AI controller before changing its provider settings.")
    return false
  end
  local defaults = getAiProviderDefaults()[provider]
  if not defaults then ChatManager.SystemMessage("Nerve: choose a supported AI provider."); return false end
  model = type(model) == "string" and model or ""
  if provider ~= "connector" and provider ~= "manual" and provider ~= "fake" and provider ~= "companion" then
    if #model < 2 or #model > 128 or not string.match(model, "^[%w%._:%-]+$") then
      ChatManager.SystemMessage("Nerve: enter a valid provider model ID using letters, numbers, dots, underscores, colons, or hyphens.")
      return false
    end
  else model = "" end
  if hasPendingNerveRequest("nerve-setup-control.json") then ChatManager.SystemMessage("Nerve: a setup step is queued internally. Press Refresh to check progress."); return false end
  local sequence = DB.getValue("nerve.supervisor.setupsequence", 0) + 1
  DB.setValue("nerve.supervisor.setupsequence", "number", sequence)
  local request = Utility.encodeJSON({
    schemaVersion = "0.1", operation = "configure",
    requestId = string.format("fgu-setup-%06d-%d", sequence, os.time()),
    campaign = User.getCampaignName(), provider = provider, model = model,
    appConnector = provider == "connector" and (appConnector or "codex") or nil,
    allowWrites = allowWrites == true, liveCheck = liveCheck == true,
    requestedAtEpoch = os.time(), expiresAtEpoch = os.time() + 120
  })
  if not request then ChatManager.SystemMessage("Nerve: AI setup request could not be encoded."); return false end
  File.saveTextFile(File.getCampaignFolder() .. "/nerve-setup-control.json", request)
  if provider == "connector" then
    ChatManager.SystemMessage("Nerve AI App Connector setup requested. After it saves, use Start Nerve and confirm the cue channel reports READY. A compatible AI integration must also be monitoring it.")
  elseif provider == "manual" or provider == "companion" then
    ChatManager.SystemMessage("Nerve manual compatibility fallback requested. This mode requires copy/paste.")
  elseif provider == "fake" then
    ChatManager.SystemMessage("Nerve offline setup requested.")
  elseif provider == "ollama" then
    ChatManager.SystemMessage("Nerve Ollama setup requested. Ollama and the selected model must already be installed on this computer; no API key or paid fallback will be used.")
  else
    ChatManager.SystemMessage("Nerve direct API setup requested. A secure API-key window will open on this GM computer; the key is never saved in Fantasy Grounds.")
  end
  return true
end

function openAiSetup()
  if not Session.IsHost then ChatManager.SystemMessage("Nerve AI setup is available only on the GM host."); return end
  Interface.openWindow("nerve_ai_setup", "")
end

local function publishAiCue(actor, source)
  if not Session.IsHost then return false end
  local nowEpoch = os.time()
  local status = DB.getValue(aiCuePath("status"), "idle")
  if status == "called" then
    local existingSource = DB.getValue(aiCuePath("source"), "control")
    local existingId = DB.getValue(aiCuePath("cueid"), "")
    local kind = string.sub(existingSource, 1, 10) == "automatic:" and "automatic cue" or "Call Nerve cue"
    ChatManager.SystemMessage("Nerve: " .. kind .. " " .. existingId .. " is already waiting. The existing request was kept.")
    if source == "player" and actor and actor ~= "" then
      Comm.deliverOOBMessage({ type = OOB_MSGTYPE_AI_CUE_STATUS, status = "called" }, actor)
    end
    refreshNerveControlWindows()
    return true
  end
  local lastEpoch = DB.getValue(aiCuePath("requestedepoch"), 0)
  local requestCount = status == "called" and nowEpoch - lastEpoch <= 5 and
    DB.getValue(aiCuePath("requestcount"), 1) + 1 or 1
  local cueSequence = DB.getValue(aiCuePath("sequence"), 0) + 1
  local cueId = string.format("cue-%06d", cueSequence)
  local requestedAt = os.date("!%Y-%m-%dT%H:%M:%SZ")
  local automatic = type(source) == "string" and string.sub(source, 1, 10) == "automatic:"
  local triggerType = automatic and string.sub(source, 11) or ""
  DB.setValue(aiCuePath("status"), "string", "called")
  DB.setValue(aiCuePath("sequence"), "number", cueSequence)
  DB.setValue(aiCuePath("cueid"), "string", cueId)
  DB.setValue(aiCuePath("actor"), "string", actor or "GM")
  DB.setValue(aiCuePath("source"), "string", source or "control")
  DB.setValue(aiCuePath("requestedat"), "string", requestedAt)
  DB.setValue(aiCuePath("requestedepoch"), "number", nowEpoch)
  DB.setValue(aiCuePath("requestcount"), "number", requestCount)
  publishSnapshot("ai-cue-requested", {
    type = "ai.cue_requested", actor = actor or "GM",
    text = automatic and ("Automatic Nerve cue requested: " .. triggerType) or "Call Nerve requested", visibility = "gm", subjectId = cueId,
    data = {
      cueId = cueId, source = source or "control", requestCount = requestCount,
      latestSequenceBeforeCue = eventSequence, triggerType = triggerType
    }
  })
  if automatic then
    local supervisor = getControllerSupervisorState()
    if supervisor.listenerState == "connected" then
      ChatManager.SystemMessage("Nerve created an automatic AI cue for " .. triggerType .. ". The AI listener is connected.")
    else
      ChatManager.SystemMessage("Nerve created an automatic AI cue for " .. triggerType .. ", but no AI listener is connected. Open or start the configured AI integration.")
    end
  else
    local supervisor = getControllerSupervisorState()
    local listenerNote = supervisor.connectionMode == "connector" and supervisor.listenerState ~= "connected" and " No AI listener is currently connected." or ""
    ChatManager.SystemMessage("Call Nerve received. Waiting for the active AI monitor; the control will change when a response is delivered." .. listenerNote)
  end
  if isFlowModeActive() and startFlowInboxPoll then startFlowInboxPoll() end
  if startAiCueResultPoll then startAiCueResultPoll() end
  refreshNerveControlWindows()
  if source == "player" and actor and actor ~= "" then
    Comm.deliverOOBMessage({ type = OOB_MSGTYPE_AI_CUE_STATUS, status = "called" }, actor)
  end
  return true
end

function requestAutomaticConnectorCue(trigger)
  if not Session.IsHost or type(trigger) ~= "table" or not AUTOMATIC_CONNECTOR_CUE_EVENT_TYPES[trigger.type] then return false end
  if not isNerveSessionActive() or isNerveHeld() or not isFlowModeActive() or isAiCueWaiting() then return false end
  local supervisor = getControllerSupervisorState()
  if supervisor.status ~= "online" or supervisor.controllerStatus ~= "running" then return false end
  if supervisor.connectionMode ~= "connector" and supervisor.provider ~= "connector" then return false end
  local nowEpoch = os.time()
  if nowEpoch - DB.getValue(aiCuePath("lastautomaticepoch"), 0) < 3 then return false end
  DB.setValue(aiCuePath("lastautomaticepoch"), "number", nowEpoch)
  return publishAiCue("GM", "automatic:" .. trigger.type)
end

function requestPendingAutomaticConnectorCue()
  if not automaticConnectorCueTrigger or not requestAutomaticConnectorCue then return false end
  local trigger = automaticConnectorCueTrigger
  if not requestAutomaticConnectorCue(trigger) then return false end
  automaticConnectorCueTrigger = nil
  return true
end

function handleAiCueRequest(msgOOB)
  if not Session.IsHost or type(msgOOB) ~= "table" then return end
  local actor = type(msgOOB.username) == "string" and msgOOB.username or "Player"
  publishAiCue(actor, "player")
end

function callNerve()
  if Session.IsHost then return publishAiCue("GM", "control") end
  clientAiCueStatus = "called"
  clientAiCueLatencySeconds = nil
  Comm.deliverOOBMessage({
    type = OOB_MSGTYPE_AI_CUE,
    username = User.getUsername() or "Player"
  })
  ChatManager.SystemMessage("Call Nerve received by the GM host. Waiting for the active AI monitor.")
  refreshNerveControlWindows()
  return true
end

function publishOocQuestion(username, question, requesterRole)
  if not Session.IsHost then return false end
  question = NerveCampaignMemory.truncate(question, 500)
  if question == "" then return false end
  local requester = username and username ~= "" and username or "GM"
  local role = requesterRole == "gm" and "gm" or "player"
  publishSnapshot("ooc-question", {
    type = "ooc.question", actor = requester, text = question, visibility = "gm", subjectId = requester,
    data = { outOfCharacter = true, requesterRole = role, replyVisibility = role == "gm" and "gm" or "recipients", recipients = role == "gm" and {} or { requester }, spoilerPolicy = role == "gm" and "gm_private_adventure_context_allowed" or "public_or_character_established_only" }
  })
  ChatManager.SystemMessage("Nerve received an out-of-character question from " .. requester .. ".")
  return true
end

function handleOocQuestion(msgOOB)
  if not Session.IsHost or type(msgOOB) ~= "table" then return end
  publishOocQuestion(type(msgOOB.username) == "string" and msgOOB.username or "Player", msgOOB.question, "player")
end

function submitOocQuestion(question)
  question = NerveCampaignMemory.truncate(question, 500)
  if question == "" then ChatManager.SystemMessage("Nerve: enter an out-of-character question first."); return false end
  if Session.IsHost then return publishOocQuestion("GM", question, "gm") end
  Comm.deliverOOBMessage({ type = OOB_MSGTYPE_OOC_QUESTION, username = User.getUsername() or "Player", question = question })
  ChatManager.SystemMessage("Your private out-of-character question was sent to Nerve through the GM host.")
  return true
end

function openOocQuestion() Interface.openWindow("nerve_ooc_question", "") end

function processOocQuestionSlash(command, params)
  local question = tostring(params or "")
  if question == "" then openOocQuestion() else submitOocQuestion(question) end
end

NerveSessionOpening = { modes = { session_zero = true, session_one = true, resume = true } }

function NerveSessionOpening.publishPending()
  if not Session.IsHost or not isNerveSessionActive() or isNerveHeld() or not isFlowModeActive() or isAiCueWaiting() then return false end
  if DB.getValue("nerve.sessionoperations.openingstatus", "") ~= "pending" then return false end
  local mode = DB.getValue("nerve.sessionoperations.openingmode", "")
  if not NerveSessionOpening.modes[mode] then return false end
  if publishAiCue("GM", "session_opening:" .. mode) then
    DB.setValue("nerve.sessionoperations.openingstatus", "string", "requested")
    ChatManager.SystemMessage("Nerve " .. string.gsub(mode, "_", " ") .. " opening requested. It will be grounded in confirmed campaign state and memory.")
    return true
  end
  return false
end

function requestSessionOpening(mode)
  if not Session.IsHost then
    ChatManager.SystemMessage("Nerve session openings are available only on the GM host.")
    return false
  end
  if not NerveSessionOpening.modes[mode] then
    ChatManager.SystemMessage("Nerve: choose Session 0, Session 1, or Resume.")
    return false
  end
  if not isNerveSessionActive() then return startNerveSession(mode) end
  if isAiCueWaiting() then
    ChatManager.SystemMessage("Nerve: an AI response is already waiting; try the session opening after it completes.")
    return false
  end
  DB.setValue("nerve.sessionoperations.openingmode", "string", mode)
  DB.setValue("nerve.sessionoperations.openingstatus", "string", "pending")
  if NerveSessionOpening.publishPending() then return true end
  ChatManager.SystemMessage("Nerve session opening saved. Enable Flow Mode to deliver it automatically.")
  publishSnapshot("session-opening-pending", nil, true)
  refreshNerveControlWindows()
  return true
end

function openSessionOpening()
  if not Session.IsHost then
    ChatManager.SystemMessage("Nerve session openings are available only on the GM host.")
    return
  end
  Interface.openWindow("nerve_session_opening", "")
end

function handleAiCueStatus(msgOOB)
  if Session.IsHost or type(msgOOB) ~= "table" then return end
  if msgOOB.status ~= "called" and msgOOB.status ~= "answered" and msgOOB.status ~= "failed" and msgOOB.status ~= "idle" then return end
  clientAiCueStatus = msgOOB.status
  clientAiCueLatencySeconds = tonumber(msgOOB.latencySeconds)
  refreshNerveControlWindows()
end

markAiCueFailed = function(errorCode)
  if not Session.IsHost or not isAiCueWaiting() then return end
  local latencySeconds = math.max(0, os.time() - DB.getValue(aiCuePath("requestedepoch"), os.time()))
  DB.setValue(aiCuePath("status"), "string", "failed")
  if stopAiCueResultPoll then stopAiCueResultPoll() end
  DB.setValue(aiCuePath("answeredat"), "string", os.date("!%Y-%m-%dT%H:%M:%SZ"))
  DB.setValue(aiCuePath("latencyseconds"), "number", latencySeconds)
  local actor = DB.getValue(aiCuePath("actor"), "")
  local source = DB.getValue(aiCuePath("source"), "")
  if string.sub(source, 1, 16) == "session_opening:" then DB.setValue("nerve.sessionoperations.openingstatus", "string", "failed") end
  if actor ~= "" and actor ~= "GM" then
    Comm.deliverOOBMessage({ type = OOB_MSGTYPE_AI_CUE_STATUS, status = "failed", latencySeconds = latencySeconds }, actor)
  end
  ChatManager.SystemMessage("Nerve AI response failed: " .. tostring(errorCode or "UNKNOWN_ERROR") .. ". The controller remains available for another Call Nerve unless it reached its failure limit.")
  refreshNerveControlWindows()
end

local function markAiCueAnswered()
  if not Session.IsHost or not isAiCueWaiting() then return end
  local cueId = getAiCueId()
  local answeredAt = os.date("!%Y-%m-%dT%H:%M:%SZ")
  local latencySeconds = math.max(0, os.time() - DB.getValue(aiCuePath("requestedepoch"), os.time()))
  local source = DB.getValue(aiCuePath("source"), "")
  local automatic = string.sub(source, 1, 10) == "automatic:"
  if string.sub(source, 1, 16) == "session_opening:" then DB.setValue("nerve.sessionoperations.openingstatus", "string", "delivered") end
  DB.setValue(aiCuePath("status"), "string", "answered")
  DB.setValue(aiCuePath("answeredat"), "string", answeredAt)
  DB.setValue(aiCuePath("latencyseconds"), "number", latencySeconds)
  local usedStoryCueIds = consumeOneShotStoryCues(cueId)
  if stopAiCueResultPoll then stopAiCueResultPoll() end
  publishSnapshot("ai-cue-answered", {
    type = "ai.cue_answered", actor = "Nerve", text = automatic and "Automatic Nerve cue answered" or "Call Nerve answered",
    visibility = "gm", subjectId = cueId,
    data = { cueId = cueId, latencySeconds = latencySeconds, source = source, storyCueRecordIds = usedStoryCueIds }
  })
  if source == "session_opening:resume" then pendingResumedCombatTurnCue = true end
  local actor = DB.getValue(aiCuePath("actor"), "")
  if actor ~= "" and actor ~= "GM" then
    Comm.deliverOOBMessage({ type = OOB_MSGTYPE_AI_CUE_STATUS, status = "answered", latencySeconds = latencySeconds }, actor)
  end
  refreshNerveControlWindows()
end

function publishPendingResumedCombatTurnCue()
  if not pendingResumedCombatTurnCue then return false end
  pendingResumedCombatTurnCue = false
  local tracker = createCombatTracker()
  for _, combatant in ipairs(tracker.combatants or {}) do
    if combatant.active and combatant.faction == "foe" and combatant.disposition == "active" then
      publishSnapshot("session-opening-combat-resume", {
        type = "combat.turn_started", actor = combatant.name,
        text = "Resumed active turn: " .. combatant.name, visibility = "all", subjectId = combatant.id,
        data = { previousCombatantId = "", round = tracker.round, resumed = true }
      })
      return true
    end
  end
  return false
end

local function combatantPulseState(combatant)
  local effects = {}
  for _, effect in ipairs(combatant.effects) do
    if effect.label ~= "" then
      effects[effect.id] = { label = effect.label, duration = effect.duration, gmOnly = effect.gmOnly }
    end
  end
  return {
    name = combatant.name,
    wounds = combatant.hitPoints.wounds,
    temporary = combatant.hitPoints.temporary,
    total = combatant.hitPoints.total,
    effects = effects
  }
end

local function rememberCombatPulseState(tracker)
  local state = { initialized = true, round = tracker.round, activeId = nil, combatants = {} }
  for _, combatant in ipairs(tracker.combatants) do
    if combatant.active then state.activeId = combatant.id end
    state.combatants[combatant.id] = combatantPulseState(combatant)
  end
  pulseCombatState = state
end

local function emitCombatPulseEvents(tracker)
  if not pulseCombatState.initialized then
    rememberCombatPulseState(tracker)
    return
  end

  local nextActiveId = nil
  local nextById = {}
  for _, combatant in ipairs(tracker.combatants) do
    nextById[combatant.id] = combatant
    if combatant.active then nextActiveId = combatant.id end
  end

  if tracker.round ~= pulseCombatState.round then
    appendRecentEvent(
      "combat.round_changed", "", "Round changed to " .. tostring(tracker.round), "all", "combat-tracker",
      { previousRound = pulseCombatState.round, round = tracker.round }
    )
  end
  if nextActiveId and nextActiveId ~= pulseCombatState.activeId then
    local active = nextActiveId and nextById[nextActiveId] or nil
    appendRecentEvent(
      "combat.turn_started", active and active.name or "", active and ("Turn started: " .. active.name) or "No active turn", "all",
      nextActiveId or "", { previousCombatantId = pulseCombatState.activeId or "", round = tracker.round }
    )
  end

  for _, combatant in ipairs(tracker.combatants) do
    local previous = pulseCombatState.combatants[combatant.id]
    if previous then
      local woundDelta = combatant.hitPoints.wounds - previous.wounds
      if woundDelta > 0 then
        appendRecentEvent(
          "combat.damage", combatant.name, combatant.name .. " took " .. tostring(woundDelta) .. " wound(s)", "all", combatant.id,
          { amount = woundDelta, wounds = combatant.hitPoints.wounds, totalHitPoints = combatant.hitPoints.total }
        )
      elseif woundDelta < 0 then
        appendRecentEvent(
          "combat.healing", combatant.name, combatant.name .. " recovered " .. tostring(-woundDelta) .. " wound(s)", "all", combatant.id,
          { amount = -woundDelta, wounds = combatant.hitPoints.wounds, totalHitPoints = combatant.hitPoints.total }
        )
      end

      local currentEffects = {}
      for _, effect in ipairs(combatant.effects) do
        if effect.label ~= "" then currentEffects[effect.id] = effect end
        if effect.label ~= "" and not previous.effects[effect.id] then
          appendRecentEvent(
            "combat.effect_added", combatant.name, "Effect added: " .. effect.label, effect.gmOnly and "gm" or "all", combatant.id,
            { effectId = effect.id, label = effect.label, duration = effect.duration }
          )
        end
      end
      for effectId, effect in pairs(previous.effects) do
        if not currentEffects[effectId] then
          appendRecentEvent(
            "combat.effect_removed", combatant.name, "Effect removed: " .. effect.label, effect.gmOnly and "gm" or "all", combatant.id,
            { effectId = effectId, label = effect.label }
          )
        end
      end
    end
  end
  for combatantId, previous in pairs(pulseCombatState.combatants) do
    if not nextById[combatantId] then
      for index = #recentEvents, 1, -1 do
        local event = recentEvents[index]
        if event.subjectId == combatantId and
          (event.type == "combat.healing" or event.type == "combat.effect_removed") then
          table.remove(recentEvents, index)
        end
      end
      appendRecentEvent(
        "combat.removed", previous.name, "Removed from combat tracker: " .. previous.name, "gm", combatantId,
        { disposition = "removed" }
      )
    end
  end
  local previousActiveId = pulseCombatState.activeId
  rememberCombatPulseState(tracker)
  if not nextActiveId then pulseCombatState.activeId = previousActiveId end
end

local function eventTypeForReason(reason)
  if reason == "extension-initialized" then return "adapter.started" end
  if reason == "combat-tracker-changed" then return "combat.changed" end
  if reason == "party-changed" then return "party.changed" end
  if reason == "character-changed" then return "character.changed" end
  if reason == "user-login-changed" then return "users.changed" end
  return "adapter.started"
end

local function createSnapshotFingerprint(summary, tracker, party, characters, openMaps, mapScene)
  local parts = {
    summary.campaignId or "",
    summary.name or "",
    summary.ruleset or "",
    tostring(summary.connectedPlayers or 0),
    tostring(summary.inCombat == true),
    summary.activeEncounterId or "",
    tostring(tracker.round or 0),
    DB.getValue("nerve.sessionoperations.status", "not_started"),
    tostring(DB.getValue("nerve.sessionoperations.held", 0)),
    tostring(sessionMetric("actionsprocessed")),
    tostring(sessionMetric("approved")),
    tostring(sessionMetric("denied")),
    tostring(sessionMetric("failed")),
    tostring(sessionMetric("sessiongrantexecutions")),
    tostring(libraryCatalog and #(libraryCatalog.records or {}) or 0)
  }

  for _, combatant in ipairs(tracker.combatants) do
    table.insert(parts, combatant.id)
    table.insert(parts, combatant.name)
    table.insert(parts, combatant.type)
    table.insert(parts, combatant.faction)
    table.insert(parts, tostring(combatant.initiative))
    table.insert(parts, tostring(combatant.active))
    table.insert(parts, combatant.status)
    table.insert(parts, tostring(combatant.hitPoints.total))
    table.insert(parts, tostring(combatant.hitPoints.temporary))
    table.insert(parts, tostring(combatant.hitPoints.wounds))
    for _, effect in ipairs(combatant.effects) do
      table.insert(parts, effect.id)
      table.insert(parts, effect.label)
      table.insert(parts, tostring(effect.duration))
      table.insert(parts, tostring(effect.initiative))
      table.insert(parts, tostring(effect.active))
      table.insert(parts, tostring(effect.gmOnly))
    end
  end

  for _, member in ipairs(party.members) do
    table.insert(parts, member.id)
    table.insert(parts, member.name)
    table.insert(parts, member.race)
    table.insert(parts, member.classLevel)
    table.insert(parts, tostring(member.armorClass))
    table.insert(parts, tostring(member.passivePerception))
    for _, abilityName in ipairs({ "strength", "dexterity", "constitution", "intelligence", "wisdom", "charisma" }) do
      local ability = member.abilities[abilityName]
      table.insert(parts, tostring(ability.score))
      table.insert(parts, tostring(ability.modifier))
    end
    table.insert(parts, tostring(member.experience.current))
    table.insert(parts, tostring(member.experience.nextLevel))
    table.insert(parts, tostring(member.hitDice.total))
    table.insert(parts, tostring(member.hitDice.used))
    table.insert(parts, tostring(member.hitPoints.total))
    table.insert(parts, tostring(member.hitPoints.wounds))
    table.insert(parts, member.senses)
  end

  for _, character in ipairs(characters) do
    table.insert(parts, Utility.encodeJSON(character) or character.id)
  end

  table.insert(parts, openMaps.currentMapId or "")
  for _, map in ipairs(openMaps.maps) do
    table.insert(parts, map.recordId)
    table.insert(parts, map.panel)
    table.insert(parts, map.shareMode)
    table.insert(parts, table.concat(map.holders, ","))
  end
  table.insert(parts, mapScene.playStyle)
  for _, token in ipairs(mapScene.tokens or {}) do
    table.insert(parts, token.tokenId)
    table.insert(parts, token.combatantId)
    table.insert(parts, tostring(token.x))
    table.insert(parts, tostring(token.y))
    table.insert(parts, tostring(token.playerVisible))
  end

  return table.concat(parts, "|")
end

function publishSnapshot(reason, eventData, suppressReasonEvent)
  if not Session.IsHost then
    return
  end

  local campaignSummary = createCampaignSummary()
  local combatTracker = createCombatTracker()
  if not pulseCombatState.initialized then rememberCombatPulseState(combatTracker) end
  local party = createParty()
  local characters = createCharacters()
  local openMaps = createOpenMapState()
  local mapScene = createMapSceneState(openMaps)
  local savedFocusModule = DB.getValue("nerve.campaignfocus.module", "")
  local focusModule = savedFocusModule ~= "" and savedFocusModule or moduleFromRecordId(mapScene.recordId)
  if not libraryCatalog or libraryCatalog.focusModule ~= focusModule then
    libraryCatalog = createLibraryCatalog(focusModule, characters)
    local libraryEncoded = Utility.encodeJSON(libraryCatalog)
    if libraryEncoded then
      File.saveTextFile(File.getCampaignFolder() .. "/" .. LIBRARY_FILENAME, libraryEncoded)
    end
  end
  local fingerprint = createSnapshotFingerprint(campaignSummary, combatTracker, party, characters, openMaps, mapScene)
  if reason ~= "extension-initialized" and fingerprint == lastSnapshotFingerprint and not eventData then
    return
  end

  lastSnapshotFingerprint = fingerprint
  if eventData then
    appendRecentEvent(eventData.type, eventData.actor, eventData.text, eventData.visibility, eventData.subjectId, eventData.data)
  elseif not suppressReasonEvent then
    appendRecentEvent(eventTypeForReason(reason), "", reason or "snapshot", "gm")
  end
  snapshotSequence = snapshotSequence + 1
  local snapshot = {
    schemaVersion = "1.4",
    adapterVersion = ADAPTER_VERSION,
    sequence = snapshotSequence,
    reason = reason or "unspecified",
    generatedAt = os.date("!%Y-%m-%dT%H:%M:%SZ"),
    campaignSummary = campaignSummary,
    combatTracker = combatTracker,
    party = party,
    characters = characters,
    manualAdjudications = createManualAdjudicationState(),
    sessionOperations = createSessionOperationsState(campaignSummary, combatTracker, party),
    aiCue = {
      status = DB.getValue(aiCuePath("status"), "idle"),
      cueId = DB.getValue(aiCuePath("cueid"), ""),
      sequence = DB.getValue(aiCuePath("sequence"), 0),
      actor = DB.getValue(aiCuePath("actor"), ""),
      source = DB.getValue(aiCuePath("source"), ""),
      requestedAt = DB.getValue(aiCuePath("requestedat"), ""),
      requestedEpoch = DB.getValue(aiCuePath("requestedepoch"), 0),
      requestCount = DB.getValue(aiCuePath("requestcount"), 0),
      answeredAt = DB.getValue(aiCuePath("answeredat"), ""),
      latencySeconds = DB.getValue(aiCuePath("latencyseconds"), -1)
    },
    sessionContinuity = createSessionContinuityState(),
    openMaps = openMaps,
    mapScene = mapScene,
    campaignFocus = createCampaignFocusState(mapScene),
    storyCues = getStoryCueState(),
    questLog = createQuestLogState(),
    recentEvents = {
      events = recentEvents,
      streamId = eventStreamId,
      latestSequence = eventSequence,
      observedAt = os.date("!%Y-%m-%dT%H:%M:%SZ")
    }
  }

  local encoded = Utility.encodeJSON(snapshot)
  if not encoded then
    Debug.console("Nerve Adapter: unable to encode campaign snapshot")
    return
  end

  local snapshotPath = File.getCampaignFolder() .. "/" .. SNAPSHOT_FILENAME
  File.saveTextFile(snapshotPath, encoded)
  Debug.console("Nerve Adapter: published snapshot " .. tostring(snapshotSequence))
  requestPendingAutomaticConnectorCue()
end

local function onCombatStateChanged()
  if suppressCombatStateChanged then return end
  emitCombatPulseEvents(createCombatTracker())
  publishSnapshot("combat-tracker-changed", nil, true)
end

local function onUserLoginChanged()
  publishSnapshot("user-login-changed")
end

local function onPartyChanged()
  publishSnapshot("party-changed")
end

local function onCharacterChanged()
  publishSnapshot("character-changed")
end

local function onLibraryModuleChanged()
  local savedFocusModule = DB.getValue("nerve.campaignfocus.module", "")
  libraryCatalog = createLibraryCatalog(savedFocusModule ~= "" and savedFocusModule or moduleFromRecordId(currentMapId), createCharacters())
  local encoded = Utility.encodeJSON(libraryCatalog)
  if encoded then
    File.saveTextFile(File.getCampaignFolder() .. "/" .. LIBRARY_FILENAME, encoded)
  end
  publishSnapshot("library-changed", nil, true)
  ChatManager.SystemMessage("Nerve library index refreshed: " .. tostring(#libraryCatalog.records) .. " record(s).")
end

local function onImageWindowOpened(window)
  if not Session.IsHost or not window or suppressImageWindowEvent then return end
  local windowClass = window.getClass and window.getClass() or ""
  if RecordDataManager.getRecordTypeFromDisplayClass(windowClass) ~= "image" then return end
  local nodeRecord = WindowManager.getOuterWindowDatabaseNode(window)
  if not nodeRecord then return end
  currentMapId = DB.getPath(nodeRecord)
  publishSnapshot("map-opened", {
    type = "map.opened", actor = "GM", text = DB.getValue(nodeRecord, "name", ""),
    visibility = "gm", subjectId = currentMapId,
    data = { panel = imagePanelName(windowClass), source = "fantasy_grounds" }
  })
end

local function onImageWindowClosed(windowClass)
  if not Session.IsHost or RecordDataManager.getRecordTypeFromDisplayClass(windowClass or "") ~= "image" then return end
  publishSnapshot("map-closed", nil, true)
end

local function onMapTokenChanged()
  if not Session.IsHost or suppressCombatStateChanged then return end
  publishSnapshot("map-token-changed", {
    type = "map.tokens_changed", actor = "GM", text = "Current-map token state changed.",
    visibility = "gm", subjectId = currentMapId or "", data = { source = "fantasy_grounds" }
  })
end

NerveChatContext = NerveChatContext or {}
NerveChatContext.recentPlayerMessages = NerveChatContext.recentPlayerMessages or {}

function NerveChatContext.getRemotePlayerForChatSender(sender)
  if not Session.IsHost or type(sender) ~= "string" or sender == "" or sender == "Nerve" then return nil end
  for _, username in ipairs(User.getActiveUsers() or {}) do
    if sender == username then return username end
    for _, identityId in ipairs(User.getActiveIdentities(username) or {}) do
      if User.getIdentityLabel(identityId) == sender then return username end
    end
  end
  return nil
end

function NerveChatContext.getHostPartyCharacterForChatSender(sender)
  if not Session.IsHost or type(sender) ~= "string" or sender == "" or sender == "Nerve" then return nil end
  local normalizedSender = string.lower(sender)
  local party = createParty()
  for _, member in ipairs(party.members or {}) do
    if type(member.name) == "string" and string.lower(member.name) == normalizedSender then
      return "GM character"
    end
  end
  return nil
end

function NerveChatContext.getHostGuidanceText(sender, text)
  if not Session.IsHost or string.lower(sender or "") ~= "gm" or type(text) ~= "string" then return nil end
  local _, prefixEnd = string.find(string.lower(text), "^as%s+gm%s*[:%-]?%s*")
  local guidance = string.gsub(prefixEnd and string.sub(text, prefixEnd + 1) or text, "^%s+", "")
  return guidance ~= "" and guidance or nil
end

function NerveChatContext.shouldPublishPlayerMessage(username, actor, text)
  if not username or not actor or not text or text == "" then return false end
  local key = string.lower(username .. "|" .. actor .. "|" .. text)
  local nowEpoch = os.time()
  if nowEpoch - (NerveChatContext.recentPlayerMessages[key] or 0) <= 2 then return false end
  NerveChatContext.recentPlayerMessages[key] = nowEpoch
  return true
end

local function onChatMessageReceived(msg)
  if not msg then return end
  local text = msg.text or ""
  if msg.type == "dice" and text == "" and countEntries(msg.dice or {}) == 0 then return end
  if awaitingVoteCommand and msg.mode == "vote" then
    local command = awaitingVoteCommand.command
    local question = command.arguments and command.arguments.question or ""
    if text == "Nerve asks: " .. question then
      awaitingVoteCommand = nil
      writeCommandResult({
        schemaVersion = "0.1",
        requestId = command.requestId,
        capability = command.capability,
        ok = true,
        executedAt = os.date("!%Y-%m-%dT%H:%M:%SZ"),
        data = { opened = true, question = question, executedAt = os.date("!%Y-%m-%dT%H:%M:%SZ") }
      })
      recordDecision(command, "native vote opened")
      ChatManager.SystemMessage("Nerve executed: request_vote")
    end
  end
  if string.match(text, "^%[TURN%]") or string.match(text, "^%[ROUND%s") then return end
  if string.match(string.lower(text), "^%[understood by:") then return end
  if msg.mode == "whisper" and string.match(text, "^%[Private from Nerve%]") and
      text == lastPrivateNerveMessageText and os.time() - lastPrivateNerveMessageEpoch <= 2 then
    suppressNerveWhisperCallbacks = math.max(0, suppressNerveWhisperCallbacks - 1)
    return
  end
  if msg.type == "languagechatresult" then
    local sender = msg.sender or ""
    if sender == "" then return end
    local actor, language = string.match(sender, "^(.-)%s*%[([^%]]+)%]$")
    actor = actor or sender
    language = language or ""
    text = string.gsub(text, "^%[Translation%]%s*", "")
    local playerSource = NerveChatContext.getRemotePlayerForChatSender(actor) or
      NerveChatContext.getRemotePlayerForChatSender(sender) or
      NerveChatContext.getHostPartyCharacterForChatSender(actor)
    local eventType = playerSource and text ~= "" and msg.mode ~= "whisper" and
      NerveChatContext.shouldPublishPlayerMessage(playerSource, actor, text) and "player.chat_message" or "chat.message"
    publishSnapshot("chat-message", {
      type = eventType,
      actor = actor,
      text = text,
      visibility = "gm",
      data = {
        mode = msg.mode or "",
        messageType = msg.type,
        language = language,
        translated = true,
        playerAuthored = playerSource and eventType == "player.chat_message" or nil,
        sourceUser = playerSource and eventType == "player.chat_message" and playerSource or nil
      }
    })
    return
  end
  local eventType = "chat.message"
  local upper = string.upper(text)
  if string.find(upper, "[ATTACK", 1, true) or string.match(upper, "^ATTACK") then eventType = "roll.attack"
  elseif string.find(upper, "[DAMAGE", 1, true) or string.match(upper, "^DAMAGE") then eventType = "roll.damage"
  elseif string.find(upper, "[HEAL", 1, true) or string.match(upper, "^HEAL") then eventType = "roll.heal"
  elseif string.find(upper, "[SAVE", 1, true) or string.match(upper, "^SAVE") then eventType = "roll.save"
  elseif string.find(upper, "[SKILL", 1, true) or string.match(upper, "^SKILL") then eventType = "roll.skill"
  elseif string.find(upper, "[CHECK", 1, true) or string.match(upper, "^CHECK") then eventType = "roll.check"
  elseif string.find(upper, "[INIT", 1, true) or string.match(upper, "^INIT") then eventType = "roll.initiative"
  elseif msg.dice and countEntries(msg.dice) > 0 then eventType = "roll.result"
  end
  local diceResults = {}
  local diceTotal = 0
  local keptDiceResults = {}
  local droppedDiceResults = {}
  local keptDiceTotal = 0
  -- Final chat-result dice can be keyed rather than a dense Lua array,
  -- especially after traits such as Halfling Luck replace a natural 1.
  -- `pairs` captures the kept reroll that `ipairs` previously missed.
  for _, die in pairs(msg.dice or {}) do
    local result = tonumber(die.result or die.value or 0) or 0
    table.insert(diceResults, result)
    diceTotal = diceTotal + result
    if die.dropped == true or die.dropped == 1 then
      table.insert(droppedDiceResults, result)
    else
      table.insert(keptDiceResults, result)
      keptDiceTotal = keptDiceTotal + result
    end
  end
  local modifier = tonumber(msg.diemodifier or msg.modifier or 0) or 0
  local resolvedDiceTotal = #droppedDiceResults > 0 and keptDiceTotal or diceTotal
  local total = #diceResults > 0 and (resolvedDiceTotal + modifier) or nil
  if text == "" and total then text = "[ROLL] " .. tostring(total) end
  local isSecret = msg.secret == true or msg.secret == 1
  local isWhisper = msg.mode == "whisper"
  local isNerveSystemMessage = (msg.sender or "") == "" and string.match(text, "^Nerve") ~= nil
  local isPrivateNerveMessage = (msg.sender or "") == "Nerve" and
    (isWhisper or string.match(text, "^%[Private from Nerve%]") ~= nil)
  local playerSource = eventType == "chat.message" and not isSecret and not isWhisper and
    not isNerveSystemMessage and not isPrivateNerveMessage and #diceResults == 0 and text ~= "" and
    (NerveChatContext.getRemotePlayerForChatSender(msg.sender or "") or
      NerveChatContext.getHostPartyCharacterForChatSender(msg.sender or "")) or nil
  if playerSource and NerveChatContext.shouldPublishPlayerMessage(playerSource, msg.sender or "", text) then
    eventType = "player.chat_message"
  else
    playerSource = nil
  end
  local hostGuidance = eventType == "chat.message" and not isSecret and not isWhisper and
    not isNerveSystemMessage and not isPrivateNerveMessage and #diceResults == 0 and
    NerveChatContext.getHostGuidanceText(msg.sender or "", text) or nil
  if hostGuidance then
    eventType = "gm.guidance"
    text = hostGuidance
  end
  if isPrivateNerveMessage then
    local nowEpoch = os.time()
    if text == lastPrivateNerveMessageText and nowEpoch - lastPrivateNerveMessageEpoch <= 1 then return end
    lastPrivateNerveMessageText = text
    lastPrivateNerveMessageEpoch = nowEpoch
  end
  local eventData = {
    mode = msg.mode or "",
    messageType = msg.type or "",
    dice = diceResults,
    modifier = modifier,
    total = total
  }
  if playerSource then
    eventData.playerAuthored = true
    eventData.sourceUser = playerSource
  end
  if hostGuidance then eventData.authoritative = true end
  if #keptDiceResults > 0 then eventData.keptDice = keptDiceResults end
  if #droppedDiceResults > 0 then eventData.droppedDice = droppedDiceResults end
  local remoteKey = string.lower((msg.sender or "") .. "|" .. eventType)
  if #diceResults == 0 and eventType ~= "chat.message" and
      os.time() - (recentRemoteRolls[remoteKey] or 0) <= 3 then return end
  publishSnapshot("chat-message", {
    type = eventType,
    actor = msg.sender or "",
    text = text,
    visibility = (isSecret or isWhisper or isNerveSystemMessage) and "gm" or "all",
    data = eventData
  })
end

local function eventTypeForRollDescription(description, fallback)
  local upper = string.upper(description or "")
  if string.find(upper, "[ATTACK", 1, true) or string.match(upper, "^ATTACK") then return "roll.attack" end
  if string.find(upper, "[DAMAGE", 1, true) or string.match(upper, "^DAMAGE") then return "roll.damage" end
  if string.find(upper, "[HEAL", 1, true) or string.match(upper, "^HEAL") then return "roll.heal" end
  if string.find(upper, "[SAVE", 1, true) or string.match(upper, "^SAVE") then return "roll.save" end
  if string.find(upper, "[SKILL", 1, true) or string.match(upper, "^SKILL") then return "roll.skill" end
  if string.find(upper, "[CHECK", 1, true) or string.match(upper, "^CHECK") then return "roll.check" end
  if string.find(upper, "[INIT", 1, true) or string.match(upper, "^INIT") then return "roll.initiative" end
  return fallback or "roll.result"
end

local function handleRemoteRollResult(msgOOB)
  if not Session.IsHost or type(msgOOB) ~= "table" then return end
  local dice = Utility.decodeJSON(msgOOB.diceJson or "[]") or {}
  local keptDice = Utility.decodeJSON(msgOOB.keptDiceJson or "[]") or {}
  local droppedDice = Utility.decodeJSON(msgOOB.droppedDiceJson or "[]") or {}
  local actor = User.getIdentityLabel(msgOOB.identityId or "") or msgOOB.username or "Player"
  local eventType = eventTypeForRollDescription(msgOOB.description, msgOOB.eventType)
  local remoteKey = string.lower(actor .. "|" .. eventType)
  recentRemoteRolls[remoteKey] = os.time()
  for index = #recentEvents, 1, -1 do
    local prior = recentEvents[index]
    if eventSequence - (prior.sequence or 0) > 3 then break end
    if prior.type == eventType and string.lower(prior.actor or "") == string.lower(actor) and
        countEntries((prior.data or {}).dice or {}) == 0 then
      table.remove(recentEvents, index)
      break
    end
  end
  local total = tonumber(msgOOB.total or 0) or 0
  local description = msgOOB.description or ""
  publishSnapshot("remote-dice-landed", {
    type = eventType,
    actor = actor,
    text = description ~= "" and (description .. " [" .. tostring(total) .. "]") or ("[ROLL] " .. tostring(total)),
    visibility = msgOOB.secret == "1" and "gm" or "all",
    subjectId = msgOOB.identityId or "",
    data = {
      source = "remote_player",
      rollType = msgOOB.rollType or "dice",
      dice = dice,
      keptDice = keptDice,
      droppedDice = droppedDice,
      diceTotal = tonumber(msgOOB.diceTotal or 0) or 0,
      rawDiceTotal = tonumber(msgOOB.rawDiceTotal or 0) or 0,
      rollMode = msgOOB.rollMode or "normal",
      modifier = tonumber(msgOOB.modifier or 0) or 0,
      total = total
    }
  })
end

local function onDiceLanded(draginfo)
  if not draginfo then return end
  local dice = draginfo.getDiceData() or {}
  local metadata = draginfo.getMetaDataList() or {}
  local hasAdvantage = metadata.bADV == true or tonumber(metadata.bADV or 0) == 1
  local hasDisadvantage = metadata.bDIS == true or tonumber(metadata.bDIS or 0) == 1
  local diceResults = {}
  local keptDiceResults = {}
  local droppedDiceResults = {}
  local rawDiceTotal = 0
  local keptDiceTotal = 0
  for _, die in ipairs(dice) do
    local result = tonumber(die.result or die.value or 0) or 0
    table.insert(diceResults, result)
    rawDiceTotal = rawDiceTotal + result
    if die.dropped == true or die.dropped == 1 then
      table.insert(droppedDiceResults, result)
    else
      table.insert(keptDiceResults, result)
      keptDiceTotal = keptDiceTotal + result
    end
  end
  local rollMode = "normal"
  if hasAdvantage and not hasDisadvantage then rollMode = "advantage"
  elseif hasDisadvantage and not hasAdvantage then rollMode = "disadvantage" end
  if #droppedDiceResults == 0 and #diceResults >= 2 and rollMode ~= "normal" then
    local dropIndex = 2
    if rollMode == "advantage" and diceResults[1] < diceResults[2] then dropIndex = 1
    elseif rollMode == "disadvantage" and diceResults[1] > diceResults[2] then dropIndex = 1 end
    keptDiceResults = {}
    droppedDiceResults = { diceResults[dropIndex] }
    keptDiceTotal = 0
    for index, result in ipairs(diceResults) do
      if index ~= dropIndex then
        table.insert(keptDiceResults, result)
        keptDiceTotal = keptDiceTotal + result
      end
    end
  end
  local modifier = tonumber(draginfo.getNumberData() or 0) or 0
  local reportedDiceTotal = tonumber(dice.total) or rawDiceTotal
  local resolvedDiceTotal = #droppedDiceResults > 0 and keptDiceTotal or reportedDiceTotal
  local total = resolvedDiceTotal + modifier
  local rollType = draginfo.getSlotType()
  if not rollType or rollType == "" then rollType = draginfo.getType() or "dice" end
  local description = draginfo.getStringData()
  if not description or description == "" then description = draginfo.getDescription() or "" end
  description = string.gsub(description, "%[__ActionsManagerRoll__%]", "")
  local rollData = {
    rollType = rollType,
    dice = diceResults,
    diceTotal = resolvedDiceTotal,
    rawDiceTotal = rawDiceTotal,
    rollMode = rollMode,
    modifier = modifier,
    total = total
  }
  if type(metadata.sNerveRequestId) == "string" and metadata.sNerveRequestId ~= "" then
    rollData.correlationId = metadata.sNerveRequestId
    rollData.characterId = metadata.sNerveCharacterId or ""
    rollData.powerId = metadata.sNervePowerId or ""
    rollData.actionId = metadata.sNerveActionId or ""
    rollData.sourceKind = metadata.sNerveSourceKind or "character"
    if metadata.sNerveCombatantId and metadata.sNerveCombatantId ~= "" then
      rollData.combatantId = metadata.sNerveCombatantId
      rollData.section = metadata.sNerveActionSection or ""
      rollData.actionRecordId = metadata.sNerveActionRecordId or ""
      rollData.abilityIndex = tonumber(metadata.sNerveAbilityIndex or 0) or 0
    end
  end
  if #keptDiceResults > 0 then rollData.keptDice = keptDiceResults end
  if #droppedDiceResults > 0 then rollData.droppedDice = droppedDiceResults end
  local correlatedClientRoll = pendingClientRoll ~= nil
  publishSnapshot("dice-landed", {
    type = "roll.result",
    actor = "",
    text = description ~= "" and (description .. " [" .. tostring(total) .. "]") or ("[ROLL] " .. tostring(total)),
    visibility = draginfo.getSecret() and "gm" or "all",
    data = rollData
  })
  if Session.IsHost and publishNervePowerFollowUpOutcome and rollData.correlationId and
      rollData.characterId ~= "" and eventTypeForRollDescription(description, "roll.result") == "roll.damage" then
    publishNervePowerFollowUpOutcome(metadata, "damage", total)
  end
  if Session.IsHost and publishNerveCombatantFollowUpOutcome and rollData.correlationId and
      rollData.sourceKind == "combatant" and eventTypeForRollDescription(description, "roll.result") == "roll.damage" then
    publishNerveCombatantFollowUpOutcome(metadata, total)
  end
  if not Session.IsHost and not correlatedClientRoll then
    Comm.deliverOOBMessage({
      type = OOB_MSGTYPE_REMOTE_ROLL_RESULT,
      username = User.getUsername() or "Player",
      identityId = User.getCurrentIdentity() or "",
      description = description,
      eventType = eventTypeForRollDescription(description, "roll.result"),
      rollType = rollType,
      diceJson = Utility.encodeJSON(diceResults) or "[]",
      keptDiceJson = Utility.encodeJSON(keptDiceResults) or "[]",
      droppedDiceJson = Utility.encodeJSON(droppedDiceResults) or "[]",
      diceTotal = tostring(resolvedDiceTotal),
      rawDiceTotal = tostring(rawDiceTotal),
      rollMode = rollMode,
      modifier = tostring(modifier),
      total = tostring(total),
      secret = draginfo.getSecret() and "1" or "0"
    })
  end
  if resolveNerveAutoFailSave and rollData.correlationId and
      string.find(description, "[AUTOFAIL]", 1, true) then
    resolveNerveAutoFailSave(metadata, total)
  end
  if pendingClientRoll then
    local request = pendingClientRoll
    pendingClientRoll = nil
    if #droppedDiceResults == 0 and #diceResults >= 2 then
      if request.rollMode == "advantage" then
        resolvedDiceTotal = reportedDiceTotal - math.min(diceResults[1], diceResults[2])
      elseif request.rollMode == "disadvantage" then
        resolvedDiceTotal = reportedDiceTotal - math.max(diceResults[1], diceResults[2])
      end
    end
    total = resolvedDiceTotal + modifier
    local result = "rolled"
    if request.dc then result = total >= request.dc and "success" or "failure" end
    local msgOOB = {
      type = OOB_MSGTYPE_PLAYER_PROMPT_RESPONSE,
      promptId = request.promptId,
      username = Session.IsHost and "GM" or User.getUsername(),
      identityId = request.identityId or "",
      response = "rolled",
      value = tostring(total),
      rollResult = result,
      rollType = request.rollType,
      diceJson = Utility.encodeJSON(diceResults) or "[]",
      modifier = modifier,
      total = total,
      respondedAtEpoch = os.time()
    }
    if Session.IsHost then handlePlayerPromptResponse(msgOOB)
    else Comm.deliverOOBMessage(msgOOB) end
    if completeClientPrompt then completeClientPrompt() end
  end
  return nil
end

function normalizeNervePowerLabel(value)
  return string.lower(string.gsub(value or "", "[^%w]", ""))
end

function inferLocalNervePowerContext(rSource, rolls)
  if not Session.IsHost or not isNerveSessionActive() or not isFlowModeActive() then return nil end
  local nodeCharacter = rSource and ActorManager.getCreatureNode(rSource) or nil
  if not nodeCharacter or not string.match(DB.getPath(nodeCharacter), "^charsheet%.id%-%d+$") then return nil end
  local descriptions = ""
  local expectedActionType = nil
  for _, roll in ipairs(rolls or {}) do
    descriptions = descriptions .. normalizeNervePowerLabel(roll.sDesc or "")
    if roll.sType == "attack" or roll.sType == "powersave" then expectedActionType = "cast" end
  end
  if descriptions == "" or not expectedActionType then return nil end

  local matchedPower, matchedAction = nil, nil
  for _, nodePower in ipairs(DB.getChildList(nodeCharacter, "powers") or {}) do
    local powerLabel = normalizeNervePowerLabel(DB.getValue(nodePower, "name", ""))
    if powerLabel ~= "" and string.find(descriptions, powerLabel, 1, true) then
      for _, nodeAction in ipairs(DB.getChildList(nodePower, "actions") or {}) do
        if DB.getValue(nodeAction, "type", "") == expectedActionType then
          if matchedPower then return nil end
          matchedPower, matchedAction = nodePower, nodeAction
          break
        end
      end
    end
  end
  if not matchedPower or not matchedAction then return nil end

  localPowerCorrelationSequence = localPowerCorrelationSequence + 1
  return {
    requestId = string.format("local-power-%d-%d", os.time(), localPowerCorrelationSequence),
    characterId = DB.getName(nodeCharacter),
    powerId = DB.getName(matchedPower),
    actionId = DB.getName(matchedAction),
    sourceKind = "character",
    initiatedBy = "player"
  }
end

function isNerveHalfOnSave(powerContext, rolls)
  for _, roll in ipairs(rolls or {}) do
    if string.find(string.upper(roll.sDesc or ""), "[HALF ON SAVE]", 1, true) then return true end
  end
  if powerContext.halfOnSave == true then return true end
  local characterId = powerContext.characterId or ""
  local powerId = powerContext.powerId or ""
  local actionId = powerContext.actionId or ""
  if not string.match(characterId, "^id%-%d+$")
    or not string.match(powerId, "^id%-%d+$")
    or not string.match(actionId, "^id%-%d+$") then return false end
  local nodeAction = DB.findNode(string.format(
    "charsheet.%s.powers.%s.actions.%s",
    characterId,
    powerId,
    actionId
  ))
  return nodeAction ~= nil and string.lower(DB.getValue(nodeAction, "onmissdamage", "")) == "half"
end

local function attachNervePowerContext(rSource, targetGroups, rolls)
  local powerContext = activeNervePowerContext or inferLocalNervePowerContext(rSource, rolls)
  if not powerContext then return end
  local includesSave = false
  local halfOnSave = isNerveHalfOnSave(powerContext, rolls)
  local targetCombatantIds = {}
  for _, targetGroup in ipairs(targetGroups or {}) do
    for _, rTarget in ipairs(targetGroup or {}) do
      local targetPath = ActorManager.getCTNodeName(rTarget)
      local nodeTarget = targetPath ~= "" and DB.findNode(targetPath) or nil
      if nodeTarget then table.insert(targetCombatantIds, DB.getName(nodeTarget)) end
    end
  end
  if #targetCombatantIds == 0 then
    for _, targetId in ipairs(powerContext.targetCombatantIds or {}) do table.insert(targetCombatantIds, targetId) end
  end
  local targetCombatantIdList = table.concat(targetCombatantIds, ",")
  for _, roll in ipairs(rolls or {}) do
    roll.sNerveRequestId = powerContext.requestId
    roll.sNerveCharacterId = powerContext.characterId
    roll.sNervePowerId = powerContext.powerId
    roll.sNerveActionId = powerContext.actionId
    roll.sNerveSourceKind = powerContext.sourceKind or "character"
    roll.sNerveCombatantId = powerContext.combatantId or ""
    roll.sNerveActionSection = powerContext.actionSection or ""
    roll.sNerveActionRecordId = powerContext.actionRecordId or ""
    roll.sNerveAbilityIndex = powerContext.abilityIndex or 0
    roll.sNerveTargetCombatantIds = targetCombatantIdList
    roll.sNerveInitiatedBy = powerContext.initiatedBy or "nerve"
    if roll.sType == "powersave" then includesSave = true end
    if roll.sType == "save" then
      roll.sNerveSaveActorPath = rSource and ActorManager.getCTNodeName(rSource) or ""
    end
  end
  if includesSave then
    local sourcePath = rSource and ActorManager.getCTNodeName(rSource) or ""
    local contextOrder = {}
    for _, targetGroup in ipairs(targetGroups or {}) do
      for _, rTarget in ipairs(targetGroup or {}) do
        local targetPath = ActorManager.getCTNodeName(rTarget)
        if targetPath ~= "" then
          table.insert(contextOrder, targetPath)
          pendingNerveSaveContexts[targetPath] = {
            requestId = powerContext.requestId,
            characterId = powerContext.characterId,
            powerId = powerContext.powerId,
            actionId = powerContext.actionId,
            sourceKind = powerContext.sourceKind or "character",
            combatantId = powerContext.combatantId or "",
            actionSection = powerContext.actionSection or "",
            actionRecordId = powerContext.actionRecordId or "",
            abilityIndex = powerContext.abilityIndex or 0,
            sourcePath = sourcePath,
            halfOnSave = halfOnSave,
            expiresAt = os.time() + 30
          }
        end
      end
    end
    pendingNerveSaveContextOrder[powerContext.requestId] = contextOrder
  end
end

local function getNervePowerFollowUps(characterId, powerId, actionId, allowedTypes)
  local followUps = {}
  local nodePower = DB.findNode("charsheet." .. characterId .. ".powers." .. powerId)
  local nodeCurrent = nodePower and DB.findNode(DB.getPath(nodePower) .. ".actions." .. actionId) or nil
  if not nodeCurrent then return followUps end
  local currentOrder = DB.getValue(nodeCurrent, "order", 0)
  for _, nodeAction in ipairs(DB.getChildList(nodePower, "actions") or {}) do
    local actionType = DB.getValue(nodeAction, "type", "")
    local order = DB.getValue(nodeAction, "order", 0)
    if order > currentOrder and allowedTypes[actionType] then
      table.insert(followUps, { id = DB.getName(nodeAction), type = actionType, order = order })
    end
  end
  table.sort(followUps, function(left, right) return left.order < right.order end)
  return followUps
end

local function getNerveFollowUpKey(correlationId, targetCombatantId, actionId)
  return correlationId .. "|" .. targetCombatantId .. "|" .. actionId
end

NerveFollowUpContext = NerveFollowUpContext or {}

function NerveFollowUpContext.getTurn()
  local nodeActive = CombatManager.getActiveCT()
  return nodeActive and DB.getName(nodeActive) or "", DB.getValue("combattracker.round", 0)
end

function NerveFollowUpContext.turnChanged(authorization)
  if not authorization or authorization.activeCombatantId == "" then return false end
  local activeCombatantId, combatRound = NerveFollowUpContext.getTurn()
  return activeCombatantId ~= authorization.activeCombatantId or combatRound ~= authorization.combatRound
end

local function authorizeNervePowerFollowUps(correlationId, targetCombatantId, characterId, powerId, originActionId, outcome, followUps)
  if correlationId == "" or targetCombatantId == "" or #followUps == 0 then return nil end
  local expiresAt = os.time() + NERVE_FOLLOW_UP_SECONDS
  local activeCombatantId, combatRound = NerveFollowUpContext.getTurn()
  for _, followUp in ipairs(followUps) do
    pendingNervePowerFollowUps[getNerveFollowUpKey(correlationId, targetCombatantId, followUp.id)] = {
      correlationId = correlationId,
      targetCombatantId = targetCombatantId,
      characterId = characterId,
      powerId = powerId,
      originActionId = originActionId,
      actionId = followUp.id,
      actionType = followUp.type,
      outcome = outcome,
      activeCombatantId = activeCombatantId,
      combatRound = combatRound,
      expiresAt = expiresAt
    }
  end
  return expiresAt
end

publishNervePowerFollowUpOutcome = function(metadata, completedActionType, total)
  local correlationId = metadata.sNerveRequestId or ""
  local characterId = metadata.sNerveCharacterId or ""
  local powerId = metadata.sNervePowerId or ""
  local actionId = metadata.sNerveActionId or ""
  if correlationId == "" or characterId == "" or powerId == "" or actionId == "" then return end
  local targetIds = {}
  for targetId in string.gmatch(metadata.sNerveTargetCombatantIds or "", "[^,]+") do
    if string.match(targetId, "^id%-%d+$") then table.insert(targetIds, targetId) end
  end
  if #targetIds == 0 then return end
  local nodeCharacter = DB.findNode("charsheet." .. characterId)
  local actorName = nodeCharacter and DB.getValue(nodeCharacter, "name", "") or ""
  for _, targetId in ipairs(targetIds) do
    local followUps = getNervePowerFollowUps(characterId, powerId, actionId, { damage = true, effect = true })
    local data = {
      correlationId = correlationId,
      characterId = characterId,
      powerId = powerId,
      actionId = actionId,
      resolutionType = "follow_up",
      outcome = "completed",
      completedActionType = completedActionType,
      total = tonumber(total or 0) or 0,
      targetCombatantId = targetId,
      followUpCount = #followUps
    }
    if #followUps > 0 then
      data.followUpActions = followUps
      data.followUpExpiresAtEpoch = authorizeNervePowerFollowUps(
        correlationId, targetId, characterId, powerId, actionId, "completed", followUps
      )
    else
      data.turnContinuationReady = true
    end
    publishSnapshot("power-follow-up-outcome", {
      type = "power.action_outcome",
      actor = actorName,
      text = string.format("Power %s follow-up completed", completedActionType),
      visibility = "gm",
      subjectId = targetId,
      data = data
    })
  end
end

local function getNerveCombatantFollowUps(combatantId, section, actionRecordId, abilityIndex, allowedTypes)
  local followUps = {}
  local nodeAction = DB.findNode("combattracker.list." .. combatantId .. "." .. section .. "." .. actionRecordId)
  if not nodeAction then return followUps end
  local parsed = CombatManager2.parseAttackLine(DB.getValue(nodeAction, "value", ""))
  if not parsed then return followUps end
  for index, ability in ipairs(parsed.aAbilities or {}) do
    if index > abilityIndex and allowedTypes[ability.sType] then
      table.insert(followUps, { abilityIndex = index, type = ability.sType })
    end
  end
  return followUps
end

local function getNerveCombatantFollowUpKey(correlationId, targetCombatantId, section, actionRecordId, abilityIndex)
  return table.concat({ correlationId, targetCombatantId, section, actionRecordId, tostring(abilityIndex) }, "|")
end

local function authorizeNerveCombatantFollowUps(correlationId, targetCombatantId, context, outcome, followUps)
  if correlationId == "" or targetCombatantId == "" or #followUps == 0 then return nil end
  local expiresAt = os.time() + NERVE_FOLLOW_UP_SECONDS
  local activeCombatantId, combatRound = NerveFollowUpContext.getTurn()
  for _, followUp in ipairs(followUps) do
    local key = getNerveCombatantFollowUpKey(
      correlationId, targetCombatantId, context.actionSection, context.actionRecordId, followUp.abilityIndex
    )
    pendingNerveCombatantFollowUps[key] = {
      correlationId = correlationId,
      targetCombatantId = targetCombatantId,
      combatantId = context.combatantId,
      section = context.actionSection,
      actionRecordId = context.actionRecordId,
      originAbilityIndex = context.abilityIndex,
      abilityIndex = followUp.abilityIndex,
      actionType = followUp.type,
      outcome = outcome,
      activeCombatantId = activeCombatantId,
      combatRound = combatRound,
      expiresAt = expiresAt
    }
  end
  return expiresAt
end

local function publishNerveCombatantOutcome(rSource, targetId, context, outcome, total, resolutionType, saveAbility, dc)
  local allowedTypes = {}
  if resolutionType == "attack" then
    if outcome == "hit" or outcome == "crit" then
      allowedTypes.damage = true
      allowedTypes.effect = true
    end
  elseif outcome == "failure" then
    allowedTypes.damage = true
    allowedTypes.effect = true
  elseif outcome == "half_failure" or outcome == "half_success" then
    allowedTypes.damage = true
  end
  local followUps = getNerveCombatantFollowUps(
    context.combatantId, context.actionSection, context.actionRecordId, context.abilityIndex, allowedTypes
  )
  local data = {
    correlationId = context.requestId,
    combatantId = context.combatantId,
    section = context.actionSection,
    actionRecordId = context.actionRecordId,
    abilityIndex = context.abilityIndex,
    resolutionType = resolutionType,
    outcome = outcome,
    total = tonumber(total or 0) or 0,
    targetCombatantId = targetId,
    followUpCount = #followUps
  }
  if resolutionType == "save" then
    data.saveAbility = saveAbility or ""
    data.dc = tonumber(dc or 0) or 0
  end
  if #followUps > 0 then
    data.followUpActions = followUps
    data.followUpExpiresAtEpoch = authorizeNerveCombatantFollowUps(context.requestId, targetId, context, outcome, followUps)
  elseif resolutionType == "save" and outcome == "failure" then
    local nodeAction = DB.findNode(
      "combattracker.list." .. context.combatantId .. "." .. context.actionSection .. "." .. context.actionRecordId
    )
    local description = nodeAction and DB.getValue(nodeAction, "desc", "") or ""
    if description ~= "" then
      data.manualAdjudicationRequired = true
      data.manualAdjudicationReason = "prose_only_outcome"
      data.manualAdjudicationText = string.sub(description, 1, 1000)
      local nodeTarget = targetId ~= "" and DB.findNode("combattracker.list." .. targetId) or nil
      local targetName = nodeTarget and DB.getValue(nodeTarget, "name", "") or targetId
      local actionName = DB.getValue(nodeAction, "name", "this action")
      data.manualAdjudicationId = persistManualAdjudication(
        context, rSource and ActorManager.getDisplayName(rSource) or "", targetId, targetName, actionName, description
      )
      deliverNerveWhisper("GM", string.format(
        "ACTION NEEDED: %s failed %s. Review manual adjudication %s in Nerve Control.",
        targetName, actionName, data.manualAdjudicationId
      ))
    end
  end
  publishSnapshot("combatant-action-outcome", {
    type = "combatant.action_outcome",
    actor = rSource and ActorManager.getDisplayName(rSource) or "",
    text = string.format("Combatant action outcome: %s", outcome),
    visibility = "gm",
    subjectId = targetId,
    data = data
  })
end

publishNerveCombatantFollowUpOutcome = function(metadata, total)
  local correlationId = metadata.sNerveRequestId or ""
  local combatantId = metadata.sNerveCombatantId or ""
  local section = metadata.sNerveActionSection or ""
  local actionRecordId = metadata.sNerveActionRecordId or ""
  local abilityIndex = tonumber(metadata.sNerveAbilityIndex or 0) or 0
  if correlationId == "" or combatantId == "" or section == "" or actionRecordId == "" or abilityIndex < 1 then return end
  for targetId in string.gmatch(metadata.sNerveTargetCombatantIds or "", "[^,]+") do
    if string.match(targetId, "^id%-%d+$") then
      publishNerveCombatantOutcome(nil, targetId, {
        requestId = correlationId,
        combatantId = combatantId,
        actionSection = section,
        actionRecordId = actionRecordId,
        abilityIndex = abilityIndex
      }, "completed", total, "follow_up")
    end
  end
end

local function onNerveAttackPostResolve(rSource, rTarget, rRoll)
  local correlationId = rRoll and rRoll.sNerveRequestId or ""
  if correlationId == "" then return end
  local outcome = rRoll.sResult or "unknown"
  local targetPath = rTarget and ActorManager.getCTNodeName(rTarget) or ""
  local nodeTarget = targetPath ~= "" and DB.findNode(targetPath) or nil
  local targetId = nodeTarget and DB.getName(nodeTarget) or ""
  if rRoll.sNerveSourceKind == "combatant" then
    publishNerveCombatantOutcome(rSource, targetId, {
      requestId = correlationId,
      combatantId = rRoll.sNerveCombatantId or "",
      actionSection = rRoll.sNerveActionSection or "",
      actionRecordId = rRoll.sNerveActionRecordId or "",
      abilityIndex = tonumber(rRoll.sNerveAbilityIndex or 0) or 0
    }, outcome, rRoll.nTotal, "attack")
    return
  end
  local data = {
    correlationId = correlationId,
    characterId = rRoll.sNerveCharacterId or "",
    powerId = rRoll.sNervePowerId or "",
    actionId = rRoll.sNerveActionId or "",
    outcome = outcome,
    total = tonumber(rRoll.nTotal or 0) or 0,
    targetCombatantId = targetId,
    followUpCount = 0
  }
  if outcome == "hit" or outcome == "crit" then
    local followUps = getNervePowerFollowUps(data.characterId, data.powerId, data.actionId, { damage = true, effect = true })
    data.followUpCount = #followUps
    if #followUps > 0 then
      data.followUpActions = followUps
      data.followUpExpiresAtEpoch = authorizeNervePowerFollowUps(
        correlationId, targetId, data.characterId, data.powerId, data.actionId, outcome, followUps
      )
    end
  end
  publishSnapshot("power-action-outcome", {
    type = "power.action_outcome",
    actor = rSource and ActorManager.getDisplayName(rSource) or "",
    text = string.format("Power action outcome: %s", outcome),
    visibility = "gm",
    subjectId = targetId,
    data = data
  })
end

local function publishNerveSaveOutcome(targetPath, context, outcome, rOrigin, saveAbility, dc, total)
  local nodeTarget = DB.findNode(targetPath)
  local targetId = nodeTarget and DB.getName(nodeTarget) or ""
  if context.sourceKind == "combatant" then
    publishNerveCombatantOutcome(rOrigin, targetId, context, outcome, total, "save", saveAbility, dc)
    return
  end
  local allowedTypes = {}
  if outcome == "failure" then
    allowedTypes.damage = true
    allowedTypes.effect = true
  elseif outcome == "half_failure" or outcome == "half_success" then
    allowedTypes.damage = true
  end
  local followUps = getNervePowerFollowUps(context.characterId, context.powerId, context.actionId, allowedTypes)
  local data = {
    correlationId = context.requestId,
    characterId = context.characterId,
    powerId = context.powerId,
    actionId = context.actionId,
    resolutionType = "save",
    outcome = outcome,
    saveAbility = saveAbility or "",
    dc = tonumber(dc or 0) or 0,
    total = tonumber(total or 0) or 0,
    targetCombatantId = targetId,
    followUpCount = #followUps
  }
  if #followUps > 0 then data.followUpActions = followUps end
  if #followUps > 0 then
    data.followUpExpiresAtEpoch = authorizeNervePowerFollowUps(
      context.requestId, targetId, context.characterId, context.powerId, context.actionId, outcome, followUps
    )
  end
  publishSnapshot("power-save-outcome", {
    type = "power.action_outcome",
    actor = rOrigin and ActorManager.getDisplayName(rOrigin) or "",
    text = string.format("Power save outcome: %s", outcome),
    visibility = "gm",
    subjectId = targetId,
    data = data
  })
end

local function onNerveSavePostResolve(rTarget, rOrigin, rRoll)
  local targetPath = rTarget and ActorManager.getCTNodeName(rTarget) or ""
  local context = targetPath ~= "" and pendingNerveSaveContexts[targetPath] or nil
  if not context then return end
  local originPath = rOrigin and ActorManager.getCTNodeName(rOrigin) or ""
  if os.time() > context.expiresAt or (context.sourcePath ~= "" and context.sourcePath ~= originPath) then
    pendingNerveSaveContexts[targetPath] = nil
    return
  end
  pendingNerveSaveContexts[targetPath] = nil
  local outcome = rRoll.sResult or "unknown"
  if outcome == "success" and context.halfOnSave then outcome = "half_success" end
  publishNerveSaveOutcome(
    targetPath,
    context,
    outcome,
    rOrigin,
    rRoll.sSave or "",
    rRoll.nTarget,
    rRoll.nTotal
  )
end

resolveNerveAutoFailSave = function(metadata, total)
  local correlationId = metadata.sNerveRequestId or ""
  local exactTargetPath = metadata.sNerveSaveActorPath or ""
  if exactTargetPath ~= "" then
    local exactContext = pendingNerveSaveContexts[exactTargetPath]
    if exactContext and exactContext.requestId == correlationId then
      pendingNerveSaveContexts[exactTargetPath] = nil
      local rOrigin = exactContext.sourcePath ~= "" and ActorManager.resolveActor(exactContext.sourcePath) or nil
      publishNerveSaveOutcome(
        exactTargetPath,
        exactContext,
        "failure",
        rOrigin,
        metadata.sSave or metadata.sAbility or "",
        metadata.nTarget,
        total
      )
      return
    end
  end
  local contextOrder = pendingNerveSaveContextOrder[correlationId] or {}
  for _, targetPath in ipairs(contextOrder) do
    local context = pendingNerveSaveContexts[targetPath]
    if context and context.requestId == correlationId then
      pendingNerveSaveContexts[targetPath] = nil
      local rOrigin = context.sourcePath ~= "" and ActorManager.resolveActor(context.sourcePath) or nil
      publishNerveSaveOutcome(
        targetPath,
        context,
        "failure",
        rOrigin,
        metadata.sSave or metadata.sAbility or "",
        metadata.nTarget,
        total
      )
      return
    end
  end
end

writeCommandResult = function(result)
  local encoded = Utility.encodeJSON(result)
  if not encoded then
    Debug.console("Nerve Adapter: unable to encode command result")
    return
  end
  File.saveTextFile(File.getCampaignFolder() .. "/" .. COMMAND_RESULT_FILENAME, encoded)
  -- The result is authoritative once written. Clear the source envelope so a
  -- late approval cannot be fetched repeatedly after the middleware timed out.
  File.saveTextFile(File.getCampaignFolder() .. "/" .. COMMAND_FILENAME, "")
end

local function commandFailure(command, code, message)
  writeCommandResult({
    schemaVersion = "0.1",
    requestId = command and command.requestId or "unknown",
    capability = command and command.capability or "unknown",
    ok = false,
    executedAt = os.date("!%Y-%m-%dT%H:%M:%SZ"),
    error = { code = code, message = message }
  })
  ChatManager.SystemMessage("Nerve rejected command: " .. message)
end

local function findCombatantById(combatantId)
  for _, nodeCombatant in pairs(DB.getChildren("combattracker.list") or {}) do
    if DB.getName(nodeCombatant) == combatantId then return nodeCombatant end
  end
  return nil
end

local function resolveActiveUser(recipient)
  if type(recipient) ~= "string" or recipient == "" then return nil end
  local wanted = string.lower(recipient)
  for _, activeUser in ipairs(User.getActiveUsers() or {}) do
    if string.lower(activeUser) == wanted then return activeUser end
  end
  for _, identityId in ipairs(User.getAllActiveIdentities() or {}) do
    local owner = User.getIdentityOwner(identityId)
    local label = User.getIdentityLabel(identityId)
    if type(owner) == "string" and type(label) == "string" and string.lower(label) == wanted then
      for _, activeUser in ipairs(User.getActiveUsers() or {}) do
        if string.lower(activeUser) == string.lower(owner) then return activeUser end
      end
    end
  end
  return nil
end

local function openNextPlayerPrompt()
  if activeClientPrompt or #clientPromptQueue == 0 then return end
  activeClientPrompt = table.remove(clientPromptQueue, 1)
  if os.time() > activeClientPrompt.deadlineEpoch then
    submitPlayerPromptResponse("timeout", "")
    return
  end
  local promptWindow = Interface.openWindow("nerve_player_prompt", "")
  if promptWindow and promptWindow.refresh then promptWindow.refresh() end
  if not Session.IsHost then
    Comm.deliverOOBMessage({
      type = OOB_MSGTYPE_PLAYER_PROMPT_RECEIPT,
      promptId = activeClientPrompt.promptId,
      username = User.getUsername() or "Player",
      state = promptWindow and "displayed" or "received"
    })
  end
  ChatManager.SystemMessage("Nerve: private response required. Use /nerveprompt to reopen the prompt.")
  User.ringBell()
end

function handlePlayerPrompt(msgOOB)
  local deadlineEpoch = type(msgOOB) == "table" and tonumber(msgOOB.deadlineEpoch) or nil
  if type(msgOOB) ~= "table" or type(msgOOB.promptId) ~= "string" or
      type(msgOOB.prompt) ~= "string" or type(msgOOB.responseType) ~= "string" or
      not deadlineEpoch then return end
  local choices = {}
  if type(msgOOB.choicesJson) == "string" and msgOOB.choicesJson ~= "" then
    local decoded = Utility.decodeJSON(msgOOB.choicesJson)
    if type(decoded) == "table" then choices = decoded end
  end
  local roll = nil
  if type(msgOOB.rollJson) == "string" and msgOOB.rollJson ~= "" then
    local decodedRoll = Utility.decodeJSON(msgOOB.rollJson)
    if type(decodedRoll) == "table" then roll = decodedRoll end
  end
  table.insert(clientPromptQueue, {
    promptId = msgOOB.promptId,
    prompt = msgOOB.prompt,
    responseType = msgOOB.responseType,
    choices = choices,
    roll = roll,
    characterId = type(msgOOB.characterId) == "string" and msgOOB.characterId or "",
    characterName = type(msgOOB.characterName) == "string" and msgOOB.characterName or "",
    deadlineEpoch = deadlineEpoch
  })
  openNextPlayerPrompt()
end

function handlePlayerPromptReceipt(msgOOB)
  if not Session.IsHost or type(msgOOB) ~= "table" then return end
  local prompt = pendingPlayerPrompts[msgOOB.promptId]
  local username = type(msgOOB.username) == "string" and msgOOB.username or ""
  if not prompt or not prompt.statuses[username] then return end
  local state = msgOOB.state == "displayed" and "displayed" or "received"
  if prompt.statuses[username] == "sent" or prompt.statuses[username] == "pending" then prompt.statuses[username] = state end
  refreshNerveControlWindows()
end

function getActivePlayerPrompt()
  return activeClientPrompt
end

function reopenPlayerPrompt()
  if not activeClientPrompt then
    ChatManager.SystemMessage("Nerve: no player response is pending.")
    return
  end
  local promptWindow = Interface.openWindow("nerve_player_prompt", "")
  if promptWindow and promptWindow.refresh then promptWindow.refresh() end
end

completeClientPrompt = function()
  activeClientPrompt = nil
  local promptWindow = Interface.findWindow("nerve_player_prompt", "")
  if promptWindow then promptWindow.close() end
  openNextPlayerPrompt()
end

local function findCurrentIdentityActor()
  local identityId = User.getCurrentIdentity() or ""
  if identityId == "" then return nil, nil end
  local nodeCharacter = DB.findNode("charsheet." .. identityId)
  if not nodeCharacter then return nil, identityId end
  return ActorManager.resolveActor(nodeCharacter), identityId
end

function performRequestedPlayerRoll()
  if not activeClientPrompt or activeClientPrompt.responseType ~= "roll" or pendingClientRoll then return false end
  local roll = activeClientPrompt.roll or {}
  local rActor, identityId = findCurrentIdentityActor()
  if not rActor then
    ChatManager.SystemMessage("Nerve: select an owned character identity before rolling.")
    return false
  end
  if activeClientPrompt.characterId ~= "" and identityId ~= activeClientPrompt.characterId then
    ChatManager.SystemMessage("Nerve: this roll is assigned to " .. (activeClientPrompt.characterName ~= "" and activeClientPrompt.characterName or activeClientPrompt.characterId) .. ". Select that character identity before rolling.")
    return false
  end

  local rRoll = nil
  if roll.rollType == "ability_check" then
    rRoll = ActionCheck.getRoll(rActor, roll.ability, roll.dc)
  elseif roll.rollType == "saving_throw" then
    rRoll = ActionSave.getRoll(rActor, roll.ability)
    rRoll.nTarget = roll.dc
  elseif roll.rollType == "skill_check" then
    local nodeCharacter = ActorManager.getCreatureNode(rActor)
    local requestedSkill = string.lower(roll.skill or "")
    for _, nodeSkill in ipairs(DB.getChildList(nodeCharacter, "skilllist") or {}) do
      if string.lower(DB.getValue(nodeSkill, "name", "")) == requestedSkill then
        rRoll = ActionSkill.getRoll(rActor, nodeSkill)
        break
      end
    end
    if not rRoll then rRoll = ActionSkill.getUnlistedRoll(rActor, roll.skill or "") end
    rRoll.nTarget = roll.dc
  elseif roll.rollType == "initiative" then
    rRoll = ActionInit.getRoll(rActor, roll.visibility == "gm")
  end
  if not rRoll then
    ChatManager.SystemMessage("Nerve: unable to prepare the requested roll.")
    return false
  end

  if roll.rollMode == "advantage" then rRoll.bADV = true
  elseif roll.rollMode == "disadvantage" then rRoll.bDIS = true end
  if roll.visibility == "gm" then
    rRoll.bSecret = true
    rRoll.bTower = true
  end
  pendingClientRoll = {
    promptId = activeClientPrompt.promptId,
    identityId = identityId,
    rollType = roll.rollType,
    dc = roll.dc,
    rollMode = roll.rollMode
  }
  ActionsManager.performAction(nil, rActor, rRoll)
  return true
end

function submitPlayerPromptResponse(response, value)
  if not activeClientPrompt then return false end
  local prompt = activeClientPrompt
  local resolvedResponse = response
  if os.time() > prompt.deadlineEpoch then
    resolvedResponse = "timeout"
    ChatManager.SystemMessage("Nerve: the response deadline passed; this attempt was recorded as a timeout.")
  end
  local identityId = User.getCurrentIdentity() or ""
  local msgOOB = {
    type = OOB_MSGTYPE_PLAYER_PROMPT_RESPONSE,
    promptId = prompt.promptId,
    username = Session.IsHost and "GM" or User.getUsername(),
    identityId = identityId,
    response = resolvedResponse,
    value = value or "",
    respondedAtEpoch = os.time()
  }
  if Session.IsHost then handlePlayerPromptResponse(msgOOB)
  else Comm.deliverOOBMessage(msgOOB) end
  completeClientPrompt()
  return true
end

function handlePlayerPromptResponse(msgOOB)
  if not Session.IsHost or type(msgOOB) ~= "table" then return end
  local prompt = pendingPlayerPrompts[msgOOB.promptId]
  local username = msgOOB.username
  if not prompt or type(username) ~= "string" or not prompt.statuses[username] then return end
  local currentStatus = prompt.statuses[username]
  if currentStatus ~= "pending" and currentStatus ~= "sent" and currentStatus ~= "received" and currentStatus ~= "displayed" then return end
  if prompt.characterId and prompt.characterId ~= "" and msgOOB.identityId ~= prompt.characterId then
    ChatManager.SystemMessage("Nerve rejected a roll response from the wrong character identity. Expected " .. (prompt.characterName or prompt.characterId) .. ".")
    return
  end

  local response = msgOOB.response
  local value = type(msgOOB.value) == "string" and msgOOB.value or ""
  if os.time() > prompt.deadlineEpoch then response, value = "timeout", "" end
  local valid = response == "declined" or response == "timeout" or
    (prompt.responseType == "acknowledge" and response == "acknowledged") or
    (prompt.responseType == "yes_no" and (response == "yes" or response == "no")) or
    (prompt.responseType == "short_text" and response == "submitted" and value ~= "")
  if prompt.responseType == "roll" and response == "rolled" and tonumber(msgOOB.total or value) then
    valid = msgOOB.rollType == prompt.roll.rollType
  end
  if prompt.responseType == "multiple_choice" and response == "choice" then
    for _, choice in ipairs(prompt.choices) do
      local label = type(choice) == "table" and choice.label or choice
      if label == value then valid = true end
    end
  end
  if not valid then return end

  local total = tonumber(msgOOB.total or value)
  local rollResult = type(msgOOB.rollResult) == "string" and msgOOB.rollResult or "rolled"
  prompt.statuses[username] = response == "rolled" and (rollResult .. " " .. tostring(total)) or response
  local actor = username
  if type(msgOOB.identityId) == "string" and msgOOB.identityId ~= "" then
    actor = User.getIdentityLabel(msgOOB.identityId) or username
  end
  local eventType = response == "timeout" and "player.prompt_timeout" or "player.prompt_response"
  local eventText = response == "timeout" and "Player prompt timed out" or "Player prompt response: " .. response
  if prompt.responseType == "roll" then
    if response == "rolled" then
      eventType = "player.roll_response"
      eventText = "Player roll response: " .. tostring(total) .. " (" .. rollResult .. ")"
    elseif response == "timeout" then
      eventType, eventText = "player.roll_timeout", "Player roll request timed out"
    elseif response == "declined" then
      eventType, eventText = "player.roll_declined", "Player declined roll request"
    end
  end
  local dice = {}
  if type(msgOOB.diceJson) == "string" and msgOOB.diceJson ~= "" then
    local decodedDice = Utility.decodeJSON(msgOOB.diceJson)
    if type(decodedDice) == "table" then dice = decodedDice end
  end
  publishSnapshot("player-prompt-response", {
    type = eventType,
    actor = actor,
    text = eventText,
    visibility = "gm",
    subjectId = prompt.promptId,
    data = {
      promptId = prompt.promptId,
      username = username,
      characterId = prompt.characterId or "",
      characterName = prompt.characterName or "",
      responseType = prompt.responseType,
      response = response,
      value = value,
      rollType = prompt.roll and prompt.roll.rollType or nil,
      dc = prompt.roll and prompt.roll.dc or nil,
      rollMode = prompt.roll and prompt.roll.rollMode or nil,
      result = prompt.responseType == "roll" and response == "rolled" and rollResult or nil,
      dice = prompt.responseType == "roll" and dice or nil,
      modifier = prompt.responseType == "roll" and tonumber(msgOOB.modifier) or nil,
      total = prompt.responseType == "roll" and total or nil
    }
  })
  if prompt.responseType == "roll" and response == "rolled" then
    suppressNextPromptRollCueActor = actor
    suppressNextPromptRollCueEpoch = os.time()
    ChatManager.SystemMessage("Nerve roll received from " .. actor .. ": " .. tostring(total) .. " (" .. rollResult .. ")")
  else
    ChatManager.SystemMessage("Nerve prompt response received from " .. actor .. ": " .. response)
  end
  local approvalWindow = Interface.findWindow("nerve_approval", "")
  if approvalWindow and approvalWindow.refresh then approvalWindow.refresh() end
end

local function processPlayerPromptSlash(_, _params)
  reopenPlayerPrompt()
end

local function executeRequestPlayerInput(command)
  local args = command.arguments or {}
  if type(args.prompt) ~= "string" or args.prompt == "" or #args.prompt > 1000 then
    return nil, "INVALID_ARGUMENT", "Prompt must contain 1 to 1000 characters."
  end
  local validResponseTypes = { acknowledge = true, yes_no = true, short_text = true, multiple_choice = true }
  if not validResponseTypes[args.responseType] then return nil, "INVALID_ARGUMENT", "Response type is invalid." end
  if args.audience ~= "gm" and args.audience ~= "recipients" and args.audience ~= "all_players" then
    return nil, "INVALID_ARGUMENT", "Audience must be gm, recipients, or all_players."
  end
  if type(args.timeoutSeconds) ~= "number" or args.timeoutSeconds < 15 or args.timeoutSeconds > 900 or args.timeoutSeconds % 1 ~= 0 then
    return nil, "INVALID_ARGUMENT", "Prompt timeout must be an integer from 15 to 900 seconds."
  end
  local choices = {}
  if args.responseType == "multiple_choice" then
    if type(args.choices) ~= "table" or #args.choices < 2 or #args.choices > 6 then
      return nil, "INVALID_ARGUMENT", "Multiple-choice prompts require 2 to 6 choices."
    end
    for _, choice in ipairs(args.choices) do
      local label, description
      if type(choice) == "string" then
        label, description = choice, ""
      elseif type(choice) == "table" then
        label = choice.label
        description = choice.description or ""
      end
      if type(label) ~= "string" or label == "" or #label > 80 then
        return nil, "INVALID_ARGUMENT", "Each prompt choice label must contain 1 to 80 characters."
      end
      if type(description) ~= "string" or #description > 240 then
        return nil, "INVALID_ARGUMENT", "Each prompt choice description must contain at most 240 characters."
      end
      table.insert(choices, { label = label, description = description })
    end
  end

  local recipients = {}
  if args.audience == "gm" then
    table.insert(recipients, "GM")
  elseif args.audience == "recipients" then
    if type(args.recipients) ~= "table" or #args.recipients == 0 or #args.recipients > 20 then
      return nil, "INVALID_ARGUMENT", "Named prompts require 1 to 20 Fantasy Grounds usernames."
    end
    for _, recipient in ipairs(args.recipients) do
      local activeUser = resolveActiveUser(recipient)
      if not activeUser then
        return nil, "RECIPIENT_UNAVAILABLE", "Prompt recipient is not connected: " .. tostring(recipient)
      end
      table.insert(recipients, activeUser)
    end
  else
    for _, recipient in ipairs(User.getActiveUsers() or {}) do table.insert(recipients, recipient) end
    if #recipients == 0 then return nil, "RECIPIENT_UNAVAILABLE", "No player clients are connected." end
  end

  local deadlineEpoch = os.time() + args.timeoutSeconds
  local prompt = {
    promptId = command.requestId,
    prompt = args.prompt,
    responseType = args.responseType,
    choices = choices,
    deadlineEpoch = deadlineEpoch,
    statuses = {}
  }
  for _, recipient in ipairs(recipients) do prompt.statuses[recipient] = "sent" end
  pendingPlayerPrompts[command.requestId] = prompt
  table.insert(playerPromptOrder, 1, command.requestId)
  while #playerPromptOrder > 20 do
    local removedId = table.remove(playerPromptOrder)
    pendingPlayerPrompts[removedId] = nil
  end

  local msgOOB = {
    type = OOB_MSGTYPE_PLAYER_PROMPT,
    promptId = command.requestId,
    prompt = args.prompt,
    responseType = args.responseType,
    choicesJson = Utility.encodeJSON(choices) or "[]",
    deadlineEpoch = deadlineEpoch
  }
  for _, recipient in ipairs(recipients) do
    if recipient == "GM" then handlePlayerPrompt(msgOOB); prompt.statuses[recipient] = "displayed"
    else Comm.deliverOOBMessage(msgOOB, recipient) end
  end

  return {
    opened = true,
    promptId = command.requestId,
    responseType = args.responseType,
    audience = args.audience,
    recipients = recipients,
    deadlineAt = os.date("!%Y-%m-%dT%H:%M:%SZ", deadlineEpoch),
    executedAt = os.date("!%Y-%m-%dT%H:%M:%SZ")
  }
end

local function executeRequestPlayerRoll(command)
  local args = command.arguments or {}
  if type(args.prompt) ~= "string" or args.prompt == "" or #args.prompt > 1000 then
    return nil, "INVALID_ARGUMENT", "Roll prompt must contain 1 to 1000 characters."
  end
  local validRollTypes = { ability_check = true, skill_check = true, saving_throw = true, initiative = true }
  local validAbilities = { strength = true, dexterity = true, constitution = true, intelligence = true, wisdom = true, charisma = true }
  if not validRollTypes[args.rollType] then return nil, "INVALID_ARGUMENT", "Roll type is invalid." end
  if (args.rollType == "ability_check" or args.rollType == "saving_throw") and not validAbilities[args.ability] then
    return nil, "INVALID_ARGUMENT", "Ability checks and saving throws require a valid ability."
  end
  if args.rollType == "skill_check" and (type(args.skill) ~= "string" or args.skill == "" or #args.skill > 80) then
    return nil, "INVALID_ARGUMENT", "Skill checks require a skill name of 1 to 80 characters."
  end
  if args.dc ~= nil and (type(args.dc) ~= "number" or args.dc < 1 or args.dc > 40 or args.dc % 1 ~= 0) then
    return nil, "INVALID_ARGUMENT", "Roll DC must be an integer from 1 to 40."
  end
  if args.rollMode ~= "normal" and args.rollMode ~= "advantage" and args.rollMode ~= "disadvantage" then
    return nil, "INVALID_ARGUMENT", "Roll mode must be normal, advantage, or disadvantage."
  end
  if args.visibility ~= "public" and args.visibility ~= "gm" then
    return nil, "INVALID_ARGUMENT", "Roll visibility must be public or gm."
  end
  if args.audience ~= "gm" and args.audience ~= "recipients" and args.audience ~= "all_players" then
    return nil, "INVALID_ARGUMENT", "Audience must be gm, recipients, or all_players."
  end
  if type(args.timeoutSeconds) ~= "number" or args.timeoutSeconds < 15 or args.timeoutSeconds > 900 or args.timeoutSeconds % 1 ~= 0 then
    return nil, "INVALID_ARGUMENT", "Roll timeout must be an integer from 15 to 900 seconds."
  end
  local expectedCharacterId = type(args.characterId) == "string" and args.characterId or ""
  local expectedCharacterName = type(args.characterName) == "string" and args.characterName or ""
  local expectedOwner = ""
  if expectedCharacterId ~= "" then
    local nodeCharacter = DB.findNode("charsheet." .. expectedCharacterId)
    if not nodeCharacter then return nil, "CHARACTER_NOT_FOUND", "The assigned roll character is not available." end
    local observedName = DB.getValue(nodeCharacter, "name", "")
    if expectedCharacterName == "" or string.lower(expectedCharacterName) ~= string.lower(observedName) then
      return nil, "CHARACTER_CHANGED", "The assigned roll character name does not match current Fantasy Grounds state."
    end
    expectedCharacterName = observedName
    expectedOwner = User.getIdentityOwner(expectedCharacterId) or ""
    if args.audience ~= "recipients" then
      return nil, "INVALID_ARGUMENT", "A character-bound remote roll requires one named player recipient."
    end
  end

  local recipients = {}
  if args.audience == "gm" then
    table.insert(recipients, "GM")
  elseif args.audience == "recipients" then
    if type(args.recipients) ~= "table" or #args.recipients == 0 or #args.recipients > 20 then
      return nil, "INVALID_ARGUMENT", "Named roll requests require 1 to 20 Fantasy Grounds usernames."
    end
    for _, recipient in ipairs(args.recipients) do
      local activeUser = resolveActiveUser(recipient)
      if not activeUser then
        return nil, "RECIPIENT_UNAVAILABLE", "Roll recipient is not connected: " .. tostring(recipient)
      end
      table.insert(recipients, activeUser)
    end
    if expectedCharacterId ~= "" then
      if expectedOwner == "" or #recipients ~= 1 or string.lower(recipients[1]) ~= string.lower(expectedOwner) then
        return nil, "CHARACTER_OWNER_MISMATCH", "The assigned character is not owned by the named connected player."
      end
    end
  else
    for _, recipient in ipairs(User.getActiveUsers() or {}) do table.insert(recipients, recipient) end
    if #recipients == 0 then return nil, "RECIPIENT_UNAVAILABLE", "No player clients are connected." end
  end

  local deadlineEpoch = os.time() + args.timeoutSeconds
  local roll = {
    rollType = args.rollType,
    ability = args.ability,
    skill = args.skill,
    dc = args.dc,
    rollMode = args.rollMode,
    visibility = args.visibility
  }
  local prompt = {
    promptId = command.requestId,
    prompt = args.prompt,
    responseType = "roll",
    choices = {},
    roll = roll,
    characterId = expectedCharacterId,
    characterName = expectedCharacterName,
    deadlineEpoch = deadlineEpoch,
    statuses = {}
  }
  for _, recipient in ipairs(recipients) do prompt.statuses[recipient] = "sent" end
  pendingPlayerPrompts[command.requestId] = prompt
  table.insert(playerPromptOrder, 1, command.requestId)
  while #playerPromptOrder > 20 do
    local removedId = table.remove(playerPromptOrder)
    pendingPlayerPrompts[removedId] = nil
  end

  local msgOOB = {
    type = OOB_MSGTYPE_PLAYER_PROMPT,
    promptId = command.requestId,
    prompt = args.prompt,
    responseType = "roll",
    choicesJson = "[]",
    rollJson = Utility.encodeJSON(roll) or "{}",
    characterId = expectedCharacterId,
    characterName = expectedCharacterName,
    deadlineEpoch = deadlineEpoch
  }
  for _, recipient in ipairs(recipients) do
    if recipient == "GM" then handlePlayerPrompt(msgOOB); prompt.statuses[recipient] = "displayed"
    else Comm.deliverOOBMessage(msgOOB, recipient) end
  end

  return {
    opened = true,
    rollRequestId = command.requestId,
    rollType = args.rollType,
    audience = args.audience,
    recipients = recipients,
    characterId = expectedCharacterId,
    characterName = expectedCharacterName,
    deadlineAt = os.date("!%Y-%m-%dT%H:%M:%SZ", deadlineEpoch),
    executedAt = os.date("!%Y-%m-%dT%H:%M:%SZ")
  }
end

deliverNerveWhisper = function(target, text)
  local privateText = "[Private from Nerve] " .. text
  lastPrivateNerveMessageText = privateText
  lastPrivateNerveMessageEpoch = os.time()
  suppressNerveWhisperCallbacks = suppressNerveWhisperCallbacks + 1
  ChatManager.processWhisperHelper(target, privateText)
end

local function executeSendChat(command)
  local args = command.arguments or {}
  local text = args.text
  local visibility = args.visibility
  if type(text) ~= "string" or text == "" or #text > 1000 then
    return nil, "INVALID_ARGUMENT", "Chat text must contain 1 to 1000 characters."
  end
  if visibility ~= "all" and visibility ~= "gm" and visibility ~= "recipients" and visibility ~= "all_individual" then
    return nil, "INVALID_ARGUMENT", "Chat visibility must be all, gm, recipients, or all_individual."
  end

  -- Public `chat` mode inherits the language currently selected in the host
  -- chat window. Nerve narration uses neutral story mode so a preceding
  -- character message cannot silently change its language.
  local message = { sender = "Nerve", text = text, font = "chatfont", mode = "story" }
  local deliveredRecipients = nil
  if visibility == "gm" then
    deliverNerveWhisper("GM", text)
  elseif visibility == "all" then
    Comm.deliverChatMessage(message)
  else
    deliveredRecipients = {}
    if visibility == "recipients" then
      if type(args.recipients) ~= "table" or #args.recipients == 0 or #args.recipients > 20 then
        return nil, "INVALID_ARGUMENT", "Recipient whispers require 1 to 20 Fantasy Grounds usernames."
      end
      for _, recipient in ipairs(args.recipients) do
        if type(recipient) ~= "string" or recipient == "" or #recipient > 100 then
          return nil, "INVALID_ARGUMENT", "Each recipient must be a valid Fantasy Grounds username."
        end
        local activeUser = resolveActiveUser(recipient)
        if not activeUser then
          return nil, "RECIPIENT_UNAVAILABLE", "Private recipient is not connected: " .. recipient
        end
        table.insert(deliveredRecipients, activeUser)
      end
    else
      for _, recipient in ipairs(User.getActiveUsers() or {}) do table.insert(deliveredRecipients, recipient) end
    end

    local identityLabels = {}
    for _, recipient in ipairs(deliveredRecipients) do
      local identityLabel = nil
      for _, identityId in ipairs(User.getAllActiveIdentities() or {}) do
        if User.getIdentityOwner(identityId) == recipient then
          identityLabel = User.getIdentityLabel(identityId)
          break
        end
      end
      if not identityLabel or identityLabel == "" then
        return nil, "RECIPIENT_UNAVAILABLE", "Private recipient must be connected and control an active character: " .. recipient
      end
      table.insert(identityLabels, identityLabel)
    end

    if #identityLabels == 0 then
      deliverNerveWhisper("GM", text)
    else
      for _, identityLabel in ipairs(identityLabels) do
        deliverNerveWhisper(identityLabel, text)
      end
    end
  end

  if visibility ~= "all" then
    local privateData = { mode = "whisper", messageType = "nerve.private" }
    if deliveredRecipients and #deliveredRecipients > 0 then privateData.recipients = deliveredRecipients end
    publishSnapshot("chat-message", {
      type = "chat.message",
      actor = "Nerve",
      text = "[Private from Nerve] " .. text,
      visibility = "gm",
      data = privateData
    })
  end
  local result = { delivered = true, text = text, visibility = visibility, executedAt = os.date("!%Y-%m-%dT%H:%M:%SZ") }
  -- Fantasy Grounds' JSON encoder represents an empty Lua table as an object,
  -- not an array. Omit the optional field when no player clients are connected
  -- so the acknowledgement still satisfies the cross-host result contract.
  if deliveredRecipients and #deliveredRecipients > 0 then result.recipients = deliveredRecipients end
  markAiCueAnswered()
  return result
end

local function executeRequestVote(command)
  local args = command.arguments or {}
  local question = args.question
  if type(question) ~= "string" or question == "" or #question > 500 then
    return nil, "INVALID_ARGUMENT", "Vote question must contain 1 to 500 characters."
  end

  local chatWindow = ChatManager.getChatWindow()
  if not chatWindow or not chatWindow.entry then
    return nil, "CHAT_ENTRY_UNAVAILABLE", "Fantasy Grounds chat entry is unavailable."
  end
  if (chatWindow.entry.getValue() or "") ~= "" then
    return nil, "CHAT_ENTRY_NOT_EMPTY", "The chat entry contains unsent text; Nerve did not overwrite it."
  end
  chatWindow.entry.setValue("/vote Nerve asks: " .. question)
  return { prepared = true }
end

local function executeProxyCharacterRoll(command)
  local args = command.arguments or {}
  if playerProxyMode ~= "all" then
    return nil, "PLAYER_PROXY_DISABLED", "Enable Entity Proxy in Nerve Control before rolling for a character."
  end
  if type(args.characterId) ~= "string" or not string.match(args.characterId, "^id%-%d+$") then
    return nil, "INVALID_ARGUMENT", "Character ID is invalid."
  end
  local validRollTypes = { ability_check = true, skill_check = true, saving_throw = true, initiative = true }
  if not validRollTypes[args.rollType] then return nil, "INVALID_ARGUMENT", "Roll type is invalid." end
  local validRollModes = { normal = true, advantage = true, disadvantage = true }
  if not validRollModes[args.rollMode] then return nil, "INVALID_ARGUMENT", "Roll mode is invalid." end
  if args.visibility ~= "public" and args.visibility ~= "gm" then
    return nil, "INVALID_ARGUMENT", "Visibility must be public or gm."
  end
  if args.dc ~= nil and (type(args.dc) ~= "number" or args.dc < 1 or args.dc > 40 or args.dc % 1 ~= 0) then
    return nil, "INVALID_ARGUMENT", "DC must be an integer from 1 to 40."
  end

  local nodeCharacter = DB.findNode("charsheet." .. args.characterId)
  if not nodeCharacter then return nil, "CHARACTER_NOT_FOUND", "The character no longer exists." end
  local rActor = ActorManager.resolveActor(nodeCharacter)
  if not rActor then return nil, "CHARACTER_UNAVAILABLE", "Fantasy Grounds could not resolve the character actor." end

  local rRoll = nil
  if args.rollType == "ability_check" then
    if type(args.ability) ~= "string" then return nil, "INVALID_ARGUMENT", "Ability is required." end
    rRoll = ActionCheck.getRoll(rActor, args.ability, args.dc)
  elseif args.rollType == "saving_throw" then
    if type(args.ability) ~= "string" then return nil, "INVALID_ARGUMENT", "Ability is required." end
    rRoll = ActionSave.getRoll(rActor, args.ability)
    rRoll.nTarget = args.dc
  elseif args.rollType == "skill_check" then
    if type(args.skill) ~= "string" or args.skill == "" or #args.skill > 80 then
      return nil, "INVALID_ARGUMENT", "Skill must contain 1 to 80 characters."
    end
    local requestedSkill = string.lower(args.skill)
    for _, nodeSkill in ipairs(DB.getChildList(nodeCharacter, "skilllist") or {}) do
      if string.lower(DB.getValue(nodeSkill, "name", "")) == requestedSkill then
        rRoll = ActionSkill.getRoll(rActor, nodeSkill)
        break
      end
    end
    if not rRoll then rRoll = ActionSkill.getUnlistedRoll(rActor, args.skill) end
    rRoll.nTarget = args.dc
  elseif args.rollType == "initiative" then
    rRoll = ActionInit.getRoll(rActor, args.visibility == "gm")
  end
  if not rRoll then return nil, "ROLL_UNAVAILABLE", "Fantasy Grounds could not prepare the character roll." end

  if args.rollMode == "advantage" then rRoll.bADV = true
  elseif args.rollMode == "disadvantage" then rRoll.bDIS = true end
  if args.visibility == "gm" then
    rRoll.bSecret = true
    rRoll.bTower = true
  end
  ActionsManager.performAction(nil, rActor, rRoll)
  return {
    launched = true,
    characterId = args.characterId,
    characterName = DB.getValue(nodeCharacter, "name", ""),
    rollType = args.rollType,
    rollMode = args.rollMode,
    visibility = args.visibility,
    executedAt = os.date("!%Y-%m-%dT%H:%M:%SZ")
  }
end

local function restoreCombatantTargets(nodeSourceCT, targetPaths)
  if not nodeSourceCT then return end
  TargetingManager.clearCTTargets(nodeSourceCT)
  for _, targetPath in ipairs(targetPaths or {}) do
    local nodeTarget = DB.findNode(targetPath)
    if nodeTarget then TargetingManager.addCTTarget(nodeSourceCT, nodeTarget) end
  end
end

local function powerActionRequiresNerveFollowUp(nodePower, nodeAction, actionType)
  if actionType ~= "damage" and actionType ~= "effect" then return false end
  local currentOrder = DB.getValue(nodeAction, "order", 0)
  for _, candidateAction in ipairs(DB.getChildList(nodePower, "actions") or {}) do
    if DB.getValue(candidateAction, "type", "") == "cast" and
        DB.getValue(candidateAction, "order", 0) < currentOrder then
      return true
    end
  end
  return false
end

local function validateNerveFollowUpContexts(args, nodePower, nodeAction, actionType, targetIds)
  local requiresFollowUp = powerActionRequiresNerveFollowUp(nodePower, nodeAction, actionType)
  local contexts = args.followUpContexts
  if not requiresFollowUp then
    if contexts ~= nil then
      return nil, "FOLLOW_UP_NOT_APPLICABLE", "This sheet action does not accept a correlated follow-up context."
    end
    return {}
  end
  if type(contexts) ~= "table" or #contexts == 0 then
    return nil, "FOLLOW_UP_CONTEXT_REQUIRED", "This damage or effect follows a cast action and requires a correlated resolved outcome."
  end
  if #contexts ~= #targetIds then
    return nil, "FOLLOW_UP_TARGET_MISMATCH", "Supply exactly one follow-up context for each explicit target."
  end

  local targetSet = {}
  for _, targetId in ipairs(targetIds) do targetSet[targetId] = true end
  local seenTargets = {}
  local authorizations = {}
  for _, context in ipairs(contexts) do
    if type(context) ~= "table" or type(context.correlationId) ~= "string" or context.correlationId == "" or
        type(context.targetCombatantId) ~= "string" then
      return nil, "INVALID_ARGUMENT", "Each follow-up context requires a correlation ID and target combatant ID."
    end
    if not targetSet[context.targetCombatantId] or seenTargets[context.targetCombatantId] then
      return nil, "FOLLOW_UP_TARGET_MISMATCH", "Follow-up target identities must exactly match the explicit target list."
    end
    seenTargets[context.targetCombatantId] = true
    local key = getNerveFollowUpKey(context.correlationId, context.targetCombatantId, DB.getName(nodeAction))
    local authorization = pendingNervePowerFollowUps[key]
    if not authorization then
      return nil, "FOLLOW_UP_NOT_AUTHORIZED", "No matching unresolved follow-up authorization is available."
    end
    if NerveFollowUpContext.turnChanged(authorization) then
      pendingNervePowerFollowUps[key] = nil
      return nil, "FOLLOW_UP_TURN_CHANGED", "The combat turn changed before this correlated follow-up could execute. Resolve the new active turn instead."
    end
    if os.time() > authorization.expiresAt then
      pendingNervePowerFollowUps[key] = nil
      return nil, "FOLLOW_UP_EXPIRED", "The correlated follow-up authorization expired. Resolve the action again."
    end
    if authorization.characterId ~= args.characterId or authorization.powerId ~= args.powerId or
        authorization.actionId ~= args.actionId or authorization.actionType ~= actionType then
      return nil, "FOLLOW_UP_NOT_AUTHORIZED", "The correlated outcome does not authorize this character, power, or action."
    end
    table.insert(authorizations, { key = key, correlationId = context.correlationId })
  end
  return authorizations
end

local function combatantAbilityRequiresFollowUp(parsed, abilityIndex, actionType)
  if actionType ~= "damage" and actionType ~= "effect" then return false end
  for index, ability in ipairs(parsed.aAbilities or {}) do
    if index >= abilityIndex then break end
    if ability.sType == "attack" or ability.sType == "powersave" then return true end
  end
  return false
end

local function validateCombatantFollowUpContexts(args, parsed, ability, targetIds)
  local requiresFollowUp = combatantAbilityRequiresFollowUp(parsed, args.abilityIndex, ability.sType)
  local contexts = args.followUpContexts
  if not requiresFollowUp then
    if contexts ~= nil then
      return nil, "FOLLOW_UP_NOT_APPLICABLE", "This combatant ability does not accept a correlated follow-up context."
    end
    return {}
  end
  if type(contexts) ~= "table" or #contexts == 0 then
    return nil, "FOLLOW_UP_CONTEXT_REQUIRED", "This combatant damage or effect follows an attack/save and requires a correlated outcome."
  end
  if #contexts ~= #targetIds then
    return nil, "FOLLOW_UP_TARGET_MISMATCH", "Supply exactly one combatant follow-up context for each explicit target."
  end
  local targetSet, seenTargets, authorizations = {}, {}, {}
  for _, targetId in ipairs(targetIds) do targetSet[targetId] = true end
  for _, context in ipairs(contexts) do
    if type(context) ~= "table" or type(context.correlationId) ~= "string" or context.correlationId == "" or
        type(context.targetCombatantId) ~= "string" then
      return nil, "INVALID_ARGUMENT", "Each combatant follow-up context requires a correlation ID and target combatant ID."
    end
    if not targetSet[context.targetCombatantId] or seenTargets[context.targetCombatantId] then
      return nil, "FOLLOW_UP_TARGET_MISMATCH", "Combatant follow-up targets must exactly match the explicit target list."
    end
    seenTargets[context.targetCombatantId] = true
    local key = getNerveCombatantFollowUpKey(
      context.correlationId, context.targetCombatantId, args.section, args.actionId, args.abilityIndex
    )
    local authorization = pendingNerveCombatantFollowUps[key]
    if not authorization then
      return nil, "FOLLOW_UP_NOT_AUTHORIZED", "No matching unresolved combatant follow-up authorization is available."
    end
    if NerveFollowUpContext.turnChanged(authorization) then
      pendingNerveCombatantFollowUps[key] = nil
      return nil, "FOLLOW_UP_TURN_CHANGED", "The combat turn changed before this combatant follow-up could execute. Resolve the new active turn instead."
    end
    if os.time() > authorization.expiresAt then
      pendingNerveCombatantFollowUps[key] = nil
      return nil, "FOLLOW_UP_EXPIRED", "The combatant follow-up authorization expired. Resolve the action again."
    end
    if authorization.combatantId ~= args.combatantId or authorization.section ~= args.section or
        authorization.actionRecordId ~= args.actionId or authorization.abilityIndex ~= args.abilityIndex or
        authorization.actionType ~= ability.sType then
      return nil, "FOLLOW_UP_NOT_AUTHORIZED", "The outcome does not authorize this combatant action ability."
    end
    table.insert(authorizations, { key = key, correlationId = context.correlationId })
  end
  return authorizations
end

local function markCombatantActionUsed(nodeCombatant, nodeAction, parsed)
  if not parsed or not parsed.sUsage or parsed.sUsage == "USED" or not parsed.nUsageEnd then return false end
  local value = DB.getValue(nodeAction, "value", "")
  local rechargeThreshold = tonumber(string.match(value, "%[R:(%d)%]"))
  if not rechargeThreshold then return false end
  local nextValue = string.sub(value, 1, parsed.nUsageEnd) .. "[USED]" .. string.sub(value, parsed.nUsageEnd + 1)
  DB.setValue(nodeAction, "value", "string", nextValue)
  EffectManager.addEffectByTable(nodeCombatant, {
    sName = string.format("RCHG: %s %s", tostring(rechargeThreshold), parsed.name or DB.getValue(nodeAction, "name", "")),
    nGMOnly = 1
  })
  return true
end

local function executeProxyCombatantAction(command)
  local args = command.arguments or {}
  if playerProxyMode ~= "all" then
    return nil, "PLAYER_PROXY_DISABLED", "Enable Entity Proxy in Nerve Control before executing a combatant action."
  end
  local allowedSections = {}
  for _, section in ipairs(COMBATANT_ACTION_SECTIONS) do allowedSections[section] = true end
  if type(args.combatantId) ~= "string" or not string.match(args.combatantId, "^id%-%d+$") or
      not allowedSections[args.section] or type(args.actionId) ~= "string" or
      not string.match(args.actionId, "^id%-%d+$") or type(args.abilityIndex) ~= "number" or
      args.abilityIndex < 1 or args.abilityIndex % 1 ~= 0 then
    return nil, "INVALID_ARGUMENT", "Combatant, section, action, and ability identifiers must come from the published Combat Tracker."
  end
  if type(args.targetCombatantIds) ~= "table" or #args.targetCombatantIds > 20 then
    return nil, "INVALID_ARGUMENT", "Target combatant IDs must be an array containing no more than 20 entries."
  end
  local nodeCombatant = findCombatantById(args.combatantId)
  if not nodeCombatant then return nil, "COMBATANT_NOT_FOUND", "The acting combatant no longer exists." end
  local nodeAction = DB.findNode(DB.getPath(nodeCombatant) .. "." .. args.section .. "." .. args.actionId)
  if not nodeAction then return nil, "COMBATANT_ACTION_NOT_FOUND", "The selected combatant action no longer exists." end
  local parsed = CombatManager2.parseAttackLine(DB.getValue(nodeAction, "value", ""))
  local ability = parsed and parsed.aAbilities and parsed.aAbilities[args.abilityIndex] or nil
  if not ability or not COMBATANT_ACTION_TYPES[ability.sType] then
    return nil, "COMBATANT_ABILITY_NOT_FOUND", "The selected parsed combatant ability no longer exists."
  end
  local hasFollowUpContexts = type(args.followUpContexts) == "table" and #args.followUpContexts > 0
  if parsed.sUsage == "USED" and not hasFollowUpContexts then
    return nil, "RESOURCE_LIMIT", "The selected combatant action is already marked used and must recharge before it can start again."
  end

  local requestedTargets, requestedTargetIds = {}, {}
  for _, targetId in ipairs(args.targetCombatantIds) do
    if type(targetId) ~= "string" or not string.match(targetId, "^id%-%d+$") then
      return nil, "INVALID_ARGUMENT", "A target Combat Tracker ID is invalid."
    end
    local nodeTarget = findCombatantById(targetId)
    if not nodeTarget then return nil, "COMBATANT_NOT_FOUND", "A selected target no longer exists: " .. targetId end
    table.insert(requestedTargets, nodeTarget)
    table.insert(requestedTargetIds, targetId)
  end
  local authorizations, authCode, authMessage = validateCombatantFollowUpContexts(args, parsed, ability, requestedTargetIds)
  if not authorizations then return nil, authCode, authMessage end

  local rActor = ActorManager.resolveActor(nodeCombatant)
  if not rActor then return nil, "COMBATANT_ACTION_UNAVAILABLE", "Fantasy Grounds could not resolve the acting combatant." end
  local priorTargetPaths = {}
  for _, nodeTargetEntry in ipairs(DB.getChildList(nodeCombatant, "targets") or {}) do
    local targetPath = DB.getValue(nodeTargetEntry, "noderef", "")
    if targetPath ~= "" then table.insert(priorTargetPaths, targetPath) end
  end
  TargetingManager.clearCTTargets(nodeCombatant)
  for _, nodeTarget in ipairs(requestedTargets) do TargetingManager.addCTTarget(nodeCombatant, nodeTarget) end

  activeNervePowerContext = {
    requestId = command.requestId,
    sourceKind = "combatant",
    combatantId = args.combatantId,
    actionSection = args.section,
    actionRecordId = args.actionId,
    abilityIndex = args.abilityIndex,
    characterId = "",
    powerId = "",
    actionId = tostring(args.abilityIndex)
  }
  local handler
  if ability.sType == "attack" then handler = ActionAttack.performRoll
  elseif ability.sType == "powersave" then handler = ActionPower.performSaveVsRoll
  elseif ability.sType == "damage" then handler = ActionDamageD20.performRoll
  elseif ability.sType == "heal" then handler = ActionHealD20.performRoll
  elseif ability.sType == "effect" then handler = ActionEffect.performRoll end
  local callSucceeded, callError = pcall(handler, nil, rActor, ability)
  activeNervePowerContext = nil
  restoreCombatantTargets(nodeCombatant, priorTargetPaths)
  if not callSucceeded then
    Debug.console("Nerve Adapter: proxy combatant action failed: " .. tostring(callError))
    return nil, "COMBATANT_ACTION_FAILED", "Fantasy Grounds could not execute the selected combatant action."
  end
  local usageConsumed = false
  if #authorizations == 0 then usageConsumed = markCombatantActionUsed(nodeCombatant, nodeAction, parsed) end
  for _, authorization in ipairs(authorizations) do pendingNerveCombatantFollowUps[authorization.key] = nil end

  return {
    launched = true,
    correlationId = command.requestId,
    combatantId = args.combatantId,
    combatantName = DB.getValue(nodeCombatant, "name", ""),
    section = args.section,
    actionId = args.actionId,
    actionName = DB.getValue(nodeAction, "name", parsed.name or ""),
    abilityIndex = args.abilityIndex,
    actionType = ability.sType,
    targetCombatantIds = requestedTargetIds,
    targetCount = #requestedTargetIds,
    followUpContextCount = #authorizations,
    usageConsumed = usageConsumed,
    executedAt = os.date("!%Y-%m-%dT%H:%M:%SZ")
  }
end

local function executeProxyCharacterPowerAction(command)
  local args = command.arguments or {}
  if playerProxyMode ~= "all" then
    return nil, "PLAYER_PROXY_DISABLED", "Enable Entity Proxy in Nerve Control before executing a character power."
  end
  if type(args.characterId) ~= "string" or not string.match(args.characterId, "^id%-%d+$") or
      type(args.powerId) ~= "string" or not string.match(args.powerId, "^id%-%d+$") or
      type(args.actionId) ~= "string" or not string.match(args.actionId, "^id%-%d+$") then
    return nil, "INVALID_ARGUMENT", "Character, power, and action IDs must be published Fantasy Grounds IDs."
  end
  if type(args.targetCombatantIds) ~= "table" or #args.targetCombatantIds > 20 then
    return nil, "INVALID_ARGUMENT", "Target combatant IDs must be an array containing no more than 20 entries."
  end

  local nodeCharacter = DB.findNode("charsheet." .. args.characterId)
  if not nodeCharacter then return nil, "CHARACTER_NOT_FOUND", "The character no longer exists." end
  local nodePower = DB.findNode(DB.getPath(nodeCharacter) .. ".powers." .. args.powerId)
  if not nodePower then return nil, "POWER_NOT_FOUND", "The selected power no longer exists on the character sheet." end
  local nodeAction = DB.findNode(DB.getPath(nodePower) .. ".actions." .. args.actionId)
  if not nodeAction then return nil, "POWER_ACTION_NOT_FOUND", "The selected power action no longer exists." end

  local actionType = DB.getValue(nodeAction, "type", "")
  local allowedTypes = { cast = true, damage = true, heal = true, effect = true }
  if not allowedTypes[actionType] then
    return nil, "POWER_ACTION_UNSUPPORTED", "Nerve does not execute this Fantasy Grounds power action type."
  end

  local rAction, rActor = PowerManager.getPCPowerAction(nodeAction)
  if not rAction or not rActor then
    return nil, "POWER_ACTION_UNAVAILABLE", "Fantasy Grounds could not prepare the selected character power action."
  end
  local nodeSourceCT = ActorManager.getCTNode(rActor)
  if #args.targetCombatantIds > 0 and not nodeSourceCT then
    return nil, "SOURCE_NOT_IN_COMBAT", "The character must be in the Combat Tracker to use explicit targets."
  end

  local requestedTargets = {}
  local requestedTargetIds = {}
  for _, combatantId in ipairs(args.targetCombatantIds) do
    if type(combatantId) ~= "string" or not string.match(combatantId, "^id%-%d+$") then
      return nil, "INVALID_ARGUMENT", "A target Combat Tracker ID is invalid."
    end
    local nodeTarget = findCombatantById(combatantId)
    if not nodeTarget then return nil, "COMBATANT_NOT_FOUND", "A selected target no longer exists: " .. combatantId end
    table.insert(requestedTargets, nodeTarget)
    table.insert(requestedTargetIds, combatantId)
  end

  local followUpAuthorizations, followUpErrorCode, followUpErrorMessage = validateNerveFollowUpContexts(
    args, nodePower, nodeAction, actionType, requestedTargetIds
  )
  if not followUpAuthorizations then return nil, followUpErrorCode, followUpErrorMessage end

  local slotResult = nil
  if args.spellSlot ~= nil then
    if type(args.spellSlot) ~= "table" or type(args.spellSlot.level) ~= "number" or
        args.spellSlot.level < 1 or args.spellSlot.level > 9 or args.spellSlot.level % 1 ~= 0 or
        type(args.spellSlot.expectedUsed) ~= "number" or args.spellSlot.expectedUsed < 0 or
        args.spellSlot.expectedUsed % 1 ~= 0 then
      return nil, "INVALID_ARGUMENT", "Spell-slot level and expected usage must be bounded integers."
    end
    local powerLevel = DB.getValue(nodePower, "level", 0)
    if powerLevel < 1 or args.spellSlot.level < powerLevel then
      return nil, "INVALID_ARGUMENT", "The requested spell-slot level cannot cast this power."
    end
    local hasCastAction = false
    for _, candidateAction in ipairs(DB.getChildList(nodePower, "actions") or {}) do
      if DB.getValue(candidateAction, "type", "") == "cast" then
        hasCastAction = true
        break
      end
    end
    if hasCastAction and actionType ~= "cast" then
      return nil, "INVALID_ARGUMENT", "This power has a cast action; consume its spell slot on that action only."
    end
    local slotPath = "powermeta.spellslots" .. tostring(args.spellSlot.level)
    local maximum = DB.getValue(nodeCharacter, slotPath .. ".max", 0)
    local previousUsed = DB.getValue(nodeCharacter, slotPath .. ".used", 0)
    if maximum <= 0 then return nil, "SPELL_SLOT_LEVEL_UNAVAILABLE", "The character has no spell slots at that level." end
    if previousUsed ~= args.spellSlot.expectedUsed then
      return nil, "STATE_CONFLICT", "Spell-slot usage changed before the power action was executed."
    end
    if previousUsed >= maximum then return nil, "RESOURCE_LIMIT", "No spell slot is available at the requested level." end
    slotResult = {
      level = args.spellSlot.level,
      previousUsed = previousUsed,
      used = previousUsed + 1,
      maximum = maximum,
      available = maximum - previousUsed - 1,
      path = slotPath
    }
  end

  local priorTargetPaths = {}
  if nodeSourceCT then
    for _, nodeTargetEntry in ipairs(DB.getChildList(nodeSourceCT, "targets") or {}) do
      local targetPath = DB.getValue(nodeTargetEntry, "noderef", "")
      if targetPath ~= "" then table.insert(priorTargetPaths, targetPath) end
    end
    TargetingManager.clearCTTargets(nodeSourceCT)
    for _, nodeTarget in ipairs(requestedTargets) do TargetingManager.addCTTarget(nodeSourceCT, nodeTarget) end
  end

  local continuationCorrelationId = #followUpAuthorizations > 0 and followUpAuthorizations[1].correlationId or command.requestId
  activeNervePowerContext = {
    requestId = continuationCorrelationId,
    characterId = args.characterId,
    powerId = args.powerId,
    actionId = args.actionId,
    targetCombatantIds = requestedTargetIds,
    initiatedBy = "nerve"
  }
  local callSucceeded, actionLaunched = pcall(PowerManager.performAction, nil, rActor, rAction, nodePower)
  activeNervePowerContext = nil
  restoreCombatantTargets(nodeSourceCT, priorTargetPaths)
  if not callSucceeded or actionLaunched ~= true then
    Debug.console("Nerve Adapter: proxy power action failed: " .. tostring(actionLaunched))
    return nil, "POWER_ACTION_FAILED", "Fantasy Grounds could not execute the selected power action."
  end

  for _, authorization in ipairs(followUpAuthorizations) do
    pendingNervePowerFollowUps[authorization.key] = nil
  end

  if #followUpAuthorizations > 0 and actionType == "effect" and publishNervePowerFollowUpOutcome then
    publishNervePowerFollowUpOutcome({
      sNerveRequestId = continuationCorrelationId,
      sNerveCharacterId = args.characterId,
      sNervePowerId = args.powerId,
      sNerveActionId = args.actionId,
      sNerveTargetCombatantIds = table.concat(requestedTargetIds, ",")
    }, "effect", 0)
  end

  if slotResult then DB.setValue(nodeCharacter, slotResult.path .. ".used", "number", slotResult.used) end
  local result = {
    launched = true,
    correlationId = continuationCorrelationId,
    characterId = args.characterId,
    characterName = DB.getValue(nodeCharacter, "name", ""),
    powerId = args.powerId,
    powerName = DB.getValue(nodePower, "name", ""),
    actionId = args.actionId,
    actionType = actionType,
    targetCount = #requestedTargetIds,
    followUpContextCount = #followUpAuthorizations,
    slotConsumed = slotResult ~= nil,
    executedAt = os.date("!%Y-%m-%dT%H:%M:%SZ")
  }
  if #requestedTargetIds > 0 then result.targetCombatantIds = requestedTargetIds end
  if slotResult then
    slotResult.path = nil
    result.spellSlot = slotResult
  end
  return result
end

local function rollbackAddedCombatants(combatants)
  suppressCombatStateChanged = true
  for _, nodeCombatant in ipairs(combatants or {}) do
    if nodeCombatant and DB.findNode(DB.getPath(nodeCombatant)) then CombatManager.deleteCombatant(nodeCombatant) end
  end
  suppressCombatStateChanged = false
  onCombatStateChanged()
end

local function executeAddLibraryNpc(command)
  local args = command.arguments or {}
  local allowedFactions = { friend = true, foe = true, neutral = true }
  if type(args.recordId) ~= "string" or args.recordId == "" or #args.recordId > 512 or
      type(args.expectedName) ~= "string" or args.expectedName == "" or #args.expectedName > 200 or
      type(args.quantity) ~= "number" or args.quantity < 1 or args.quantity > 20 or args.quantity % 1 ~= 0 or
      not allowedFactions[args.faction] or type(args.identified) ~= "boolean" or
      (args.name ~= nil and (type(args.name) ~= "string" or args.name == "" or #args.name > 100)) then
    return nil, "INVALID_ARGUMENT", "Library NPC arguments are invalid or outside their bounded limits."
  end
  local nodeRecord = DB.findNode(args.recordId)
  if not nodeRecord or RecordDataManager.getRecordTypeFromRecordPath(DB.getPath(nodeRecord)) ~= "npc" then
    return nil, "LIBRARY_NPC_NOT_FOUND", "The selected loaded-library NPC record is unavailable."
  end
  local recordName = DB.getValue(nodeRecord, "name", "")
  if recordName ~= args.expectedName then
    return nil, "STATE_CONFLICT", "The library NPC name changed or does not match the observed record."
  end

  local addedNodes = {}
  suppressCombatStateChanged = true
  for _ = 1, args.quantity do
    local custom = {
      sRecordType = "npc",
      sRecord = DB.getPath(nodeRecord),
      nodeRecord = nodeRecord,
      sFaction = args.faction,
      nIdentified = args.identified and 1 or 0,
      sName = args.name
    }
    local callSucceeded, added = pcall(CombatRecordManager.onRecordTypeEvent, "npc", custom)
    if not callSucceeded or added ~= true or not custom.nodeCT then
      suppressCombatStateChanged = false
      rollbackAddedCombatants(addedNodes)
      Debug.console("Nerve Adapter: library NPC add failed: " .. tostring(added))
      return nil, "LIBRARY_NPC_ADD_FAILED", "Fantasy Grounds could not add every requested NPC; partial additions were rolled back."
    end
    table.insert(addedNodes, custom.nodeCT)
  end
  suppressCombatStateChanged = false
  onCombatStateChanged()

  local combatants = {}
  for _, nodeCombatant in ipairs(addedNodes) do
    table.insert(combatants, { id = DB.getName(nodeCombatant), name = DB.getValue(nodeCombatant, "name", "") })
  end
  return {
    recordId = args.recordId,
    recordName = recordName,
    quantity = #combatants,
    faction = args.faction,
    identified = args.identified,
    combatants = combatants,
    executedAt = os.date("!%Y-%m-%dT%H:%M:%SZ")
  }
end

local function findEncounterHistory(recordId)
  for _, nodeHistory in pairs(DB.getChildren("nerve.encounterhistory") or {}) do
    if DB.getValue(nodeHistory, "recordid", "") == recordId then return nodeHistory end
  end
  return nil
end

local function recordEncounterHistory(recordId, encounterName)
  local nodeHistory = findEncounterHistory(recordId)
  if not nodeHistory then
    local nodeRoot = DB.createNode("nerve.encounterhistory")
    nodeHistory = nodeRoot and DB.createChild(nodeRoot) or nil
  end
  if not nodeHistory then return 1 end
  local occurrence = DB.getValue(nodeHistory, "timesadded", 0) + 1
  DB.setValue(nodeHistory, "recordid", "string", recordId)
  DB.setValue(nodeHistory, "name", "string", encounterName)
  DB.setValue(nodeHistory, "timesadded", "number", occurrence)
  DB.setValue(nodeHistory, "lastaddedat", "string", os.date("!%Y-%m-%dT%H:%M:%SZ"))
  return occurrence
end

local function executeAddLibraryEncounter(command)
  local args = command.arguments or {}
  if type(args.recordId) ~= "string" or args.recordId == "" or #args.recordId > 512 or
      type(args.expectedName) ~= "string" or args.expectedName == "" or #args.expectedName > 200 or
      (args.allowRepeat ~= nil and type(args.allowRepeat) ~= "boolean") then
    return nil, "INVALID_ARGUMENT", "Library encounter arguments are invalid or outside their bounded limits."
  end
  local nodeRecord = DB.findNode(args.recordId)
  if not nodeRecord or RecordDataManager.getRecordTypeFromRecordPath(DB.getPath(nodeRecord)) ~= "battle" then
    return nil, "LIBRARY_ENCOUNTER_NOT_FOUND", "The selected loaded-library encounter record is unavailable."
  end
  local encounterName = DB.getValue(nodeRecord, "name", "")
  if encounterName ~= args.expectedName then
    return nil, "STATE_CONFLICT", "The library encounter name changed or does not match the observed record."
  end
  local destinationKey = string.match(encounterName, "^([A-Za-z]%d+)%s*:")
  local continuity = args.continuity
  if destinationKey then
    if type(continuity) ~= "table" or continuity.preservePlayerVision ~= true or
        type(continuity.currentAreaKey) ~= "string" or continuity.currentAreaKey == "" or
        continuity.destinationAreaKey ~= destinationKey or type(continuity.routeAreaKeys) ~= "table" or
        #continuity.routeAreaKeys < 1 or #continuity.routeAreaKeys > 30 or
        type(continuity.resolvedAreaKeys) ~= "table" or type(continuity.explicitlyBypassedAreaKeys) ~= "table" then
      return nil, "CONTINUITY_CONTEXT_REQUIRED", "Keyed encounters require an exact route, resolved/bypassed areas, and preserved player vision."
    end
    if continuity.routeAreaKeys[1] ~= continuity.currentAreaKey or
        continuity.routeAreaKeys[#continuity.routeAreaKeys] ~= destinationKey then
      return nil, "CONTINUITY_ROUTE_INVALID", "The keyed encounter route must begin at the current area and end at the destination."
    end
    local resolved, bypassed = {}, {}
    for _, key in ipairs(continuity.resolvedAreaKeys) do resolved[key] = true end
    for _, key in ipairs(continuity.explicitlyBypassedAreaKeys) do bypassed[key] = true end
    for index = 2, #continuity.routeAreaKeys - 1 do
      local key = continuity.routeAreaKeys[index]
      if not resolved[key] and not bypassed[key] then
        return nil, "CONTINUITY_AREA_UNRESOLVED", "Intervening area " .. tostring(key) .. " is neither resolved nor explicitly bypassed."
      end
    end
  end
  local priorHistory = findEncounterHistory(args.recordId)
  if priorHistory and args.allowRepeat ~= true then
    return nil, "ENCOUNTER_ALREADY_ADDED", string.format(
      "This campaign already added %s %d time(s). Set allowRepeat only after the GM explicitly confirms a repeat encounter.",
      encounterName, DB.getValue(priorHistory, "timesadded", 1)
    )
  end

  local listPath = RecordDataManager.getCustomData("battle", "npclist", "npclist")
  local expectedCount = 0
  local encounterMapsById = {}
  for _, nodeEntry in ipairs(DB.getChildList(nodeRecord, listPath) or {}) do
    local entry = CombatRecordManager.getBattleEntryData(nodeEntry)
    if not entry or not entry.nodeRecord then
      return nil, "ENCOUNTER_RECORD_UNAVAILABLE", "An NPC referenced by the encounter is not currently loaded."
    end
    expectedCount = expectedCount + entry.nCount
    for _, placement in ipairs(entry.tAllPlacements or {}) do
      if placement.imagelink ~= "" and not DB.findNode(placement.imagelink) then
        return nil, "ENCOUNTER_ASSET_UNAVAILABLE", "A map referenced by the prepared encounter is not currently loaded."
      end
      if placement.imagelink ~= "" then
        local nodeMap = DB.findNode(placement.imagelink)
        encounterMapsById[placement.imagelink] = {
          recordId = placement.imagelink,
          name = nodeMap and DB.getValue(nodeMap, "name", DB.getValue(nodeMap, "title", "")) or ""
        }
      end
    end
  end
  if expectedCount < 1 or expectedCount > 30 then
    return nil, "RESOURCE_LIMIT", "Prepared encounters must contain between 1 and 30 combatants."
  end

  local priorIds = {}
  for _, nodeCombatant in pairs(DB.getChildren("combattracker.list") or {}) do priorIds[DB.getName(nodeCombatant)] = true end
  suppressCombatStateChanged = true
  local callSucceeded, added = pcall(CombatRecordManager.onRecordTypeEvent, "battle", {
    sRecordType = "battle", sRecord = DB.getPath(nodeRecord), nodeRecord = nodeRecord
  })
  suppressCombatStateChanged = false
  local addedNodes = {}
  for _, nodeCombatant in pairs(DB.getChildren("combattracker.list") or {}) do
    if not priorIds[DB.getName(nodeCombatant)] then table.insert(addedNodes, nodeCombatant) end
  end
  if not callSucceeded or added ~= true or #addedNodes ~= expectedCount then
    rollbackAddedCombatants(addedNodes)
    Debug.console("Nerve Adapter: library encounter add failed: " .. tostring(added))
    return nil, "LIBRARY_ENCOUNTER_ADD_FAILED", "Fantasy Grounds could not add the complete encounter; partial additions were rolled back."
  end
  for _, nodeCombatant in ipairs(addedNodes) do
    if DB.getValue(nodeCombatant, "friendfoe", "") == "foe" then
      DB.setValue(nodeCombatant, "tokenvis", "number", 0)
    end
  end
  onCombatStateChanged()
  table.sort(addedNodes, function(left, right) return DB.getName(left) < DB.getName(right) end)
  local combatants = {}
  for _, nodeCombatant in ipairs(addedNodes) do
    table.insert(combatants, { id = DB.getName(nodeCombatant), name = DB.getValue(nodeCombatant, "name", "") })
  end
  local maps = {}
  for _, map in pairs(encounterMapsById) do table.insert(maps, map) end
  table.sort(maps, function(left, right) return string.lower(left.name) < string.lower(right.name) end)
  local encounterOccurrence = recordEncounterHistory(args.recordId, encounterName)
  local continuityRecorded = false
  if destinationKey and continuity then
    local root = DB.createNode("nerve.areacontinuity")
    if root then
      for _, key in ipairs(continuity.resolvedAreaKeys) do DB.setValue(root, key .. ".status", "string", "resolved") end
      for _, key in ipairs(continuity.explicitlyBypassedAreaKeys) do DB.setValue(root, key .. ".status", "string", "bypassed") end
      DB.setValue(root, destinationKey .. ".status", "string", "visited")
      DB.setValue(root, destinationKey .. ".recordid", "string", args.recordId)
      DB.setValue("nerve.areacontinuity.currentarea", "string", destinationKey)
      continuityRecorded = true
    end
  end
  return {
    recordId = args.recordId,
    encounterName = encounterName,
    encounterOccurrence = encounterOccurrence,
    repeatEncounter = encounterOccurrence > 1,
    addedCount = #combatants,
    combatants = combatants,
    maps = maps,
    playerVisionPreserved = true,
    continuityRecorded = continuityRecorded,
    executedAt = os.date("!%Y-%m-%dT%H:%M:%SZ")
  }
end

local function findOpenImageWindow(recordId)
  for _, imageControl in ipairs(ImageManager.getActiveImages() or {}) do
    local nodeImage = imageControl.getDatabaseNode and imageControl.getDatabaseNode() or nil
    local nodeRecord = nodeImage and DB.getParent(nodeImage) or nil
    if nodeRecord and DB.getPath(nodeRecord) == recordId then
      return WindowManager.getTopWindow(imageControl)
    end
  end
  return nil
end

local function executeOpenLibraryImage(command)
  local args = command.arguments or {}
  if type(args.recordId) ~= "string" or args.recordId == "" or #args.recordId > 512 or
      type(args.expectedName) ~= "string" or args.expectedName == "" or #args.expectedName > 200 or
      (args.visibility ~= "gm" and args.visibility ~= "all") then
    return nil, "INVALID_ARGUMENT", "Library image arguments are invalid or outside their bounded limits."
  end
  local nodeRecord = DB.findNode(args.recordId)
  if not nodeRecord or RecordDataManager.getRecordTypeFromRecordPath(DB.getPath(nodeRecord)) ~= "image" then
    return nil, "LIBRARY_IMAGE_NOT_FOUND", "The selected loaded-library image record is unavailable."
  end
  local name = DB.getValue(nodeRecord, "name", DB.getValue(nodeRecord, "title", ""))
  if name ~= args.expectedName then
    return nil, "STATE_CONFLICT", "The library image name changed or does not match the observed record."
  end
  local access = UtilityManager.getNodeAccessLevel(nodeRecord)
  if args.visibility == "gm" and access ~= 0 then
    return nil, "IMAGE_ALREADY_SHARED", "This image is already shared. Nerve will not claim a GM-only open without revoking existing player access."
  end

  local recordId = DB.getPath(nodeRecord)
  local window = findOpenImageWindow(recordId)
  local alreadyOpen = window ~= nil
  if not window then
    suppressImageWindowEvent = true
    window = RecordManager.openRecordWindow("image", nodeRecord)
    suppressImageWindowEvent = false
  end
  if not window then return nil, "IMAGE_OPEN_FAILED", "Fantasy Grounds could not open the selected image." end
  if window.bringToFront then window.bringToFront() end
  currentMapId = recordId

  local shared = access ~= 0
  if args.visibility == "all" then
    DB.setPublic(nodeRecord, true)
    if imagePanelName(window.getClass and window.getClass() or "imagewindow") == "window" and window.share then
      window.share()
    else
      Interface.openRemoteWindow("imagewindow", nodeRecord)
    end
    shared = true
    publishSnapshot("map-shared", {
      type = "map.shared", actor = "Nerve", text = name, visibility = "all", subjectId = recordId,
      data = { visibility = "all" }
    })
  else
    publishSnapshot("map-opened-by-nerve", {
      type = "map.opened", actor = "Nerve", text = name, visibility = "gm", subjectId = recordId,
      data = { visibility = "gm", source = "nerve" }
    })
  end
  return {
    recordId = recordId, name = name, visibility = args.visibility, opened = true,
    shared = shared, alreadyOpen = alreadyOpen,
    executedAt = os.date("!%Y-%m-%dT%H:%M:%SZ")
  }
end

local function executeSetSpellSlotUsage(command)
  local args = command.arguments or {}
  if playerProxyMode ~= "all" then
    return nil, "PLAYER_PROXY_DISABLED", "Enable Entity Proxy in Nerve Control before changing a character resource."
  end
  if type(args.characterId) ~= "string" or not string.match(args.characterId, "^id%-%d+$") then
    return nil, "INVALID_ARGUMENT", "Character ID is invalid."
  end
  if type(args.level) ~= "number" or args.level < 1 or args.level > 9 or args.level % 1 ~= 0 then
    return nil, "INVALID_ARGUMENT", "Spell level must be an integer from 1 to 9."
  end
  if type(args.expectedUsed) ~= "number" or args.expectedUsed < 0 or args.expectedUsed % 1 ~= 0 or
      type(args.used) ~= "number" or args.used < 0 or args.used % 1 ~= 0 then
    return nil, "INVALID_ARGUMENT", "Spell-slot usage values must be non-negative integers."
  end
  local nodeCharacter = DB.findNode("charsheet." .. args.characterId)
  if not nodeCharacter then return nil, "CHARACTER_NOT_FOUND", "The character no longer exists." end
  local path = "powermeta.spellslots" .. tostring(args.level)
  local maximum = DB.getValue(nodeCharacter, path .. ".max", 0)
  local previousUsed = DB.getValue(nodeCharacter, path .. ".used", 0)
  if maximum <= 0 then return nil, "SPELL_SLOT_LEVEL_UNAVAILABLE", "The character has no spell slots at that level." end
  if previousUsed ~= args.expectedUsed then
    return nil, "STATE_CONFLICT", "Spell-slot usage changed before the command was executed."
  end
  if args.used > maximum then return nil, "RESOURCE_LIMIT", "Used spell slots cannot exceed the character's maximum." end
  DB.setValue(nodeCharacter, path .. ".used", "number", args.used)
  return {
    characterId = args.characterId,
    characterName = DB.getValue(nodeCharacter, "name", ""),
    level = args.level,
    previousUsed = previousUsed,
    used = args.used,
    maximum = maximum,
    available = maximum - args.used,
    executedAt = os.date("!%Y-%m-%dT%H:%M:%SZ")
  }
end

local function executeAdvanceTurn(command)
  local args = command.arguments or {}
  local nodeActive = CombatManager.getActiveCT()
  local activeId = nodeActive and DB.getName(nodeActive) or nil
  if not activeId then return nil, "NO_ACTIVE_COMBATANT", "No combatant currently has the active turn." end
  if args.expectedActiveCombatantId ~= activeId then
    return nil, "STATE_CONFLICT", "The active combatant changed before the command was executed."
  end

  local skippedCombatantIds = {}
  local combatantCount = 0
  for _, _ in pairs(DB.getChildren("combattracker.list") or {}) do combatantCount = combatantCount + 1 end
  CombatManager.nextActor()
  local nodeNext = CombatManager.getActiveCT()
  local attempts = 0
  while args.skipDefeated == true and nodeNext and isDefeatedCombatant(nodeNext) and attempts < combatantCount do
    table.insert(skippedCombatantIds, DB.getName(nodeNext))
    CombatManager.nextActor()
    nodeNext = CombatManager.getActiveCT()
    attempts = attempts + 1
  end
  return {
    previousCombatantId = activeId,
    activeCombatantId = nodeNext and DB.getName(nodeNext) or nil,
    round = DB.getValue("combattracker.round", 0),
    skippedCombatantIds = skippedCombatantIds,
    executedAt = os.date("!%Y-%m-%dT%H:%M:%SZ")
  }
end

local function executeStartEncounter(command)
  local args = command.arguments or {}
  if type(args.expectedCombatantIds) ~= "table" or #args.expectedCombatantIds == 0 or #args.expectedCombatantIds > 100 then
    return nil, "INVALID_ARGUMENT", "Expected Combat Tracker roster must contain 1 to 100 combatant IDs."
  end
  if type(args.expectedRound) ~= "number" or args.expectedRound < 0 or args.expectedRound % 1 ~= 0 then
    return nil, "INVALID_ARGUMENT", "Expected round must be a non-negative integer."
  end
  if CombatManager.getActiveCT() then
    return nil, "ENCOUNTER_ALREADY_ACTIVE", "A combatant already has the active turn."
  end
  if DB.getValue("combattracker.round", 0) ~= args.expectedRound then
    return nil, "STATE_CONFLICT", "The combat round changed before the encounter was started."
  end
  local expected = {}
  for _, combatantId in ipairs(args.expectedCombatantIds) do
    if type(combatantId) ~= "string" or not string.match(combatantId, "^id%-%d+$") or expected[combatantId] then
      return nil, "INVALID_ARGUMENT", "Expected Combat Tracker IDs must be unique stable IDs."
    end
    expected[combatantId] = true
  end
  local nodes = DB.getChildren("combattracker.list") or {}
  local actualCount = 0
  for _, nodeCombatant in pairs(nodes) do
    local combatantId = DB.getName(nodeCombatant)
    if not expected[combatantId] then
      return nil, "STATE_CONFLICT", "The Combat Tracker roster changed before the encounter was started."
    end
    actualCount = actualCount + 1
  end
  if actualCount ~= #args.expectedCombatantIds then
    return nil, "STATE_CONFLICT", "The Combat Tracker roster changed before the encounter was started."
  end

  local preservePublishedInitiative = args.expectedRound > 0
  if preservePublishedInitiative then
    for _, nodeCombatant in pairs(nodes) do
      if DB.getValue(nodeCombatant, "initresult", 0) == 0 then preservePublishedInitiative = false break end
    end
  end
  if not preservePublishedInitiative then CombatManager.rollInit() end
  local initiativeOrder = {}
  for _, nodeCombatant in pairs(nodes) do
    table.insert(initiativeOrder, {
      combatantId = DB.getName(nodeCombatant),
      name = DB.getValue(nodeCombatant, "name", ""),
      initiative = DB.getValue(nodeCombatant, "initresult", 0),
      playerVisible = ActorManager.isVisible(nodeCombatant)
    })
  end
  table.sort(initiativeOrder, function(left, right)
    if left.initiative == right.initiative then return left.combatantId < right.combatantId end
    return left.initiative > right.initiative
  end)
  if args.expectedRound > 0 then CombatManager.nextActor(nil, true) else CombatManager.nextActor() end
  local nodeActive = CombatManager.getActiveCT()
  return {
    started = true,
    round = DB.getValue("combattracker.round", 0),
    activeCombatantId = nodeActive and DB.getName(nodeActive) or nil,
    initiativeOrder = initiativeOrder,
    executedAt = os.date("!%Y-%m-%dT%H:%M:%SZ")
  }
end

local function executeBeginStoryEncounter(command)
  local args = command.arguments or {}
  if type(args.sourceStoryRecordId) ~= "string" or args.sourceStoryRecordId == "" or
      type(args.currentAreaKey) ~= "string" or args.currentAreaKey == "" or
      type(args.preparedEncounters) ~= "table" or #args.preparedEncounters < 1 or #args.preparedEncounters > 4 or
      type(args.expectedCombatantIds) ~= "table" or #args.expectedCombatantIds < 1 or #args.expectedCombatantIds > 100 or
      type(args.expectedRound) ~= "number" or args.expectedRound < 0 or args.expectedRound % 1 ~= 0 or
      args.arrivalMode ~= "approach_party" or type(args.publicNarration) ~= "string" or
      args.publicNarration == "" or #args.publicNarration > 1000 then
    return nil, "INVALID_ARGUMENT", "Story encounter arguments are invalid or outside bounded limits."
  end
  if DB.getValue("nerve.areacontinuity.currentarea", "") ~= args.currentAreaKey then
    return nil, "STATE_CONFLICT", "The confirmed party area changed before the story encounter began."
  end
  local nodeStory = DB.findNode(args.sourceStoryRecordId)
  if not nodeStory or RecordDataManager.getRecordTypeFromRecordPath(DB.getPath(nodeStory)) ~= "story" or
      not string.match(string.lower(DB.getValue(nodeStory, "name", "")), "^" .. string.lower(args.currentAreaKey) .. "%s*:") then
    return nil, "STORY_TRIGGER_NOT_FOUND", "The exact current-area story source is unavailable or no longer matches the party area."
  end
  if CombatManager.getActiveCT() or DB.getValue("combattracker.round", 0) ~= args.expectedRound then
    return nil, "STATE_CONFLICT", "Combat became active or the combat round changed before the story encounter began."
  end
  local expectedExisting = {}
  for _, id in ipairs(args.expectedCombatantIds) do
    if type(id) ~= "string" or not string.match(id, "^id%-%d+$") or expectedExisting[id] then
      return nil, "INVALID_ARGUMENT", "Expected Combat Tracker IDs must be unique stable IDs."
    end
    expectedExisting[id] = true
  end
  local priorIds = {}
  local priorInitiatives = {}
  local existingCount = 0
  for _, nodeCombatant in pairs(DB.getChildren("combattracker.list") or {}) do
    local id = DB.getName(nodeCombatant)
    if not expectedExisting[id] then return nil, "STATE_CONFLICT", "The Combat Tracker roster changed before encounter insertion." end
    priorIds[id] = true
    priorInitiatives[id] = DB.getValue(nodeCombatant, "initresult", 0)
    existingCount = existingCount + 1
  end
  if existingCount ~= #args.expectedCombatantIds then return nil, "STATE_CONFLICT", "The Combat Tracker roster changed before encounter insertion." end

  local records = {}
  local seenRecords = {}
  local expectedAddedCount = 0
  local listPath = RecordDataManager.getCustomData("battle", "npclist", "npclist")
  for _, descriptor in ipairs(args.preparedEncounters) do
    if type(descriptor) ~= "table" or type(descriptor.recordId) ~= "string" or descriptor.recordId == "" or
        type(descriptor.expectedName) ~= "string" or descriptor.expectedName == "" or seenRecords[descriptor.recordId] or
        string.find(string.lower(descriptor.expectedName), "optional", 1, true) then
      return nil, "INVALID_ARGUMENT", "Prepared story encounters must be unique, exact, and non-optional."
    end
    local nodeRecord = DB.findNode(descriptor.recordId)
    if not nodeRecord or RecordDataManager.getRecordTypeFromRecordPath(DB.getPath(nodeRecord)) ~= "battle" or
        DB.getValue(nodeRecord, "name", "") ~= descriptor.expectedName or findEncounterHistory(descriptor.recordId) then
      return nil, "STATE_CONFLICT", "A prepared encounter is unavailable, changed, optional, or was already added."
    end
    local recordCount = 0
    for _, nodeEntry in ipairs(DB.getChildList(nodeRecord, listPath) or {}) do
      local entry = CombatRecordManager.getBattleEntryData(nodeEntry)
      if not entry or not entry.nodeRecord then return nil, "ENCOUNTER_RECORD_UNAVAILABLE", "A prepared encounter NPC is unavailable." end
      recordCount = recordCount + (tonumber(entry.nCount) or 0)
      for _, placement in ipairs(entry.tAllPlacements or {}) do
        if placement.imagelink ~= "" and not DB.findNode(placement.imagelink) then
          return nil, "ENCOUNTER_ASSET_UNAVAILABLE", "A prepared encounter map is unavailable."
        end
      end
    end
    if recordCount < 1 then return nil, "RESOURCE_LIMIT", "A prepared encounter contains no combatants." end
    expectedAddedCount = expectedAddedCount + recordCount
    seenRecords[descriptor.recordId] = true
    table.insert(records, { node = nodeRecord, id = descriptor.recordId, name = descriptor.expectedName })
  end
  if expectedAddedCount > 30 then return nil, "RESOURCE_LIMIT", "A story encounter may add at most 30 combatants." end

  local addedNodes = {}
  local function collectAddedNodes()
    local collected = {}
    for _, nodeCombatant in pairs(DB.getChildren("combattracker.list") or {}) do
      if not priorIds[DB.getName(nodeCombatant)] then table.insert(collected, nodeCombatant) end
    end
    table.sort(collected, function(a, b) return DB.getName(a) < DB.getName(b) end)
    return collected
  end
  local function rollbackAddedNodes()
    for _, nodeCombatant in ipairs(collectAddedNodes()) do pcall(CombatManager.deleteCombatant, nodeCombatant) end
  end
  suppressCombatStateChanged = true
  for _, record in ipairs(records) do
    local ok, added = pcall(CombatRecordManager.onRecordTypeEvent, "battle", {
      sRecordType = "battle", sRecord = DB.getPath(record.node), nodeRecord = record.node
    })
    if not ok or added ~= true then
      rollbackAddedNodes()
      suppressCombatStateChanged = false
      return nil, "STORY_ENCOUNTER_ADD_FAILED", "Fantasy Grounds could not add every prepared encounter; new entries were rolled back."
    end
    addedNodes = collectAddedNodes()
  end
  if #addedNodes ~= expectedAddedCount then
    rollbackAddedNodes()
    suppressCombatStateChanged = false
    return nil, "STORY_ENCOUNTER_ADD_FAILED", "Fantasy Grounds added an incomplete story encounter; new entries were rolled back."
  end
  for _, nodeCombatant in ipairs(addedNodes) do
    if DB.getValue(nodeCombatant, "friendfoe", "") ~= "foe" then
      rollbackAddedNodes()
      suppressCombatStateChanged = false
      return nil, "STORY_ENCOUNTER_ADD_FAILED", "A prepared story encounter contained a non-hostile entry; new entries were rolled back."
    end
  end

  local imageControl
  for _, candidate in ipairs(ImageManager.getActiveImages() or {}) do
    local hasParty = false
    for _, token in ipairs(candidate.getTokens() or {}) do
      local nodeCT = CombatManager.getCTFromToken(token)
      if nodeCT and DB.getValue(nodeCT, "friendfoe", "") == "friend" then hasParty = true break end
    end
    if hasParty then imageControl = candidate break end
  end
  local relocatedCount = 0
  if imageControl then
    local nodeImage = imageControl.getDatabaseNode and imageControl.getDatabaseNode() or nil
    local imageData = nodeImage and (DB.getValue(nodeImage) or {}) or {}
    local gridX, gridY = tonumber(imageData.gridsizex) or 100, tonumber(imageData.gridsizey) or 100
    if gridX < 1 then gridX = 100 end; if gridY < 1 then gridY = 100 end
    local partyX, partyY, partyCount, sourceX, sourceY, sourceCount = 0, 0, 0, 0, 0, 0
    for _, token in ipairs(imageControl.getTokens() or {}) do
      local nodeCT = CombatManager.getCTFromToken(token)
      local x, y = token.getPosition()
      if nodeCT and DB.getValue(nodeCT, "friendfoe", "") == "friend" then partyX = partyX + x; partyY = partyY + y; partyCount = partyCount + 1
      elseif nodeCT and not priorIds[DB.getName(nodeCT)] then sourceX = sourceX + x; sourceY = sourceY + y; sourceCount = sourceCount + 1 end
    end
    if partyCount > 0 then
      partyX, partyY = partyX / partyCount, partyY / partyCount
      sourceX, sourceY = sourceCount > 0 and sourceX / sourceCount or partyX - gridX, sourceCount > 0 and sourceY / sourceCount or partyY
      local horizontal = math.abs(sourceX - partyX) >= math.abs(sourceY - partyY)
      local sideX = horizontal and (sourceX < partyX and -1 or 1) or 0
      local sideY = not horizontal and (sourceY < partyY and -1 or 1) or 0
      table.sort(addedNodes, function(a, b) return DB.getName(a) < DB.getName(b) end)
      for index, nodeCombatant in ipairs(addedNodes) do
        local token = CombatManager.getTokenFromCT and CombatManager.getTokenFromCT(nodeCombatant) or nil
        if token and token.setPosition then
          local spread = index - ((#addedNodes + 1) / 2)
          local targetX = partyX + sideX * gridX * 2 + (horizontal and 0 or spread * gridX)
          local targetY = partyY + sideY * gridY * 2 + (horizontal and spread * gridY or 0)
          local moved = pcall(token.setPosition, targetX, targetY)
          if moved then relocatedCount = relocatedCount + 1 end
        end
      end
    end
  end
  if relocatedCount ~= #addedNodes then
    rollbackAddedNodes()
    suppressCombatStateChanged = false
    return nil, "STORY_ENCOUNTER_PLACEMENT_FAILED", "Fantasy Grounds could not stage every hostile token on the party map; new entries were rolled back."
  end
  for _, nodeCombatant in ipairs(addedNodes) do DB.setValue(nodeCombatant, "tokenvis", "number", 1) end

  local allNodes = DB.getChildren("combattracker.list") or {}
  CombatManager.rollInit()
  local initiativeOrder = {}
  for _, nodeCombatant in pairs(allNodes) do
    table.insert(initiativeOrder, { combatantId = DB.getName(nodeCombatant), name = DB.getValue(nodeCombatant, "name", ""), initiative = DB.getValue(nodeCombatant, "initresult", 0), playerVisible = ActorManager.isVisible(nodeCombatant) })
  end
  table.sort(initiativeOrder, function(left, right) if left.initiative == right.initiative then return left.combatantId < right.combatantId end return left.initiative > right.initiative end)
  CombatManager.nextRound(1)
  local active = CombatManager.getActiveCT()
  if not active and DB.getValue("combattracker.round", 0) >= 1 then
    CombatManager.nextActor(nil, true)
    active = CombatManager.getActiveCT()
  end
  if not active or DB.getValue("combattracker.round", 0) < 1 then
    rollbackAddedNodes()
    for _, nodeCombatant in pairs(DB.getChildren("combattracker.list") or {}) do
      DB.setValue(nodeCombatant, "initresult", "number", priorInitiatives[DB.getName(nodeCombatant)] or 0)
      DB.setValue(nodeCombatant, "active", "number", 0)
    end
    DB.setValue("combattracker.round", "number", args.expectedRound)
    suppressCombatStateChanged = false
    return nil, "STORY_ENCOUNTER_START_FAILED", "Fantasy Grounds added and staged the encounter but could not activate its first turn."
  end
  suppressCombatStateChanged = false
  for _, record in ipairs(records) do recordEncounterHistory(record.id, record.name) end
  Comm.deliverChatMessage({ sender = "Nerve", text = args.publicNarration, font = "chatfont", mode = "story" })
  onCombatStateChanged()
  local encounterResults, combatantResults = {}, {}
  for _, record in ipairs(records) do table.insert(encounterResults, { recordId = record.id, name = record.name }) end
  for _, node in ipairs(addedNodes) do table.insert(combatantResults, { id = DB.getName(node), name = DB.getValue(node, "name", "") }) end
  return { started = true, sourceStoryRecordId = args.sourceStoryRecordId, currentAreaKey = args.currentAreaKey, encounters = encounterResults, addedCombatants = combatantResults, relocatedCount = relocatedCount, round = DB.getValue("combattracker.round", 0), activeCombatantId = active and DB.getName(active) or nil, initiativeOrder = initiativeOrder, executedAt = os.date("!%Y-%m-%dT%H:%M:%SZ") }
end

storyNodeContainsText = function(node, needle, depth)
  if not node or depth > 10 then return false end
  local value = DB.getValue(node)
  if type(value) == "string" and string.find(string.lower(value), needle, 1, true) then return true end
  for _, child in pairs(DB.getChildren(node) or {}) do
    if storyNodeContainsText(child, needle, depth + 1) then return true end
  end
  return false
end

function executeBeginStoryNpcEncounter(command)
  local args = command.arguments or {}
  if type(args.sourceStoryRecordId) ~= "string" or args.sourceStoryRecordId == "" or
      type(args.npcs) ~= "table" or #args.npcs < 1 or #args.npcs > 4 or
      type(args.expectedCombatantIds) ~= "table" or #args.expectedCombatantIds > 100 or
      type(args.expectedRound) ~= "number" or args.expectedRound < 0 or args.expectedRound % 1 ~= 0 or
      type(args.publicNarration) ~= "string" or args.publicNarration == "" or #args.publicNarration > 1000 then
    return nil, "INVALID_ARGUMENT", "Story NPC encounter arguments are invalid or outside bounded limits."
  end
  local nodeStory = DB.findNode(args.sourceStoryRecordId)
  if not nodeStory or RecordDataManager.getRecordTypeFromRecordPath(DB.getPath(nodeStory)) ~= "story" then
    return nil, "STORY_TRIGGER_NOT_FOUND", "The exact story source is unavailable."
  end
  if CombatManager.getActiveCT() or DB.getValue("combattracker.round", 0) ~= args.expectedRound then
    return nil, "STATE_CONFLICT", "Combat became active or the combat round changed before the story NPC encounter began."
  end
  local expected, priorIds, priorInitiatives = {}, {}, {}
  for _, id in ipairs(args.expectedCombatantIds) do
    if type(id) ~= "string" or not string.match(id, "^id%-%d+$") or expected[id] then
      return nil, "INVALID_ARGUMENT", "Expected Combat Tracker IDs must be unique stable IDs."
    end
    expected[id] = true
  end
  local existingCount = 0
  for _, nodeCombatant in pairs(DB.getChildren("combattracker.list") or {}) do
    local id = DB.getName(nodeCombatant)
    if not expected[id] then return nil, "STATE_CONFLICT", "The Combat Tracker roster changed before story NPC insertion." end
    priorIds[id] = true
    priorInitiatives[id] = DB.getValue(nodeCombatant, "initresult", 0)
    existingCount = existingCount + 1
  end
  if existingCount ~= #args.expectedCombatantIds then return nil, "STATE_CONFLICT", "The Combat Tracker roster changed before story NPC insertion." end

  local sourceModule = DB.getModule(nodeStory) or ""
  local descriptors, total, seen = {}, 0, {}
  for _, descriptor in ipairs(args.npcs) do
    if type(descriptor) ~= "table" or type(descriptor.recordId) ~= "string" or descriptor.recordId == "" or
        type(descriptor.expectedName) ~= "string" or descriptor.expectedName == "" or
        type(descriptor.quantity) ~= "number" or descriptor.quantity < 1 or descriptor.quantity > 10 or descriptor.quantity % 1 ~= 0 or seen[descriptor.recordId] then
      return nil, "INVALID_ARGUMENT", "Story NPC descriptors must be unique exact records with bounded quantities."
    end
    local nodeNpc = DB.findNode(descriptor.recordId)
    local npcModule = nodeNpc and (DB.getModule(nodeNpc) or "") or ""
    if not nodeNpc or RecordDataManager.getRecordTypeFromRecordPath(DB.getPath(nodeNpc)) ~= "npc" or
        DB.getValue(nodeNpc, "name", "") ~= descriptor.expectedName or npcModule ~= sourceModule or
        not storyNodeContainsText(nodeStory, string.lower(descriptor.expectedName), 0) then
      return nil, "STORY_NPC_TRIGGER_NOT_FOUND", "The story does not explicitly name the exact same-module NPC or trap record."
    end
    total = total + descriptor.quantity
    seen[descriptor.recordId] = true
    table.insert(descriptors, { node = nodeNpc, id = descriptor.recordId, name = descriptor.expectedName, quantity = descriptor.quantity })
  end
  if total > 30 then return nil, "RESOURCE_LIMIT", "A story NPC encounter may add at most 30 combatants." end

  local function collectAdded()
    local result = {}
    for _, nodeCombatant in pairs(DB.getChildren("combattracker.list") or {}) do
      if not priorIds[DB.getName(nodeCombatant)] then table.insert(result, nodeCombatant) end
    end
    table.sort(result, function(a, b) return DB.getName(a) < DB.getName(b) end)
    return result
  end
  local function rollback()
    for _, nodeCombatant in ipairs(collectAdded()) do pcall(CombatManager.deleteCombatant, nodeCombatant) end
    for _, nodeCombatant in pairs(DB.getChildren("combattracker.list") or {}) do
      DB.setValue(nodeCombatant, "initresult", "number", priorInitiatives[DB.getName(nodeCombatant)] or 0)
      DB.setValue(nodeCombatant, "active", "number", 0)
    end
    DB.setValue("combattracker.round", "number", args.expectedRound)
  end

  suppressCombatStateChanged = true
  for _, descriptor in ipairs(descriptors) do
    for _ = 1, descriptor.quantity do
      local custom = { sRecordType = "npc", sRecord = DB.getPath(descriptor.node), nodeRecord = descriptor.node, sFaction = "foe", nIdentified = 1 }
      local ok, added = pcall(CombatRecordManager.onRecordTypeEvent, "npc", custom)
      if not ok or added ~= true or not custom.nodeCT then
        rollback(); suppressCombatStateChanged = false
        return nil, "STORY_NPC_ENCOUNTER_ADD_FAILED", "Fantasy Grounds could not add every exact story NPC; new entries were rolled back."
      end
      DB.setValue(custom.nodeCT, "friendfoe", "string", "foe")
      DB.setValue(custom.nodeCT, "tokenvis", "number", 1)
    end
  end
  local addedNodes = collectAdded()
  if #addedNodes ~= total then
    rollback(); suppressCombatStateChanged = false
    return nil, "STORY_NPC_ENCOUNTER_ADD_FAILED", "Fantasy Grounds added an incomplete story NPC encounter; new entries were rolled back."
  end

  CombatManager.rollInit()
  local initiativeOrder = {}
  for _, nodeCombatant in pairs(DB.getChildren("combattracker.list") or {}) do
    table.insert(initiativeOrder, { combatantId = DB.getName(nodeCombatant), name = DB.getValue(nodeCombatant, "name", ""), initiative = DB.getValue(nodeCombatant, "initresult", 0), playerVisible = ActorManager.isVisible(nodeCombatant) })
  end
  table.sort(initiativeOrder, function(left, right) if left.initiative == right.initiative then return left.combatantId < right.combatantId end return left.initiative > right.initiative end)
  CombatManager.nextRound(1)
  local active = CombatManager.getActiveCT()
  if not active then CombatManager.nextActor(nil, true); active = CombatManager.getActiveCT() end
  if not active then
    rollback(); suppressCombatStateChanged = false
    return nil, "STORY_NPC_ENCOUNTER_START_FAILED", "Fantasy Grounds added the story NPC encounter but could not activate its first turn."
  end
  suppressCombatStateChanged = false
  Comm.deliverChatMessage({ sender = "Nerve", text = args.publicNarration, font = "chatfont", mode = "story" })
  onCombatStateChanged()
  local npcResults, combatantResults = {}, {}
  for _, descriptor in ipairs(descriptors) do table.insert(npcResults, { recordId = descriptor.id, name = descriptor.name, quantity = descriptor.quantity }) end
  for _, node in ipairs(addedNodes) do table.insert(combatantResults, { id = DB.getName(node), name = DB.getValue(node, "name", "") }) end
  return { started = true, sourceStoryRecordId = args.sourceStoryRecordId, npcs = npcResults, addedCombatants = combatantResults, round = DB.getValue("combattracker.round", 0), activeCombatantId = DB.getName(active), initiativeOrder = initiativeOrder, executedAt = os.date("!%Y-%m-%dT%H:%M:%SZ") }
end

normalizeQuestKey = function(value)
  return string.lower(string.gsub(tostring(value or ""), "^%s*(.-)%s*$", "%1"))
end

function executeCreateQuest(command)
  local args = command.arguments or {}
  local validStatus = args.status == "accepted" or args.status == "active"
  local validProvenance = args.provenance == "module" or args.provenance == "gm" or args.provenance == "ai_improvised"
  if type(args.name) ~= "string" or args.name == "" or #args.name > 200 or
      type(args.description) ~= "string" or args.description == "" or #args.description > 2000 or
      not validStatus or type(args.giver) ~= "string" or #args.giver > 200 or
      type(args.location) ~= "string" or #args.location > 200 or type(args.reward) ~= "string" or #args.reward > 300 or
      not validProvenance or type(args.sourceRecordId) ~= "string" or #args.sourceRecordId > 512 then
    return nil, "INVALID_ARGUMENT", "Quest fields are invalid or outside bounded limits."
  end
  if args.provenance == "module" then
    local source = args.sourceRecordId ~= "" and DB.findNode(args.sourceRecordId) or nil
    local selectedModule = DB.getValue("nerve.campaignfocus.module", "")
    if not source or (selectedModule ~= "" and (DB.getModule(source) or "") ~= selectedModule) then
      return nil, "QUEST_SOURCE_NOT_FOUND", "A module quest requires an exact record from the selected adventure source."
    end
  end
  local nameKey, giverKey, locationKey = normalizeQuestKey(args.name), normalizeQuestKey(args.giver), normalizeQuestKey(args.location)
  for _, node in pairs(DB.getChildren("quest") or {}) do
    local status = DB.getValue(node, "nerve.status", "active")
    if (status == "accepted" or status == "active") and normalizeQuestKey(DB.getValue(node, "name", "")) == nameKey and
        normalizeQuestKey(DB.getValue(node, "nerve.giver", "")) == giverKey and
        normalizeQuestKey(DB.getValue(node, "nerve.location", "")) == locationKey then
      return nil, "QUEST_DUPLICATE", "An active Quest with the same name, giver, and location already exists."
    end
  end
  local root = DB.createNode("quest")
  local node = root and DB.createChild(root) or nil
  if not node then return nil, "QUEST_CREATE_FAILED", "Fantasy Grounds could not create the native Quest record." end
  local now = os.date("!%Y-%m-%dT%H:%M:%SZ")
  DB.setValue(node, "name", "string", args.name)
  DB.setValue(node, "description", "formattedtext", args.description)
  DB.setValue(node, "locked", "number", 1)
  DB.setValue(node, "nerve.status", "string", args.status)
  DB.setValue(node, "nerve.giver", "string", args.giver)
  DB.setValue(node, "nerve.location", "string", args.location)
  DB.setValue(node, "nerve.reward", "string", args.reward)
  DB.setValue(node, "nerve.provenance", "string", args.provenance)
  DB.setValue(node, "nerve.sourcerecordid", "string", args.sourceRecordId)
  DB.setValue(node, "nerve.updatedat", "string", now)
  publishSnapshot("quest-created", nil, true)
  return { questId = DB.getName(node), name = args.name, previousStatus = nil, status = args.status, created = true, executedAt = now }
end

function executeUpdateQuest(command)
  local args = command.arguments or {}
  local validExpected = { offered = true, accepted = true, active = true, completed = true, failed = true, abandoned = true }
  local validStatus = { accepted = true, active = true, completed = true, failed = true, abandoned = true }
  if type(args.questId) ~= "string" or not string.match(args.questId, "^id%-%d+$") or
      not validExpected[args.expectedStatus] or not validStatus[args.status] or
      type(args.summary) ~= "string" or args.summary == "" or #args.summary > 1000 then
    return nil, "INVALID_ARGUMENT", "Quest update fields are invalid or outside bounded limits."
  end
  local node = DB.findNode("quest." .. args.questId)
  if not node then return nil, "QUEST_NOT_FOUND", "The exact campaign Quest record no longer exists." end
  local previousStatus = DB.getValue(node, "nerve.status", "active")
  if previousStatus ~= args.expectedStatus then
    return nil, "STATE_CONFLICT", "The Quest status changed before this update. Read the Quest log again."
  end
  local now = os.date("!%Y-%m-%dT%H:%M:%SZ")
  DB.setValue(node, "nerve.status", "string", args.status)
  DB.setValue(node, "nerve.progress", "string", args.summary)
  DB.setValue(node, "nerve.updatedat", "string", now)
  publishSnapshot("quest-updated", nil, true)
  return { questId = args.questId, name = DB.getValue(node, "name", "Untitled Quest"), previousStatus = previousStatus, status = args.status, created = false, executedAt = now }
end

local function executeApplyEffect(command)
  local args = command.arguments or {}
  if type(args.combatantId) ~= "string" or not string.match(args.combatantId, "^id%-%d+$") then
    return nil, "INVALID_ARGUMENT", "Combatant ID is invalid."
  end
  if type(args.label) ~= "string" or args.label == "" or #args.label > 200 then
    return nil, "INVALID_ARGUMENT", "Effect label must contain 1 to 200 characters."
  end
  if type(args.duration) ~= "number" or args.duration < 0 or args.duration > 100 or args.duration % 1 ~= 0 then
    return nil, "INVALID_ARGUMENT", "Effect duration must be an integer from 0 to 100."
  end
  if type(args.gmOnly) ~= "boolean" then return nil, "INVALID_ARGUMENT", "gmOnly must be boolean." end

  local nodeCombatant = findCombatantById(args.combatantId)
  if not nodeCombatant then return nil, "COMBATANT_NOT_FOUND", "The target combatant no longer exists." end
  suppressCombatStateChanged = true
  local nodeEffect = EffectManager.addEffectByTable(nodeCombatant, {
    sName = args.label,
    nDuration = args.duration,
    nGMOnly = args.gmOnly and 1 or 0,
    nInit = DB.getValue(nodeCombatant, "initresult", 0)
  })
  suppressCombatStateChanged = false
  if not nodeEffect then return nil, "EFFECT_NOT_APPLIED", "Fantasy Grounds did not apply the effect." end
  onCombatStateChanged()

  return {
    combatantId = args.combatantId,
    effectId = DB.getName(nodeEffect),
    label = args.label,
    duration = args.duration,
    gmOnly = args.gmOnly,
    executedAt = os.date("!%Y-%m-%dT%H:%M:%SZ")
  }
end

local function executeRemoveEffect(command)
  local args = command.arguments or {}
  if type(args.combatantId) ~= "string" or not string.match(args.combatantId, "^id%-%d+$") or
      type(args.effectId) ~= "string" or not string.match(args.effectId, "^id%-%d+$") then
    return nil, "INVALID_ARGUMENT", "Combatant and effect IDs are invalid."
  end
  if type(args.expectedLabel) ~= "string" or args.expectedLabel == "" or #args.expectedLabel > 200 then
    return nil, "INVALID_ARGUMENT", "Expected effect label must contain 1 to 200 characters."
  end
  local nodeCombatant = findCombatantById(args.combatantId)
  if not nodeCombatant then return nil, "COMBATANT_NOT_FOUND", "The target combatant no longer exists." end
  local nodeEffect = DB.findNode(DB.getPath(nodeCombatant) .. ".effects." .. args.effectId)
  if not nodeEffect then return nil, "EFFECT_NOT_FOUND", "The selected effect no longer exists on that combatant." end
  local label = DB.getValue(nodeEffect, "label", "")
  if label ~= args.expectedLabel then
    return nil, "STATE_CONFLICT", "The effect label changed before the command was executed."
  end

  suppressCombatStateChanged = true
  local removalSucceeded, removalError = pcall(EffectManager.removeEffect, nodeCombatant, nodeEffect)
  suppressCombatStateChanged = false
  if not removalSucceeded then
    Debug.console("Nerve Adapter: exact effect removal failed: " .. tostring(removalError))
    return nil, "EFFECT_NOT_REMOVED", "Fantasy Grounds could not remove the selected effect."
  end
  if DB.findNode(DB.getPath(nodeCombatant) .. ".effects." .. args.effectId) then
    return nil, "EFFECT_NOT_REMOVED", "Fantasy Grounds did not remove the selected effect."
  end
  onCombatStateChanged()
  return {
    removed = true,
    combatantId = args.combatantId,
    effectId = args.effectId,
    label = label,
    executedAt = os.date("!%Y-%m-%dT%H:%M:%SZ")
  }
end

local function executeRemoveCombatant(command)
  local args = command.arguments or {}
  if type(args.combatantId) ~= "string" or not string.match(args.combatantId, "^id%-%d+$") then
    return nil, "INVALID_ARGUMENT", "Combatant ID is invalid."
  end
  if type(args.expectedName) ~= "string" or args.expectedName == "" or #args.expectedName > 200 then
    return nil, "INVALID_ARGUMENT", "Expected combatant name must contain 1 to 200 characters."
  end
  local allowedFactions = { friend = true, foe = true, neutral = true, unknown = true }
  if not allowedFactions[args.expectedFaction] then
    return nil, "INVALID_ARGUMENT", "Expected combatant faction is invalid."
  end
  local nodeCombatant = findCombatantById(args.combatantId)
  if not nodeCombatant then return nil, "COMBATANT_NOT_FOUND", "The exact Combat Tracker entry no longer exists." end
  local name = DB.getValue(nodeCombatant, "name", "")
  local faction = normalizeFaction(DB.getValue(nodeCombatant, "friendfoe", ""))
  if name ~= args.expectedName or faction ~= args.expectedFaction then
    return nil, "STATE_CONFLICT", "The combatant name or faction changed before removal. Read the Combat Tracker again."
  end
  local path = DB.getPath(nodeCombatant)
  suppressCombatStateChanged = true
  local removalSucceeded, removalError = pcall(CombatManager.deleteCombatant, nodeCombatant)
  suppressCombatStateChanged = false
  if not removalSucceeded then
    Debug.console("Nerve Adapter: exact combatant removal failed: " .. tostring(removalError))
    return nil, "COMBATANT_NOT_REMOVED", "Fantasy Grounds could not remove the exact Combat Tracker entry."
  end
  if DB.findNode(path) then
    return nil, "COMBATANT_NOT_REMOVED", "Fantasy Grounds did not remove the exact Combat Tracker entry."
  end
  priorThreatFactions[args.combatantId] = nil
  onCombatStateChanged()
  return {
    removed = true, combatantId = args.combatantId, name = name, faction = faction,
    executedAt = os.date("!%Y-%m-%dT%H:%M:%SZ")
  }
end

local function resolveManualAdjudicationRecord(adjudicationId, resolution, note)
  if type(adjudicationId) ~= "string" or not string.match(adjudicationId, "^id%-%d+$") or
      (resolution ~= "applied" and resolution ~= "waived") or type(note) ~= "string" or #note > 500 then
    return nil, "INVALID_ARGUMENT", "Manual adjudication resolution arguments are invalid."
  end
  local nodeTask = DB.findNode("nerve.manualadjudications." .. adjudicationId)
  if not nodeTask then return nil, "ADJUDICATION_NOT_FOUND", "The manual adjudication task no longer exists." end
  if DB.getValue(nodeTask, "status", "pending") ~= "pending" then
    return nil, "STATE_CONFLICT", "The manual adjudication task is already resolved."
  end
  local resolvedAt = os.date("!%Y-%m-%dT%H:%M:%SZ")
  DB.setValue(nodeTask, "status", "string", resolution)
  DB.setValue(nodeTask, "note", "string", note)
  DB.setValue(nodeTask, "resolvedat", "string", resolvedAt)
  publishSnapshot("manual-adjudication-resolved", nil, true)
  return {
    adjudicationId = adjudicationId, resolution = resolution,
    actionName = DB.getValue(nodeTask, "actionname", ""), targetName = DB.getValue(nodeTask, "targetname", ""),
    note = note, resolvedAt = resolvedAt
  }
end

local function executeResolveManualAdjudication(command)
  local args = command.arguments or {}
  return resolveManualAdjudicationRecord(args.adjudicationId, args.resolution, args.note or "")
end

local function executeSetCombatantThreat(command)
  local args = command.arguments or {}
  if type(args.combatantId) ~= "string" or not string.match(args.combatantId, "^id%-%d+$") then
    return nil, "INVALID_ARGUMENT", "Combatant ID is invalid."
  end
  if type(args.active) ~= "boolean" then return nil, "INVALID_ARGUMENT", "active must be boolean." end
  local nodeCombatant = findCombatantById(args.combatantId)
  if not nodeCombatant then return nil, "COMBATANT_NOT_FOUND", "The target combatant no longer exists." end

  local previousRaw = DB.getValue(nodeCombatant, "friendfoe", "")
  local previousFaction = normalizeFaction(previousRaw)
  local nextFaction
  if args.active then
    nextFaction = priorThreatFactions[args.combatantId]
    if nextFaction ~= "foe" then nextFaction = "foe" end
    priorThreatFactions[args.combatantId] = nil
  else
    if previousRaw == "foe" then priorThreatFactions[args.combatantId] = previousRaw end
    nextFaction = "neutral"
  end
  DB.setValue(nodeCombatant, "friendfoe", "string", nextFaction)
  -- Containment ends initiative only after the final live hostile is resolved.
  -- Keep the roster, round, wounds and effects intact for the GM.
  if not args.active and not getCombatState() then
    for _, node in pairs(DB.getChildren("combattracker.list") or {}) do
      DB.setValue(node, "active", "number", 0)
    end
  end
  onCombatStateChanged()
  return {
    combatantId = args.combatantId,
    active = args.active,
    previousFaction = previousFaction,
    faction = normalizeFaction(nextFaction),
    executedAt = os.date("!%Y-%m-%dT%H:%M:%SZ")
  }
end

local function executeSetCombatantVisibility(command)
  local args = command.arguments or {}
  if type(args.combatantId) ~= "string" or not string.match(args.combatantId, "^id%-%d+$") then
    return nil, "INVALID_ARGUMENT", "Combatant ID is invalid."
  end
  if type(args.expectedVisible) ~= "boolean" or type(args.visible) ~= "boolean" then
    return nil, "INVALID_ARGUMENT", "expectedVisible and visible must be boolean."
  end
  local validDiscoveryBases = { native_vision = true, detection = true, gm_override = true }
  if not validDiscoveryBases[args.discoveryBasis] then
    return nil, "INVALID_ARGUMENT", "A valid discovery basis is required for visibility changes."
  end
  local nodeCombatant = findCombatantById(args.combatantId)
  if not nodeCombatant then return nil, "COMBATANT_NOT_FOUND", "The target combatant no longer exists." end
  local previousVisible = ActorManager.isVisible(nodeCombatant)
  if previousVisible ~= args.expectedVisible then
    return nil, "STATE_CONFLICT", "Combatant visibility changed before the command was executed. Read the Combat Tracker again."
  end
  if DB.getValue(nodeCombatant, "friendfoe", "") == "friend" and args.visible == false then
    return nil, "VISIBILITY_UNSUPPORTED", "Friendly combatants are always visible to players in the native Combat Tracker."
  end
  DB.setValue(nodeCombatant, "tokenvis", "number", args.visible and 1 or 0)
  local visible = ActorManager.isVisible(nodeCombatant)
  if visible ~= args.visible then
    return nil, "VISIBILITY_NOT_CHANGED", "Fantasy Grounds did not apply the requested player visibility."
  end
  onCombatStateChanged()
  return {
    combatantId = args.combatantId,
    combatantName = DB.getValue(nodeCombatant, "name", ""),
    previousVisible = previousVisible,
    visible = visible,
    discoveryBasis = args.discoveryBasis,
    executedAt = os.date("!%Y-%m-%dT%H:%M:%SZ")
  }
end

recordDecision = function(command, outcome)
  table.insert(decisionHistory, 1, string.format(
    "%s  %s  %s",
    os.date("%H:%M:%S"),
    command and command.capability or "unknown",
    outcome
  ))
  while #decisionHistory > MAX_DECISION_HISTORY do table.remove(decisionHistory) end
  incrementSessionMetric("actionsprocessed")
  if string.find(outcome, "denied", 1, true) then
    incrementSessionMetric("denied")
  elseif string.find(outcome, "failed", 1, true) or string.find(outcome, "rejected", 1, true) or outcome == "expired" then
    incrementSessionMetric("failed")
  else
    incrementSessionMetric("approved")
  end
  if string.find(outcome, "session grant", 1, true) then incrementSessionMetric("sessiongrantexecutions") end
  publishSnapshot("session-telemetry-changed", nil, true)
end

local function executeCommand(command)
  local data, errorCode, errorMessage
  if command.capability == "send_chat" then
    data, errorCode, errorMessage = executeSendChat(command)
  elseif command.capability == "request_vote" then
    data, errorCode, errorMessage = executeRequestVote(command)
  elseif command.capability == "request_player_input" then
    data, errorCode, errorMessage = executeRequestPlayerInput(command)
  elseif command.capability == "request_player_roll" then
    data, errorCode, errorMessage = executeRequestPlayerRoll(command)
  elseif command.capability == "proxy_character_roll" then
    data, errorCode, errorMessage = executeProxyCharacterRoll(command)
  elseif command.capability == "proxy_character_power_action" then
    data, errorCode, errorMessage = executeProxyCharacterPowerAction(command)
  elseif command.capability == "proxy_combatant_action" then
    data, errorCode, errorMessage = executeProxyCombatantAction(command)
  elseif command.capability == "add_library_npc" then
    data, errorCode, errorMessage = executeAddLibraryNpc(command)
  elseif command.capability == "add_library_encounter" then
    data, errorCode, errorMessage = executeAddLibraryEncounter(command)
  elseif command.capability == "begin_story_encounter" then
    data, errorCode, errorMessage = executeBeginStoryEncounter(command)
  elseif command.capability == "begin_story_npc_encounter" then
    data, errorCode, errorMessage = executeBeginStoryNpcEncounter(command)
  elseif command.capability == "create_quest" then
    data, errorCode, errorMessage = executeCreateQuest(command)
  elseif command.capability == "update_quest" then
    data, errorCode, errorMessage = executeUpdateQuest(command)
  elseif command.capability == "open_library_image" then
    data, errorCode, errorMessage = executeOpenLibraryImage(command)
  elseif command.capability == "set_spell_slot_usage" then
    data, errorCode, errorMessage = executeSetSpellSlotUsage(command)
  elseif command.capability == "advance_turn" then
    data, errorCode, errorMessage = executeAdvanceTurn(command)
  elseif command.capability == "start_encounter" then
    data, errorCode, errorMessage = executeStartEncounter(command)
  elseif command.capability == "apply_effect" then
    data, errorCode, errorMessage = executeApplyEffect(command)
  elseif command.capability == "remove_effect" then
    data, errorCode, errorMessage = executeRemoveEffect(command)
  elseif command.capability == "remove_combatant" then
    data, errorCode, errorMessage = executeRemoveCombatant(command)
  elseif command.capability == "resolve_manual_adjudication" then
    data, errorCode, errorMessage = executeResolveManualAdjudication(command)
  elseif command.capability == "set_combatant_threat" then
    data, errorCode, errorMessage = executeSetCombatantThreat(command)
  elseif command.capability == "set_combatant_visibility" then
    data, errorCode, errorMessage = executeSetCombatantVisibility(command)
  elseif command.capability == "record_session_continuity" then
    if not isNerveSessionActive() then
      errorCode, errorMessage = "SESSION_NOT_ACTIVE", "Start session tracking before recording narrative continuity."
    else
      data, errorCode, errorMessage = persistSessionContinuity(command.arguments or {}, "ai_confirmed")
      if data then
        publishSnapshot("session-continuity-recorded", {
          type = "session.continuity_recorded", actor = "Nerve", text = "Narrative continuity checkpoint recorded.",
          visibility = "gm", subjectId = data.id, data = { sessionId = data.sessionId, source = data.source }
        })
      end
    end
  else
    errorCode, errorMessage = "CAPABILITY_DENIED", "The requested write capability is not allowed."
  end
  return data, errorCode, errorMessage
end

local function executeApprovedCommand(command, approvalLabel)
  lastProcessedRequestId = command.requestId
  local data, errorCode, errorMessage = executeCommand(command)
  if not data then
    commandFailure(command, errorCode or "FGU_COMMAND_FAILED", errorMessage or "Fantasy Grounds rejected the command.")
    recordDecision(command, "failed: " .. (errorCode or "unknown"))
    return false
  end
  if command.capability == "request_vote" and data.prepared then
    awaitingVoteCommand = { command = command }
    recordDecision(command, "native vote prepared; awaiting GM Enter")
    ChatManager.SystemMessage("Nerve prepared a native vote in chat. Press Enter to open it.")
    return true
  end
  writeCommandResult({
    schemaVersion = "0.1",
    requestId = command.requestId,
    capability = command.capability,
    ok = true,
    executedAt = os.date("!%Y-%m-%dT%H:%M:%SZ"),
    data = data
  })
  recordDecision(command, approvalLabel or "approved")
  local responseCapabilities = {
    send_chat = true, request_vote = true, request_player_input = true, request_player_roll = true,
    proxy_character_roll = true, proxy_character_power_action = true, proxy_combatant_action = true,
    begin_story_encounter = true, begin_story_npc_encounter = true, start_encounter = true, advance_turn = true,
    create_quest = true, update_quest = true, apply_effect = true, remove_effect = true,
    set_spell_slot_usage = true, set_combatant_visibility = true, set_combatant_threat = true,
    record_session_continuity = true
  }
  if responseCapabilities[command.capability] then markAiCueAnswered() end
  ChatManager.SystemMessage("Nerve executed: " .. command.capability)
  publishPendingResumedCombatTurnCue()
  requestPendingAutomaticConnectorCue()
  return true
end

local function openApprovalPanel()
  local approvalWindow = Interface.openWindow("nerve_approval", "")
  if approvalWindow and approvalWindow.refresh then approvalWindow.refresh() end
end

local function openActionCard()
  local card = Interface.findWindow("nerve_action_card", "") or Interface.openWindow("nerve_action_card", "")
  if card and card.refresh then card.refresh() end
end

local function closeActionCards()
  for _, card in ipairs(Interface.getWindows("nerve_action_card") or {}) do card.close() end
end

function openControlPanel()
  openApprovalPanel()
end

function hasPendingCommand()
  return pendingCommand ~= nil
end

function getPendingCommandCapability()
  return pendingCommand and pendingCommand.capability or ""
end

function getPendingCommandSummary()
  if not pendingCommand then
    return "No action is loaded. When the active AI says an action is waiting, click Check for Action or the amber NERVE icon beside chat."
  end
  local args = pendingCommand.arguments or {}
  local detail = ""
  if pendingCommand.capability == "send_chat" then
    detail = string.format("Send chat (%s)\n%s", args.visibility or "unknown", args.text or "")
  elseif pendingCommand.capability == "request_vote" then
    detail = "Prepare native yes/no vote (press Enter in chat)\n" .. (args.question or "")
  elseif pendingCommand.capability == "request_player_input" then
    detail = string.format(
      "Open private response window (%s / %s)\n%s\nDeadline: %s seconds",
      args.audience or "unknown",
      args.responseType or "unknown",
      args.prompt or "",
      tostring(args.timeoutSeconds or "unknown")
    )
  elseif pendingCommand.capability == "request_player_roll" then
    local rollLabel = args.rollType or "unknown"
    if args.ability then rollLabel = rollLabel .. ": " .. args.ability end
    if args.skill then rollLabel = rollLabel .. ": " .. args.skill end
    if args.dc then rollLabel = rollLabel .. " vs. DC " .. tostring(args.dc) end
    detail = string.format(
      "Request private native roll (%s)\n%s\n%s | %s | deadline %s seconds",
      args.audience or "unknown",
      args.prompt or "",
      rollLabel,
      (args.rollMode or "normal") .. " / " .. (args.visibility or "public"),
      tostring(args.timeoutSeconds or "unknown")
    )
  elseif pendingCommand.capability == "proxy_character_roll" then
    local rollLabel = args.rollType or "unknown"
    if args.ability then rollLabel = rollLabel .. ": " .. args.ability end
    if args.skill then rollLabel = rollLabel .. ": " .. args.skill end
    if args.dc then rollLabel = rollLabel .. " vs. DC " .. tostring(args.dc) end
    detail = string.format(
      "Roll for character %s through Entity Proxy\n%s | %s / %s",
      args.characterId or "unknown",
      rollLabel,
      args.rollMode or "normal",
      args.visibility or "public"
    )
  elseif pendingCommand.capability == "proxy_character_power_action" then
    local targets = type(args.targetCombatantIds) == "table" and #args.targetCombatantIds or 0
    local nodeCharacter = type(args.characterId) == "string" and DB.findNode("charsheet." .. args.characterId) or nil
    local nodePower = nodeCharacter and type(args.powerId) == "string" and
      DB.findNode(DB.getPath(nodeCharacter) .. ".powers." .. args.powerId) or nil
    local nodeAction = nodePower and type(args.actionId) == "string" and
      DB.findNode(DB.getPath(nodePower) .. ".actions." .. args.actionId) or nil
    local characterName = nodeCharacter and DB.getValue(nodeCharacter, "name", "") or args.characterId or "unknown"
    local powerName = nodePower and DB.getValue(nodePower, "name", "") or args.powerId or "unknown"
    local actionName = nodeAction and DB.getValue(nodeAction, "type", "") or args.actionId or "unknown"
    local targetNames = {}
    for _, targetId in ipairs(args.targetCombatantIds or {}) do
      local nodeTarget = findCombatantById(targetId)
      table.insert(targetNames, nodeTarget and DB.getValue(nodeTarget, "name", "") or targetId)
    end
    local slotText = "no slot change"
    if type(args.spellSlot) == "table" then
      slotText = string.format("consume level %s slot if used is still %s", tostring(args.spellSlot.level), tostring(args.spellSlot.expectedUsed))
    end
    local followUpText = "initial or standalone action"
    if type(args.followUpContexts) == "table" and #args.followUpContexts > 0 then
      local correlationId = args.followUpContexts[1].correlationId or "unknown"
      followUpText = "resolved follow-up to " .. string.sub(correlationId, 1, 12)
    end
    detail = string.format(
      "Execute %s: %s for %s\nTargets (%s): %s\n%s | %s",
      actionName,
      powerName,
      characterName,
      tostring(targets),
      #targetNames > 0 and table.concat(targetNames, ", ") or "none",
      followUpText,
      slotText
    )
  elseif pendingCommand.capability == "proxy_combatant_action" then
    local nodeCombatant = type(args.combatantId) == "string" and findCombatantById(args.combatantId) or nil
    local nodeAction = nodeCombatant and type(args.section) == "string" and type(args.actionId) == "string" and
      DB.findNode(DB.getPath(nodeCombatant) .. "." .. args.section .. "." .. args.actionId) or nil
    local targetNames = {}
    for _, targetId in ipairs(args.targetCombatantIds or {}) do
      local nodeTarget = findCombatantById(targetId)
      table.insert(targetNames, nodeTarget and DB.getValue(nodeTarget, "name", "") or targetId)
    end
    local followUpText = "initial or standalone ability"
    if type(args.followUpContexts) == "table" and #args.followUpContexts > 0 then
      followUpText = "resolved follow-up to " .. string.sub(args.followUpContexts[1].correlationId or "unknown", 1, 12)
    end
    detail = string.format(
      "Execute NPC ability %s of %s for %s\nTargets: %s\n%s",
      tostring(args.abilityIndex or "unknown"),
      nodeAction and DB.getValue(nodeAction, "name", "") or args.actionId or "unknown",
      nodeCombatant and DB.getValue(nodeCombatant, "name", "") or args.combatantId or "unknown",
      #targetNames > 0 and table.concat(targetNames, ", ") or "none",
      followUpText
    )
  elseif pendingCommand.capability == "add_library_npc" then
    local nodeRecord = type(args.recordId) == "string" and DB.findNode(args.recordId) or nil
    detail = string.format(
      "Add %s loaded-library NPC(s) to the Combat Tracker\n%s\nFaction: %s | identified: %s%s",
      tostring(args.quantity or "unknown"),
      nodeRecord and DB.getValue(nodeRecord, "name", "") or args.expectedName or args.recordId or "unknown",
      args.faction or "unknown",
      tostring(args.identified == true),
      args.name and (" | name: " .. args.name) or ""
    )
  elseif pendingCommand.capability == "add_library_encounter" then
    local nodeRecord = type(args.recordId) == "string" and DB.findNode(args.recordId) or nil
    local expectedCount = 0
    if nodeRecord then
      local listPath = RecordDataManager.getCustomData("battle", "npclist", "npclist")
      for _, nodeEntry in ipairs(DB.getChildList(nodeRecord, listPath) or {}) do
        local entry = CombatRecordManager.getBattleEntryData(nodeEntry)
        expectedCount = expectedCount + (entry and tonumber(entry.nCount or 0) or 0)
      end
    end
    local history = type(args.recordId) == "string" and findEncounterHistory(args.recordId) or nil
    local repeatText = history and string.format(
      "\nWARNING: previously added %d time(s)%s.",
      DB.getValue(history, "timesadded", 1), args.allowRepeat == true and "; explicit repeat requested" or ""
    ) or ""
    detail = string.format(
      "Add prepared encounter to the Combat Tracker\n%s\nCombatants: %s. Native token placements may be restored.%s",
      nodeRecord and DB.getValue(nodeRecord, "name", "") or args.expectedName or args.recordId or "unknown",
      expectedCount > 0 and tostring(expectedCount) or "unknown",
      repeatText
    )
  elseif pendingCommand.capability == "begin_story_encounter" then
    local names = {}
    for _, encounter in ipairs(args.preparedEncounters or {}) do table.insert(names, encounter.expectedName or encounter.recordId or "unknown") end
    detail = string.format(
      "Begin story-triggered encounter\nSource: %s | current area: %s\nPrepared encounters: %s\nStage new foes toward the party, reveal established contact, roll initiative, and activate the first turn.",
      args.sourceStoryRecordId or "unknown", args.currentAreaKey or "unknown", table.concat(names, ", ")
    )
  elseif pendingCommand.capability == "begin_story_npc_encounter" then
    local names = {}
    for _, npc in ipairs(args.npcs or {}) do table.insert(names, string.format("%dx %s", npc.quantity or 0, npc.expectedName or "NPC")) end
    detail = string.format(
      "Begin exact story NPC/trap encounter\nSource: %s\nExact NPCs: %s\nExisting roster: %d | expected round %s\nRoll initiative and activate the first turn without requiring a map.",
      args.sourceStoryRecordId or "unknown", table.concat(names, ", "), #(args.expectedCombatantIds or {}), tostring(args.expectedRound or "unknown")
    )
  elseif pendingCommand.capability == "open_library_image" then
    local nodeRecord = type(args.recordId) == "string" and DB.findNode(args.recordId) or nil
    detail = string.format(
      "Open loaded-library image\n%s\nVisibility: %s%s",
      nodeRecord and DB.getValue(nodeRecord, "name", "") or args.expectedName or args.recordId or "unknown",
      args.visibility == "all" and "share with all connected players" or "GM host only",
      args.visibility == "gm" and " (existing sharing will never be revoked automatically)" or ""
    )
  elseif pendingCommand.capability == "set_spell_slot_usage" then
    detail = string.format(
      "Set spell-slot usage for character %s\nLevel %s: expected used %s -> new used %s",
      args.characterId or "unknown",
      tostring(args.level or "unknown"),
      tostring(args.expectedUsed or "unknown"),
      tostring(args.used or "unknown")
    )
  elseif pendingCommand.capability == "advance_turn" then
    detail = "Advance combat turn\nExpected active combatant: " .. (args.expectedActiveCombatantId or "unknown") ..
      (args.skipDefeated and "\nSkip defeated/unconscious combatants: yes" or "")
  elseif pendingCommand.capability == "start_encounter" then
    detail = string.format(
      "Start encounter with native 5E initiative\nExpected round: %s | exact roster: %s combatants\nHidden combatants remain hidden; first actor will become active.",
      tostring(args.expectedRound or "unknown"), tostring(type(args.expectedCombatantIds) == "table" and #args.expectedCombatantIds or "unknown")
    )
  elseif pendingCommand.capability == "apply_effect" then
    detail = string.format(
      "Apply effect to %s\n%s | duration %s | GM-only %s",
      args.combatantId or "unknown",
      args.label or "",
      tostring(args.duration or "unknown"),
      tostring(args.gmOnly == true)
    )
  elseif pendingCommand.capability == "remove_effect" then
    detail = string.format(
      "Remove exact effect from %s\nEffect %s | expected label: %s",
      args.combatantId or "unknown",
      args.effectId or "unknown",
      args.expectedLabel or ""
    )
  elseif pendingCommand.capability == "remove_combatant" then
    detail = string.format(
      "Permanently remove exact Combat Tracker entry\n%s (%s) | expected faction: %s\nDefeat alone never triggers removal.",
      args.expectedName or "unknown", args.combatantId or "unknown", args.expectedFaction or "unknown"
    )
  elseif pendingCommand.capability == "resolve_manual_adjudication" then
    local nodeTask = type(args.adjudicationId) == "string" and DB.findNode("nerve.manualadjudications." .. args.adjudicationId) or nil
    detail = string.format(
      "Mark manual adjudication %s\n%s for %s | resolution: %s\nThis records the decision but applies no rules effect.",
      args.adjudicationId or "unknown", nodeTask and DB.getValue(nodeTask, "actionname", "") or "unknown action",
      nodeTask and DB.getValue(nodeTask, "targetname", "") or "unknown target", args.resolution or "unknown"
    )
  elseif pendingCommand.capability == "set_combatant_threat" then
    detail = string.format(
      "%s combatant threat\nCombatant: %s (record is preserved)",
      args.active and "Restore" or "Deactivate",
      args.combatantId or "unknown"
    )
  elseif pendingCommand.capability == "set_combatant_visibility" then
    detail = string.format(
      "%s combatant for players\nCombatant: %s\nExpected currently visible: %s",
      args.visible and "Reveal" or "Hide",
      args.combatantId or "unknown",
      tostring(args.expectedVisible)
    )
    detail = detail .. "\nDiscovery basis: " .. tostring(args.discoveryBasis or "missing")
  elseif pendingCommand.capability == "create_quest" then
    detail = string.format(
      "Create native World > Quests record\n%s [%s]\nGiver: %s | location: %s | provenance: %s\n%s",
      args.name or "Untitled Quest", args.status or "unknown", args.giver ~= "" and args.giver or "not stated",
      args.location ~= "" and args.location or "not stated", args.provenance or "unknown", args.description or ""
    )
  elseif pendingCommand.capability == "update_quest" then
    detail = string.format(
      "Update native World > Quests record %s\nExpected status %s -> %s\n%s",
      args.questId or "unknown", args.expectedStatus or "unknown", args.status or "unknown", args.summary or ""
    )
  elseif pendingCommand.capability == "record_session_continuity" then
    detail = string.format(
      "Record durable narrative continuity for session %s\n%s\nUnresolved threads: %s | party goals: %s | important NPCs: %s\nJourney: %s location(s) | %s NPC(s) met | %s conversation(s) | %s discovery item(s)\nNext opening: %s",
      args.sessionId or "unknown",
      args.summary or "",
      tostring(type(args.unresolvedThreads) == "table" and #args.unresolvedThreads or 0),
      tostring(type(args.partyGoals) == "table" and #args.partyGoals or 0),
      tostring(type(args.importantNpcs) == "table" and #args.importantNpcs or 0),
      tostring(type(args.locationsVisited) == "table" and #args.locationsVisited or 0),
      tostring(type(args.npcsMet) == "table" and #args.npcsMet or 0),
      tostring(type(args.conversationHighlights) == "table" and #args.conversationHighlights or 0),
      tostring(type(args.discoveries) == "table" and #args.discoveries or 0),
      args.nextSessionOpening ~= "" and args.nextSessionOpening or "not supplied"
    )
  else
    detail = "Unknown capability: " .. tostring(pendingCommand.capability)
  end
  return detail .. "\nInbox item remains available until " .. os.date("%Y-%m-%d %H:%M", pendingCommand.expiresAtEpoch)
end

function getDecisionHistoryText()
  if #decisionHistory == 0 then return "No decisions yet this session." end
  return table.concat(decisionHistory, "\n")
end

function getPlayerPromptStatusText()
  getPendingPlayerResponseCount()
  if #playerPromptOrder == 0 then return "No player prompts yet this session." end
  local lines = {}
  for index = 1, math.min(#playerPromptOrder, 6) do
    local promptId = playerPromptOrder[index]
    local prompt = pendingPlayerPrompts[promptId]
    if prompt then
      local statuses = {}
      for username, status in pairs(prompt.statuses) do
        local displayStatus = status
        if status == "timed_out" then displayStatus = "timed out" end
        table.insert(statuses, username .. ": " .. displayStatus)
      end
      table.sort(statuses)
      table.insert(lines, string.sub(prompt.prompt, 1, 55) .. " - " .. table.concat(statuses, ", "))
    end
  end
  return table.concat(lines, "\n")
end

function getManualAdjudicationStatusText()
  local state = createManualAdjudicationState()
  if #state.tasks == 0 then return "No pending manual adjudications." end
  local lines = {}
  for index = 1, math.min(#state.tasks, 3) do
    local task = state.tasks[index]
    table.insert(lines, string.format("%s  %s — %s", task.id, task.targetName, task.actionName))
  end
  if #state.tasks > 3 then table.insert(lines, string.format("+ %s more", tostring(#state.tasks - 3))) end
  return table.concat(lines, "\n")
end

function hasManualAdjudications()
  return #createManualAdjudicationState().tasks > 0
end

function openNextManualAdjudication()
  local tasks = createManualAdjudicationState().tasks
  if #tasks == 0 then ChatManager.SystemMessage("Nerve: no pending manual adjudications."); return false end
  activeManualAdjudicationId = tasks[1].id
  Interface.openWindow("nerve_adjudication", "")
  return true
end

function getActiveManualAdjudicationText()
  if not activeManualAdjudicationId then return "No manual adjudication is selected." end
  local nodeTask = DB.findNode("nerve.manualadjudications." .. activeManualAdjudicationId)
  if not nodeTask or DB.getValue(nodeTask, "status", "pending") ~= "pending" then return "This task is no longer pending." end
  return string.format(
    "Task: %s\nCreated: %s\nSource: %s\nTarget: %s\nAction: %s\n\n%s",
    activeManualAdjudicationId, DB.getValue(nodeTask, "createdat", ""), DB.getValue(nodeTask, "sourcename", ""),
    DB.getValue(nodeTask, "targetname", ""), DB.getValue(nodeTask, "actionname", ""), DB.getValue(nodeTask, "text", "")
  )
end

function resolveActiveManualAdjudication(resolution)
  if not activeManualAdjudicationId then ChatManager.SystemMessage("Nerve: no manual adjudication is selected."); return false end
  local data, errorCode, errorMessage = resolveManualAdjudicationRecord(activeManualAdjudicationId, resolution, "Resolved directly by GM in Nerve Control.")
  if not data then ChatManager.SystemMessage("Nerve: " .. (errorMessage or errorCode or "resolution failed")); return false end
  ChatManager.SystemMessage(string.format("Nerve: manual adjudication %s marked %s.", activeManualAdjudicationId, resolution))
  activeManualAdjudicationId = nil
  for _, approvalWindow in ipairs(Interface.getWindows("nerve_approval") or {}) do
    if approvalWindow.refresh then approvalWindow.refresh() end
  end
  return true
end

function isChatSessionGrantActive()
  return sessionGrants.send_chat == true
end

function isProxyActionSessionGrantActive()
  return sessionGrants.proxy_actions == true
end

function isCombatPacingSessionGrantActive()
  return sessionGrants.combat_pacing == true
end

function isFlowModeActive()
  return sessionGrants.send_chat == true and sessionGrants.proxy_actions == true and
    sessionGrants.combat_pacing == true
end

local function isProxyActionCapability(capability)
  return capability == "proxy_character_roll" or capability == "proxy_character_power_action" or
    capability == "proxy_combatant_action"
end

local function isCombatPacingCapability(capability)
  return capability == "start_encounter" or capability == "begin_story_encounter" or
    capability == "begin_story_npc_encounter" or capability == "advance_turn"
end

function isNarrativeFlowCapability(capability)
  return capability == "send_chat" or capability == "request_player_input" or
    capability == "request_player_roll"
end

function getApprovalProfile()
  local profiles = {}
  if sessionGrants.send_chat then table.insert(profiles, "narrative flow") end
  if sessionGrants.proxy_actions then table.insert(profiles, "proxy actions") end
  if sessionGrants.combat_pacing then table.insert(profiles, "combat pacing") end
  if isFlowModeActive() then return "flow mode" end
  return #profiles > 0 and table.concat(profiles, " + ") or "manual"
end

function revokeChatSessionGrant()
  sessionGrants.send_chat = false
  if stopFlowInboxPoll then stopFlowInboxPoll() end
  ChatManager.SystemMessage("Nerve narrative-flow session grant revoked.")
  publishSnapshot("chat-session-grant-revoked", nil, true)
  refreshNerveControlWindows()
end

function revokeSessionGrants()
  sessionGrants.send_chat = false
  sessionGrants.proxy_actions = false
  sessionGrants.combat_pacing = false
  if stopFlowInboxPoll then stopFlowInboxPoll() end
  ChatManager.SystemMessage("Nerve session grants revoked.")
  publishSnapshot("session-grants-revoked", {
    type = "session.approval_policy_changed", actor = "GM", text = "Nerve approval policy set to manual.",
    visibility = "gm", subjectId = DB.getValue("nerve.sessionoperations.sessionid", ""),
    data = { mode = "manual" }
  })
  refreshNerveControlWindows()
end

function toggleFlowMode()
  if not isNerveSessionActive() then
    ChatManager.SystemMessage("Nerve: start tracking before enabling Flow Mode.")
    return false
  end
  if isNerveHeld() then
    ChatManager.SystemMessage("Nerve: resume before enabling Flow Mode.")
    return false
  end
  local enabled = not isFlowModeActive()
  sessionGrants.send_chat = enabled
  sessionGrants.proxy_actions = enabled
  sessionGrants.combat_pacing = enabled
  publishSnapshot("flow-mode-changed", {
    type = "session.approval_policy_changed", actor = "GM",
    text = enabled and "Nerve Flow Mode enabled." or "Nerve Flow Mode disabled.",
    visibility = "gm", subjectId = DB.getValue("nerve.sessionoperations.sessionid", ""),
    data = { mode = enabled and "flow" or "manual" }
  })
  ChatManager.SystemMessage(enabled and
    "Nerve Flow Mode enabled for this tracked session. Fantasy Grounds may ask once to allow the local Nerve wake address; choose Yes To All for hands-free routine narration and pacing. If declined, Check for Action remains available. Players may still decline or time out. Exact story-triggered prepared or named-NPC encounters may start automatically; quests, ad hoc encounter insertion, votes, visibility, effects, resources, removals, and other guarded actions remain manual." or
    "Nerve Flow Mode disabled. All actions returned to manual approval.")
  if enabled and startFlowInboxPoll then startFlowInboxPoll() elseif stopFlowInboxPoll then stopFlowInboxPoll() end
  if enabled then NerveSessionOpening.publishPending() end
  refreshNerveControlWindows()
  return true
end

function isNerveSessionActive()
  return DB.getValue("nerve.sessionoperations.status", "not_started") == "active"
end

function isNerveHeld()
  return DB.getValue("nerve.sessionoperations.held", 0) == 1
end

function getSessionReadinessText()
  local summary = createCampaignSummary()
  local party = createParty()
  local tracker = createCombatTracker()
  local adjudications = #createManualAdjudicationState().tasks
  local libraryCount = libraryCatalog and #(libraryCatalog.records or {}) or 0
  local focus = createCampaignFocusState(createMapSceneState(createOpenMapState()))
  local warnings = {}
  if summary.connectedPlayers == 0 then table.insert(warnings, "no remote players") end
  if #(party.members or {}) == 0 then table.insert(warnings, "Party Sheet empty") end
  if libraryCount == 0 then table.insert(warnings, "library index empty") end
  if focus.status == "not_selected" then table.insert(warnings, "choose Adventure Source") end
  if focus.status == "source_unavailable" then table.insert(warnings, "Adventure Source not loaded") end
  if adjudications > 0 then table.insert(warnings, tostring(adjudications) .. " adjudication(s) pending") end
  local readiness = #warnings == 0 and "READY" or ("CHECK: " .. table.concat(warnings, "; "))
  return string.format(
    "%s\n%s | %s | players %d | party %d | combatants %d | library %d",
    readiness, summary.name or "", summary.ruleset or "", summary.connectedPlayers or 0,
    #(party.members or {}), #(tracker.combatants or {}), libraryCount
  )
end

function getSessionOperationsText()
  local state = createSessionOperationsState(createCampaignSummary(), createCombatTracker(), createParty())
  local scene = createMapSceneState(createOpenMapState())
  local styleLabels = { mixed = "Mixed", map = "Map", theater_of_mind = "Theater of Mind" }
  local sceneName = scene.name ~= "" and string.sub(scene.name, 1, 28) or "none"
  local sceneLine = string.format(
    "Scene: %s | %s | shared %s | pending %d/%d",
    styleLabels[state.playStyle] or state.playStyle, sceneName, scene.shareMode,
    state.pendingPlayerResponses, state.pendingManualAdjudications
  )
  local statusLabel = state.status == "active" and (state.held and "ON HOLD" or "Active") or "Ended"
  local metrics = string.format(
    "%s · %d actions: %d approved / %d denied / %d failed",
    statusLabel, state.actionsProcessed, state.approved, state.denied, state.failed
  )
  return metrics .. "\n" .. sceneLine
end

function cycleScenePlayStyle()
  local style = getScenePlayStyle()
  if style == "mixed" then style = "map"
  elseif style == "map" then style = "theater_of_mind"
  else style = "mixed" end
  DB.setValue("nerve.sessionoperations.playstyle", "string", style)
  publishSnapshot("scene-style-changed", nil, true)
  local labels = { mixed = "Mixed", map = "Map", theater_of_mind = "Theater of Mind" }
  ChatManager.SystemMessage("Nerve scene style: " .. labels[style] .. ". This guides AI context and does not alter maps or tokens.")
  refreshNerveControlWindows()
  return style
end

refreshNerveControlWindows = function()
  for _, approvalWindow in ipairs(Interface.getWindows("nerve_approval") or {}) do
    if approvalWindow.refresh then approvalWindow.refresh() end
  end
  for _, desktopWindow in ipairs(Interface.getWindows("nerve_call_desktop") or {}) do
    if desktopWindow.refresh then desktopWindow.refresh() end
  end
  for _, card in ipairs(Interface.getWindows("nerve_action_card") or {}) do
    if card.refresh then card.refresh() end
  end
end

function startNerveSession(openingMode)
  if isNerveSessionActive() then
    ChatManager.SystemMessage("Nerve: a live session is already active.")
    return false
  end
  local now = os.date("!%Y-%m-%dT%H:%M:%SZ")
  pendingPlayerPrompts = {}
  playerPromptOrder = {}
  local sessionId = "fgu-" .. string.gsub(now, "[^0-9]", "")
  local continuity = createSessionContinuityState()
  local resumedFrom = continuity.latest and continuity.latest.id or ""
  if not NerveSessionOpening.modes[openingMode] then openingMode = continuity.latest and "resume" or "session_one" end
  DB.setValue("nerve.sessionoperations.status", "string", "active")
  DB.setValue("nerve.sessionoperations.held", "number", 0)
  DB.setValue("nerve.sessionoperations.sessionid", "string", sessionId)
  DB.setValue("nerve.sessionoperations.startedat", "string", now)
  DB.setValue("nerve.sessionoperations.endedat", "string", "")
  DB.setValue("nerve.sessionoperations.resumedfromcheckpointid", "string", resumedFrom)
  DB.setValue("nerve.sessionoperations.openingmode", "string", openingMode)
  DB.setValue("nerve.sessionoperations.openingstatus", "string", "pending")
  DB.setValue(aiCuePath("status"), "string", "idle")
  DB.setValue(aiCuePath("actor"), "string", "")
  DB.setValue(aiCuePath("source"), "string", "")
  DB.setValue(aiCuePath("answeredat"), "string", "")
  DB.setValue(aiCuePath("latencyseconds"), "number", -1)
  DB.setValue(aiCuePath("requestcount"), "number", 0)
  for _, name in ipairs({ "actionsprocessed", "approved", "denied", "failed", "sessiongrantexecutions" }) do
    DB.setValue("nerve.sessionoperations." .. name, "number", 0)
  end
  decisionHistory = {}
  if not isFlowModeActive() then toggleFlowMode() end
  publishSnapshot("nerve-session-started", {
    type = "session.started", actor = "GM", text = "Nerve live session started.", visibility = "gm",
    subjectId = sessionId, data = { sessionId = sessionId, resumedFromCheckpointId = resumedFrom, openingMode = openingMode }
  })
  local continuityText = continuity.latest and (" Continuity loaded from " .. continuity.latest.createdAt .. ": " .. continuity.latest.summary) or " No prior continuity checkpoint is available."
  ChatManager.SystemMessage("Nerve live session started." .. continuityText .. " " .. getSessionReadinessText() .. " A " .. string.gsub(openingMode, "_", " ") .. " opening is ready. Flow Mode is enabled; guarded actions still require approval.")
  refreshNerveControlWindows()
  return true
end

function toggleNerveHold()
  if not isNerveSessionActive() then
    ChatManager.SystemMessage("Nerve: start a live session before using Hold.")
    return false
  end
  local held = not isNerveHeld()
  DB.setValue("nerve.sessionoperations.held", "number", held and 1 or 0)
  if held then
    sessionGrants.send_chat = false
    sessionGrants.proxy_actions = false
    sessionGrants.combat_pacing = false
    if pendingCommand then
      local command = pendingCommand
      pendingCommand = nil
      lastProcessedRequestId = command.requestId
      commandFailure(command, "NERVE_HELD", "The GM placed Nerve on Hold before this action executed.")
      recordDecision(command, "denied: Nerve held")
    end
    if stopFlowInboxPoll then stopFlowInboxPoll() end
  end
  publishSnapshot(held and "nerve-session-held" or "nerve-session-resumed", {
    type = held and "session.held" or "session.resumed", actor = "GM",
    text = held and "Nerve live session held." or "Nerve live session resumed.", visibility = "gm",
    subjectId = DB.getValue("nerve.sessionoperations.sessionid", ""), data = { held = held }
  })
  ChatManager.SystemMessage(held and "Nerve is ON HOLD. New AI mutations are blocked and session grants were revoked." or "Nerve resumed. Writes still require the normal approval policy.")
  refreshNerveControlWindows()
  return true
end

function endNerveSession()
  if not isNerveSessionActive() then
    ChatManager.SystemMessage("Nerve: no live session is active.")
    return false
  end
  if pendingCommand then
    local command = pendingCommand
    pendingCommand = nil
    lastProcessedRequestId = command.requestId
    commandFailure(command, "SESSION_ENDED", "The GM ended the Nerve live session before this action executed.")
    recordDecision(command, "denied: session ended")
  end
  sessionGrants.send_chat = false
  sessionGrants.proxy_actions = false
  sessionGrants.combat_pacing = false
  for _, prompt in pairs(pendingPlayerPrompts) do
    for username, status in pairs(prompt.statuses or {}) do
      if status == "pending" or status == "sent" or status == "received" or status == "displayed" then
        prompt.statuses[username] = "timed_out"
      end
    end
  end
  if stopFlowInboxPoll then stopFlowInboxPoll() end
  expireStoryCues({ once = true, scene = true, session = true })
  local sessionId = DB.getValue("nerve.sessionoperations.sessionid", "")
  local continuity = createSessionContinuityState()
  if continuity.latest and continuity.latest.sessionId == sessionId then
    NerveContinuity.refreshFacts(continuity.latest.id)
  else
    local pending = createManualAdjudicationState()
    local openMaps = createOpenMapState()
    local mapScene = createMapSceneState(openMaps)
    local tracker = createCombatTracker()
    local facts = NerveContinuity.createFacts(mapScene, tracker, createParty(), pending)
    local automatic = NerveContinuity.automaticNarrative(sessionId, mapScene, tracker, facts)
    persistSessionContinuity({
      sessionId = sessionId,
      summary = automatic.summary,
      currentSituation = automatic.currentSituation,
      unresolvedThreads = automatic.unresolvedThreads,
      partyGoals = automatic.partyGoals, importantNpcs = automatic.importantNpcs,
      partyOrigin = automatic.partyOrigin, reasonHere = automatic.reasonHere,
      locationsVisited = automatic.locationsVisited, npcsMet = automatic.npcsMet,
      conversationHighlights = automatic.conversationHighlights, discoveries = automatic.discoveries,
      completedObjectives = automatic.completedObjectives, nextSessionOpening = automatic.nextSessionOpening,
      sourceEventSequence = eventSequence
    }, "automatic")
  end
  DB.setValue("nerve.sessionoperations.status", "string", "ended")
  DB.setValue("nerve.sessionoperations.held", "number", 0)
  DB.setValue("nerve.sessionoperations.endedat", "string", os.date("!%Y-%m-%dT%H:%M:%SZ"))
  publishSnapshot("nerve-session-ended", {
    type = "session.ended", actor = "GM", text = "Nerve live session ended.", visibility = "gm",
    subjectId = sessionId, data = { sessionId = sessionId }
  })
  local controllerState = getControllerSupervisorState()
  if controllerState.controllerStatus == "running" or controllerState.controllerStatus == "starting" then
    DB.setValue("nerve.sessionoperations.shutdownrequestedat", "string", os.date("!%Y-%m-%dT%H:%M:%SZ"))
    requestControllerOperation("stop")
  end
  ChatManager.SystemMessage("Nerve live session ended. " .. getSessionOperationsText())
  refreshNerveControlWindows()
  return true
end

function getPlayerProxyMode()
  return playerProxyMode
end

function togglePlayerProxyMode()
  playerProxyMode = playerProxyMode == "all" and "none" or "all"
  publishSnapshot("character-changed")
  ChatManager.SystemMessage("Nerve entity proxy: " .. playerProxyMode)
end

function approvePendingCommand(grantMode)
  local command = pendingCommand
  if not command then
    ChatManager.SystemMessage("Nerve: no pending command to approve.")
    return false
  end
  if isNerveHeld() and command.capability ~= "record_session_continuity" then
    ChatManager.SystemMessage("Nerve is on Hold. Resume before approving actions.")
    return false
  end
  if os.time() > command.expiresAtEpoch then
    pendingCommand = nil
    commandFailure(command, "COMMAND_EXPIRED", "The pending command expired.")
    recordDecision(command, "expired")
    return false
  end
  local grantChat = grantMode == true or grantMode == "chat"
  local grantProxy = grantMode == "proxy"
  local grantCombatPacing = grantMode == "combat"
  if grantChat and isNarrativeFlowCapability(command.capability) then
    sessionGrants.send_chat = true
  end
  if grantProxy and isProxyActionCapability(command.capability) then
    sessionGrants.proxy_actions = true
  end
  if grantCombatPacing and isCombatPacingCapability(command.capability) then
    sessionGrants.combat_pacing = true
  end
  pendingCommand = nil
  local approvalLabel = "approved"
  if grantChat and isNarrativeFlowCapability(command.capability) then approvalLabel = "approved + narrative flow grant" end
  if grantProxy and isProxyActionCapability(command.capability) then approvalLabel = "approved + proxy grant" end
  if grantCombatPacing and isCombatPacingCapability(command.capability) then approvalLabel = "approved + combat pacing grant" end
  local executed = executeApprovedCommand(command, approvalLabel)
  if executed then closeActionCards() end
  return executed
end

function denyPendingCommand()
  local command = pendingCommand
  if not command then
    ChatManager.SystemMessage("Nerve: no pending command to deny.")
    return false
  end
  pendingCommand = nil
  lastProcessedRequestId = command.requestId
  commandFailure(command, "COMMAND_DENIED", "The GM denied the pending command.")
  recordDecision(command, "denied")
  closeActionCards()
  return true
end

function reconcileAiCueResult(silent)
  if not Session.IsHost or not isAiCueWaiting() then return false end
  local statusText = File.openTextFile(File.getCampaignFolder() .. "/nerve-controller-status.json")
  local controllerStatus = statusText and statusText ~= "" and Utility.decodeJSON(statusText) or nil
  local lastResult = type(controllerStatus) == "table" and controllerStatus.lastResult or nil
  local requestedAt = DB.getValue(aiCuePath("requestedat"), "")
  if type(lastResult) ~= "table" or type(lastResult.timestamp) ~= "string" or lastResult.timestamp < requestedAt then return false end
  if type(lastResult.cueId) == "string" and lastResult.cueId ~= "" and lastResult.cueId ~= getAiCueId() then return false end
  if lastResult.status == "completed" and (lastResult.decision == "hold" or lastResult.decision == "request_clarification") then
    markAiCueAnswered()
    ChatManager.SystemMessage(lastResult.decision == "hold" and "Nerve AI answered with HOLD; no Fantasy Grounds action was proposed." or ("Nerve AI requested clarification: " .. tostring(lastResult.summary or "More information is needed.")))
    return true
  end
  if lastResult.status == "provider_failed" and lastResult.transient == true then
    if not silent then ChatManager.SystemMessage("Nerve AI provider is temporarily unavailable; the controller will retry automatically.") end
    return false
  end
  if lastResult.status == "provider_rate_limited" then
    markAiCueFailed("Gemini free-tier limit reached. Nerve stopped after one delayed retry; restart it later or choose another AI.")
    return true
  end
  if lastResult.status == "provider_failed" or lastResult.status == "action_rejected" then
    local detail = tostring(lastResult.errorCode or lastResult.status)
    if type(lastResult.errorMessage) == "string" and lastResult.errorMessage ~= "" then detail = detail .. ": " .. string.sub(lastResult.errorMessage, 1, 180) end
    if tonumber(lastResult.httpStatus) then detail = detail .. " (HTTP " .. tostring(lastResult.httpStatus) .. ")" end
    if type(lastResult.validationErrors) == "table" and #lastResult.validationErrors > 0 then detail = detail .. ": " .. tostring(lastResult.validationErrors[1]) end
    markAiCueFailed(detail)
    return true
  end
  return false
end

aiCueResultPollGeneration = 0

stopAiCueResultPoll = function()
  aiCueResultPollGeneration = aiCueResultPollGeneration + 1
end

function armAiCueResultPoll(generation, poll)
  if not Session.IsHost or generation ~= aiCueResultPollGeneration or not isAiCueWaiting() then return end
  local pollUrl = "http://127.0.0.1:47831/nerve-flow-wait?cue_result_generation=" .. tostring(generation) .. "&poll=" .. tostring(poll)
  Interface.openURL(pollUrl, function(_, response)
    if generation ~= aiCueResultPollGeneration then return end
    if type(response) == "string" and string.find(response, '"status":"action"', 1, true) then
      stopAiCueResultPoll()
      processPendingCommand(nil, "flow_poll")
      return
    end
    if reconcileAiCueResult(true) then return end
    if isAiCueWaiting() then armAiCueResultPoll(generation, poll + 1) end
  end)
end

startAiCueResultPoll = function()
  if not Session.IsHost or not isAiCueWaiting() then return false end
  stopAiCueResultPoll()
  local generation = aiCueResultPollGeneration
  armAiCueResultPoll(generation, 1)
  return true
end

processPendingCommand = function(_, params)
  if params == "call" then
    callNerve()
    return
  end
  if params == "library" then
    onLibraryModuleChanged()
    return
  end
  if params and params ~= "" and params ~= "panel" and params ~= "flow_poll" then
    ChatManager.SystemMessage("Usage: /nerve [panel|library|call]")
    return
  end

  local path = File.getCampaignFolder() .. "/" .. COMMAND_FILENAME
  local text = File.openTextFile(path)
  if not text or text == "" then
    pendingCommand = nil
    if reconcileAiCueResult(false) then return end
    if params ~= "flow_poll" then ChatManager.SystemMessage("Nerve: no action is waiting in the inbox.") end
    return
  end
  local command = Utility.decodeJSON(text)
  if type(command) ~= "table" or command.schemaVersion ~= "0.1" or type(command.requestId) ~= "string" then
    commandFailure(command, "INVALID_COMMAND", "The pending command is malformed.")
    recordDecision(command, "rejected: malformed")
    openActionCard()
    return
  end
  if command.requestId == lastProcessedRequestId then
    commandFailure(command, "DUPLICATE_COMMAND", "This command was already processed.")
    recordDecision(command, "rejected: duplicate")
    openActionCard()
    return
  end
  if type(command.expiresAtEpoch) ~= "number" or os.time() > command.expiresAtEpoch then
    commandFailure(command, "COMMAND_EXPIRED", "The pending command expired.")
    recordDecision(command, "expired")
    openActionCard()
    return
  end

  if isNerveHeld() and command.capability ~= "record_session_continuity" then
    lastProcessedRequestId = command.requestId
    commandFailure(command, "NERVE_HELD", "Nerve is on Hold. The GM must resume it before AI mutations can execute.")
    recordDecision(command, "denied: Nerve held")
    pendingCommand = nil
    openActionCard()
    return
  end

  if isNarrativeFlowCapability(command.capability) and sessionGrants.send_chat then
    executeApprovedCommand(command, "narrative flow session grant")
    return
  end
  if isProxyActionCapability(command.capability) and sessionGrants.proxy_actions and playerProxyMode == "all" then
    executeApprovedCommand(command, "proxy session grant")
    return
  end
  if isCombatPacingCapability(command.capability) and sessionGrants.combat_pacing then
    executeApprovedCommand(command, "combat pacing session grant")
    return
  end
  pendingCommand = command
  openActionCard()
end

function checkPendingCommand()
  processPendingCommand(nil, "")
end

function stopFlowInboxPoll()
  flowInboxPollGeneration = (flowInboxPollGeneration or 0) + 1
  flowInboxPollActive = false
end

function armFlowInboxPoll(generation)
  if not flowInboxPollActive or generation ~= flowInboxPollGeneration or not isFlowModeActive() or isNerveHeld() then return end
  flowInboxPollSequence = (flowInboxPollSequence or 0) + 1
  local pollUrl = "http://127.0.0.1:47831/nerve-flow-wait?generation=" .. tostring(generation) .. "&poll=" .. tostring(flowInboxPollSequence)
  Interface.openURL(pollUrl, function(_, response)
    if not flowInboxPollActive or generation ~= flowInboxPollGeneration then return end
    reconcileAiCueResult(true)
    if type(response) == "string" and string.find(response, '"status":"action"', 1, true) then
      processPendingCommand(nil, "flow_poll")
    end
    if flowInboxPollActive and generation == flowInboxPollGeneration then armFlowInboxPoll(generation) end
  end)
end

function startFlowInboxPoll()
  if not Session.IsHost or not isFlowModeActive() or isNerveHeld() then return false end
  stopFlowInboxPoll()
  flowInboxPollActive = true
  armFlowInboxPoll(flowInboxPollGeneration)
  return true
end

local function registerHandlers()
  if handlersRegistered then
    return
  end

  DB.addHandler("combattracker.list", "onChildAdded", onCombatStateChanged)
  DB.addHandler("combattracker.list", "onChildDeleted", onCombatStateChanged)
  for _, field in ipairs(TRACKED_COMBATANT_FIELDS) do
    DB.addHandler("combattracker.list.*." .. field, "onUpdate", onCombatStateChanged)
  end
  DB.addHandler("combattracker.list.*.effects", "onChildAdded", onCombatStateChanged)
  DB.addHandler("combattracker.list.*.effects", "onChildDeleted", onCombatStateChanged)
  for _, field in ipairs(TRACKED_EFFECT_FIELDS) do
    DB.addHandler("combattracker.list.*.effects.*." .. field, "onUpdate", onCombatStateChanged)
  end
  for _, section in ipairs(COMBATANT_ACTION_SECTIONS) do
    DB.addHandler("combattracker.list.*." .. section, "onChildAdded", onCombatStateChanged)
    DB.addHandler("combattracker.list.*." .. section, "onChildDeleted", onCombatStateChanged)
    for _, field in ipairs({ "name", "desc", "value" }) do
      DB.addHandler("combattracker.list.*." .. section .. ".*." .. field, "onUpdate", onCombatStateChanged)
    end
  end
  DB.addHandler("combattracker.round", "onUpdate", onCombatStateChanged)
  DB.addHandler("partysheet.partyinformation", "onChildAdded", onPartyChanged)
  DB.addHandler("partysheet.partyinformation", "onChildDeleted", onPartyChanged)
  for _, field in ipairs(TRACKED_PARTY_FIELDS) do
    DB.addHandler("partysheet.partyinformation.*." .. field, "onUpdate", onPartyChanged)
  end
  DB.addHandler("charsheet", "onChildAdded", onCharacterChanged)
  DB.addHandler("charsheet", "onChildDeleted", onCharacterChanged)
  for _, path in ipairs(TRACKED_CHARACTER_PATHS) do
    DB.addHandler("charsheet.*." .. path, "onUpdate", onCharacterChanged)
  end
  for _, field in ipairs(TRACKED_ABILITY_FIELDS) do
    DB.addHandler("charsheet.*.abilities.*." .. field, "onUpdate", onCharacterChanged)
  end
  DB.addHandler("charsheet.*.classes", "onChildAdded", onCharacterChanged)
  DB.addHandler("charsheet.*.classes", "onChildDeleted", onCharacterChanged)
  for _, field in ipairs(TRACKED_CLASS_FIELDS) do
    DB.addHandler("charsheet.*.classes.*." .. field, "onUpdate", onCharacterChanged)
  end
  DB.addHandler("charsheet.*.skilllist", "onChildAdded", onCharacterChanged)
  DB.addHandler("charsheet.*.skilllist", "onChildDeleted", onCharacterChanged)
  for _, field in ipairs(TRACKED_SKILL_FIELDS) do
    DB.addHandler("charsheet.*.skilllist.*." .. field, "onUpdate", onCharacterChanged)
  end
  DB.addHandler("charsheet.*.powers", "onChildAdded", onCharacterChanged)
  DB.addHandler("charsheet.*.powers", "onChildDeleted", onCharacterChanged)
  for _, field in ipairs(TRACKED_POWER_FIELDS) do
    DB.addHandler("charsheet.*.powers.*." .. field, "onUpdate", onCharacterChanged)
  end
  DB.addHandler("charsheet.*.powers.*.actions", "onChildAdded", onCharacterChanged)
  DB.addHandler("charsheet.*.powers.*.actions", "onChildDeleted", onCharacterChanged)
  for _, field in ipairs(TRACKED_POWER_ACTION_FIELDS) do
    DB.addHandler("charsheet.*.powers.*.actions.*." .. field, "onUpdate", onCharacterChanged)
  end
  for level = 1, 9 do
    DB.addHandler("charsheet.*.powermeta.spellslots" .. tostring(level) .. ".max", "onUpdate", onCharacterChanged)
    DB.addHandler("charsheet.*.powermeta.spellslots" .. tostring(level) .. ".used", "onUpdate", onCharacterChanged)
  end
  for _, listName in ipairs({ "languagelist", "proficiencylist" }) do
    DB.addHandler("charsheet.*." .. listName, "onChildAdded", onCharacterChanged)
    DB.addHandler("charsheet.*." .. listName, "onChildDeleted", onCharacterChanged)
    DB.addHandler("charsheet.*." .. listName .. ".*.name", "onUpdate", onCharacterChanged)
  end
  ChatManager.registerReceiveMessageCallback(onChatMessageReceived)
  ChatManager.registerDiceLandedCallback(onDiceLanded)
  GameManager.addEventFunction("onActionPostTargeting", attachNervePowerContext)
  GameManager.addEventFunction("onAttackPostResolve", onNerveAttackPostResolve)
  GameManager.addEventFunction("onSavePostResolve", onNerveSavePostResolve)
  Comm.registerSlashHandler("nerve", processPendingCommand, "[panel]")
  User.addEventHandler("onLogin", onUserLoginChanged)
  Module.addEventHandler("onModuleLoad", onLibraryModuleChanged)
  Module.addEventHandler("onModuleUnload", onLibraryModuleChanged)
  Interface.addKeyedEventHandler("onWindowOpened", "", onImageWindowOpened)
  Interface.addKeyedEventHandler("onWindowClosed", "", onImageWindowClosed)
  Token.addEventHandler("onAdd", onMapTokenChanged)
  Token.addEventHandler("onMove", onMapTokenChanged)
  Token.addEventHandler("onDelete", onMapTokenChanged)
  handlersRegistered = true
end

function onInit()
  OOBManager.registerOOBMsgHandler(OOB_MSGTYPE_PLAYER_PROMPT, handlePlayerPrompt)
  OOBManager.registerOOBMsgHandler(OOB_MSGTYPE_PLAYER_PROMPT_RESPONSE, handlePlayerPromptResponse)
  OOBManager.registerOOBMsgHandler(OOB_MSGTYPE_PLAYER_PROMPT_RECEIPT, handlePlayerPromptReceipt)
  OOBManager.registerOOBMsgHandler(OOB_MSGTYPE_REMOTE_ROLL_RESULT, handleRemoteRollResult)
  OOBManager.registerOOBMsgHandler(OOB_MSGTYPE_AI_CUE, handleAiCueRequest)
  OOBManager.registerOOBMsgHandler(OOB_MSGTYPE_AI_CUE_STATUS, handleAiCueStatus)
  OOBManager.registerOOBMsgHandler(OOB_MSGTYPE_OOC_QUESTION, handleOocQuestion)
  Comm.registerSlashHandler("nerveprompt", processPlayerPromptSlash, "")
  Comm.registerSlashHandler("nervecall", function() callNerve() end, "")
  Comm.registerSlashHandler("nerveask", processOocQuestionSlash, "[question]")
  if not Session.IsHost then
    ChatManager.registerDiceLandedCallback(onDiceLanded)
    clientDiceHandlerRegistered = true
    return
  end

  eventStreamId = User.getCampaignName() .. ":" .. tostring(os.time())
  local hostStatus = Utility.encodeJSON({ schemaVersion = "0.1", adapterVersion = ADAPTER_VERSION, status = "running", updatedAt = os.date("!%Y-%m-%dT%H:%M:%SZ") })
  if hostStatus then File.saveTextFile(File.getCampaignFolder() .. "/nerve-host-status.json", hostStatus) end
  registerHandlers()
  NerveCampaignMemory.repairLegacySanitizer()
  publishSnapshot("extension-initialized")
end

function onTabletopInit()
  if not Session.IsHost then return end
  registerNerveSidebar()
  if isFlowModeActive() then startFlowInboxPoll() end
end

function onClose()
  stopFlowInboxPoll()
  if stopAiCueResultPoll then stopAiCueResultPoll() end
  if Session.IsHost then
    local hostStatus = Utility.encodeJSON({ schemaVersion = "0.1", adapterVersion = ADAPTER_VERSION, status = "closed", updatedAt = os.date("!%Y-%m-%dT%H:%M:%SZ") })
    if hostStatus then File.saveTextFile(File.getCampaignFolder() .. "/nerve-host-status.json", hostStatus) end
  end
  if clientDiceHandlerRegistered then
    ChatManager.unregisterDiceLandedCallback(onDiceLanded)
    clientDiceHandlerRegistered = false
  end
  if not handlersRegistered then
    return
  end

  DB.removeHandler("combattracker.list", "onChildAdded", onCombatStateChanged)
  DB.removeHandler("combattracker.list", "onChildDeleted", onCombatStateChanged)
  for _, field in ipairs(TRACKED_COMBATANT_FIELDS) do
    DB.removeHandler("combattracker.list.*." .. field, "onUpdate", onCombatStateChanged)
  end
  DB.removeHandler("combattracker.list.*.effects", "onChildAdded", onCombatStateChanged)
  DB.removeHandler("combattracker.list.*.effects", "onChildDeleted", onCombatStateChanged)
  for _, field in ipairs(TRACKED_EFFECT_FIELDS) do
    DB.removeHandler("combattracker.list.*.effects.*." .. field, "onUpdate", onCombatStateChanged)
  end
  for _, section in ipairs(COMBATANT_ACTION_SECTIONS) do
    DB.removeHandler("combattracker.list.*." .. section, "onChildAdded", onCombatStateChanged)
    DB.removeHandler("combattracker.list.*." .. section, "onChildDeleted", onCombatStateChanged)
    for _, field in ipairs({ "name", "desc", "value" }) do
      DB.removeHandler("combattracker.list.*." .. section .. ".*." .. field, "onUpdate", onCombatStateChanged)
    end
  end
  DB.removeHandler("combattracker.round", "onUpdate", onCombatStateChanged)
  DB.removeHandler("partysheet.partyinformation", "onChildAdded", onPartyChanged)
  DB.removeHandler("partysheet.partyinformation", "onChildDeleted", onPartyChanged)
  for _, field in ipairs(TRACKED_PARTY_FIELDS) do
    DB.removeHandler("partysheet.partyinformation.*." .. field, "onUpdate", onPartyChanged)
  end
  DB.removeHandler("charsheet", "onChildAdded", onCharacterChanged)
  DB.removeHandler("charsheet", "onChildDeleted", onCharacterChanged)
  for _, path in ipairs(TRACKED_CHARACTER_PATHS) do
    DB.removeHandler("charsheet.*." .. path, "onUpdate", onCharacterChanged)
  end
  for _, field in ipairs(TRACKED_ABILITY_FIELDS) do
    DB.removeHandler("charsheet.*.abilities.*." .. field, "onUpdate", onCharacterChanged)
  end
  DB.removeHandler("charsheet.*.classes", "onChildAdded", onCharacterChanged)
  DB.removeHandler("charsheet.*.classes", "onChildDeleted", onCharacterChanged)
  for _, field in ipairs(TRACKED_CLASS_FIELDS) do
    DB.removeHandler("charsheet.*.classes.*." .. field, "onUpdate", onCharacterChanged)
  end
  DB.removeHandler("charsheet.*.skilllist", "onChildAdded", onCharacterChanged)
  DB.removeHandler("charsheet.*.skilllist", "onChildDeleted", onCharacterChanged)
  for _, field in ipairs(TRACKED_SKILL_FIELDS) do
    DB.removeHandler("charsheet.*.skilllist.*." .. field, "onUpdate", onCharacterChanged)
  end
  for _, listName in ipairs({ "languagelist", "proficiencylist" }) do
    DB.removeHandler("charsheet.*." .. listName, "onChildAdded", onCharacterChanged)
    DB.removeHandler("charsheet.*." .. listName, "onChildDeleted", onCharacterChanged)
    DB.removeHandler("charsheet.*." .. listName .. ".*.name", "onUpdate", onCharacterChanged)
  end
  ChatManager.unregisterReceiveMessageCallback(onChatMessageReceived)
  ChatManager.unregisterDiceLandedCallback(onDiceLanded)
  GameManager.removeEventFunction("onActionPostTargeting", attachNervePowerContext)
  GameManager.removeEventFunction("onAttackPostResolve", onNerveAttackPostResolve)
  GameManager.removeEventFunction("onSavePostResolve", onNerveSavePostResolve)
  User.removeEventHandler("onLogin", onUserLoginChanged)
  Module.removeEventHandler("onModuleLoad", onLibraryModuleChanged)
  Module.removeEventHandler("onModuleUnload", onLibraryModuleChanged)
  handlersRegistered = false
end
