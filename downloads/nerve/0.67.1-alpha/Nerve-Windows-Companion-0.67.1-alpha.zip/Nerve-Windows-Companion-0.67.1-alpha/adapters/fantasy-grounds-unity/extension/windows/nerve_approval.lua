function onInit()
  refresh()
end

function refresh()
  NerveAdapter.reconcileAiCueResult(true)
  NerveAdapter.reportSupervisorOperationResult()
  local hasPending = NerveAdapter.hasPendingCommand()
  local pendingCapability = NerveAdapter.getPendingCommandCapability()
  local chatGrantActive = NerveAdapter.isChatSessionGrantActive()
  local proxyGrantActive = NerveAdapter.isProxyActionSessionGrantActive()
  local combatGrantActive = NerveAdapter.isCombatPacingSessionGrantActive()
  local sessionActive = NerveAdapter.isNerveSessionActive()
  local held = NerveAdapter.isNerveHeld()

  if title and title.setValue then
    if held then title.setValue("Nerve Control — ON HOLD")
    elseif hasPending then title.setValue("Nerve Control — Action Waiting")
    elseif NerveAdapter.getControllerSupervisorState().controllerStatus ~= "stopped" and NerveAdapter.getControllerSupervisorState().listenerPhase == "failed" then title.setValue("Nerve Control — CONNECTION FAILED")
    elseif NerveAdapter.isAiCueWaiting() then title.setValue("Nerve Control — WAITING FOR AI")
    else title.setValue("Nerve Control") end
  end
  readiness_status.setValue(NerveAdapter.getSessionReadinessText())
  session_status.setValue(NerveAdapter.getSessionOperationsText())
  pending_summary.setValue(NerveAdapter.getPendingCommandSummary())
  decision_history.setValue(NerveAdapter.getDecisionHistoryText())
  prompt_status.setValue(NerveAdapter.getPlayerPromptStatusText())
  adjudication_status.setValue(NerveAdapter.getManualAdjudicationStatusText())
  review_adjudication.setVisible(NerveAdapter.hasManualAdjudications())
  grant_status.setValue("Approval profile: " .. NerveAdapter.getApprovalProfile())
  proxy_status.setValue("Entity proxy: " .. NerveAdapter.getPlayerProxyMode())
  cue_status.setValue(NerveAdapter.getAiCueStatusText())
  controller_status.setValue(NerveAdapter.getControllerStatusText())
  controller_toggle.setText(NerveAdapter.getControllerButtonText())
  controller_toggle.setVisible(Session.IsHost)
  controller_setup.setVisible(Session.IsHost)
  collect_support.setVisible(Session.IsHost)
  system_check.setVisible(Session.IsHost)
  campaign_memory.setVisible(Session.IsHost)
  story_cues.setVisible(Session.IsHost)
  ask_ooc.setVisible(Session.IsHost)

  start_session.setVisible(not sessionActive)
  hold_session.setVisible(sessionActive and not held)
  resume_session.setVisible(sessionActive and held)
  end_session.setVisible(sessionActive)
  flow_mode.setVisible(sessionActive and not held)
  flow_mode.setText(NerveAdapter.isFlowModeActive() and "Disable Flow Mode" or "Enable Flow Mode")

  local heldMetadataApproval = held and pendingCapability == "record_session_continuity"
  approve.setVisible(hasPending and (not held or heldMetadataApproval))
  deny.setVisible(hasPending)
  local isNarrativeFlow = pendingCapability == "send_chat" or pendingCapability == "request_player_input" or
    pendingCapability == "request_player_roll"
  local isProxyAction = pendingCapability == "proxy_character_roll" or pendingCapability == "proxy_character_power_action" or
    pendingCapability == "proxy_combatant_action"
  local isCombatPacing = pendingCapability == "start_encounter" or pendingCapability == "begin_story_encounter" or
    pendingCapability == "begin_story_npc_encounter" or pendingCapability == "advance_turn"
  allow_chat.setVisible(hasPending and not held and isNarrativeFlow and not chatGrantActive)
  allow_proxy.setVisible(hasPending and not held and isProxyAction and not proxyGrantActive)
  allow_combat.setVisible(hasPending and not held and isCombatPacing and not combatGrantActive)
  revoke_grants.setVisible(not hasPending and (chatGrantActive or proxyGrantActive or combatGrantActive))
end
