# Nerve 0.67.1 alpha — start here

Use a backup/test copy of your campaign. Windows GM host and Fantasy Grounds 5E are the supported alpha target. Install Node.js 22+ if needed. AI accounts, applications and usage are separate requirements.

1. Install Nerve through Forge and run the Fantasy Grounds updater. Then extract the matching companion ZIP completely and run Install-Nerve.cmd. Forge manages the extension; this companion installs only its runtime. For pre-publication review, place the supplied .ext in the Fantasy Grounds extensions folder first.
2. Enable Nerve Adapter in the campaign extensions and load the campaign. Confirm version 0.67.1 in chat.
3. Open Nerve Control → AI Setup. Select your provider, use Install / Repair if needed, then Sign In. Complete provider-owned authentication. A browser may not appear when already signed in.
4. Use Test + Use. This can consume AI allowance. Confirm the selected provider is saved and ready before starting.
5. Start the session/Nerve. Flow Mode is enabled for a new tracked session; select manual mode if preferred. Try a short recap or a simple action. Avoid repeated Call Nerve while a request is responding.
6. End Session to preserve continuity; confirm the connector stops. If needed, Stop Nerve. After a failure, inspect the error before retrying.

Story Cues: drag a supported record's link icon into the Story Cue Tower and confirm its title appears. Pins supply context; they do not move characters or reveal records to players.

Check native records after approvals. Rewards and purchases may still need manual bookkeeping; verify before adding anything to avoid duplicates. Quest-completion display remains a known limitation.

The companion requires installation outside Forge. Use the Forge companion build for future repairs and updates. It will not overwrite the .ext. If upgrading from a developer preview, close Fantasy Grounds, move the old extensions/Nerve folder to a backup outside extensions, then install the Forge extension and rerun the companion installer. Do not delete campaign folders. Keep exactly one packaged Nerve extension. Version mismatches require the matching companion release and/or the Fantasy Grounds updater, followed by a campaign reload.

Forge review currently targets Data installation, not encrypted Vault packages. Real Forge delivery and update testing remain pending moderation/access.

Use Collect-Nerve-Support.cmd for diagnostic assistance. Inspect any bundle before sharing and use a private support channel for sensitive material. Never post campaign snapshots, licensed module text, provider credentials or raw AI transcripts publicly.
