import { cp, mkdir, readFile, writeFile } from "node:fs/promises";
import { randomUUID } from "node:crypto";
import { spawn } from "node:child_process";
import { dirname, join, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import {
  assertReadableSnapshot,
  campaignPaths,
  defaultFguDataPath,
  diagnoseCampaign,
  discoverCampaigns
} from "./paths.js";
import { persistActiveCampaign, resolveActiveCampaign } from "../adapters/fantasy-grounds-unity/bridge/campaign-bridge.js";

const repositoryRoot = fileURLToPath(new URL("../", import.meta.url));

export async function runCli(argv, io = defaultIo()) {
  const [command = "help", ...tokens] = argv;
  const options = parseOptions(tokens);
  if (options.help || command === "help" || command === "--help" || command === "-h") {
    io.out(`${helpText()}\nGuided no-key Companion handoff:\n  nerve companion-prepare --campaign <name> [--fgu-data <path>] [--json]\n  nerve companion-submit --campaign <name> --cue-id <id> --response-file <path> --expose-writes --allow-writes [--json]\nOffline compatibility:\n  nerve provider-acceptance [--json]\nProvider connection test (one billed request for real providers):\n  nerve provider-check --provider <id> --model <id> [--json]`);
    return 0;
  }

  if (command === "playtest") {
    const steps = positiveInteger(options.steps ?? "500", "--steps");
    const seed = positiveInteger(options.seed ?? "42", "--seed");
    const { runPlaytest } = await import("../playtest/run.js");
    const report = await runPlaytest({ steps, seed });
    io.out(options.json ? JSON.stringify(report, null, 2) : formatPlaytest(report));
    return report.failedCalls === 0 ? 0 : 1;
  }

  if (command === "controller-simulate") {
    const { runControllerSimulation } = await import("../ai/controller-simulation.js");
    const report = await runControllerSimulation();
    io.out(options.json ? JSON.stringify(report, null, 2) : formatControllerSimulation(report));
    return report.passed ? 0 : 1;
  }

  if (command === "controller-evaluate") {
    const { runControllerEvaluation } = await import("../ai/controller-evaluation.js");
    const report = await runControllerEvaluation();
    io.out(options.json ? JSON.stringify(report, null, 2) : formatControllerEvaluation(report));
    return report.passed ? 0 : 1;
  }

  if (command === "provider-acceptance") {
    const { runProviderAcceptance } = await import("../ai/provider-acceptance.js");
    const report = await runProviderAcceptance();
    io.out(options.json ? JSON.stringify(report, null, 2) : formatProviderAcceptance(report));
    return report.passed ? 0 : 1;
  }

  if (command === "providers") {
    const { listConfiguredAiProviders } = await import("../ai/provider-factory.js");
    const providers = listConfiguredAiProviders();
    io.out(options.json ? JSON.stringify(providers, null, 2) : formatProviders(providers));
    return 0;
  }

  if (command === "provider-check") {
    const [{ createConfiguredAiProvider }, { checkProviderConnection }] = await Promise.all([
      import("../ai/provider-factory.js"), import("../ai/provider-connection-check.js")
    ]);
    const provider = createConfiguredAiProvider({
      provider: options.provider ?? "fake",
      model: options.model,
      maxOutputTokens: options.maxOutputTokens ? positiveInteger(options.maxOutputTokens, "--max-output-tokens", 100000) : 800
    });
    const report = await checkProviderConnection(provider);
    io.out(options.json ? JSON.stringify(report, null, 2) : formatProviderConnection(report));
    return 0;
  }

  if (command === "app-connector-check") {
    const { checkConfiguredAppConnector } = await import("../ai/app-listeners.js");
    const report = await checkConfiguredAppConnector({
      appConnector: options.appListener || "codex",
      customConfigPath: options.appListenerConfig ? resolve(options.appListenerConfig) : null,
      codexPath: options.codexPath ? resolve(options.codexPath) : null
    });
    io.out(options.json ? JSON.stringify(report, null, 2) : `${report.label}: connected`);
    return 0;
  }

  if (command === "connector-serve") {
    if (!options.campaign) throw new Error("connector-serve requires --campaign <name>.");
    if (!options.fguData) throw new Error("connector-serve requires --fgu-data <path>.");
    if (!options.tokenFile) throw new Error("connector-serve requires --token-file <path>.");
    const [{ runLocalConnector, ensureConnectorToken }] = await Promise.all([
      import("../ai/local-connector-server.js")
    ]);
    const token = await ensureConnectorToken(resolve(options.tokenFile));
    await runLocalConnector({
      campaign: options.campaign,
      fguDataPath: options.fguData,
      token,
      port: options.port ? positiveInteger(options.port, "--port", 65535) : 47832,
      allowWrites: Boolean(options.exposeWrites && options.allowWrites),
      autoCodexListener: Boolean(options.codexAppListener),
      appConnector: options.appListener || null,
      customConfigPath: options.appListenerConfig ? resolve(options.appListenerConfig) : null,
      codexPath: options.codexPath ? resolve(options.codexPath) : null
    });
    return 0;
  }

  if (command === "package-preview") {
    const { buildDeveloperPreview } = await import("../packaging/developer-preview.js");
    const report = await buildDeveloperPreview({ outputPath: options.output ? resolve(options.output) : null });
    io.out(options.json ? JSON.stringify(report, null, 2) : `Built Nerve developer preview at ${report.destination}\nFiles: ${report.fileCount}\nManifest: ${join(report.destination, "manifest.json")}\nArchive: ${report.archivePath}\nArchive SHA-256: ${report.archiveSha256}`);
    return 0;
  }

  if (command === "package-verify") {
    if (!options.input) throw new Error("package-verify requires --input <directory-or-zip>.");
    const { verifyDeveloperPreview } = await import("../packaging/verify-preview.js");
    const report = await verifyDeveloperPreview(resolve(options.input));
    io.out(options.json ? JSON.stringify(report, null, 2) : `Nerve preview verified\nInput: ${report.input}\nType: ${report.inputType}\nVersion: ${report.version}\nFiles: ${report.fileCount}${report.archiveSha256 ? `\nArchive SHA-256: ${report.archiveSha256}` : ""}`);
    return 0;
  }

  const fguDataPath = options.fguData ?? defaultFguDataPath();
  if (command === "companion-prepare") {
    if (!fguDataPath) throw new Error("Fantasy Grounds data path was not found. Use --fgu-data <path>.");
    const campaign = requireCampaign(options);
    const paths = campaignPaths({ fguDataPath, campaign });
    const snapshot = await assertReadableSnapshot(paths.snapshotPath);
    process.env.NERVE_FGU_SNAPSHOT_PATH = paths.snapshotPath;
    const [{ createNerve }, { prepareCompanionHandoff }] = await Promise.all([
      import("../core/create-nerve.js"),
      import("../ai/companion-handoff.js")
    ]);
    const handoff = await prepareCompanionHandoff({
      nerve: createNerve({ toolProfile: "session" }),
      snapshot,
      campaign,
      sessionId: `companion-${randomUUID()}`
    });
    io.out(options.json ? JSON.stringify(handoff) : `Companion prompt prepared for ${campaign}.`);
    return 0;
  }
  if (command === "companion-submit") {
    if (!fguDataPath) throw new Error("Fantasy Grounds data path was not found. Use --fgu-data <path>.");
    requireBothWriteFlags(options);
    if (!options.exposeWrites) throw new Error("companion-submit requires --expose-writes and --allow-writes.");
    if (!options.responseFile) throw new Error("companion-submit requires --response-file <path>.");
    if (!options.cueId) throw new Error("companion-submit requires --cue-id <id>.");
    const campaign = requireCampaign(options);
    const paths = campaignPaths({ fguDataPath, campaign });
    const snapshot = await assertReadableSnapshot(paths.snapshotPath);
    process.env.NERVE_FGU_SNAPSHOT_PATH = paths.snapshotPath;
    const [{ createNerve }, companion, { ControllerStatusStore }] = await Promise.all([
      import("../core/create-nerve.js"),
      import("../ai/companion-handoff.js"),
      import("../ai/controller-status-store.js")
    ]);
    const sessionId = `companion-${randomUUID()}`;
    const decision = await companion.readCompanionDecision(resolve(options.responseFile));
    const result = await companion.submitCompanionDecision({
      nerve: createNerve({ toolProfile: "session", enableWriteCapabilities: true, allowWrite: true }),
      snapshot,
      cueId: options.cueId,
      sessionId,
      decision
    });
    const timestamp = new Date().toISOString();
    await new ControllerStatusStore({
      statusPath: paths.controllerStatusPath,
      stopPath: paths.controllerStopPath
    }).write({
      status: "stopped",
      sessionId,
      campaign,
      provider: "companion",
      model: null,
      maxOutputTokens: 0,
      stoppedAt: timestamp,
      lastResult: {
        timestamp,
        status: result.status,
        providerCalled: false,
        decision: decision.decision,
        summary: decision.summary ?? null,
        proposedCapability: decision.action?.capabilityName ?? null,
        errorCode: result.actionResult?.error?.code ?? null,
        queued: result.status === "action_queued",
        httpStatus: null,
        validationErrors: [],
        transient: false,
        retryAfterMs: null,
        reason: null
      }
    });
    io.out(options.json ? JSON.stringify(result) : `Companion response accepted (${result.status}).`);
    return result.status === "action_rejected" ? 1 : 0;
  }
  if (command === "controller-preflight") {
    if (!fguDataPath) throw new Error("Fantasy Grounds data path was not found. Use --fgu-data <path>.");
    requireBothWriteFlags(options);
    const campaign = requireCampaign(options);
    const paths = campaignPaths({ fguDataPath, campaign });
    const snapshot = await assertReadableSnapshot(paths.snapshotPath);
    const lifecycle = controllerLifecycleOptions(options);
    const maxOutputTokens = options.maxOutputTokens ? positiveInteger(options.maxOutputTokens, "--max-output-tokens", 100000) : undefined;
    const [{ createConfiguredAiProvider }, { SessionContextReducer }, { UsageLedger }] = await Promise.all([
      import("../ai/provider-factory.js"), import("../ai/context-delta.js"), import("../ai/usage-ledger.js")
    ]);
    const provider = createConfiguredAiProvider({ provider: options.provider ?? "fake", model: options.model, maxOutputTokens });
    const cursor = {
      streamId: snapshot.recentEvents?.streamId ?? "unavailable",
      sequence: snapshot.recentEvents?.latestSequence ?? 0
    };
    const packet = new SessionContextReducer().build({
      sessionId: "controller-preflight",
      briefing: {
        campaignSummary: snapshot.campaignSummary,
        currentEncounter: snapshot.currentEncounter,
        combatTracker: snapshot.combatTracker,
        party: snapshot.party,
        mapScene: snapshot.mapScene,
        sessionContinuity: snapshot.sessionContinuity,
        sessionOperations: snapshot.sessionOperations,
        recentEvents: snapshot.recentEvents ?? { events: [] },
        cursorReset: false,
        nextCursor: cursor
      }
    });
    const authorization = new UsageLedger(lifecycle.budgets).authorize("controller-preflight", packet.approximateInputTokens, provider.maxOutputTokens ?? 0);
    const report = {
      schemaVersion: "0.1", campaign, adapterVersion: snapshot.adapterVersion ?? null,
      provider: provider.id, model: provider.model ?? null, networkCalled: false,
      writeMode: Boolean(options.exposeWrites), timeoutSeconds: lifecycle.timeoutSeconds,
      eventLimit: lifecycle.eventLimit, budgets: lifecycle.budgets,
      projectedBaselineBytes: packet.inputBytes,
      projectedBaselineTokens: packet.approximateInputTokens,
      reservedOutputTokens: provider.maxOutputTokens ?? 0,
      projectedFirstCallTokens: packet.approximateInputTokens + (provider.maxOutputTokens ?? 0),
      pulseAvailable: cursor.streamId !== "unavailable",
      budgetAllowsFirstCall: authorization.allowed,
      ready: cursor.streamId !== "unavailable" && authorization.allowed
    };
    io.out(options.json ? JSON.stringify(report, null, 2) : formatControllerPreflight(report));
    return report.ready ? 0 : 1;
  }
  if (command === "playtest-readiness") {
    if (!fguDataPath) throw new Error("Fantasy Grounds data path was not found. Use --fgu-data <path>.");
    const campaign = requireCampaign(options);
    const { assessPlaytestReadiness } = await import("../playtest/readiness.js");
    const report = await assessPlaytestReadiness({ fguDataPath, campaign, processAlive: isProcessAlive });
    io.out(options.json ? JSON.stringify(report, null, 2) : formatPlaytestReadiness(report));
    return report.readyForLivePlaytest ? 0 : 1;
  }
  if (command === "campaigns") {
    const campaigns = await discoverCampaigns(fguDataPath);
    io.out(options.json ? JSON.stringify(campaigns, null, 2) : formatCampaigns(campaigns));
    return 0;
  }

  if (command === "doctor") {
    const campaign = requireCampaign(options);
    const diagnosis = await diagnoseCampaign({ fguDataPath, campaign });
    io.out(options.json ? JSON.stringify(diagnosis, null, 2) : formatDiagnosis(diagnosis));
    return diagnosis.ok ? 0 : 1;
  }

  if (command === "session-report") {
    const campaign = requireCampaign(options);
    const paths = campaignPaths({ fguDataPath, campaign });
    const { snapshotPath } = paths;
    const snapshot = await assertReadableSnapshot(snapshotPath);
    if (!new Set(["0.7", "0.8", "0.9", "1.0", "1.1", "1.2", "1.3", "1.4"]).has(snapshot.schemaVersion) || !snapshot.sessionOperations) {
      throw new Error("The campaign does not publish v0.32 live-session operations. Reload Fantasy Grounds with the current Nerve extension.");
    }
    const [{ ControllerTelemetryStore }, { ControllerStatusStore }] = await Promise.all([
      import("../ai/controller-telemetry-store.js"),
      import("../ai/controller-status-store.js")
    ]);
    const statusStore = new ControllerStatusStore({ statusPath: paths.controllerStatusPath, stopPath: paths.controllerStopPath });
    const [controllerTelemetry, controllerStatus] = await Promise.all([
      new ControllerTelemetryStore(paths.controllerTelemetryPath).summarize(),
      statusStore.read()
    ]);
    const report = {
      campaign,
      ruleset: snapshot.campaignSummary?.ruleset ?? "unknown",
      adapterVersion: snapshot.adapterVersion ?? "unknown",
      generatedAt: snapshot.generatedAt,
      continuity: snapshot.sessionContinuity?.latest ?? null,
      aiController: {
        status: controllerStatus?.status ?? "not_started",
        provider: controllerStatus?.provider ?? controllerTelemetry.latest?.provider ?? null,
        model: controllerStatus?.model ?? controllerTelemetry.latest?.model ?? null,
        sessionId: controllerStatus?.sessionId ?? controllerTelemetry.latest?.sessionId ?? null,
        listenerState: controllerStatus?.listenerState ?? null,
        listenerLastSeenAt: controllerStatus?.listenerLastSeenAt ?? null,
        cycles: controllerTelemetry.cycles,
        providerCalls: controllerTelemetry.providerCalls,
        usage: controllerTelemetry.usage,
        failures: controllerTelemetry.failures
      },
      ...snapshot.sessionOperations,
      snapshotBytes: Buffer.byteLength(JSON.stringify(snapshot), "utf8")
    };
    report.approximateSnapshotTokens = Math.ceil(report.snapshotBytes / 4);
    io.out(options.json ? JSON.stringify(report, null, 2) : formatSessionReport(report));
    return 0;
  }

  if (command === "map-report") {
    const campaign = requireCampaign(options);
    const { snapshotPath } = campaignPaths({ fguDataPath, campaign });
    const { FileFantasyGroundsBridge } = await import("../adapters/fantasy-grounds-unity/bridge/file-bridge.js");
    const scene = await new FileFantasyGroundsBridge({ snapshotPath }).getMapScene();
    const report = { campaign, ...scene };
    io.out(options.json ? JSON.stringify(report, null, 2) : formatMapReport(report));
    return 0;
  }

  if (command === "continuity-report") {
    const campaign = requireCampaign(options);
    const { snapshotPath } = campaignPaths({ fguDataPath, campaign });
    const snapshot = await assertReadableSnapshot(snapshotPath);
    const state = snapshot.sessionContinuity ?? {};
    const history = Array.isArray(state.history) ? state.history : [];
    const report = { campaign, available: Boolean(state.latest), latest: state.latest ?? null, historyCount: history.length, observedAt: state.observedAt ?? snapshot.generatedAt };
    io.out(options.json ? JSON.stringify(report, null, 2) : formatContinuityReport(report));
    return 0;
  }

  if (command === "controller-report") {
    const campaign = requireCampaign(options);
    const paths = campaignPaths({ fguDataPath, campaign });
    const { ControllerTelemetryStore } = await import("../ai/controller-telemetry-store.js");
    const report = { campaign, ...(await new ControllerTelemetryStore(paths.controllerTelemetryPath).summarize()) };
    io.out(options.json ? JSON.stringify(report, null, 2) : formatControllerTelemetry(report));
    return report.failures === 0 ? 0 : 1;
  }

  if (command === "diagnostics") {
    if (!fguDataPath) throw new Error("Fantasy Grounds data path was not found. Use --fgu-data <path>.");
    const campaign = requireCampaign(options);
    const paths = campaignPaths({ fguDataPath, campaign });
    const snapshot = await assertReadableSnapshot(paths.snapshotPath);
    const [{ ControllerTelemetryStore }, { ControllerStatusStore }, { listConfiguredAiProviders }] = await Promise.all([
      import("../ai/controller-telemetry-store.js"), import("../ai/controller-status-store.js"), import("../ai/provider-factory.js")
    ]);
    const [telemetry, status] = await Promise.all([
      new ControllerTelemetryStore(paths.controllerTelemetryPath).summarize(),
      new ControllerStatusStore({ statusPath: paths.controllerStatusPath, stopPath: paths.controllerStopPath }).read()
    ]);
    const report = {
      schemaVersion: "0.1", generatedAt: new Date().toISOString(), privacy: "redacted-operational-metadata-only",
      environment: { node: process.version, platform: process.platform, architecture: process.arch },
      campaign: {
        name: campaign, ruleset: snapshot.campaignSummary?.ruleset ?? null,
        adapterVersion: snapshot.adapterVersion ?? null, snapshotSchemaVersion: snapshot.schemaVersion ?? null,
        snapshotGeneratedAt: snapshot.generatedAt ?? null,
        pulseAvailable: Boolean(snapshot.recentEvents?.streamId), pulseLatestSequence: snapshot.recentEvents?.latestSequence ?? null,
        sessionStatus: snapshot.sessionOperations?.status ?? null,
        connectedPlayerCount: snapshot.sessionOperations?.connectedPlayers ?? null,
        partyMemberCount: snapshot.sessionOperations?.partyMembers ?? null,
        combatantCount: snapshot.sessionOperations?.combatants ?? null,
        libraryRecordCount: snapshot.sessionOperations?.libraryIndexed ?? null,
        continuityAvailable: Boolean(snapshot.sessionContinuity?.latest),
        pendingActionCount: snapshot.sessionOperations?.pendingActions ?? null,
        pendingPlayerResponseCount: snapshot.sessionOperations?.pendingPlayerResponses ?? null,
        pendingAdjudicationCount: snapshot.sessionOperations?.pendingManualAdjudications ?? null
      },
      controller: status ? {
        status: status.status, provider: status.provider ?? null, model: status.model ?? null,
        maxOutputTokens: status.maxOutputTokens ?? 0, budgets: status.budgets ?? null,
        updatedAt: status.updatedAt, summary: status.summary ?? null, usage: status.usage ?? telemetry.usage,
        listenerState: status.listenerState ?? null,
        listenerProtocol: status.listenerProtocol ?? null,
        listenerLastSeenAt: status.listenerLastSeenAt ?? null,
        lastCueClaimedAt: status.lastCueClaimedAt ?? null,
        lastResult: status.lastResult ?? null
      } : {
        status: "not_started", provider: telemetry.latest?.provider ?? null, model: telemetry.latest?.model ?? null,
        listenerState: null, listenerProtocol: null, listenerLastSeenAt: null, lastCueClaimedAt: null,
        usage: telemetry.usage
      },
      telemetry: {
        sessionCount: telemetry.sessionCount, cycles: telemetry.cycles, providerCalls: telemetry.providerCalls,
        completed: telemetry.completed, rejected: telemetry.rejected, blocked: telemetry.blocked, failures: telemetry.failures,
        sessions: telemetry.sessions, recent: telemetry.recent
      },
      providers: listConfiguredAiProviders()
    };
    if (options.output) {
      const destination = resolve(options.output);
      await mkdir(dirname(destination), { recursive: true });
      await writeFile(destination, `${JSON.stringify(report, null, 2)}\n`, "utf8");
      io.out(options.json ? JSON.stringify({ written: true, path: destination, report }, null, 2) : `Wrote redacted Nerve diagnostics to ${destination}`);
    } else {
      io.out(options.json ? JSON.stringify(report, null, 2) : formatDiagnostics(report));
    }
    return 0;
  }

  if (new Set(["controller-start", "controller-run", "controller-status", "controller-stop"]).has(command)) {
    if (!fguDataPath) throw new Error("Fantasy Grounds data path was not found. Use --fgu-data <path>.");
    const campaign = requireCampaign(options);
    const paths = campaignPaths({ fguDataPath, campaign });
    const { ControllerStatusStore } = await import("../ai/controller-status-store.js");
    const statusStore = new ControllerStatusStore({
      statusPath: paths.controllerStatusPath,
      stopPath: paths.controllerStopPath
    });

    if (command === "controller-status") {
      const status = await statusStore.read();
      const stopRequest = await statusStore.readStopRequest();
      const report = status
        ? controllerStatusReport(status, stopRequest)
        : { schemaVersion: "0.1", campaign, status: "not_started", stopRequested: false, processAlive: false };
      io.out(options.json ? JSON.stringify(report, null, 2) : formatControllerStatus(report));
      return 0;
    }

    if (command === "controller-stop") {
      const status = await statusStore.read();
      if (!status || !new Set(["starting", "running", "stopping"]).has(status.status)) {
        io.out(`Nerve controller is not running for campaign ${campaign}.`);
        return 0;
      }
      await statusStore.requestStop({ sessionId: status.sessionId });
      io.out(`Stop requested for Nerve controller ${status.sessionId}. It will stop after the current bounded wait.`);
      return 0;
    }

    requireBothWriteFlags(options);
    const { createConfiguredAiProvider } = await import("../ai/provider-factory.js");
    const configuredProvider = createConfiguredAiProvider({
      provider: options.provider ?? "fake",
      model: options.model,
      maxOutputTokens: options.maxOutputTokens ? positiveInteger(options.maxOutputTokens, "--max-output-tokens", 100000) : undefined
    });
    const provider = configuredProvider.id;
    const lifecycle = controllerLifecycleOptions(options);
    await assertReadableSnapshot(paths.snapshotPath);

    if (command === "controller-start") {
      const current = await statusStore.read();
      if (current && new Set(["starting", "running", "stopping"]).has(current.status) && isProcessAlive(current.pid)) {
        throw new Error(`A Nerve controller is already running for ${campaign} (PID ${current.pid}).`);
      }
      const sessionId = `controller-${randomUUID()}`;
      const args = buildControllerRunArgs({ campaign, fguDataPath, options, lifecycle, sessionId });
      const child = io.spawnBackground
        ? await io.spawnBackground(process.execPath, args)
        : spawn(process.execPath, args, { cwd: repositoryRoot, detached: true, stdio: "ignore", windowsHide: true });
      if (!child?.pid) throw new Error("The controller process did not start.");
      child.unref?.();
      await statusStore.clearStopRequest();
      await statusStore.write({
        status: "starting",
        sessionId,
        campaign,
        provider,
        model: configuredProvider.model ?? null,
        maxOutputTokens: configuredProvider.maxOutputTokens ?? 0,
        budgets: lifecycle.budgets,
        pid: child.pid,
        startedAt: new Date().toISOString()
      });
      io.out(`Started Nerve controller ${sessionId} for ${campaign} (PID ${child.pid}, provider ${provider}${configuredProvider.model ? `, model ${configuredProvider.model}` : ""}).`);
      return 0;
    }

    const sessionId = options.controllerSession ?? `controller-${randomUUID()}`;
    await persistActiveCampaign(fguDataPath, campaign);
    process.env.NERVE_FGU_SNAPSHOT_PATH = paths.snapshotPath;
    process.env.NERVE_ENABLE_WRITES = options.exposeWrites ? "true" : "false";
    process.env.NERVE_ALLOW_WRITE = options.allowWrites ? "true" : "false";
    process.env.NERVE_TOOL_PROFILE = "session";
    if (options.journal) process.env.NERVE_JOURNAL_PATH = resolve(options.journal);
    const [{ createNerve }, { runControllerWorker }, { ControllerTelemetryStore }, { createFguControllerLifecycleProbe }] = await Promise.all([
      import("../core/create-nerve.js"),
      import("../ai/controller-worker.js"),
      import("../ai/controller-telemetry-store.js"),
      import("../adapters/fantasy-grounds-unity/bridge/controller-lifecycle.js")
    ]);
    const controllerSignal = new AbortController();
    const stop = () => controllerSignal.abort();
    process.once("SIGINT", stop);
    process.once("SIGTERM", stop);
    try {
      if (options.controllerSession) {
        await waitForControllerLaunch(statusStore, sessionId, process.pid);
      } else {
        await statusStore.clearStopRequest();
      }
      const summary = await runControllerWorker({
        nerve: createNerve({ toolProfile: "session" }),
        provider: configuredProvider,
        statusStore,
        campaign,
        sessionId,
        signal: controllerSignal.signal,
        telemetryStore: new ControllerTelemetryStore(paths.controllerTelemetryPath),
        lifecycleProbe: createFguControllerLifecycleProbe(paths),
        ...lifecycle
      });
      io.out(options.json ? JSON.stringify(summary, null, 2) : formatControllerSummary(summary));
      return summary.failures === 0 ? 0 : 1;
    } finally {
      process.removeListener("SIGINT", stop);
      process.removeListener("SIGTERM", stop);
    }
  }

  if (command === "config") {
    const adapter = selectedAdapter(options);
    requireBothWriteFlags(options);
    const toolProfile = options.toolProfile ?? (adapter === "fantasy-grounds-unity" ? "session" : "full");
    validateToolProfile(adapter, toolProfile);
    const args = [fileURLToPath(new URL("../bin/nerve.js", import.meta.url)), "serve"];
    if (adapter === "fantasy-grounds-unity") {
      args.push("--campaign", requireCampaign(options));
      if (options.fguData) args.push("--fgu-data", resolve(options.fguData));
    } else {
      args.push("--adapter", adapter);
    }
    if (options.journal) args.push("--journal", resolve(options.journal));
    args.push("--tool-profile", toolProfile);
    if (options.exposeWrites) args.push("--expose-writes", "--allow-writes");
    io.out(JSON.stringify({ mcpServers: { nerve: { command: process.execPath, args } } }, null, 2));
    return 0;
  }

  if (command === "install-extension") {
    if (!fguDataPath) throw new Error("Fantasy Grounds data path was not found. Use --fgu-data <path>.");
    try {
      const distribution = JSON.parse((await readFile(join(repositoryRoot, "distribution.json"), "utf8")).replace(/^\uFEFF/, ""));
      if (distribution.extensionOwner === "forge") throw new Error("Forge owns this extension. Use the Fantasy Grounds updater; Nerve will not overwrite it.");
    } catch (error) { if (error.code !== "ENOENT") throw error; }
    const { inspectNerveExtensions } = await import("./extension-installation.js");
    if ((await inspectNerveExtensions(fguDataPath)).archives.length) throw new Error("A packaged Nerve extension is installed. Update it through Fantasy Grounds; no files were changed.");
    const source = join(repositoryRoot, "adapters", "fantasy-grounds-unity", "extension");
    const destination = join(resolve(fguDataPath), "extensions", "Nerve");
    await mkdir(dirname(destination), { recursive: true });
    await cp(source, destination, { recursive: true, force: true });
    io.out(`Installed Nerve extension to ${destination}`);
    return 0;
  }

  if (command === "notify") {
    if (!fguDataPath) throw new Error("Fantasy Grounds data path was not found. Use --fgu-data <path>.");
    const { ActionInboxWatcher } = await import("../adapters/fantasy-grounds-unity/notifications/action-inbox-watcher.js");
    const { LocalActionNotifier } = await import("../adapters/fantasy-grounds-unity/notifications/local-action-notifier.js");
    const controller = new AbortController();
    const stop = () => controller.abort();
    process.once("SIGINT", stop);
    process.once("SIGTERM", stop);
    io.err(`Nerve watching Fantasy Grounds Action Inboxes under ${resolve(fguDataPath)}.`);
    try {
      const watcher = new ActionInboxWatcher({
        fguDataPath,
        notifier: new LocalActionNotifier({ enabled: process.env.NERVE_DESKTOP_NOTIFICATIONS !== "false" }),
        onError: (error) => io.err(`Nerve notifier: ${error.message}`),
        onNotification: ({ capability, campaign }) => io.err(`Nerve notifier: announced ${capability} for ${campaign}.`)
      });
      await watcher.run({ signal: controller.signal });
    } finally {
      process.removeListener("SIGINT", stop);
      process.removeListener("SIGTERM", stop);
    }
    return 0;
  }

  if (command === "serve") {
    const adapter = selectedAdapter(options);
    requireBothWriteFlags(options);
    const toolProfile = options.toolProfile ?? "full";
    validateToolProfile(adapter, toolProfile);
    let serviceDescription;
    if (adapter === "fantasy-grounds-unity") {
      const campaign = await resolveActiveCampaign(fguDataPath, requireCampaign(options));
      const { snapshotPath } = campaignPaths({ fguDataPath, campaign });
      const snapshot = await assertReadableSnapshot(snapshotPath);
      await persistActiveCampaign(fguDataPath, campaign);
      process.env.NERVE_FGU_SNAPSHOT_PATH = snapshotPath;
      serviceDescription = `campaign ${campaign} with adapter ${snapshot.adapterVersion ?? "unknown"}`;
    } else {
      process.env.NERVE_ADAPTER = adapter;
      serviceDescription = `adapter ${adapter}`;
    }
    if (options.journal) process.env.NERVE_JOURNAL_PATH = resolve(options.journal);
    process.env.NERVE_ENABLE_WRITES = options.exposeWrites ? "true" : "false";
    process.env.NERVE_ALLOW_WRITE = options.allowWrites ? "true" : "false";
    process.env.NERVE_TOOL_PROFILE = toolProfile;
    io.err(`Nerve serving ${serviceDescription}; tool profile ${toolProfile}; writes ${options.exposeWrites ? "enabled" : "disabled"}.`);
    const { runMcpServer } = await import("../link/mcp/server.js");
    await runMcpServer();
    return 0;
  }

  throw new Error(`Unknown command: ${command}`);
}

export function parseOptions(tokens) {
  const result = {};
  const valueOptions = new Map([
    ["--campaign", "campaign"], ["--fgu-data", "fguData"], ["--journal", "journal"], ["--adapter", "adapter"],
    ["--steps", "steps"], ["--seed", "seed"], ["--tool-profile", "toolProfile"],
    ["--provider", "provider"], ["--model", "model"], ["--max-cycles", "maxCycles"], ["--timeout-seconds", "timeoutSeconds"],
    ["--event-limit", "eventLimit"], ["--max-output-tokens", "maxOutputTokens"], ["--warning-tokens", "warningTokens"], ["--hard-tokens", "hardTokens"],
    ["--hard-cost-micros", "hardCostMicros"], ["--controller-session", "controllerSession"],
    ["--output", "output"], ["--input", "input"], ["--response-file", "responseFile"], ["--cue-id", "cueId"],
    ["--token-file", "tokenFile"], ["--port", "port"], ["--codex-path", "codexPath"],
    ["--app-listener", "appListener"], ["--app-listener-config", "appListenerConfig"]
  ]);
  const flags = new Map([
    ["--json", "json"], ["--help", "help"], ["-h", "help"],
    ["--expose-writes", "exposeWrites"], ["--allow-writes", "allowWrites"],
    ["--codex-app-listener", "codexAppListener"]
  ]);
  for (let index = 0; index < tokens.length; index += 1) {
    const token = tokens[index];
    if (valueOptions.has(token)) {
      const value = tokens[index + 1];
      if (!value || value.startsWith("--")) throw new Error(`${token} requires a value.`);
      result[valueOptions.get(token)] = value;
      index += 1;
    } else if (flags.has(token)) {
      result[flags.get(token)] = true;
    } else {
      throw new Error(`Unknown option: ${token}`);
    }
  }
  return result;
}

function requireCampaign(options) {
  if (!options.campaign) throw new Error("--campaign <name> is required.");
  return options.campaign;
}

function selectedAdapter(options) {
  const adapter = options.adapter ?? "fantasy-grounds-unity";
  if (!new Set(["fantasy-grounds-unity", "task-board"]).has(adapter)) {
    throw new Error(`Unknown adapter: ${adapter}`);
  }
  return adapter;
}

function requireBothWriteFlags(options) {
  if (Boolean(options.exposeWrites) !== Boolean(options.allowWrites)) {
    throw new Error("Writes require both --expose-writes and --allow-writes.");
  }
}

function controllerLifecycleOptions(options) {
  return {
    timeoutSeconds: positiveInteger(options.timeoutSeconds ?? "30", "--timeout-seconds", 55),
    eventLimit: positiveInteger(options.eventLimit ?? "25", "--event-limit", 100),
    maxCycles: options.maxCycles ? positiveInteger(options.maxCycles, "--max-cycles") : Number.POSITIVE_INFINITY,
    budgets: {
      warningTokens: optionalPositiveInteger(options.warningTokens, "--warning-tokens"),
      hardTokens: optionalPositiveInteger(options.hardTokens, "--hard-tokens"),
      hardCostMicros: optionalPositiveInteger(options.hardCostMicros, "--hard-cost-micros")
    }
  };
}

function buildControllerRunArgs({ campaign, fguDataPath, options, lifecycle, sessionId }) {
  const args = [
    fileURLToPath(new URL("../bin/nerve.js", import.meta.url)),
    "controller-run",
    "--campaign", campaign,
    "--fgu-data", resolve(fguDataPath),
    "--provider", options.provider ?? "fake",
    "--timeout-seconds", String(lifecycle.timeoutSeconds),
    "--event-limit", String(lifecycle.eventLimit),
    "--controller-session", sessionId
  ];
  if (options.model) args.push("--model", options.model);
  if (options.maxOutputTokens) args.push("--max-output-tokens", options.maxOutputTokens);
  if (Number.isFinite(lifecycle.maxCycles)) args.push("--max-cycles", String(lifecycle.maxCycles));
  if (options.journal) args.push("--journal", resolve(options.journal));
  if (options.warningTokens) args.push("--warning-tokens", options.warningTokens);
  if (options.hardTokens) args.push("--hard-tokens", options.hardTokens);
  if (options.hardCostMicros) args.push("--hard-cost-micros", options.hardCostMicros);
  if (options.exposeWrites) args.push("--expose-writes", "--allow-writes");
  return args;
}

function validateToolProfile(adapter, profile) {
  if (!new Set(["full", "session"]).has(profile)) {
    throw new Error(`Unknown tool profile: ${profile}`);
  }
  if (profile === "session" && adapter !== "fantasy-grounds-unity") {
    throw new Error("The session tool profile is only available for Fantasy Grounds.");
  }
}

function formatCampaigns(campaigns) {
  if (campaigns.length === 0) return "No Fantasy Grounds campaigns found.";
  return campaigns.map((item) => `${item.name}\t${item.snapshotAvailable ? `Nerve ${item.adapterVersion ?? "unknown"}` : "no snapshot"}`).join("\n");
}

function formatDiagnosis(value) {
  return [
    `Campaign: ${value.campaign}`,
    `Status: ${value.ok ? "ready" : "not ready"}`,
    `Extension installed: ${yesNo(value.extensionInstalled)}`,
    `Snapshot available: ${yesNo(value.snapshotAvailable)}`,
    `Adapter: ${value.adapterVersion ?? "unknown"}`,
    `Ruleset: ${value.ruleset ?? "unknown"}`,
    `Snapshot age: ${value.snapshotAgeSeconds ?? "unknown"} second(s)`,
    `Pulse stream: ${value.pulseStreamId ?? "unavailable"}`
  ].join("\n");
}

function yesNo(value) { return value ? "yes" : "no"; }
function positiveInteger(value, option, maximum = null) {
  const parsed = Number(value);
  if (!Number.isInteger(parsed) || parsed <= 0) throw new Error(`${option} must be a positive integer.`);
  if (maximum !== null && parsed > maximum) throw new Error(`${option} must be at most ${maximum}.`);
  return parsed;
}
function optionalPositiveInteger(value, option) { return value === undefined ? null : positiveInteger(value, option); }

function isProcessAlive(pid) {
  if (!Number.isInteger(pid) || pid <= 0) return false;
  try { process.kill(pid, 0); return true; } catch { return false; }
}

function controllerStatusReport(status, stopRequest) {
  const processAlive = isProcessAlive(status.pid);
  const active = new Set(["starting", "running", "stopping"]).has(status.status);
  return {
    ...status,
    effectiveStatus: active && !processAlive ? "stale" : status.status,
    stopRequested: stopRequest?.sessionId === status.sessionId,
    processAlive,
    recoveryRecommended: active && !processAlive
  };
}

async function waitForControllerLaunch(statusStore, sessionId, pid) {
  for (let attempt = 0; attempt < 80; attempt += 1) {
    const status = await statusStore.read();
    if (status?.sessionId === sessionId && status.pid === pid) return;
    await new Promise((resolveDelay) => setTimeout(resolveDelay, 25));
  }
  throw new Error("Controller launch handshake timed out.");
}

function formatPlaytest(value) {
  return [
    `Playtest: passed`, `Seed: ${value.seed}`, `Steps: ${value.steps}`,
    `Capability calls: ${value.capabilityCalls}`, `Write calls: ${value.writeCalls}`,
    `Simulated mutations: ${value.simulatedMutations}`, `Pulse stream resets observed: ${value.streamResets}`,
    `Final round: ${value.finalRound}`, `Retained events: ${value.retainedEvents}`,
    `Journal entries: ${value.journalEntries}`, `Failed calls: ${value.failedCalls}`
  ].join("\n");
}
function formatPlaytestReadiness(value) {
  return [
    `Live playtest readiness: ${value.readyForLivePlaytest ? "READY" : "NOT READY"}`,
    `Campaign: ${value.campaign}`,
    ...value.checks.map((item) => `${item.passed ? "PASS" : "FAIL"}\t${item.detail}`),
    `Controller: ${value.controller.recordedStatus}${value.controller.active ? " (active)" : ""}`,
    "Remaining manual gates:",
    ...value.manualGates.map((item) => `- ${item}`)
  ].join("\n");
}
function formatControllerSimulation(value) {
  return [
    `Controller simulation: ${value.passed ? "passed" : "failed"}`,
    `Cycles: ${value.cycles}`,
    `Provider calls: ${value.providerCalls}`,
    `Baseline packet: ${value.baselineBytes} bytes`,
    `Delta packet: ${value.deltaBytes} bytes`,
    `Unchanged sections omitted: ${value.unchangedSectionsOmitted}`,
    `Journal entries: ${value.journalEntries}`
  ].join("\n");
}
function formatControllerEvaluation(value) {
  return [
    `Controller evaluation: ${value.passed ? "passed" : "failed"}`,
    `Provider: ${value.provider}`,
    `Scenarios: ${value.passedCount}/${value.scenarioCount} passed`,
    `Packets: ${value.baselinePackets} baseline, ${value.deltaPackets} delta`,
    `Input: ${value.totalInputBytes} bytes`,
    ...value.scenarios.map((item) => `${item.passed ? "PASS" : "FAIL"}\t${item.id}\t${item.actualDecision}${item.proposedCapability ? ` -> ${item.proposedCapability}` : ""}`)
  ].join("\n");
}
function formatControllerPreflight(value) {
  return [
    `Controller preflight: ${value.ready ? "READY" : "NOT READY"}`,
    `Campaign: ${value.campaign}; adapter ${value.adapterVersion ?? "unknown"}`,
    `Provider: ${value.provider}${value.model ? ` / ${value.model}` : ""}`,
    `Network called: no`,
    `Write mode: ${value.writeMode ? "enabled" : "read-only"}`,
    `Projected first call: ${value.projectedFirstCallTokens} tokens (${value.projectedBaselineTokens} input + ${value.reservedOutputTokens} reserved output)`,
    `Hard token budget: ${value.budgets.hardTokens ?? "not set"}`,
    `Pulse: ${value.pulseAvailable ? "available" : "missing"}`,
    `Budget permits first call: ${value.budgetAllowsFirstCall ? "yes" : "no"}`
  ].join("\n");
}
function formatProviders(providers) {
  return [
    "Nerve AI providers",
    ...providers.map((item) => `${item.configured ? "READY" : "NEEDS KEY"}\t${item.id}${item.aliases.length ? ` (${item.aliases.join(", ")})` : ""}\t${item.apiKeyEnvironment ?? "offline"}${item.modelRequired ? "\tmodel required" : ""}`)
  ].join("\n");
}
function formatProviderConnection(value) {
  return [
    `Provider connection: ${value.connected ? "PASS" : "FAIL"}`,
    `Provider: ${value.provider}${value.model ? ` / ${value.model}` : ""}`,
    `Network called: ${value.networkCalled ? "yes" : "no"}`,
    `Decision contract: ${value.decision}`,
    `Elapsed: ${value.elapsedMs} ms`,
    `Tokens reported: input ${value.usage.inputTokens ?? 0}; cached ${value.usage.cachedInputTokens ?? 0}; output ${value.usage.outputTokens ?? 0}; reasoning ${value.usage.reasoningTokens ?? 0}`
  ].join("\n");
}
function formatControllerStatus(value) {
  if (value.status === "not_started") return `Nerve controller: not started for ${value.campaign}.`;
  return [
    `Nerve controller: ${value.effectiveStatus ?? value.status}`,
    `Campaign: ${value.campaign}`,
    `Session: ${value.sessionId}`,
    `Provider: ${value.provider}`,
    `Model: ${value.model ?? "none"}`,
    `Token budget: warning ${value.budgets?.warningTokens ?? "none"}; hard ${value.budgets?.hardTokens ?? "none"}; output reservation ${value.maxOutputTokens ?? 0}`,
    `PID: ${value.pid} (${value.processAlive ? "alive" : "not running"})`,
    `Stop requested: ${value.stopRequested ? "yes" : "no"}`,
    `Cycles: ${value.summary?.cycles ?? 0}`,
    `Provider calls: ${value.summary?.providerCalls ?? 0}`
  ].join("\n");
}
function formatControllerSummary(value) {
  return [
    `Nerve controller stopped`,
    `Session: ${value.sessionId}`,
    `Cycles: ${value.cycles}`,
    `Provider calls: ${value.providerCalls}`,
    `Completed: ${value.completed}`,
    `Rejected: ${value.rejected}`,
    `Blocked: ${value.blocked}`,
    `Failures: ${value.failures}`
  ].join("\n");
}
function formatControllerTelemetry(value) {
  return [
    `Nerve controller telemetry for ${value.campaign}`,
    `Cycles: ${value.cycles}`,
    `Provider calls: ${value.providerCalls}`,
    `Completed: ${value.completed}`,
    `Rejected: ${value.rejected}`,
    `Blocked: ${value.blocked}`,
    `Failures: ${value.failures}`,
    `Tokens: ${value.usage?.totalTokens ?? 0}`,
    `Cost: ${value.usage?.costMicros ?? 0} micros`,
    `Telemetry: ${value.path}`
  ].join("\n");
}
function formatDiagnostics(value) {
  return [
    "Nerve redacted diagnostics",
    `Generated: ${value.generatedAt}`,
    `Node: ${value.environment.node}; ${value.environment.platform}/${value.environment.architecture}`,
    `Campaign: ${value.campaign.name}; ${value.campaign.ruleset ?? "unknown"}`,
    `Adapter/schema: ${value.campaign.adapterVersion ?? "unknown"} / ${value.campaign.snapshotSchemaVersion ?? "unknown"}`,
    `Pulse: ${value.campaign.pulseAvailable ? `available at ${value.campaign.pulseLatestSequence}` : "missing"}`,
    `Counts: ${value.campaign.connectedPlayerCount ?? 0} player(s), ${value.campaign.partyMemberCount ?? 0} party, ${value.campaign.combatantCount ?? 0} combatants, ${value.campaign.libraryRecordCount ?? 0} library`,
    `Controller: ${value.controller.status}; ${value.controller.provider ?? "none"}${value.controller.model ? ` / ${value.controller.model}` : ""}`,
    `Controller telemetry: ${value.telemetry.providerCalls} call(s), ${value.telemetry.failures} failure(s)`,
    "Private campaign prose, events, character names, map names, action arguments, and credentials are excluded."
  ].join("\n");
}
function formatSessionReport(value) {
  return [
    "# Nerve Live Session Report", "",
    `Campaign: ${value.campaign}`, `Ruleset: ${value.ruleset}`, `Adapter: ${value.adapterVersion}`,
    `Status: ${value.status}${value.held ? " (ON HOLD)" : ""}`, `Session ID: ${value.sessionId || "not started"}`,
    `Approval policy: ${value.approvalPolicy?.mode ?? "manual"}`,
    `Automatic capabilities: ${value.approvalPolicy?.automaticCapabilities?.join(", ") || "none"}`,
    `Started: ${value.startedAt || "not started"}`, `Ended: ${value.endedAt || "not ended"}`, "",
    `Actions processed: ${value.actionsProcessed}`, `Approved: ${value.approved}`, `Denied: ${value.denied}`,
    `Failed: ${value.failed}`, `Session-grant executions: ${value.sessionGrantExecutions}`, "",
    `Connected players: ${value.connectedPlayers}`, `Party members: ${value.partyMembers}`,
    `Combatants: ${value.combatants}`, `Library records indexed: ${value.libraryIndexed}`,
    `Pending player responses: ${value.pendingPlayerResponses}`,
    `Pending manual adjudications: ${value.pendingManualAdjudications}`, "",
    `Current snapshot payload: ${value.snapshotBytes} bytes (~${value.approximateSnapshotTokens} tokens at 4 bytes/token)`,
    `Continuity: ${value.continuity ? `${value.continuity.source} checkpoint from ${value.continuity.sessionId}` : "not available"}`,
    `AI controller: ${value.aiController.status}; ${value.aiController.provider ?? "none"}${value.aiController.model ? ` / ${value.aiController.model}` : ""}`,
    `AI usage: ${value.aiController.providerCalls} call(s), ${value.aiController.usage?.totalTokens ?? 0} token(s), ${value.aiController.failures} failure(s)`,
    "", value.summary
  ].join("\n");
}
function formatMapReport(value) {
  const nearest = value.spatial.nearestVisibleHostile;
  return [
    `Nerve map report for ${value.campaign}`,
    `Map: ${value.name || "none"} (${value.recordId ?? "no record"})`,
    `Scene: ${value.playStyle}; shared ${value.shareMode}; panel ${value.panel}`,
    `Grid: ${value.grid.enabled ? `${value.grid.sizeX} x ${value.grid.sizeY}` : "disabled"}`,
    `Tokens: party ${value.spatial.partyTokenCount}, foes ${value.spatial.foeTokenCount}, neutral ${value.spatial.neutralTokenCount}, unlinked ${value.spatial.unlinkedTokenCount}`,
    `Current area: ${value.areaContinuity.currentAreaKey ?? "unknown"}`,
    `Nearest player-visible hostile: ${nearest ? `${nearest.name} at ${nearest.distanceGridUnits?.toFixed(2) ?? "unknown"} grid units` : "unknown"}`,
    ...value.spatial.placementWarnings.map((warning) => `WARNING: ${warning}`),
    ...value.spatial.limitations.map((limitation) => `LIMIT: ${limitation}`)
  ].join("\n");
}
function formatContinuityReport(value) {
  if (!value.latest) return `No session continuity checkpoint is available for ${value.campaign}.`;
  const facts = value.latest.facts ?? {};
  const scene = facts.scene ?? {};
  return [
    `Nerve continuity for ${value.campaign}`,
    `Session: ${value.latest.sessionId}`,
    `Source: ${value.latest.source}`,
    `Created: ${value.latest.createdAt}`,
    `Summary: ${value.latest.summary}`,
    `Current situation: ${value.latest.currentSituation}`,
    `Map/area: ${value.latest.map.name || "none"} / ${value.latest.map.currentAreaKey ?? "unknown"}`,
    `Unresolved threads: ${value.latest.unresolvedThreads.length}`,
    `Party goals: ${value.latest.partyGoals.length}`,
    `Important NPCs: ${value.latest.importantNpcs.length}`,
    `Next opening: ${value.latest.nextSessionOpening || "not supplied"}`,
    `Factual handoff: ${(facts.party ?? []).length} party member(s), ${(facts.combatants ?? []).length} combatant(s), ${(facts.pendingAdjudications ?? []).length} pending adjudication(s)`,
    `Party/foe areas: ${(scene.partyAreaKeys ?? []).join("/") || "unknown"} / ${(scene.foeAreaKeys ?? []).join("/") || "unknown"}`,
    `Retained checkpoints: ${value.historyCount}`
  ].join("\n");
}
function formatProviderAcceptance(value) {
  return [
    "Nerve cross-provider acceptance",
    `Network called: ${value.networkCalled ? "yes" : "no"}`,
    `Providers: ${value.passedProviders}/${value.providerCount} passed`,
    `Cases: ${value.cases}`,
    ...value.providers.map((provider) => `${provider.passed ? "PASS" : "FAIL"}: ${provider.id} (${provider.requestCount} structured decisions)`)
  ].join("\n");
}
function defaultIo() { return { out: (value) => process.stdout.write(`${value}\n`), err: (value) => process.stderr.write(`${value}\n`) }; }

function helpText() {
  return helpTextBase()
    .replace("fake|openai|anthropic|gemini|xai", "fake|ollama|openai|anthropic|gemini|xai")
    .replace(
      "the offline fake provider and bring-your-own-key",
      "the offline fake provider, optional local Ollama, and bring-your-own-key"
    )
    .replace(
      "Real providers require an explicit model ID.",
      "AI providers require an explicit model ID; Ollama never falls back to a paid service automatically."
    );
}

function helpTextBase() {
  return `Nerve local middleware\n\nCommands:\n  nerve campaigns [--fgu-data <path>] [--json]\n  nerve doctor --campaign <name> [--fgu-data <path>] [--json]\n  nerve diagnostics --campaign <name> [--fgu-data <path>] [--output <file>] [--json]\n  nerve session-report --campaign <name> [--fgu-data <path>] [--json]\n  nerve map-report --campaign <name> [--fgu-data <path>] [--json]\n  nerve continuity-report --campaign <name> [--fgu-data <path>] [--json]\n  nerve controller-report --campaign <name> [--fgu-data <path>] [--json]\n  nerve providers [--json]\n  nerve controller-preflight --campaign <name> --provider <id> [--model <id>] [--hard-tokens <count>] [--max-output-tokens <count>] [--json]\n  nerve serve --campaign <name> [--fgu-data <path>] [--journal <path>] [--tool-profile full|session]\n  nerve serve --adapter task-board [--journal <path>]\n  nerve config --campaign <name> [--fgu-data <path>] [--journal <path>] [--tool-profile full|session]\n  nerve config --adapter task-board [--journal <path>]\n  nerve controller-simulate [--json]\n  nerve controller-evaluate [--json]\n  nerve package-preview [--output <repository-subdirectory>] [--json]\n  nerve package-verify --input <directory-or-zip> [--json]\n  nerve playtest-readiness --campaign <name> [--fgu-data <path>] [--json]\n  nerve controller-start --campaign <name> [--provider fake|openai|anthropic|gemini|xai] [--model <id>] [--max-output-tokens <count>] [--timeout-seconds <1-55>] [--max-cycles <count>]\n  nerve controller-status --campaign <name> [--json]\n  nerve controller-stop --campaign <name>\n  nerve controller-run --campaign <name> [controller options]\n  nerve install-extension [--fgu-data <path>]\n  nerve notify [--fgu-data <path>]\n  nerve playtest [--steps <count>] [--seed <number>] [--json]\n\nDiagnostics exports redacted operational metadata without campaign prose, names, events, arguments, or credentials. Controller preflight validates configuration and estimates the first-call token reservation without contacting an AI API. Package verification validates every manifest payload and archive sidecar without extracting it. The supervised controller supports the offline fake provider and bring-your-own-key OpenAI/ChatGPT, Anthropic/Claude, Google Gemini, and xAI/Grok providers. Real providers require an explicit model ID. Generated Fantasy Grounds configs default to the smaller session tool profile. Use full for maintenance or uncommon actions. Write mode requires both --expose-writes and --allow-writes on serve, config, or controller commands.\nFantasy Grounds remains the final approval boundary through its Nerve panel.`;
}
