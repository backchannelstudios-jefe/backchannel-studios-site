# Alpha deployment decisions

Owner direction: proceed with Forge submission without waiting for an email reply; comply with Forge moderation. Free alpha with optional donations; future paid products may be announced separately. No promise of a paid conversion of the existing free listing.

Owner-provided studio website: https://www.thebackchannel.studio/ . Its homepage already mentions Nerve. Proposed role: public landing page, companion download, setup instructions, release notes and support information. No new page or download URL has been deployed or verified.

Owner supplied the public donation URL: https://buymeacoffee.com/backchannelstudios . Use this for optional support; never publish the dashboard link.

These decisions update source listing drafts. The 0.67.0 archive is superseded by the 0.67.1 ownership-fix bundle. Public website/download/support URLs and usage terms remain to be finalized.
