# Forge submission checklist — 0.67.1 alpha

Prepared for owner review; nothing uploaded or published.

Artifacts: Nerve-0.67.1-alpha.ext is the Forge build. Nerve-Windows-Companion-0.67.1-alpha.zip is a separate external download, not a Forge upload. The outer submission ZIP is an owner handoff only.

Official requirements checked September 10, 2026:
- Extension packages are ZIP archives with .ext suffix and extension.xml at their root.
- Forge build upload accepts Fantasy Grounds packages and documented allowed file types; JS and PowerShell are outside that list.
- Manage Builds provides Live, Test and No Channel. Public availability is subject to review.
Sources: https://fantasygroundsunity.atlassian.net/wiki/spaces/FGCP/pages/1937768449 and https://fantasygroundsunity.atlassian.net/wiki/spaces/FGCP/pages/1916633089

Before public listing:
1. Set price (free alpha suggested for feedback, owner decides), author attribution, license/usage terms and support expectations.
2. Supply a stable companion download URL and support thread. Put required companion/AI dependencies at the top of listing text.
3. Ask SmiteWorks to review the required external-runtime arrangement. Do not describe it as approved until accepted. Review the applicable Crafter terms in the account.
4. Extension ownership is implemented: the Forge companion preserves .ext files and rejects conflicting unpacked copies before changes. Select Data installation; encrypted Vault is not supported by the manifest checks. Temporary-directory fresh-install/update/conflict tests pass. Actual Forge delivery and clean-profile validation remain pending.
5. Confirm rights/provenance for bundled code and artwork and choose public licensing. No license was invented in this packaging pass.
6. Add original, spoiler-free screenshots; Forge documents PNG/JPG images up to 300 KB. Do not use the private playtest screenshots.
7. Create/review the draft item, upload only the .ext for moderation, and verify the review/Test path before selecting Live.

Known readiness limits: local source tests and package checks passed; clean-user Forge installation, remote multiplayer and public update lifecycle have not been certified. Quest completion display and inventory/currency automation remain limited. These are disclosed in the listing.

Suggested message for Developer Relations (draft only):
We would like to submit Nerve, an early-alpha Windows/5E AI-assisted play extension. Its .ext connects to a required separately downloaded local Node.js/PowerShell companion, which uses a user-selected external AI provider and explicit FGU action approvals. Is this dependency/distribution arrangement acceptable on Forge, and what installation/update or disclosure requirements should we follow? We can supply the package and setup documentation for review.
