# Nerve — Early Alpha for Fantasy Grounds 5E

Requires a Windows GM host, Fantasy Grounds with the 5E ruleset, the separate Nerve Windows companion, Node.js 22 or newer, and a compatible AI account/application. The Forge extension alone does not run an AI. AI usage is provided by your chosen provider, not included with Nerve.

Nerve connects AI assistance to a Fantasy Grounds campaign: contextual narration, Story Cue references, session memory, player prompts and rolls, and supported guarded actions. Use it for solo exploration or GM-assisted experimentation. This is an early alpha, not a replacement for GM judgment or a promise of fully automated play.

New sessions default to Flow Mode for supported narration, proxy actions and pacing, including supported exact-source encounters. Use Disable Flow Mode for manual approval. Guarded actions such as quest changes and resource changes still require approval. Review the action itself before approving.

## Current limitations

- Narration is not proof that a native record changed. Inventory purchases and currency bookkeeping are not an automatic transaction workflow in this build.
- Quest updates can be approved, but completion status is not clearly visible in the standard quest UI. Confirm actual state; do not assume approval equals a complete workflow.
- AI responses can be wrong, contradict earlier narration, repeat decisions, or misinterpret source references. Check important outcomes against your own materials.
- Provider latency and usage limits vary. Built-in listeners normally time out after three minutes. Grok rate limits can currently appear as APP_LISTENER_PROTOCOL_FAILED; inspect the detailed message before retrying.
- Codex, Gemini/Antigravity and Grok have received local playtesting; coverage is uneven. Claude and multiplayer behavior are not certified by this release. Windows/5E is the target; other operating systems and rulesets are not claimed supported.
- Setup/recovery and extension compatibility remain alpha areas. Use a backed-up test campaign.

## Privacy and usage

Nerve runs a local bridge, but selected campaign context, references and GM-only material can be sent to the selected external AI provider. Provider terms and retention apply. Obtain your group's agreement before using their material with AI. GM-only means hidden from player-facing narration, not hidden from the provider. Do not supply passwords or credentials in game chat. Repeated calls, tests and retries may consume provider allowance or incur charges.

## Feedback wanted

Please report setup failures, confusing status messages, scene continuity, source fidelity, response times, and whether approved actions actually appeared in Fantasy Grounds. See FEEDBACK.md. This alpha does not promise response-time guarantees or a support SLA.

## Free alpha and optional support

Nerve is free during alpha. Feedback is welcome. Optional donations support development and do not unlock features or priority treatment. Future stable releases or additional products may be paid; pricing and availability will be announced separately.

Studio website: https://www.thebackchannel.studio/

Optional support: https://buymeacoffee.com/backchannelstudios

Publication fields still to supply: companion download URL, support thread URL, license/usage terms and final author attribution. This file is listing copy for review, not an already published listing.
