@echo off
setlocal
call "%~dp0scripts\Start-Nerve.cmd" %*
exit /b %ERRORLEVEL%

