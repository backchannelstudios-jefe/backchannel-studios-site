import { createNerve } from "../core/create-nerve.js";
import { MemoryJournal } from "../core/journal.js";
import { SimulatedFantasyGroundsBridge } from "./simulated-fgu-bridge.js";

export async function runPlaytest({ steps = 500, seed = 42 } = {}) {
  const random = createRandom(seed);
  let tick = 0;
  const clock = () => new Date(Date.UTC(2026, 7, 12, 12, 0, tick++));
  const bridge = new SimulatedFantasyGroundsBridge({ clock });
  const journal = new MemoryJournal();
  const nerve = createNerve({ bridge, journal, enableWriteCapabilities: true, allowWrite: true, clock });
  const metrics = { steps, seed, capabilityCalls: 0, writeCalls: 0, simulatedMutations: 0, streamResets: 0, validationFailures: 0 };
  let cursor = 0;
  let streamId = bridge.streamId;

  for (let step = 1; step <= steps; step += 1) {
    const choice = Math.floor(random() * 12);
    if (choice <= 5) {
      const calls = [
        ["get_campaign_summary", {}], ["get_combat_tracker", {}], ["get_party", {}],
        ["get_character", { id: random() < 0.5 ? "id-00001" : "id-00003" }], ["get_current_encounter", {}],
        ["get_recent_events", { afterSequence: cursor, limit: 100 }]
      ];
      const [capabilityName, args] = calls[choice];
      const result = await call(nerve, capabilityName, args, metrics);
      if (capabilityName === "get_recent_events") {
        if (result.data.streamId !== streamId) {
          streamId = result.data.streamId;
          cursor = 0;
          metrics.streamResets += 1;
        }
        cursor = result.data.latestSequence;
      }
    } else if (choice === 6) {
      const tracker = await bridge.getCombatTracker();
      await call(nerve, "advance_turn", { expectedActiveCombatantId: tracker.combatants.find((item) => item.active).id, confirmed: true }, metrics, true);
    } else if (choice === 7) {
      await call(nerve, "send_chat", { text: `Playtest message ${step}`, visibility: random() < 0.2 ? "gm" : "all", confirmed: true }, metrics, true);
    } else if (choice === 8) {
      const target = pick(bridge.combatants, random);
      await call(nerve, "apply_effect", { combatantId: target.id, label: `Test Effect ${step}`, duration: step % 5, gmOnly: random() < 0.25, confirmed: true }, metrics, true);
    } else if (choice === 9) {
      bridge.simulateDamage(pick(bridge.combatants, random).id, random() < 0.35 ? -3 : 4);
      metrics.simulatedMutations += 1;
    } else if (choice === 10) {
      bridge.simulateRoll(pick(["roll.attack", "roll.save", "roll.skill", "roll.damage"], random), pick(bridge.combatants, random).id, 1 + Math.floor(random() * 20));
      metrics.simulatedMutations += 1;
    } else {
      bridge.simulateReload();
      metrics.simulatedMutations += 1;
    }
    assertInvariants(bridge);
  }

  const finalEvents = await call(nerve, "get_recent_events", { afterSequence: 0, limit: 100 }, metrics);
  return {
    ...metrics,
    finalRound: bridge.round,
    finalStreamId: finalEvents.data.streamId,
    retainedEvents: finalEvents.data.events.length,
    latestSequence: finalEvents.data.latestSequence,
    journalEntries: journal.entries.length,
    succeededCalls: journal.entries.filter((entry) => entry.event === "capability.succeeded").length,
    failedCalls: journal.entries.filter((entry) => entry.event === "capability.failed").length
  };
}

async function call(nerve, capabilityName, argumentsValue, metrics, write = false) {
  const result = await nerve.runtime.call({ capabilityName, arguments: argumentsValue, sessionId: "playtest" });
  metrics.capabilityCalls += 1;
  if (write) metrics.writeCalls += 1;
  if (!result.ok) throw new Error(`${capabilityName} failed: ${result.error.code} ${result.error.message}`);
  return result;
}

function assertInvariants(bridge) {
  const activeCount = bridge.combatants.filter((_, index) => index === bridge.activeIndex).length;
  if (activeCount !== 1) throw new Error("Playtest invariant failed: exactly one active combatant is required.");
  for (const combatant of bridge.combatants) {
    if (combatant.hitPoints.wounds < 0 || combatant.hitPoints.wounds > combatant.hitPoints.total) {
      throw new Error(`Playtest invariant failed: invalid wounds for ${combatant.id}.`);
    }
  }
  for (let index = 1; index < bridge.events.length; index += 1) {
    if (bridge.events[index].sequence !== bridge.events[index - 1].sequence + 1) {
      throw new Error("Playtest invariant failed: Pulse event sequence has a gap.");
    }
  }
}

function createRandom(seed) {
  let state = seed >>> 0;
  return () => {
    state = (state * 1664525 + 1013904223) >>> 0;
    return state / 0x100000000;
  };
}

function pick(values, random) { return values[Math.floor(random() * values.length)]; }
