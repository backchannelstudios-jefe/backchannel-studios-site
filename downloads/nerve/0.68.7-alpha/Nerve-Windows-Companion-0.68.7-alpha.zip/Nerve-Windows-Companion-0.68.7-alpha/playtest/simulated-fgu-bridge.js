import { NerveError } from "../core/errors.js";

export class SimulatedFantasyGroundsBridge {
  constructor({ clock = () => new Date() } = {}) {
    this.clock = clock;
    this.round = 1;
    this.activeIndex = 0;
    this.streamGeneration = 1;
    this.eventSequence = 0;
    this.events = [];
    this.effectSequence = 0;
    this.combatants = [
      combatant("id-00001", "Aria", "friend", 18, 28),
      combatant("id-00002", "Goblin", "foe", 15, 14),
      combatant("id-00003", "Borin", "friend", 12, 34),
      combatant("id-00004", "Ogre", "foe", 8, 59)
    ];
    this.#event("adapter.started", "", "simulation started", "gm", "", {});
  }

  async getCampaignSummary() {
    return {
      campaignId: "simulated-campaign", name: "Simulated Campaign", ruleset: "5E",
      connectedPlayers: 2, inCombat: true, activeEncounterId: "combat-tracker", observedAt: this.#now()
    };
  }

  async getCombatTracker() {
    return {
      round: this.round,
      combatants: this.combatants.map((item, index) => ({ ...structuredClone(item), active: index === this.activeIndex })),
      observedAt: this.#now()
    };
  }

  async getParty() {
    return {
      members: [partyMember("id-00001", "Aria", "Ranger 4", 28), partyMember("id-00003", "Borin", "Cleric 4", 34)],
      observedAt: this.#now()
    };
  }

  async getCharacter(id) {
    const member = (await this.getParty()).members.find((item) => item.id === id);
    if (!member) throw new NerveError("CHARACTER_NOT_FOUND", `Fantasy Grounds character not found: ${id}`, { id });
    return character(member);
  }

  async getCurrentEncounter() {
    const tracker = await this.getCombatTracker();
    const participants = tracker.combatants.map(({ id, name, faction, active, hitPoints }) => {
      const disposition = hitPoints.total > 0 && hitPoints.wounds >= hitPoints.total ? "defeated" : "active";
      return { id, name, faction, active, disposition, threat: faction === "foe" && disposition === "active" };
    });
    const activeFoeCount = participants.filter((item) => item.threat).length;
    return {
      active: activeFoeCount > 0, id: activeFoeCount > 0 ? "combat-tracker" : null, round: this.round,
      activeCombatantId: participants.find((item) => item.active).id,
      participantCount: participants.length,
      friendlyCount: participants.filter((item) => item.faction === "friend").length,
      foeCount: participants.filter((item) => item.faction === "foe").length,
      activeFoeCount,
      neutralCount: 0, participants, observedAt: this.#now()
    };
  }

  async getRecentEvents({ afterSequence = 0, limit = 50, types } = {}) {
    const typeSet = types ? new Set(types) : null;
    return {
      events: this.events.filter((event) => event.sequence > afterSequence).filter((event) => !typeSet || typeSet.has(event.type)).slice(-limit),
      streamId: this.streamId,
      latestSequence: this.eventSequence,
      observedAt: this.#now()
    };
  }

  async sendChat({ text, visibility }) {
    this.#event("chat.message", "Nerve", text, visibility, "", { mode: "chat" });
    return { delivered: true, text, visibility, executedAt: this.#now() };
  }

  async requestPlayerInput({ responseType, audience, recipients = [] }, context) {
    return {
      opened: true,
      promptId: context.requestId,
      responseType,
      audience,
      recipients: audience === "gm" ? ["GM"] : recipients,
      deadlineAt: this.#now(),
      executedAt: this.#now()
    };
  }

  async advanceTurn({ expectedActiveCombatantId, skipDefeated = false }) {
    const previous = this.combatants[this.activeIndex];
    if (previous.id !== expectedActiveCombatantId) {
      throw new NerveError("STATE_CONFLICT", "The active combatant changed before execution.");
    }
    this.activeIndex = (this.activeIndex + 1) % this.combatants.length;
    const skippedCombatantIds = [];
    let attempts = 0;
    while (skipDefeated && this.combatants[this.activeIndex].disposition !== "active" && attempts < this.combatants.length) {
      skippedCombatantIds.push(this.combatants[this.activeIndex].id);
      this.activeIndex = (this.activeIndex + 1) % this.combatants.length;
      attempts += 1;
    }
    if (this.activeIndex === 0) {
      const previousRound = this.round;
      this.round += 1;
      this.#event("combat.round_changed", "", `Round changed to ${this.round}`, "all", "combat-tracker", { previousRound, round: this.round });
    }
    const active = this.combatants[this.activeIndex];
    this.#event("combat.turn_started", active.name, `Turn started: ${active.name}`, "all", active.id, { previousCombatantId: previous.id, round: this.round });
    return { previousCombatantId: previous.id, activeCombatantId: active.id, round: this.round, skippedCombatantIds, executedAt: this.#now() };
  }

  async startEncounter({ expectedCombatantIds, expectedRound }) {
    const actualIds = this.combatants.map(({ id }) => id);
    if (expectedRound !== this.round || JSON.stringify([...expectedCombatantIds].sort()) !== JSON.stringify([...actualIds].sort())) {
      throw new NerveError("STATE_CONFLICT", "The encounter roster or round changed before execution.");
    }
    this.activeIndex = 0;
    return {
      started: true, round: this.round, activeCombatantId: this.combatants[0].id,
      initiativeOrder: this.combatants.map((entry) => ({ combatantId: entry.id, name: entry.name, initiative: entry.initiative, playerVisible: entry.faction === "friend" })),
      executedAt: this.#now()
    };
  }

  async applyEffect({ combatantId, label, duration, gmOnly }) {
    const target = this.#combatant(combatantId);
    const effect = { id: `effect-${++this.effectSequence}`, label, duration, initiative: target.initiative, active: true, gmOnly };
    target.effects.push(effect);
    this.#event("combat.effect_added", target.name, `Effect added: ${label}`, gmOnly ? "gm" : "all", target.id, { effectId: effect.id, label, duration });
    return { combatantId, effectId: effect.id, label, duration, gmOnly, executedAt: this.#now() };
  }

  simulateDamage(combatantId, amount) {
    const target = this.#combatant(combatantId);
    const previous = target.hitPoints.wounds;
    target.hitPoints.wounds = Math.min(target.hitPoints.total, Math.max(0, previous + amount));
    const delta = target.hitPoints.wounds - previous;
    if (delta > 0) this.#event("combat.damage", target.name, `${target.name} took ${delta} wound(s)`, "all", target.id, { amount: delta, wounds: target.hitPoints.wounds, totalHitPoints: target.hitPoints.total });
    if (delta < 0) this.#event("combat.healing", target.name, `${target.name} recovered ${-delta} wound(s)`, "all", target.id, { amount: -delta, wounds: target.hitPoints.wounds, totalHitPoints: target.hitPoints.total });
  }

  simulateRoll(type, actorId, total) {
    const actor = this.#combatant(actorId);
    this.#event(type, actor.name, `${type} total ${total}`, "all", actor.id, { total });
  }

  simulateReload() {
    this.streamGeneration += 1;
    this.eventSequence = 0;
    this.events = [];
    this.#event("adapter.started", "", "simulation reloaded", "gm", "", {});
  }

  get streamId() { return `simulated-stream-${this.streamGeneration}`; }

  #combatant(id) {
    const value = this.combatants.find((item) => item.id === id);
    if (!value) throw new NerveError("COMBATANT_NOT_FOUND", `Combatant not found: ${id}`);
    return value;
  }

  #event(type, actor, text, visibility, subjectId, data) {
    this.events.push({ sequence: ++this.eventSequence, type, timestamp: this.#now(), actor, text, visibility, subjectId, data });
    if (this.events.length > 100) this.events.shift();
  }

  #now() { return this.clock().toISOString(); }
}

function combatant(id, name, faction, initiative, total) {
  return { id, name, type: "humanoid", faction, initiative, active: false, status: "Healthy", hitPoints: { total, temporary: 0, wounds: 0 }, effects: [] };
}

function partyMember(id, name, classLevel, total) {
  const ability = (score, modifier) => ({ score, modifier });
  return {
    id, name, race: "Human", classLevel, armorClass: 16, passivePerception: 14,
    abilities: { strength: ability(14, 2), dexterity: ability(16, 3), constitution: ability(14, 2), intelligence: ability(10, 0), wisdom: ability(14, 2), charisma: ability(10, 0) },
    experience: { current: 2700, nextLevel: 6500 }, hitDice: { total: 4, used: 0 }, hitPoints: { total, wounds: 0 }, senses: ""
  };
}

function character(member) {
  const ability = ({ score, modifier }) => ({ score, modifier, save: modifier, saveProficient: false });
  return {
    id: member.id, name: member.name, race: member.race, background: "Adventurer", alignment: "Neutral Good", deity: "", level: 4,
    proficiencyBonus: 2, armorClass: member.armorClass, initiative: 3, speed: 30, inspiration: false, size: "Medium", senses: member.senses,
    experience: member.experience, hitPoints: { total: member.hitPoints.total, temporary: 0, wounds: 0, deathSaveSuccesses: 0, deathSaveFailures: 0 },
    abilities: Object.fromEntries(Object.entries(member.abilities).map(([key, value]) => [key, ability(value)])),
    classes: [{ name: member.classLevel.split(" ")[0], level: 4, hitDie: "d10", usedHitDice: 0 }],
    skills: [{ name: "Perception", ability: "wisdom", modifier: 4, proficiency: 1 }], languages: ["Common"], proficiencies: ["Simple weapons"],
    referenceLinks: []
  };
}
