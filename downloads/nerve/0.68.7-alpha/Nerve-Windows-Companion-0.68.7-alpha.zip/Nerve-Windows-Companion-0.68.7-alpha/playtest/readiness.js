import { runControllerEvaluation } from "../ai/controller-evaluation.js";
import { ControllerStatusStore } from "../ai/controller-status-store.js";
import { ControllerTelemetryStore } from "../ai/controller-telemetry-store.js";
import { campaignPaths, diagnoseCampaign } from "../cli/paths.js";

export async function assessPlaytestReadiness({
  fguDataPath,
  campaign,
  processAlive = () => false,
  expectedAdapterVersion = "0.42.1",
  expectedSnapshotSchema = "1.4",
  maximumSnapshotAgeSeconds = 300
}) {
  const paths = campaignPaths({ fguDataPath, campaign });
  const [campaignDiagnosis, controllerEvaluation] = await Promise.all([
    diagnoseCampaign({ fguDataPath, campaign }),
    runControllerEvaluation()
  ]);
  const statusStore = new ControllerStatusStore({ statusPath: paths.controllerStatusPath, stopPath: paths.controllerStopPath });
  const telemetryStore = new ControllerTelemetryStore(paths.controllerTelemetryPath);
  const [status, telemetry] = await Promise.all([statusStore.read(), telemetryStore.summarize()]);
  const controllerActive = Boolean(status && new Set(["starting", "running", "stopping"]).has(status.status) && processAlive(status.pid));
  const checks = [
    check("campaign", campaignDiagnosis.campaignExists, "Fantasy Grounds campaign exists"),
    check("extension", campaignDiagnosis.extensionInstalled, "Nerve extension is installed"),
    check("snapshot", campaignDiagnosis.snapshotAvailable, "Campaign snapshot is readable"),
    check("adapter-version", campaignDiagnosis.adapterVersion === expectedAdapterVersion, `Adapter is ${expectedAdapterVersion} (observed ${campaignDiagnosis.adapterVersion ?? "none"})`),
    check("snapshot-schema", campaignDiagnosis.snapshotSchemaVersion === expectedSnapshotSchema, `Snapshot schema is ${expectedSnapshotSchema} (observed ${campaignDiagnosis.snapshotSchemaVersion ?? "none"})`),
    check("snapshot-freshness", campaignDiagnosis.snapshotAgeSeconds !== null && campaignDiagnosis.snapshotAgeSeconds <= maximumSnapshotAgeSeconds, `Snapshot is at most ${maximumSnapshotAgeSeconds} seconds old (observed ${campaignDiagnosis.snapshotAgeSeconds ?? "unknown"})`),
    check("pulse", Boolean(campaignDiagnosis.pulseStreamId), "Pulse event stream is available"),
    check("controller-evaluation", controllerEvaluation.passed, `${controllerEvaluation.passedCount}/${controllerEvaluation.scenarioCount} offline controller scenarios passed`)
  ];
  return {
    schemaVersion: "0.1",
    campaign,
    readyForLivePlaytest: checks.every((item) => item.passed),
    livePlaytestRequired: true,
    checks,
    campaignDiagnosis,
    expectedAdapterVersion,
    expectedSnapshotSchema,
    maximumSnapshotAgeSeconds,
    controllerEvaluation: {
      passed: controllerEvaluation.passed,
      passedCount: controllerEvaluation.passedCount,
      scenarioCount: controllerEvaluation.scenarioCount,
      totalInputBytes: controllerEvaluation.totalInputBytes,
      usage: controllerEvaluation.usage
    },
    controller: {
      recordedStatus: status?.status ?? "not_started",
      active: controllerActive,
      telemetryCycles: telemetry.cycles
    },
    manualGates: [
      "Connect a real GM and player client.",
      "Confirm Call Nerve wake/answer behavior and visibility routing.",
      "Approve, deny, hold, and resume harmless live actions.",
      "Run the ten scenarios with the selected real AI host and compare its report."
    ]
  };
}

function check(id, passed, detail) { return { id, passed: Boolean(passed), detail }; }
