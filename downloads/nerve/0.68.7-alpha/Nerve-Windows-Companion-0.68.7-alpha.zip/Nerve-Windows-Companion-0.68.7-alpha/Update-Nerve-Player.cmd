@echo off
setlocal
title Update Nerve Player Companion
call "%~dp0scripts\Install-Nerve.cmd" -Role PlayerCompanion
exit /b %ERRORLEVEL%
