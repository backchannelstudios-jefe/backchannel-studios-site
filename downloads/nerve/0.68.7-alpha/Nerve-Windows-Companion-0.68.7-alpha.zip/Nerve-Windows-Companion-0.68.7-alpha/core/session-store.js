import { randomUUID } from "node:crypto";

export class SessionStore {
  #sessions = new Map();

  getOrCreate(sessionId, metadata = {}) {
    const id = sessionId || randomUUID();
    const existing = this.#sessions.get(id);
    if (existing) return existing;

    const session = Object.freeze({
      id,
      createdAt: new Date().toISOString(),
      metadata: Object.freeze({ ...metadata }),
      state: Object.create(null)
    });
    this.#sessions.set(id, session);
    return session;
  }
}
