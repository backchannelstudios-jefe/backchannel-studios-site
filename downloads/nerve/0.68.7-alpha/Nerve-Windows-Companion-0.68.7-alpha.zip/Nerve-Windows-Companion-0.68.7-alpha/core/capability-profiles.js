import { NerveError } from "./errors.js";

const FGU_SESSION_CAPABILITIES = new Set([
  "get_connection_status",
  "run_dm_cycle",
  "wait_for_events",
  "get_character",
  "search_library",
  "get_library_record",
  "get_manual_adjudications",
  "get_session_status",
  "get_session_continuity",
  "get_session_preflight",
  "send_chat",
  "request_player_input",
  "request_player_roll",
  "proxy_character_roll",
  "proxy_character_power_action",
  "proxy_combatant_action",
  "start_encounter",
  "begin_story_encounter",
  "begin_story_npc_encounter",
  "create_quest",
  "update_quest",
  "advance_turn",
  "apply_effect",
  "remove_effect",
  "set_spell_slot_usage",
  "set_combatant_visibility",
  "set_combatant_threat",
  "record_dm_decision",
  "record_session_continuity"
]);

export const TOOL_PROFILES = Object.freeze(["full", "session"]);

export function capabilityIncluded({ adapterId, capabilityName, profile = "full" }) {
  if (!TOOL_PROFILES.includes(profile)) {
    throw new NerveError("INVALID_TOOL_PROFILE", `Unknown tool profile: ${profile}`);
  }
  if (profile === "full") return true;
  if (adapterId !== "fantasy-grounds-unity") {
    throw new NerveError(
      "INVALID_TOOL_PROFILE",
      `Tool profile ${profile} is only available for the fantasy-grounds-unity adapter.`
    );
  }
  return FGU_SESSION_CAPABILITIES.has(capabilityName);
}
