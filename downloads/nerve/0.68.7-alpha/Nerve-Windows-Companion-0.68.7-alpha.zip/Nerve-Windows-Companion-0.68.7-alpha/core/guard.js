import { NerveError } from "./errors.js";

export class NerveGuard {
  constructor(policy = {}) {
    this.policy = Object.freeze({
      allowRead: policy.allowRead ?? true,
      allowWrite: policy.allowWrite ?? false,
      allowedCapabilities: policy.allowedCapabilities ? new Set(policy.allowedCapabilities) : null
    });
  }

  authorize(capability, args = {}) {
    if (this.policy.allowedCapabilities && !this.policy.allowedCapabilities.has(capability.name)) {
      throw new NerveError("CAPABILITY_DENIED", `Capability is not enabled: ${capability.name}`);
    }
    if (capability.access === "read" && !this.policy.allowRead) {
      throw new NerveError("READ_DENIED", `Read access is disabled: ${capability.name}`);
    }
    if (capability.access === "write" && !this.policy.allowWrite) {
      throw new NerveError("WRITE_DENIED", `Write access is disabled: ${capability.name}`);
    }
    if (capability.access === "write" && capability.requiresConfirmation && args.confirmed !== true) {
      throw new NerveError(
        "CONFIRMATION_REQUIRED",
        `Explicit confirmation is required: ${capability.name}`
      );
    }
    return { allowed: true, access: capability.access };
  }
}
