import { randomUUID } from "node:crypto";
import { toErrorPayload } from "./errors.js";
import { validateAgainstSchema } from "./schema-validator.js";

export class NerveRuntime {
  constructor({ registry, guard, journal, sessions, clock = () => new Date() }) {
    this.registry = registry;
    this.guard = guard;
    this.journal = journal;
    this.sessions = sessions;
    this.clock = clock;
  }

  async call({ capabilityName, arguments: args = {}, sessionId, metadata = {} }) {
    const requestId = randomUUID();
    const session = this.sessions.getOrCreate(sessionId, metadata);
    const base = {
      requestId,
      capability: capabilityName,
      sessionId: session.id,
      timestamp: this.clock().toISOString()
    };

    await this.journal.append({ ...base, event: "capability.requested", arguments: args });

    try {
      const capability = this.registry.get(capabilityName);
      const authorization = this.guard.authorize(capability, args);
      await this.journal.append({ ...base, event: "capability.authorized", authorization });
      validateAgainstSchema(args, capability.inputSchema, "arguments");

      const data = await capability.execute(args, {
        requestId,
        sessionId: session.id,
        metadata,
        session
      });
      validateAgainstSchema(data, capability.dataSchema, "result.data");

      const result = { ok: true, ...base, data };
      await this.journal.append({ ...base, event: "capability.succeeded", data });
      return result;
    } catch (error) {
      const result = { ok: false, ...base, error: toErrorPayload(error) };
      const diagnostic = result.error.code === "INTERNAL_ERROR" ? {
        name: typeof error?.name === "string" ? error.name : "Error",
        message: typeof error?.message === "string" ? error.message.slice(0, 500) : "No error message was available."
      } : undefined;
      await this.journal.append({ ...base, event: "capability.failed", error: result.error, diagnostic });
      return result;
    }
  }
}
