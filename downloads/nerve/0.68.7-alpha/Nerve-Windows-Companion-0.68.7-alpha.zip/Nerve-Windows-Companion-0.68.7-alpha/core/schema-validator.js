import { NerveError } from "./errors.js";

export function validateAgainstSchema(value, schema, label = "value") {
  const errors = [];
  visit(value, schema, label, errors);

  if (errors.length > 0) {
    throw new NerveError("VALIDATION_ERROR", `${label} does not match its contract.`, { errors });
  }
}

function visit(value, schema, path, errors) {
  if (!schema || typeof schema !== "object") return;

  for (const childSchema of schema.allOf ?? []) visit(value, childSchema, path, errors);
  if (schema.if && matchesSchema(value, schema.if)) {
    if (schema.then) visit(value, schema.then, path, errors);
  } else if (schema.else) {
    visit(value, schema.else, path, errors);
  }

  if (schema.const !== undefined && !Object.is(value, schema.const)) {
    errors.push(`${path} must equal ${JSON.stringify(schema.const)}`);
    return;
  }

  if (Array.isArray(schema.enum) && !schema.enum.some((item) => Object.is(value, item))) {
    errors.push(`${path} must be one of: ${schema.enum.join(", ")}`);
    return;
  }

  if (Array.isArray(schema.type)) {
    const valid = schema.type.some((type) => matchesType(value, type));
    if (!valid) errors.push(`${path} must be one of: ${schema.type.join(", ")}`);
    if (!valid) return;
  } else if (schema.type && !matchesType(value, schema.type)) {
    errors.push(`${path} must be ${schema.type}`);
    return;
  }

  if (schema.type === "object" || (matchesType(value, "object") && (schema.properties || schema.required || schema.additionalProperties !== undefined))) {
    const properties = schema.properties ?? {};
    for (const key of schema.required ?? []) {
      if (!(key in value)) errors.push(`${path}.${key} is required`);
    }
    if (schema.additionalProperties === false) {
      for (const key of Object.keys(value)) {
        if (!(key in properties)) errors.push(`${path}.${key} is not allowed`);
      }
    }
    for (const [key, childSchema] of Object.entries(properties)) {
      if (key in value) visit(value[key], childSchema, `${path}.${key}`, errors);
    }
  }

  if (schema.type === "array" || (Array.isArray(value) && (schema.items || schema.minItems !== undefined || schema.maxItems !== undefined || schema.uniqueItems))) {
    value.forEach((item, index) => visit(item, schema.items, `${path}[${index}]`, errors));
    if (schema.minItems !== undefined && value.length < schema.minItems) {
      errors.push(`${path} must contain at least ${schema.minItems} item(s)`);
    }
    if (schema.maxItems !== undefined && value.length > schema.maxItems) {
      errors.push(`${path} must contain at most ${schema.maxItems} item(s)`);
    }
    if (schema.uniqueItems && new Set(value.map((item) => JSON.stringify(item))).size !== value.length) {
      errors.push(`${path} must contain unique items`);
    }
  }

  if (typeof value === "string" && schema.minLength !== undefined && value.length < schema.minLength) {
    errors.push(`${path} must contain at least ${schema.minLength} character(s)`);
  }
  if (typeof value === "string" && schema.maxLength !== undefined && value.length > schema.maxLength) {
    errors.push(`${path} must contain at most ${schema.maxLength} character(s)`);
  }

  if (typeof value === "number" && schema.minimum !== undefined && value < schema.minimum) {
    errors.push(`${path} must be at least ${schema.minimum}`);
  }
  if (typeof value === "number" && schema.maximum !== undefined && value > schema.maximum) {
    errors.push(`${path} must be at most ${schema.maximum}`);
  }
}

function matchesSchema(value, schema) {
  const candidateErrors = [];
  visit(value, schema, "candidate", candidateErrors);
  return candidateErrors.length === 0;
}

function matchesType(value, type) {
  if (type === "null") return value === null;
  if (type === "array") return Array.isArray(value);
  if (type === "object") return value !== null && typeof value === "object" && !Array.isArray(value);
  if (type === "integer") return Number.isInteger(value);
  return typeof value === type;
}
