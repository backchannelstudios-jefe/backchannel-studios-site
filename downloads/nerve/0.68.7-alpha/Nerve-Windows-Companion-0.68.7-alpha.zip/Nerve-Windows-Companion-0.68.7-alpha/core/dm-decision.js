import { randomUUID } from "node:crypto";
import { readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { createResultSchema } from "./result-schema.js";

const inputSchema = loadJson(new URL("../schemas/tools/record-dm-decision.input.schema.json", import.meta.url));
const dataSchema = loadJson(new URL("../schemas/state/dm-decision-record.schema.json", import.meta.url));

export function createDmDecisionCapability({ journal, clock = () => new Date() }) {
  return {
    name: "record_dm_decision",
    title: "Record DM Decision",
    description:
      "Record why the AI DM held, proposed a guarded action, or requested clarification for an observed Pulse cursor. This writes only to Nerve Journal and never changes Fantasy Grounds.",
    access: "write",
    destructive: false,
    idempotent: false,
    requiresConfirmation: false,
    inputSchema,
    dataSchema,
    outputSchema: createResultSchema(dataSchema),
    execute: async (args, context) => {
      const data = {
        decisionId: randomUUID(),
        recordedAt: clock().toISOString(),
        cursor: structuredClone(args.cursor),
        decision: args.decision,
        summary: args.summary,
        rationale: args.rationale,
        ...(args.proposedCapability ? { proposedCapability: args.proposedCapability } : {})
      };
      await journal.append({
        event: "dm.decision.recorded",
        requestId: context.requestId,
        sessionId: context.sessionId,
        ...data
      });
      return data;
    }
  };
}

function loadJson(url) {
  return JSON.parse(readFileSync(fileURLToPath(url), "utf8"));
}
