import { NerveError } from "./errors.js";
import { assertCapability } from "./capability-registry.js";

export function defineAdapter(definition) {
  assertAdapter(definition);
  return Object.freeze({
    ...definition,
    capabilities: Object.freeze([...definition.capabilities])
  });
}

export function assertAdapter(adapter) {
  const required = ["id", "title", "version", "capabilities"];
  for (const key of required) {
    if (adapter?.[key] === undefined) {
      throw new NerveError("INVALID_ADAPTER", `Adapter is missing ${key}.`);
    }
  }
  if (!/^[a-z][a-z0-9-]*$/.test(adapter.id)) {
    throw new NerveError("INVALID_ADAPTER", `Invalid adapter ID: ${adapter.id}`);
  }
  if (typeof adapter.title !== "string" || adapter.title.length === 0) {
    throw new NerveError("INVALID_ADAPTER", "Adapter title must be a non-empty string.");
  }
  if (typeof adapter.version !== "string" || adapter.version.length === 0) {
    throw new NerveError("INVALID_ADAPTER", "Adapter version must be a non-empty string.");
  }
  if (!Array.isArray(adapter.capabilities) || adapter.capabilities.length === 0) {
    throw new NerveError("INVALID_ADAPTER", "Adapter must provide at least one capability.");
  }
  const names = new Set();
  for (const capability of adapter.capabilities) {
    assertCapability(capability);
    if (names.has(capability.name)) {
      throw new NerveError("INVALID_ADAPTER", `Adapter contains a duplicate capability: ${capability.name}`);
    }
    names.add(capability.name);
  }
  if (adapter.instructions !== undefined && typeof adapter.instructions !== "string") {
    throw new NerveError("INVALID_ADAPTER", "Adapter instructions must be a string.");
  }
}
