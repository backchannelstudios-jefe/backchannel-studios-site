import { NerveError } from "./errors.js";

export class CapabilityRegistry {
  #capabilities = new Map();

  register(capability) {
    assertCapability(capability);
    if (this.#capabilities.has(capability.name)) {
      throw new NerveError("DUPLICATE_CAPABILITY", `Capability already registered: ${capability.name}`);
    }
    this.#capabilities.set(capability.name, Object.freeze({ ...capability }));
    return this;
  }

  get(name) {
    const capability = this.#capabilities.get(name);
    if (!capability) {
      throw new NerveError("CAPABILITY_NOT_FOUND", `Unknown capability: ${name}`);
    }
    return capability;
  }

  list() {
    return [...this.#capabilities.values()];
  }

  toMcpTools() {
    return this.list().map((capability) => ({
      name: capability.name,
      title: capability.title,
      description: capability.description,
      inputSchema: capability.inputSchema,
      outputSchema: capability.outputSchema,
      annotations: {
        title: capability.title,
        readOnlyHint: capability.access === "read",
        destructiveHint: capability.access === "write" && capability.destructive === true,
        idempotentHint: capability.idempotent === true,
        openWorldHint: false
      }
    }));
  }
}

export function assertCapability(capability) {
  const required = ["name", "title", "description", "access", "inputSchema", "outputSchema", "execute"];
  for (const key of required) {
    if (capability?.[key] === undefined) {
      throw new NerveError("INVALID_CAPABILITY", `Capability is missing ${key}.`);
    }
  }
  if (!/^[a-z][a-z0-9_]*$/.test(capability.name)) {
    throw new NerveError("INVALID_CAPABILITY", `Invalid capability name: ${capability.name}`);
  }
  if (!new Set(["read", "write"]).has(capability.access)) {
    throw new NerveError("INVALID_CAPABILITY", `Invalid access mode: ${capability.access}`);
  }
  if (typeof capability.execute !== "function") {
    throw new NerveError("INVALID_CAPABILITY", "Capability execute must be a function.");
  }
}
