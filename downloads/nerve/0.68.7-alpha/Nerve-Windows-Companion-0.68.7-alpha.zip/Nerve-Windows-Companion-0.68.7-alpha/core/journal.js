import { appendFile, mkdir } from "node:fs/promises";
import { dirname } from "node:path";

export class FileJournal {
  constructor(path) {
    this.path = path;
  }

  async append(entry) {
    await mkdir(dirname(this.path), { recursive: true });
    await appendFile(this.path, `${JSON.stringify(entry)}\n`, "utf8");
  }
}

export class MemoryJournal {
  entries = [];

  async append(entry) {
    this.entries.push(structuredClone(entry));
  }
}

