export class NerveError extends Error {
  constructor(code, message, details = undefined) {
    super(message);
    this.name = "NerveError";
    this.code = code;
    this.details = details;
  }
}

export function toErrorPayload(error) {
  if (error instanceof NerveError) {
    return compact({ code: error.code, message: error.message, details: error.details });
  }

  return {
    code: "INTERNAL_ERROR",
    message: "The capability call failed unexpectedly."
  };
}

function compact(value) {
  return Object.fromEntries(Object.entries(value).filter(([, item]) => item !== undefined));
}

