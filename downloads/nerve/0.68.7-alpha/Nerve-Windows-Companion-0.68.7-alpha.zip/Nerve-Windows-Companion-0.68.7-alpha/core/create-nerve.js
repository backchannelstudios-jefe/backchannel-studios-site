import { resolve } from "node:path";
import { fileURLToPath } from "node:url";
import { AiSessionController } from "../ai/session-controller.js";
import { createFantasyGroundsAdapter } from "../adapters/fantasy-grounds-unity/adapter.js";
import { CampaignFantasyGroundsBridge } from "../adapters/fantasy-grounds-unity/bridge/campaign-bridge.js";
import { MockFantasyGroundsBridge } from "../adapters/fantasy-grounds-unity/bridge/mock-bridge.js";
import { createTaskBoardAdapter } from "../adapters/task-board/adapter.js";
import { MemoryTaskBoardBridge } from "../adapters/task-board/bridge/memory-bridge.js";
import { CapabilityRegistry } from "./capability-registry.js";
import { capabilityIncluded } from "./capability-profiles.js";
import { NerveGuard } from "./guard.js";
import { FileJournal } from "./journal.js";
import { NerveRuntime } from "./runtime.js";
import { SessionStore } from "./session-store.js";

const repositoryRoot = fileURLToPath(new URL("../", import.meta.url));

export function createNerve(options = {}) {
  const registry = options.registry ?? new CapabilityRegistry();
  const clock = options.clock ?? (() => new Date());
  const journal =
    options.journal ??
    new FileJournal(
      process.env.NERVE_JOURNAL_PATH || resolve(repositoryRoot, ".nerve/journal.ndjson")
    );
  const adapter = options.adapter ?? createDefaultAdapter(options, { journal, clock });
  const bridge = adapter.bridge ?? options.bridge ?? null;

  if (registry.list().length === 0) {
    const enableWriteCapabilities =
      options.enableWriteCapabilities ?? process.env.NERVE_ENABLE_WRITES === "true";
    const toolProfile = options.toolProfile ?? process.env.NERVE_TOOL_PROFILE ?? "full";
    for (const capability of adapter.capabilities) {
      if (capability.access === "write" && !enableWriteCapabilities) continue;
      if (!capabilityIncluded({
        adapterId: adapter.id,
        capabilityName: capability.name,
        profile: toolProfile
      })) continue;
      registry.register(capability);
    }
  }

  const allowWrite = options.allowWrite ?? process.env.NERVE_ALLOW_WRITE === "true";
  const guard = options.guard ?? new NerveGuard({ allowRead: true, allowWrite });
  const sessions = options.sessions ?? new SessionStore();
  const runtime = new NerveRuntime({ registry, guard, journal, sessions, clock });
  const createController = ({ provider, contextReducer, usageLedger, triggerTypes } = {}) =>
    new AiSessionController({
      runtime,
      provider,
      journal,
      clock,
      ...(contextReducer ? { contextReducer } : {}),
      ...(usageLedger ? { usageLedger } : {}),
      ...(triggerTypes ? { triggerTypes } : {})
    });

  return { adapter, bridge, registry, guard, journal, sessions, runtime, createController };
}

function createDefaultAdapter(options, dependencies) {
  const adapterId = options.adapterId ?? process.env.NERVE_ADAPTER ?? "fantasy-grounds-unity";
  if (adapterId === "task-board") {
    const bridge = options.bridge ?? new MemoryTaskBoardBridge({ clock: dependencies.clock });
    return createTaskBoardAdapter(bridge);
  }
  if (adapterId !== "fantasy-grounds-unity") {
    throw new Error(`Unknown Nerve adapter: ${adapterId}`);
  }
  const bridge = options.bridge ?? createDefaultBridge(options, dependencies);
  return createFantasyGroundsAdapter(bridge, dependencies);
}

function createDefaultBridge(options, { clock }) {
  const snapshotPath = options.snapshotPath ?? process.env.NERVE_FGU_SNAPSHOT_PATH;
  if (snapshotPath) {
    const configuredTimeout = options.commandTimeoutMs ?? Number(process.env.NERVE_FGU_COMMAND_TIMEOUT_MS);
    const commandTimeoutMs = Number.isFinite(configuredTimeout) && configuredTimeout > 0 ? configuredTimeout : undefined;
    return new CampaignFantasyGroundsBridge({
      snapshotPath: resolve(snapshotPath),
      clock,
      ...(commandTimeoutMs ? { commandTimeoutMs } : {})
    });
  }

  return new MockFantasyGroundsBridge({
    campaignSummaryFixturePath: resolve(repositoryRoot, "tests/fixtures/fgu/campaign-summary.json"),
    combatTrackerFixturePath: resolve(repositoryRoot, "tests/fixtures/fgu/combat-tracker.json"),
    partyFixturePath: resolve(repositoryRoot, "tests/fixtures/fgu/party.json"),
    characterFixturePath: resolve(repositoryRoot, "tests/fixtures/fgu/character.json"),
    recentEventsFixturePath: resolve(repositoryRoot, "tests/fixtures/fgu/recent-events.json")
  });
}
