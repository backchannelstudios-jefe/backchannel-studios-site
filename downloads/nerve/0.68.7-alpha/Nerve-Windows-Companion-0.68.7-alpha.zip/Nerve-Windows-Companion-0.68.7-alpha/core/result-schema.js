export function createResultSchema(dataSchema) {
  return {
    $schema: "https://json-schema.org/draft/2020-12/schema",
    type: "object",
    additionalProperties: false,
    required: ["ok", "requestId", "capability", "sessionId", "timestamp"],
    properties: {
      ok: { type: "boolean" },
      requestId: { type: "string" },
      capability: { type: "string" },
      sessionId: { type: "string" },
      timestamp: { type: "string" },
      data: dataSchema,
      error: {
        type: "object",
        additionalProperties: false,
        required: ["code", "message"],
        properties: {
          code: { type: "string" },
          message: { type: "string" },
          details: { type: "object" }
        }
      }
    }
  };
}

