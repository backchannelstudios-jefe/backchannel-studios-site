# Alpha feedback template

- Nerve version; Fantasy Grounds version; ruleset; Windows version:
- Provider and observed model; account tier (no account identifiers):
- Solo or multiplayer; other enabled extensions:
- What you did, in numbered steps:
- Expected result:
- Actual result and exact error code:
- Current-attempt elapsed seconds (separate approval wait):
- Did the native quest/combat/character record change after approval?
- Can you reproduce it? Did restarting help?

Use a small original/example campaign where possible. Remove player names, private conversations, adventure spoilers, licensed source text, credentials and local account paths from public reports. Share a reviewed support bundle privately only when requested.

For comparison, record narration quality, correct source use, continuity and successful native execution separately. A Nerve parsing/routing failure is not a model-quality failure. Report unknown model/timing as unknown rather than estimated precision.
