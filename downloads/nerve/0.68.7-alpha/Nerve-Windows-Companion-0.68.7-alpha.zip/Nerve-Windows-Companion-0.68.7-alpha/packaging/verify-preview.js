import { createHash } from "node:crypto";
import { readFile, readdir, stat } from "node:fs/promises";
import { basename, join, relative, resolve, sep } from "node:path";

const CONTROL_FILES = new Set(["manifest.json", "CHECKSUMS.sha256"]);
const REQUIRED_FILES = [
  "package.json", "bin/nerve.js", "Install-Nerve.cmd", "Update-Nerve-Player.cmd", "Collect-Nerve-Support.cmd",
  "Configure-Nerve-AI.cmd", "Start-Nerve.cmd", "Stop-Nerve.cmd", "Nerve-Supervisor.cmd",
  "scripts/install-windows.ps1", "scripts/collect-support.ps1", "scripts/configure-provider.ps1",
  "scripts/start-nerve.ps1", "scripts/stop-nerve.ps1", "scripts/nerve-supervisor.ps1",
  "adapters/fantasy-grounds-unity/extension/extension.xml"
];

export async function verifyDeveloperPreview(inputPath) {
  if (!inputPath) throw new TypeError("Preview verification requires an input path.");
  const input = resolve(inputPath);
  const metadata = await stat(input);
  if (metadata.isDirectory()) return verifyDirectory(input);
  if (metadata.isFile() && input.toLowerCase().endsWith(".zip")) return verifyArchive(input);
  throw new Error("Preview input must be an extracted directory or .zip archive.");
}

async function verifyDirectory(directory) {
  const paths = await listFiles(directory);
  const contents = new Map();
  for (const path of paths) contents.set(portable(relative(directory, path)), await readFile(path));
  const verified = verifyContents(contents);
  return { schemaVersion: "0.1", input: directory, inputType: "directory", archiveSha256: null, ...verified };
}

async function verifyArchive(path) {
  const archive = await readFile(path);
  const archiveSha256 = sha256(archive);
  const sidecar = await readFile(`${path}.sha256`, "utf8");
  const match = sidecar.trim().match(/^([a-f0-9]{64})\s{2}(.+)$/i);
  if (!match || match[1].toLowerCase() !== archiveSha256 || match[2] !== basename(path)) {
    throw new Error("Archive SHA-256 sidecar does not match the selected preview archive.");
  }
  const entries = readStoredZip(archive);
  const roots = new Set([...entries.keys()].map((name) => name.split("/")[0]));
  if (roots.size !== 1 || roots.has("")) throw new Error("Preview archive must contain exactly one top-level directory.");
  const root = [...roots][0];
  const contents = new Map();
  for (const [name, data] of entries) contents.set(name.slice(root.length + 1), data);
  const verified = verifyContents(contents);
  return { schemaVersion: "0.1", input: path, inputType: "archive", archiveSha256, archiveRoot: root, ...verified };
}

function verifyContents(contents) {
  for (const path of contents.keys()) assertSafePortablePath(path);
  for (const required of [...CONTROL_FILES, ...REQUIRED_FILES]) {
    if (!contents.has(required)) throw new Error(`Preview is missing required file: ${required}`);
  }
  let manifest;
  try { manifest = JSON.parse(contents.get("manifest.json").toString("utf8")); }
  catch (error) { throw new Error(`Preview manifest is invalid JSON: ${error.message}`); }
  if (manifest.schemaVersion !== "0.1" || manifest.packageType !== "developer-preview" || !Array.isArray(manifest.files)) {
    throw new Error("Preview manifest has an unsupported contract.");
  }
  if (manifest.fileCount !== manifest.files.length) throw new Error("Preview manifest file count does not match its entries.");
  const expected = new Map();
  for (const item of manifest.files) {
    assertSafePortablePath(item.path);
    if (expected.has(item.path)) throw new Error(`Preview manifest repeats a path: ${item.path}`);
    if (!Number.isInteger(item.bytes) || item.bytes < 0 || !/^[a-f0-9]{64}$/.test(item.sha256 ?? "")) throw new Error(`Preview manifest entry is invalid: ${item.path}`);
    expected.set(item.path, item);
  }
  const payloadPaths = [...contents.keys()].filter((path) => !CONTROL_FILES.has(path)).sort();
  if (payloadPaths.length !== expected.size) throw new Error("Preview contains missing or unexpected payload files.");
  for (const path of payloadPaths) {
    const item = expected.get(path);
    if (!item) throw new Error(`Preview contains an unexpected payload file: ${path}`);
    const data = contents.get(path);
    if (data.length !== item.bytes || sha256(data) !== item.sha256) throw new Error(`Preview payload checksum failed: ${path}`);
  }
  const checksumLines = contents.get("CHECKSUMS.sha256").toString("utf8").split(/\r?\n/).filter(Boolean);
  const expectedLines = [...expected.values()].map((item) => `${item.sha256}  ${item.path}`);
  if (checksumLines.length !== expectedLines.length || checksumLines.some((line, index) => line !== expectedLines[index])) {
    throw new Error("Preview CHECKSUMS.sha256 does not match the manifest.");
  }
  return { valid: true, name: manifest.name, version: manifest.version, fileCount: expected.size };
}

function readStoredZip(buffer) {
  const entries = new Map();
  let offset = 0;
  while (offset + 4 <= buffer.length && buffer.readUInt32LE(offset) === 0x04034b50) {
    if (offset + 30 > buffer.length) throw new Error("Preview ZIP has a truncated local header.");
    const flags = buffer.readUInt16LE(offset + 6);
    const method = buffer.readUInt16LE(offset + 8);
    const compressedSize = buffer.readUInt32LE(offset + 18);
    const uncompressedSize = buffer.readUInt32LE(offset + 22);
    const nameLength = buffer.readUInt16LE(offset + 26);
    const extraLength = buffer.readUInt16LE(offset + 28);
    if (method !== 0 || (flags & 0x0008) !== 0 || compressedSize !== uncompressedSize) throw new Error("Preview ZIP uses an unsupported entry encoding.");
    const nameStart = offset + 30;
    const dataStart = nameStart + nameLength + extraLength;
    const dataEnd = dataStart + compressedSize;
    if (dataEnd > buffer.length) throw new Error("Preview ZIP has a truncated entry.");
    const name = buffer.subarray(nameStart, nameStart + nameLength).toString("utf8");
    assertSafePortablePath(name);
    if (entries.has(name)) throw new Error(`Preview ZIP repeats an entry: ${name}`);
    entries.set(name, buffer.subarray(dataStart, dataEnd));
    offset = dataEnd;
  }
  if (entries.size === 0 || offset + 4 > buffer.length || buffer.readUInt32LE(offset) !== 0x02014b50) throw new Error("Preview ZIP central directory was not found.");
  return entries;
}

async function listFiles(directory) {
  const found = [];
  for (const entry of await readdir(directory, { withFileTypes: true })) {
    const path = join(directory, entry.name);
    if (entry.isDirectory()) found.push(...await listFiles(path));
    else if (entry.isFile()) found.push(path);
    else throw new Error(`Preview contains a link or special file: ${path}`);
  }
  return found.sort((left, right) => portable(left).localeCompare(portable(right)));
}

function assertSafePortablePath(path) {
  if (typeof path !== "string" || path.length === 0 || path.startsWith("/") || path.includes("\\") || path.split("/").some((part) => part === "" || part === "." || part === "..")) {
    throw new Error(`Preview contains an unsafe path: ${path}`);
  }
}

function sha256(value) { return createHash("sha256").update(value).digest("hex"); }
function portable(path) { return path.split(sep).join("/"); }
