import { createHash } from "node:crypto";
import { cp, mkdir, readFile, readdir, stat, writeFile } from "node:fs/promises";
import { basename, dirname, join, relative, resolve, sep } from "node:path";
import { fileURLToPath } from "node:url";

const DEFAULT_ROOT = fileURLToPath(new URL("../", import.meta.url));
const INCLUDED_DIRECTORIES = ["adapters", "ai", "bin", "cli", "core", "docs", "link", "packaging", "playtest", "schemas", "scripts"];
const INCLUDED_FILES = [
  "README.md", "package.json", "Install-Nerve.cmd", "Collect-Nerve-Support.cmd",
  "Configure-Nerve-AI.cmd", "Start-Nerve.cmd", "Stop-Nerve.cmd", "Nerve-Supervisor.cmd", "Repair-Nerve-Player.cmd",
  "Update-Nerve-Player.cmd", "Configure-Nerve-Custom-App.cmd"
];

export async function buildDeveloperPreview({
  repositoryRoot = DEFAULT_ROOT,
  outputPath = null,
  createArchive = true
} = {}) {
  const root = resolve(repositoryRoot);
  const packageJson = JSON.parse(await readFile(join(root, "package.json"), "utf8"));
  const destination = resolve(outputPath ?? join(root, "dist", `nerve-developer-preview-${packageJson.version}`));
  assertDestination(root, destination);
  await assertAbsentOrEmpty(destination);
  await mkdir(destination, { recursive: true });

  for (const directory of INCLUDED_DIRECTORIES) {
    await cp(join(root, directory), join(destination, directory), { recursive: true, errorOnExist: true });
  }
  for (const file of INCLUDED_FILES) {
    await mkdir(dirname(join(destination, file)), { recursive: true });
    await cp(join(root, file), join(destination, file), { errorOnExist: true });
  }

  const files = await listFiles(destination);
  const manifestFiles = [];
  for (const path of files) {
    const data = await readFile(path);
    manifestFiles.push({
      path: portable(relative(destination, path)),
      bytes: data.length,
      sha256: createHash("sha256").update(data).digest("hex")
    });
  }
  const manifest = {
    schemaVersion: "0.1",
    name: packageJson.name,
    version: packageJson.version,
    packageType: "developer-preview",
    fileCount: manifestFiles.length,
    files: manifestFiles
  };
  await writeFile(join(destination, "manifest.json"), `${JSON.stringify(manifest, null, 2)}\n`, "utf8");
  await writeFile(
    join(destination, "CHECKSUMS.sha256"),
    `${manifestFiles.map((item) => `${item.sha256}  ${item.path}`).join("\n")}\n`,
    "utf8"
  );
  const archive = createArchive ? await archiveDeveloperPreview({ directory: destination }) : null;
  return { destination, ...manifest, ...(archive ?? {}) };
}

export async function archiveDeveloperPreview({ directory, archivePath = `${resolve(directory)}.zip` }) {
  const source = resolve(directory);
  const destination = resolve(archivePath);
  await assertAbsentFile(destination);
  const paths = await listFiles(source);
  const entries = [];
  for (const path of paths) {
    entries.push({
      name: `${basename(source)}/${portable(relative(source, path))}`,
      data: await readFile(path)
    });
  }
  const zip = createStoredZip(entries);
  await writeFile(destination, zip);
  const archiveSha256 = createHash("sha256").update(zip).digest("hex");
  const checksumPath = `${destination}.sha256`;
  await assertAbsentFile(checksumPath);
  await writeFile(checksumPath, `${archiveSha256}  ${basename(destination)}\n`, "utf8");
  return { archivePath: destination, archiveBytes: zip.length, archiveSha256, archiveChecksumPath: checksumPath };
}

async function listFiles(directory) {
  const found = [];
  for (const entry of await readdir(directory, { withFileTypes: true })) {
    const path = join(directory, entry.name);
    if (entry.isDirectory()) found.push(...await listFiles(path));
    else if (entry.isFile()) found.push(path);
    else throw new Error(`Preview packaging does not allow links or special files: ${path}`);
  }
  return found.sort((left, right) => portable(left).localeCompare(portable(right)));
}

async function assertAbsentOrEmpty(path) {
  try {
    const metadata = await stat(path);
    if (!metadata.isDirectory()) throw new Error(`Preview output exists and is not a directory: ${path}`);
    if ((await readdir(path)).length > 0) throw new Error(`Preview output directory must be empty: ${path}`);
  } catch (error) {
    if (error.code !== "ENOENT") throw error;
  }
}

async function assertAbsentFile(path) {
  try {
    await stat(path);
    throw new Error(`Preview archive already exists: ${path}`);
  } catch (error) {
    if (error.code !== "ENOENT") throw error;
  }
}

function assertDestination(root, destination) {
  if (destination === root || !destination.startsWith(`${root}${sep}`)) {
    throw new Error("Preview output must be a directory inside the repository.");
  }
  if (basename(destination) === ".nerve") throw new Error("Preview output may not use the private .nerve directory.");
}

function portable(path) { return path.split(sep).join("/"); }

function createStoredZip(entries) {
  const localParts = [];
  const centralParts = [];
  let offset = 0;
  for (const entry of entries) {
    const name = Buffer.from(entry.name, "utf8");
    const crc = crc32(entry.data);
    const local = Buffer.alloc(30);
    local.writeUInt32LE(0x04034b50, 0);
    local.writeUInt16LE(20, 4);
    local.writeUInt16LE(0x0800, 6);
    local.writeUInt16LE(0, 8);
    local.writeUInt16LE(0, 10);
    local.writeUInt16LE(0x0021, 12);
    local.writeUInt32LE(crc, 14);
    local.writeUInt32LE(entry.data.length, 18);
    local.writeUInt32LE(entry.data.length, 22);
    local.writeUInt16LE(name.length, 26);
    const central = Buffer.alloc(46);
    central.writeUInt32LE(0x02014b50, 0);
    central.writeUInt16LE(20, 4);
    central.writeUInt16LE(20, 6);
    central.writeUInt16LE(0x0800, 8);
    central.writeUInt16LE(0, 10);
    central.writeUInt16LE(0, 12);
    central.writeUInt16LE(0x0021, 14);
    central.writeUInt32LE(crc, 16);
    central.writeUInt32LE(entry.data.length, 20);
    central.writeUInt32LE(entry.data.length, 24);
    central.writeUInt16LE(name.length, 28);
    central.writeUInt32LE(offset, 42);
    localParts.push(local, name, entry.data);
    centralParts.push(central, name);
    offset += local.length + name.length + entry.data.length;
  }
  const centralDirectory = Buffer.concat(centralParts);
  const end = Buffer.alloc(22);
  end.writeUInt32LE(0x06054b50, 0);
  end.writeUInt16LE(entries.length, 8);
  end.writeUInt16LE(entries.length, 10);
  end.writeUInt32LE(centralDirectory.length, 12);
  end.writeUInt32LE(offset, 16);
  return Buffer.concat([...localParts, centralDirectory, end]);
}

const CRC_TABLE = Array.from({ length: 256 }, (_, index) => {
  let value = index;
  for (let bit = 0; bit < 8; bit += 1) value = (value & 1) ? 0xedb88320 ^ (value >>> 1) : value >>> 1;
  return value >>> 0;
});

function crc32(data) {
  let crc = 0xffffffff;
  for (const byte of data) crc = CRC_TABLE[(crc ^ byte) & 0xff] ^ (crc >>> 8);
  return (crc ^ 0xffffffff) >>> 0;
}
