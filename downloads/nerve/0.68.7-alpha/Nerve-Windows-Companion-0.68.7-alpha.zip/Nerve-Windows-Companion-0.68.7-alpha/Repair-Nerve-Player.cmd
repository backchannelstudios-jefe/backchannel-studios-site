@echo off
setlocal
call "%~dp0scripts\Repair-Nerve-Player.cmd" %*
exit /b %ERRORLEVEL%
