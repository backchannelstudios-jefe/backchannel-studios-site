@echo off
setlocal
call "%~dp0scripts\Configure-Nerve-AI.cmd" %*
exit /b %ERRORLEVEL%

