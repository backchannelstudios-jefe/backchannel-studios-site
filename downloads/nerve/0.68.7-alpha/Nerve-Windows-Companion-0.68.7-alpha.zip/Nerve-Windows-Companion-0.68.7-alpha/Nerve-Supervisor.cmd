@echo off
setlocal
title Nerve Background Control
powershell.exe -NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File "%~dp0scripts\nerve-supervisor.ps1" %*
exit /b %ERRORLEVEL%
