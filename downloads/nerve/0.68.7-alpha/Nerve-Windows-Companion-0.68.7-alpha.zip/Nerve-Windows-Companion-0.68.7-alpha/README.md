# Nerve 0.68.7 alpha — start here

Use a backup/test copy of your campaign. Windows GM host and Fantasy Grounds 5E are the supported alpha target. Install Node.js 22+ if needed. AI accounts, applications and usage are separate requirements.

1. Install Nerve through Forge and run the Fantasy Grounds updater. Then extract the matching companion ZIP completely and run Install-Nerve.cmd. Forge manages the extension; this companion installs only its runtime. For pre-publication review, place the supplied .ext in the Fantasy Grounds extensions folder first.
2. Enable Nerve Adapter in the campaign extensions and load the campaign. Confirm version 0.68.7 in chat.
3. Open Nerve Control → AI Setup. Select your provider, use Install / Repair if needed, then Sign In. Complete provider-owned authentication. A browser may not appear when already signed in.
4. Use Test + Use. This can consume AI allowance. Confirm the selected provider is saved and ready before starting.
5. Click **Begin Session + AI**. This starts tracking, enables Flow Mode, starts the configured AI connection and requests one grounded opening; do not click **Start AI Only** first. Try a short recap or a simple action. Avoid repeated Call Nerve while a request is responding.
6. End Session to preserve continuity; confirm the connector stops. If needed, Stop Nerve. After a failure, inspect the error before retrying.

Manual bookkeeping: click **Enter Manual Work Mode** before native combat cleanup, rest, inventory/currency edits or other work that should not contact the AI. The persistent title/status confirms that automatic cues are paused. Native state continues to be recorded, suppressed events are not replayed, and **Call Nerve** remains an intentional one-off option. Click **Resume AI Flow** when ready; the next intentional play event may then create one cue. If another FGU window covers the control, use `/nervemanual` in chat.

Story Cues: drag a supported record's link icon into the Story Cue Tower and confirm its title appears. Pins supply context; they do not move characters or reveal records to players.

Check native records after approvals. Rewards and purchases may still need manual bookkeeping; verify before adding anything to avoid duplicates. Quest-completion display remains a known limitation.

The companion requires installation outside Forge. Use the Forge companion build for future repairs and updates. It will not overwrite the .ext. If upgrading from a developer preview, close Fantasy Grounds, move the old extensions/Nerve folder to a backup outside extensions, then install the Forge extension and rerun the companion installer. Do not delete campaign folders. Keep exactly one packaged Nerve extension. Version mismatches require the matching companion release and/or the Fantasy Grounds updater, followed by a campaign reload.

Forge uses Data installation. Install the same extension and companion version. Nerve blocks AI startup when the versions differ and identifies the component that needs updating. After either component updates, reload Fantasy Grounds before starting. Version 0.68.7 is a local candidate until its live smoke test and public update are completed.

Use Collect-Nerve-Support.cmd for diagnostic assistance. Inspect any bundle before sharing and use a private support channel for sensitive material. Never post campaign snapshots, licensed module text, provider credentials or raw AI transcripts publicly.

## Custom Fantasy Grounds data folders

The installer reads FGU's configured Windows data directory first, then a valid saved Nerve installation, then the default folder. An explicitly supplied path takes precedence. If detection fails, interactive setup asks you to paste the data-folder path from the FGU launcher. No skeleton folder is needed.

You can also run this from a command prompt in the extracted companion folder:

```bat
Install-Nerve.cmd -FantasyGroundsData "D:\My FG Data"
```

## Codex model and usage

Stop Nerve before changing its configuration. In `%LOCALAPPDATA%\Nerve\Config\provider.json`, set `model` to an exact model ID supported by your Codex account, or leave `null` to use your Codex default. Preserve the other fields and valid JSON. Restart Nerve afterward. The connector now passes this setting to Codex and reports the model returned by Codex in status/support diagnostics. Test + Use preserves a saved Codex model selection.

The guided Configure-Nerve-AI command also offers an optional Codex model ID. No model automatically falls back to a paid API. Model availability, usage and quality vary; there is no promised number of turns per subscription. A connection test consumes allowance. Use one short test and inspect the result before retrying.

Codex now uses a fresh ephemeral thread for each complete handoff, avoiding the accumulation of prior full prompts. Campaign continuity comes from Nerve's supplied state and memory. Actual allowance savings need measurement on your account.

If `STALE_AI_DECISION` appears, native rolls, a turn or player input changed after the handoff. The old action was discarded. Allow the newest cue to resolve, or use Call Nerve once if idle. Do not repeat an already completed attack or damage roll.
