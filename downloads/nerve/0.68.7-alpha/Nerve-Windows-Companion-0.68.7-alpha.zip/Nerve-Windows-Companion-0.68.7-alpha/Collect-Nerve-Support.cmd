@echo off
setlocal
call "%~dp0scripts\Collect-Nerve-Support.cmd" %*
exit /b %ERRORLEVEL%

