import { readFile, readdir, rename, writeFile } from "node:fs/promises";
import { basename, dirname, join, resolve } from "node:path";
import { NerveError } from "../../../core/errors.js";
import { FileFantasyGroundsBridge } from "./file-bridge.js";

const ACTIVE_CAMPAIGN_FILENAME = "nerve-active-campaign.json";

export class CampaignFantasyGroundsBridge {
  constructor({ snapshotPath, commandTimeoutMs = 60000, clock = () => new Date(), notifier = null }) {
    this.commandTimeoutMs = commandTimeoutMs;
    this.clock = clock;
    this.notifier = notifier;
    this.fguDataPath = dirname(dirname(dirname(resolve(snapshotPath))));
    this.activeCampaign = basename(dirname(resolve(snapshotPath)));
    this.delegate = this.#createDelegate(this.activeCampaign);
  }

  async listCampaigns() {
    const campaignsDirectory = join(this.fguDataPath, "campaigns");
    let entries;
    try {
      entries = await readdir(campaignsDirectory, { withFileTypes: true });
    } catch (error) {
      throw new NerveError("FGU_CAMPAIGN_DISCOVERY_FAILED", "Fantasy Grounds campaigns could not be discovered.", {
        fguDataPath: this.fguDataPath
      });
    }
    const campaigns = [];
    for (const entry of entries.filter((item) => item.isDirectory())) {
      const metadata = await readSnapshot(join(campaignsDirectory, entry.name, "nerve-state.json"));
      if (!metadata) continue;
      campaigns.push({
        name: entry.name,
        active: entry.name === this.activeCampaign,
        adapterVersion: metadata.adapterVersion ?? "unknown",
        ruleset: metadata.campaignSummary?.ruleset ?? "unknown",
        generatedAt: metadata.generatedAt ?? metadata.campaignSummary?.observedAt ?? this.clock().toISOString()
      });
    }
    return { campaigns: campaigns.sort((left, right) => left.name.localeCompare(right.name)), observedAt: this.clock().toISOString() };
  }

  async getConnectionStatus() {
    const summary = await this.delegate.getCampaignSummary({});
    const snapshot = await readSnapshot(this.delegate.snapshotPath);
    return {
      campaign: this.activeCampaign,
      name: summary.name,
      ruleset: summary.ruleset,
      adapterVersion: snapshot?.adapterVersion ?? "unknown",
      generatedAt: snapshot?.generatedAt ?? summary.observedAt,
      observedAt: this.clock().toISOString()
    };
  }

  async selectCampaign({ campaign }) {
    assertSafeCampaignName(campaign);
    const snapshotPath = this.#snapshotPath(campaign);
    const snapshot = await readSnapshot(snapshotPath);
    if (!snapshot?.campaignSummary) {
      throw new NerveError("FGU_CAMPAIGN_NOT_READY", `Campaign does not have a readable Nerve snapshot: ${campaign}`, { campaign });
    }
    const previousCampaign = this.activeCampaign;
    this.delegate = this.#createDelegate(campaign);
    this.activeCampaign = campaign;
    await persistActiveCampaign(this.fguDataPath, campaign, this.clock);
    return {
      previousCampaign,
      campaign,
      changed: previousCampaign !== campaign,
      adapterVersion: snapshot.adapterVersion ?? "unknown",
      ruleset: snapshot.campaignSummary.ruleset ?? "unknown",
      selectedAt: this.clock().toISOString()
    };
  }

  getCampaignSummary(context) { return this.delegate.getCampaignSummary(context); }
  getCombatTracker(context) { return this.delegate.getCombatTracker(context); }
  getParty(context) { return this.delegate.getParty(context); }
  getCharacter(id, context) { return this.delegate.getCharacter(id, context); }
  getCurrentEncounter(context) { return this.delegate.getCurrentEncounter(context); }
  getRecentEvents(args, context) { return this.delegate.getRecentEvents(args, context); }
  waitForEvents(args, context) { return this.delegate.waitForEvents(args, context); }
  getDmBriefing(args, context) { return this.delegate.getDmBriefing(args, context); }
  searchLibrary(args, context) { return this.delegate.searchLibrary(args, context); }
  getLibraryRecord(id, context) { return this.delegate.getLibraryRecord(id, context); }
  getManualAdjudications(context) { return this.delegate.getManualAdjudications(context); }
  getSessionStatus(context) { return this.delegate.getSessionStatus(context); }
  getSessionContinuity(context) { return this.delegate.getSessionContinuity(context); }
  getOpenMaps(context) { return this.delegate.getOpenMaps(context); }
  getMapScene(context) { return this.delegate.getMapScene(context); }
  sendChat(args, context) { return this.delegate.sendChat(args, context); }
  requestVote(args, context) { return this.delegate.requestVote(args, context); }
  requestPlayerInput(args, context) { return this.delegate.requestPlayerInput(args, context); }
  requestPlayerRoll(args, context) { return this.delegate.requestPlayerRoll(args, context); }
  proxyCharacterRoll(args, context) { return this.delegate.proxyCharacterRoll(args, context); }
  proxyCharacterPowerAction(args, context) { return this.delegate.proxyCharacterPowerAction(args, context); }
  proxyCombatantAction(args, context) { return this.delegate.proxyCombatantAction(args, context); }
  addLibraryNpc(args, context) { return this.delegate.addLibraryNpc(args, context); }
  addLibraryEncounter(args, context) { return this.delegate.addLibraryEncounter(args, context); }
  createQuest(args, context) { return this.delegate.createQuest(args, context); }
  updateQuest(args, context) { return this.delegate.updateQuest(args, context); }
  beginStoryNpcEncounter(args, context) { return this.delegate.beginStoryNpcEncounter(args, context); }
  beginStoryEncounter(args, context) { return this.delegate.beginStoryEncounter(args, context); }
  openLibraryImage(args, context) { return this.delegate.openLibraryImage(args, context); }
  setSpellSlotUsage(args, context) { return this.delegate.setSpellSlotUsage(args, context); }
  advanceTurn(args, context) { return this.delegate.advanceTurn(args, context); }
  startEncounter(args, context) { return this.delegate.startEncounter(args, context); }
  applyEffect(args, context) { return this.delegate.applyEffect(args, context); }
  removeEffect(args, context) { return this.delegate.removeEffect(args, context); }
  removeCombatant(args, context) { return this.delegate.removeCombatant(args, context); }
  resolveManualAdjudication(args, context) { return this.delegate.resolveManualAdjudication(args, context); }
  setCombatantThreat(args, context) { return this.delegate.setCombatantThreat(args, context); }
  setCombatantVisibility(args, context) { return this.delegate.setCombatantVisibility(args, context); }
  recordSessionContinuity(args, context) { return this.delegate.recordSessionContinuity(args, context); }

  #snapshotPath(campaign) {
    return join(this.fguDataPath, "campaigns", campaign, "nerve-state.json");
  }

  #createDelegate(campaign) {
    return new FileFantasyGroundsBridge({
      snapshotPath: this.#snapshotPath(campaign),
      commandTimeoutMs: this.commandTimeoutMs,
      notifier: this.notifier
    });
  }
}

export async function resolveActiveCampaign(fguDataPath, fallbackCampaign) {
  try {
    const value = JSON.parse(await readFile(join(resolve(fguDataPath), ACTIVE_CAMPAIGN_FILENAME), "utf8"));
    if (typeof value.campaign === "string") {
      assertSafeCampaignName(value.campaign);
      const snapshot = await readSnapshot(join(resolve(fguDataPath), "campaigns", value.campaign, "nerve-state.json"));
      if (snapshot?.campaignSummary) return value.campaign;
    }
  } catch (error) {
    if (error.code !== "ENOENT" && !(error instanceof SyntaxError) && error.code !== "INVALID_CAMPAIGN_NAME") throw error;
  }
  assertSafeCampaignName(fallbackCampaign);
  return fallbackCampaign;
}

export async function persistActiveCampaign(fguDataPath, campaign, clock = () => new Date()) {
  assertSafeCampaignName(campaign);
  const path = join(resolve(fguDataPath), ACTIVE_CAMPAIGN_FILENAME);
  const temporaryPath = `${path}.tmp`;
  await writeFile(temporaryPath, JSON.stringify({ schemaVersion: "0.1", campaign, selectedAt: clock().toISOString() }), "utf8");
  await rename(temporaryPath, path);
}

async function readSnapshot(path) {
  try {
    const text = await readFile(path, "utf8");
    return JSON.parse(text.charCodeAt(0) === 0xfeff ? text.slice(1) : text);
  } catch (error) {
    if (error.code === "ENOENT" || error instanceof SyntaxError) return null;
    throw error;
  }
}

function assertSafeCampaignName(value) {
  if (typeof value !== "string" || value.length === 0 || value === "." || value === ".." || /[\\/]/.test(value)) {
    throw new NerveError("INVALID_CAMPAIGN_NAME", "Campaign name is invalid.", { campaign: value });
  }
}
