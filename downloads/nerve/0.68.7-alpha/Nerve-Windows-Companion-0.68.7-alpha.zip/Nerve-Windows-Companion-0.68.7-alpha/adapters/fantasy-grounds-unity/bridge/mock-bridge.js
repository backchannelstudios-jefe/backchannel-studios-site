import { readFile } from "node:fs/promises";
import { NerveError } from "../../../core/errors.js";

export class MockFantasyGroundsBridge {
  constructor({ campaignSummaryFixturePath, combatTrackerFixturePath, partyFixturePath, characterFixturePath, recentEventsFixturePath }) {
    this.campaignSummaryFixturePath = campaignSummaryFixturePath;
    this.combatTrackerFixturePath = combatTrackerFixturePath;
    this.partyFixturePath = partyFixturePath;
    this.characterFixturePath = characterFixturePath;
    this.recentEventsFixturePath = recentEventsFixturePath;
  }

  async getCampaignSummary(_context) {
    return JSON.parse(await readFile(this.campaignSummaryFixturePath, "utf8"));
  }

  async getCombatTracker(_context) {
    return JSON.parse(await readFile(this.combatTrackerFixturePath, "utf8"));
  }

  async getParty(_context) {
    return JSON.parse(await readFile(this.partyFixturePath, "utf8"));
  }

  async getCharacter(id, _context) {
    const character = JSON.parse(await readFile(this.characterFixturePath, "utf8"));
    if (character.id !== id) throw new NerveError("CHARACTER_NOT_FOUND", `Fantasy Grounds character not found: ${id}`, { id });
    return character;
  }

  async getCurrentEncounter(_context) {
    const tracker = await this.getCombatTracker(_context);
    const participants = tracker.combatants.map(({ id, name, faction, active, status, hitPoints, disposition, threat }) => {
      const resolvedDisposition = disposition ?? inferDisposition({ status, hitPoints });
      return { id, name, faction, active, disposition: resolvedDisposition, threat: threat ?? (faction === "foe" && resolvedDisposition === "active") };
    });
    const activeFoeCount = participants.filter((item) => item.faction === "foe" && item.threat).length;
    return {
      active: activeFoeCount > 0,
      id: activeFoeCount > 0 ? "combat-tracker" : null,
      round: tracker.round,
      activeCombatantId: participants.find((item) => item.active)?.id ?? null,
      participantCount: participants.length,
      friendlyCount: participants.filter((item) => item.faction === "friend").length,
      foeCount: participants.filter((item) => item.faction === "foe").length,
      activeFoeCount,
      neutralCount: participants.filter((item) => item.faction === "neutral").length,
      participants,
      observedAt: tracker.observedAt
    };
  }

  async getRecentEvents({ afterSequence = 0, limit = 50, types } = {}, _context) {
    const state = JSON.parse(await readFile(this.recentEventsFixturePath, "utf8"));
    const typeSet = types ? new Set(types) : null;
    return { ...state, events: state.events.filter((event) => event.sequence > afterSequence).filter((event) => !typeSet || typeSet.has(event.type)).slice(-limit) };
  }

  async waitForEvents({ cursor, eventLimit = 25, replayExisting = false } = {}, context) {
    const current = await this.getRecentEvents({
      afterSequence: replayExisting || (cursor && cursor.streamId !== "fixture-stream-1") ? 0 : (cursor?.sequence ?? Number.MAX_SAFE_INTEGER),
      limit: eventLimit
    }, context);
    const cursorReset = Boolean(cursor && cursor.streamId !== current.streamId);
    return {
      recentEvents: current,
      cursorReset,
      timedOut: current.events.length === 0,
      waitedMs: 0,
      nextCursor: { streamId: current.streamId, sequence: current.latestSequence }
    };
  }

  async getDmBriefing({ cursor, eventLimit = 25 } = {}, context) {
    const [campaignSummary, combatTracker, party, state] = await Promise.all([
      this.getCampaignSummary(context),
      this.getCombatTracker(context),
      this.getParty(context),
      readFile(this.recentEventsFixturePath, "utf8").then(JSON.parse)
    ]);
    const cursorReset = Boolean(cursor && cursor.streamId !== state.streamId);
    const afterSequence = cursorReset ? 0 : (cursor?.sequence ?? 0);
    const recentEvents = {
      ...state,
      events: state.events.filter((event) => event.sequence > afterSequence).slice(-eventLimit)
    };
    return {
      campaignSummary,
      currentEncounter: await this.getCurrentEncounter(context),
      combatTracker,
      party,
      campaignFocus: {
        activeAdventureModule: "Fixture",
        displayName: "Fixture Adventure",
        status: "ready",
        recordCount: 4,
        confirmedAt: "2026-08-11T21:00:00Z",
        suggestedModule: "Fixture",
        creativeAuthority: "bounded_improvisation"
      },
      actionContext: { actor: "", characterId: "", triggerText: "", powers: [], spellSlots: [], targetCandidates: [], unresolvedTarget: null },
      questLog: { quests: [], count: 0, activeCount: 0 },
      mapScene: await this.getMapScene(context),
      sessionContinuity: await this.getSessionContinuity(context),
      sessionOperations: await this.getSessionStatus(context),
      recentEvents,
      cursorReset,
      nextCursor: { streamId: state.streamId, sequence: state.latestSequence }
    };
  }

  async searchLibrary({ query = "", recordTypes, module = "", limit = 25 } = {}, _context) {
    const records = mockLibraryRecords();
    const q = query.toLowerCase();
    const m = module.toLowerCase();
    const types = recordTypes ? new Set(recordTypes) : null;
    const matched = records.filter((record) =>
      (!q || `${record.name} ${record.module} ${record.category}`.toLowerCase().includes(q)) &&
      (!m || record.module.toLowerCase().includes(m)) &&
      (!types || types.has(record.recordType))
    );
    return { records: matched.slice(0, limit).map(({ fields: _fields, ...record }) => record), matched: matched.length, indexed: records.length, truncated: false, observedAt: "2026-08-11T21:00:00Z" };
  }

  async getLibraryRecord(id, _context) {
    const record = mockLibraryRecords().find((item) => item.id === id);
    if (!record) throw new NerveError("LIBRARY_RECORD_NOT_FOUND", `Fantasy Grounds library record not found: ${id}`, { id });
    return { ...record, observedAt: "2026-08-11T21:00:00Z" };
  }

  async getManualAdjudications(_context) {
    return { tasks: [], observedAt: "2026-08-11T21:00:00Z" };
  }

  async getSessionStatus(_context) {
    return {
      status: "not_started", held: false, playStyle: "mixed", sessionId: "", startedAt: "", endedAt: "",
      actionsProcessed: 0, approved: 0, denied: 0, failed: 0, sessionGrantExecutions: 0,
      approvalPolicy: {
        mode: "manual", narrativeFlow: false, proxyActions: false, combatPacing: false, entityProxy: false,
        automaticCapabilities: [],
        alwaysManualCapabilities: ["request_vote", "add_library_npc", "add_library_encounter", "open_library_image", "set_spell_slot_usage", "apply_effect", "remove_effect", "remove_combatant", "resolve_manual_adjudication", "set_combatant_threat", "set_combatant_visibility", "record_session_continuity"]
      },
      connectedPlayers: 0, partyMembers: 2, combatants: 3, libraryIndexed: 4,
      pendingPlayerResponses: 0, pendingManualAdjudications: 0,
      summary: "No Nerve live session has been started.", snapshotBytes: 4096, approximateSnapshotTokens: 1024,
      observedAt: "2026-08-11T21:00:00Z"
    };
  }

  async getSessionContinuity(_context) {
    return { available: false, latest: null, history: [], observedAt: "2026-08-11T21:00:00Z" };
  }

  async getOpenMaps(_context) {
    return {
      maps: [{ recordId: "image.cave", name: "Cave Map", panel: "window", shareMode: "none", holders: [], current: true }],
      currentMapId: "image.cave",
      observedAt: "2026-08-11T21:00:00Z"
    };
  }

  async getMapScene(_context) {
    return {
      recordId: "image.cave", name: "Cave Map", panel: "window", shareMode: "none", holders: [],
      playStyle: "mixed",
      grid: { enabled: true, sizeX: 50, sizeY: 50, offsetX: 0, offsetY: 0, type: 0 },
      viewport: { width: 600, height: 600 },
      areaContinuity: { currentAreaKey: null, areas: [] },
      recordLinks: [],
      spatial: {
        coordinateSystem: "grid", partyTokenCount: 0, foeTokenCount: 1, neutralTokenCount: 0, unlinkedTokenCount: 0,
        partyCentroid: null, foeCentroid: { x: 200, y: 250, gridX: 4, gridY: 5 }, nearestVisibleHostile: null,
        partyAreaCandidates: [], foeAreaCandidates: [],
        visionModel: "native_token_and_ct_visibility", limitations: ["Fixture vision is bounded."], placementWarnings: ["No friendly party token is present on the current map; spatial relationships are incomplete."]
      },
      tokens: [{ tokenId: "1", name: "Goblin", combatantId: "id-00002", faction: "foe", x: 200, y: 250, gridX: 4, gridY: 5, distanceFromPartyGridUnits: null, areaCandidateKey: null, areaCandidateRecordId: null, distanceFromAreaMarkerGridUnits: null, playerVisible: true }],
      observedAt: "2026-08-11T21:00:00Z"
    };
  }

  async sendChat({ text, visibility, recipients }, _context) {
    return { delivered: true, text, visibility, ...(recipients ? { recipients } : {}), executedAt: "2026-08-11T21:00:00Z" };
  }

  async recordSessionContinuity(args, _context) {
    return {
      id: "checkpoint-20260811210000", sessionId: args.sessionId, source: "ai_confirmed",
      createdAt: "2026-08-11T21:00:00Z", summary: args.summary, currentSituation: args.currentSituation,
      unresolvedThreads: args.unresolvedThreads, partyGoals: args.partyGoals, importantNpcs: args.importantNpcs,
      partyOrigin: args.partyOrigin, reasonHere: args.reasonHere, locationsVisited: args.locationsVisited,
      npcsMet: args.npcsMet, conversationHighlights: args.conversationHighlights,
      discoveries: args.discoveries, completedObjectives: args.completedObjectives,
      nextSessionOpening: args.nextSessionOpening, sourceEventSequence: args.sourceEventSequence,
      map: { recordId: "image.cave", name: "Cave Map", currentAreaKey: null },
      combat: { active: false, round: 0, activeCombatantId: null }
    };
  }

  async requestVote({ question }, _context) {
    return { opened: true, question, executedAt: "2026-08-11T21:00:00Z" };
  }

  async requestPlayerInput({ prompt, responseType, audience, recipients = [] }, context) {
    return {
      opened: true,
      promptId: context.requestId,
      responseType,
      audience,
      recipients: audience === "gm" ? ["GM"] : recipients,
      deadlineAt: "2026-08-11T21:05:00Z",
      executedAt: "2026-08-11T21:00:00Z"
    };
  }

  async requestPlayerRoll({ rollType, audience, recipients = [] }, context) {
    return {
      opened: true,
      rollRequestId: context.requestId,
      rollType,
      audience,
      recipients: audience === "gm" ? ["GM"] : recipients,
      deadlineAt: "2026-08-11T21:05:00Z",
      executedAt: "2026-08-11T21:00:00Z"
    };
  }

  async proxyCharacterRoll({ characterId, rollType, rollMode, visibility }, _context) {
    return {
      launched: true,
      characterId,
      characterName: "Aria Vale",
      rollType,
      rollMode,
      visibility,
      executedAt: "2026-08-11T21:00:00Z"
    };
  }

  async proxyCharacterPowerAction({ characterId, powerId, actionId, targetCombatantIds, spellSlot }, context) {
    const result = {
      launched: true,
      correlationId: context.requestId,
      characterId,
      characterName: "Aria Vale",
      powerId,
      powerName: "Magic Missile",
      actionId,
      actionType: spellSlot ? "cast" : "damage",
      targetCombatantIds,
      targetCount: targetCombatantIds.length,
      slotConsumed: Boolean(spellSlot),
      executedAt: "2026-08-11T21:00:00Z"
    };
    if (spellSlot) {
      result.spellSlot = {
        level: spellSlot.level,
        previousUsed: spellSlot.expectedUsed,
        used: spellSlot.expectedUsed + 1,
        maximum: 3,
        available: 2 - spellSlot.expectedUsed
      };
    }
    return result;
  }

  async proxyCombatantAction({ combatantId, section, actionId, abilityIndex, targetCombatantIds, followUpContexts = [] }, context) {
    return {
      launched: true,
      correlationId: context.requestId,
      combatantId,
      combatantName: "Gnoll Warrior",
      section,
      actionId,
      actionName: "Rend",
      abilityIndex,
      actionType: abilityIndex === 1 ? "attack" : "damage",
      targetCombatantIds,
      targetCount: targetCombatantIds.length,
      followUpContextCount: followUpContexts.length,
      executedAt: "2026-08-11T21:00:00Z"
    };
  }

  async addLibraryNpc({ recordId, expectedName, quantity, faction, identified, name }, _context) {
    return {
      recordId,
      recordName: expectedName,
      quantity,
      faction,
      identified,
      combatants: Array.from({ length: quantity }, (_, index) => ({
        id: `id-${String(10 + index).padStart(5, "0")}`,
        name: name ?? `${expectedName} ${index + 1}`
      })),
      executedAt: "2026-08-11T21:00:00Z"
    };
  }

  async addLibraryEncounter({ recordId, expectedName }, _context) {
    return {
      recordId,
      encounterName: expectedName,
      addedCount: 2,
      combatants: [
        { id: "id-00010", name: "Goblin 1" },
        { id: "id-00011", name: "Goblin 2" }
      ],
      maps: [{ recordId: "image.cave", name: "Cave Map" }],
      playerVisionPreserved: true,
      continuityRecorded: false,
      executedAt: "2026-08-11T21:00:00Z"
    };
  }

  async beginStoryEncounter({ sourceStoryRecordId, currentAreaKey, preparedEncounters, expectedCombatantIds }, _context) {
    return {
      started: true, sourceStoryRecordId, currentAreaKey,
      encounters: preparedEncounters.map(({ recordId, expectedName }) => ({ recordId, name: expectedName })),
      addedCombatants: [{ id: "id-00099", name: "Story Foe" }], relocatedCount: 1,
      round: 1, activeCombatantId: expectedCombatantIds[0],
      initiativeOrder: expectedCombatantIds.map((combatantId, index) => ({ combatantId, name: `Combatant ${index + 1}`, initiative: 20 - index, playerVisible: true })),
      executedAt: new Date().toISOString()
    };
  }

  async beginStoryNpcEncounter({ sourceStoryRecordId, npcs, expectedCombatantIds }, _context) {
    const addedCombatants = npcs.flatMap((npc, npcIndex) => Array.from({ length: npc.quantity }, (_, index) => ({
      id: `id-${String(90 + npcIndex * 10 + index).padStart(5, "0")}`,
      name: npc.expectedName
    })));
    const roster = [...expectedCombatantIds, ...addedCombatants.map((item) => item.id)];
    return {
      started: true, sourceStoryRecordId,
      npcs: npcs.map(({ recordId, expectedName, quantity }) => ({ recordId, name: expectedName, quantity })),
      addedCombatants, round: 1, activeCombatantId: roster[0],
      initiativeOrder: roster.map((combatantId, index) => ({ combatantId, name: `Combatant ${index + 1}`, initiative: 20 - index, playerVisible: true })),
      executedAt: new Date().toISOString()
    };
  }

  async createQuest({ name, status }, _context) {
    return { questId: "id-00001", name, previousStatus: null, status, created: true, executedAt: new Date().toISOString() };
  }

  async updateQuest({ questId, status }, _context) {
    return { questId, name: "Fixture Quest", previousStatus: "active", status, created: false, executedAt: new Date().toISOString() };
  }

  async openLibraryImage({ recordId, expectedName, visibility }, _context) {
    return {
      recordId, name: expectedName, visibility, opened: true,
      shared: visibility === "all", alreadyOpen: false,
      executedAt: "2026-08-11T21:00:00Z"
    };
  }

  async setSpellSlotUsage({ characterId, level, expectedUsed, used }, _context) {
    return {
      characterId,
      characterName: "Aria Vale",
      level,
      previousUsed: expectedUsed,
      used,
      maximum: 3,
      available: 3 - used,
      executedAt: "2026-08-11T21:00:00Z"
    };
  }

  async advanceTurn({ expectedActiveCombatantId, skipDefeated = false }, _context) {
    return { previousCombatantId: expectedActiveCombatantId, activeCombatantId: "id-00003", round: 3, skippedCombatantIds: skipDefeated ? ["id-00002"] : [], executedAt: "2026-08-11T21:00:00Z" };
  }

  async startEncounter({ expectedCombatantIds, expectedRound }, _context) {
    return {
      started: true, round: expectedRound, activeCombatantId: expectedCombatantIds[0],
      initiativeOrder: expectedCombatantIds.map((combatantId, index) => ({
        combatantId, name: `Combatant ${index + 1}`, initiative: 20 - index, playerVisible: index === 0
      })),
      executedAt: "2026-08-11T21:00:00Z"
    };
  }

  async applyEffect({ combatantId, label, duration, gmOnly }, _context) {
    return { combatantId, effectId: "id-00009", label, duration, gmOnly, executedAt: "2026-08-11T21:00:00Z" };
  }

  async removeEffect({ combatantId, effectId, expectedLabel }, _context) {
    return { removed: true, combatantId, effectId, label: expectedLabel, executedAt: "2026-08-11T21:00:00Z" };
  }

  async removeCombatant({ combatantId, expectedName, expectedFaction }, _context) {
    return { removed: true, combatantId, name: expectedName, faction: expectedFaction, executedAt: "2026-08-11T21:00:00Z" };
  }

  async resolveManualAdjudication({ adjudicationId, resolution, note = "" }, _context) {
    return { adjudicationId, resolution, actionName: "Slowing Breath", targetName: "Goblin", note, resolvedAt: "2026-08-11T21:00:00Z" };
  }

  async setCombatantThreat({ combatantId, active }, _context) {
    return { combatantId, active, previousFaction: active ? "neutral" : "foe", faction: active ? "foe" : "neutral", executedAt: "2026-08-11T21:00:00Z" };
  }

  async setCombatantVisibility({ combatantId, expectedVisible, visible, discoveryBasis }, _context) {
    return { combatantId, combatantName: "Gnoll Warrior", previousVisible: expectedVisible, visible, discoveryBasis, executedAt: "2026-08-11T21:00:00Z" };
  }
}

function inferDisposition({ status, hitPoints }) {
  const lowered = String(status ?? "").toLowerCase();
  if (lowered === "dead") return "dead";
  if (lowered === "unconscious") return "unconscious";
  if (lowered === "escaped") return "escaped";
  if (lowered === "dormant") return "dormant";
  if (lowered === "dying" || (hitPoints?.total > 0 && hitPoints.wounds >= hitPoints.total)) return "defeated";
  return "active";
}

function mockLibraryRecords() {
  return [
    { id: "reference.items.id-00001@Fixture", name: "Potion of Healing", recordType: "item", module: "Fixture", category: "Magic Items", fields: { type: "Potion", rarity: "common" } },
    { id: "reference.refmanualdata.id-00001@Fixture", name: "The Ruined Shrine", recordType: "story", module: "Fixture", category: "Chapter 1", fields: { text: "A bounded fixture excerpt." } },
    { id: "reference.treasureparcels.id-00001@Fixture", name: "Shrine Cache", recordType: "treasureparcel", module: "Fixture", category: "Treasure", fields: { description: "A bounded parcel." } },
    { id: "reference.vehicles.id-00001@Fixture", name: "River Barge", recordType: "vehicle", module: "Fixture", category: "Vehicles", fields: { type: "Water" } }
  ];
}
