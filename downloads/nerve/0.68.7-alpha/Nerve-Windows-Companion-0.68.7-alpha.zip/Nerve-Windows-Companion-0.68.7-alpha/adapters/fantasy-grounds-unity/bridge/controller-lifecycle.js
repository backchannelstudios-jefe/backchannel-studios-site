import { readFile } from "node:fs/promises";

export function createFguControllerLifecycleProbe({
  snapshotPath,
  hostStatusPath,
  startupGraceMs = 60000,
  clock = () => Date.now()
}) {
  if (!snapshotPath || !hostStatusPath) throw new TypeError("FGU lifecycle probe requires snapshot and host-status paths.");
  if (!Number.isInteger(startupGraceMs) || startupGraceMs < 0 || startupGraceMs > 120000) {
    throw new TypeError("FGU lifecycle startupGraceMs must be an integer from 0 to 120000.");
  }
  const startedAt = clock();
  let observedActiveSession = false;
  return async function probe() {
    const [snapshot, host] = await Promise.all([readJson(snapshotPath), readJson(hostStatusPath)]);
    if (host?.status === "closed" && isCurrentHostStatus(host, snapshot)) {
      return { stop: true, reason: "fantasy_grounds_closed" };
    }
    const sessionStatus = snapshot?.sessionOperations?.status;
    if (sessionStatus === "active") observedActiveSession = true;
    if (sessionStatus === "ended") {
      const remainingMs = startupGraceMs - Math.max(0, clock() - startedAt);
      if (!observedActiveSession && remainingMs > 0) {
        return {
          stop: false,
          wait: true,
          reason: "awaiting_active_session",
          retryAfterMs: Math.min(1000, remainingMs)
        };
      }
      return { stop: true, reason: "session_ended" };
    }
    return { stop: false };
  };
}

async function readJson(path) {
  try {
    const text = await readFile(path, "utf8");
    return JSON.parse(text.charCodeAt(0) === 0xfeff ? text.slice(1) : text);
  } catch (error) {
    if (error.code === "ENOENT" || error instanceof SyntaxError) return null;
    throw error;
  }
}

function isCurrentHostStatus(host, snapshot) {
  const hostTime = Date.parse(host.updatedAt ?? "");
  const snapshotTime = Date.parse(snapshot?.generatedAt ?? "");
  if (!Number.isFinite(hostTime)) return true;
  if (!Number.isFinite(snapshotTime)) return true;
  return hostTime >= snapshotTime;
}
