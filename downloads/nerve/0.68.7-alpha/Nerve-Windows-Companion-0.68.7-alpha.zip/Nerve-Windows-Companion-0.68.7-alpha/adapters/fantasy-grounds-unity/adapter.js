import { readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { createResultSchema } from "../../core/result-schema.js";
import { defineAdapter } from "../../core/adapter-contract.js";
import { createDmDecisionCapability } from "../../core/dm-decision.js";

const inputSchema = loadJson(
  new URL("../../schemas/tools/get-campaign-summary.input.schema.json", import.meta.url)
);
const campaignSummarySchema = loadJson(
  new URL("../../schemas/state/campaign-summary.schema.json", import.meta.url)
);
const combatTrackerInputSchema = loadJson(
  new URL("../../schemas/tools/get-combat-tracker.input.schema.json", import.meta.url)
);
const combatTrackerSchema = loadJson(
  new URL("../../schemas/state/combat-tracker.schema.json", import.meta.url)
);
const partyInputSchema = loadJson(
  new URL("../../schemas/tools/get-party.input.schema.json", import.meta.url)
);
const partySchema = loadJson(new URL("../../schemas/state/party.schema.json", import.meta.url));
const characterInputSchema = loadJson(
  new URL("../../schemas/tools/get-character.input.schema.json", import.meta.url)
);
const characterSchema = loadJson(new URL("../../schemas/state/character.schema.json", import.meta.url));
const currentEncounterInputSchema = loadJson(
  new URL("../../schemas/tools/get-current-encounter.input.schema.json", import.meta.url)
);
const currentEncounterSchema = loadJson(
  new URL("../../schemas/state/current-encounter.schema.json", import.meta.url)
);
const recentEventsInputSchema = loadJson(
  new URL("../../schemas/tools/get-recent-events.input.schema.json", import.meta.url)
);
const recentEventsSchema = loadJson(
  new URL("../../schemas/state/recent-events.schema.json", import.meta.url)
);
const getMapSceneInputSchema = loadJson(new URL("../../schemas/tools/get-map-scene.input.schema.json", import.meta.url));
const mapSceneSchema = loadJson(new URL("../../schemas/state/map-scene.schema.json", import.meta.url));
const campaignFocusSchema = loadJson(new URL("../../schemas/state/campaign-focus.schema.json", import.meta.url));
const actionContextSchema = loadJson(new URL("../../schemas/state/action-context.schema.json", import.meta.url));
const storyCuesSchema = loadJson(new URL("../../schemas/state/story-cues.schema.json", import.meta.url));
const questLogSchema = loadJson(new URL("../../schemas/state/quest-log.schema.json", import.meta.url));
const getSessionContinuityInputSchema = loadJson(new URL("../../schemas/tools/get-session-continuity.input.schema.json", import.meta.url));
const recordSessionContinuityInputSchema = loadJson(new URL("../../schemas/tools/record-session-continuity.input.schema.json", import.meta.url));
const sessionContinuitySource = loadJson(new URL("../../schemas/state/session-continuity.schema.json", import.meta.url));
const sessionContinuityCheckpointSchema = loadJson(new URL("../../schemas/state/record-session-continuity-result.schema.json", import.meta.url));
const sessionOperationsSchema = loadJson(new URL("../../schemas/state/session-operations.schema.json", import.meta.url));
const sessionContinuitySchema = {
  ...sessionContinuitySource,
  properties: {
    ...sessionContinuitySource.properties,
    latest: { ...sessionContinuityCheckpointSchema, type: ["object", "null"] },
    history: { type: "array", maxItems: 10, items: sessionContinuityCheckpointSchema }
  }
};
const dmBriefingInputSchema = loadJson(
  new URL("../../schemas/tools/get-dm-briefing.input.schema.json", import.meta.url)
);
const runDmCycleInputSchema = loadJson(
  new URL("../../schemas/tools/run-dm-cycle.input.schema.json", import.meta.url)
);
const waitForEventsInputSchema = loadJson(
  new URL("../../schemas/tools/wait-for-events.input.schema.json", import.meta.url)
);
const eventWaitSchemaSource = loadJson(
  new URL("../../schemas/state/event-wait.schema.json", import.meta.url)
);
const eventWaitSchema = {
  ...eventWaitSchemaSource,
  properties: { ...eventWaitSchemaSource.properties, recentEvents: recentEventsSchema }
};
const dmBriefingSchema = {
  type: "object",
  additionalProperties: false,
  required: [
    "campaignSummary", "currentEncounter", "combatTracker", "party",
    "recentEvents", "mapScene", "campaignFocus", "actionContext", "questLog", "sessionContinuity", "sessionOperations", "cursorReset", "nextCursor"
  ],
  properties: {
    campaignSummary: campaignSummarySchema,
    currentEncounter: currentEncounterSchema,
    combatTracker: combatTrackerSchema,
    party: partySchema,
    recentEvents: recentEventsSchema,
    mapScene: mapSceneSchema,
    campaignFocus: campaignFocusSchema,
    actionContext: actionContextSchema,
    storyCues: storyCuesSchema,
    narrativeReferences: { type: "array", maxItems: 8, items: { type: "object" } },
    questLog: questLogSchema,
    sessionContinuity: sessionContinuitySchema,
    sessionOperations: sessionOperationsSchema,
    cursorReset: { type: "boolean" },
    nextCursor: {
      type: "object",
      additionalProperties: false,
      required: ["streamId", "sequence"],
      properties: {
        streamId: { type: "string", minLength: 1 },
        sequence: { type: "integer", minimum: 0 }
      }
    }
  }
};
const sendChatInputSchema = loadJson(new URL("../../schemas/tools/send-chat.input.schema.json", import.meta.url));
const sendChatResultSchema = loadJson(new URL("../../schemas/state/send-chat-result.schema.json", import.meta.url));
const requestVoteInputSchema = loadJson(new URL("../../schemas/tools/request-vote.input.schema.json", import.meta.url));
const requestVoteResultSchema = loadJson(new URL("../../schemas/state/request-vote-result.schema.json", import.meta.url));
const requestPlayerInputSchema = loadJson(new URL("../../schemas/tools/request-player-input.input.schema.json", import.meta.url));
const requestPlayerInputResultSchema = loadJson(new URL("../../schemas/state/request-player-input-result.schema.json", import.meta.url));
const requestPlayerRollSchema = loadJson(new URL("../../schemas/tools/request-player-roll.input.schema.json", import.meta.url));
const requestPlayerRollResultSchema = loadJson(new URL("../../schemas/state/request-player-roll-result.schema.json", import.meta.url));
const proxyCharacterRollSchema = loadJson(new URL("../../schemas/tools/proxy-character-roll.input.schema.json", import.meta.url));
const proxyCharacterRollResultSchema = loadJson(new URL("../../schemas/state/proxy-character-roll-result.schema.json", import.meta.url));
const proxyCharacterPowerActionSchema = loadJson(new URL("../../schemas/tools/proxy-character-power-action.input.schema.json", import.meta.url));
const proxyCharacterPowerActionResultSchema = loadJson(new URL("../../schemas/state/proxy-character-power-action-result.schema.json", import.meta.url));
const proxyCombatantActionSchema = loadJson(new URL("../../schemas/tools/proxy-combatant-action.input.schema.json", import.meta.url));
const proxyCombatantActionResultSchema = loadJson(new URL("../../schemas/state/proxy-combatant-action-result.schema.json", import.meta.url));
const addLibraryNpcSchema = loadJson(new URL("../../schemas/tools/add-library-npc.input.schema.json", import.meta.url));
const addLibraryNpcResultSchema = loadJson(new URL("../../schemas/state/add-library-npc-result.schema.json", import.meta.url));
const addLibraryEncounterSchema = loadJson(new URL("../../schemas/tools/add-library-encounter.input.schema.json", import.meta.url));
const addLibraryEncounterResultSchema = loadJson(new URL("../../schemas/state/add-library-encounter-result.schema.json", import.meta.url));
const beginStoryEncounterSchema = loadJson(new URL("../../schemas/tools/begin-story-encounter.input.schema.json", import.meta.url));
const beginStoryEncounterResultSchema = loadJson(new URL("../../schemas/state/begin-story-encounter-result.schema.json", import.meta.url));
const beginStoryNpcEncounterSchema = loadJson(new URL("../../schemas/tools/begin-story-npc-encounter.input.schema.json", import.meta.url));
const beginStoryNpcEncounterResultSchema = loadJson(new URL("../../schemas/state/begin-story-npc-encounter-result.schema.json", import.meta.url));
const createQuestSchema = loadJson(new URL("../../schemas/tools/create-quest.input.schema.json", import.meta.url));
const updateQuestSchema = loadJson(new URL("../../schemas/tools/update-quest.input.schema.json", import.meta.url));
const questResultSchema = loadJson(new URL("../../schemas/state/quest-result.schema.json", import.meta.url));
const setSpellSlotUsageSchema = loadJson(new URL("../../schemas/tools/set-spell-slot-usage.input.schema.json", import.meta.url));
const setSpellSlotUsageResultSchema = loadJson(new URL("../../schemas/state/set-spell-slot-usage-result.schema.json", import.meta.url));
const advanceTurnInputSchema = loadJson(new URL("../../schemas/tools/advance-turn.input.schema.json", import.meta.url));
const advanceTurnResultSchema = loadJson(new URL("../../schemas/state/advance-turn-result.schema.json", import.meta.url));
const startEncounterInputSchema = loadJson(new URL("../../schemas/tools/start-encounter.input.schema.json", import.meta.url));
const startEncounterResultSchema = loadJson(new URL("../../schemas/state/start-encounter-result.schema.json", import.meta.url));
const applyEffectInputSchema = loadJson(new URL("../../schemas/tools/apply-effect.input.schema.json", import.meta.url));
const applyEffectResultSchema = loadJson(new URL("../../schemas/state/apply-effect-result.schema.json", import.meta.url));
const removeEffectInputSchema = loadJson(new URL("../../schemas/tools/remove-effect.input.schema.json", import.meta.url));
const removeEffectResultSchema = loadJson(new URL("../../schemas/state/remove-effect-result.schema.json", import.meta.url));
const removeCombatantInputSchema = loadJson(new URL("../../schemas/tools/remove-combatant.input.schema.json", import.meta.url));
const removeCombatantResultSchema = loadJson(new URL("../../schemas/state/remove-combatant-result.schema.json", import.meta.url));
const resolveManualAdjudicationInputSchema = loadJson(new URL("../../schemas/tools/resolve-manual-adjudication.input.schema.json", import.meta.url));
const resolveManualAdjudicationResultSchema = loadJson(new URL("../../schemas/state/resolve-manual-adjudication-result.schema.json", import.meta.url));
const setCombatantThreatInputSchema = loadJson(new URL("../../schemas/tools/set-combatant-threat.input.schema.json", import.meta.url));
const setCombatantThreatResultSchema = loadJson(new URL("../../schemas/state/set-combatant-threat-result.schema.json", import.meta.url));
const setCombatantVisibilityInputSchema = loadJson(new URL("../../schemas/tools/set-combatant-visibility.input.schema.json", import.meta.url));
const setCombatantVisibilityResultSchema = loadJson(new URL("../../schemas/state/set-combatant-visibility-result.schema.json", import.meta.url));
const searchLibraryInputSchema = loadJson(new URL("../../schemas/tools/search-library.input.schema.json", import.meta.url));
const librarySearchSchema = loadJson(new URL("../../schemas/state/library-search.schema.json", import.meta.url));
const getLibraryRecordInputSchema = loadJson(new URL("../../schemas/tools/get-library-record.input.schema.json", import.meta.url));
const libraryRecordSchema = loadJson(new URL("../../schemas/state/library-record.schema.json", import.meta.url));
const getManualAdjudicationsInputSchema = loadJson(new URL("../../schemas/tools/get-manual-adjudications.input.schema.json", import.meta.url));
const manualAdjudicationsSchema = loadJson(new URL("../../schemas/state/manual-adjudications.schema.json", import.meta.url));
const getSessionPreflightInputSchema = loadJson(new URL("../../schemas/tools/get-session-preflight.input.schema.json", import.meta.url));
const sessionPreflightSchema = loadJson(new URL("../../schemas/state/session-preflight.schema.json", import.meta.url));
const getSessionStatusInputSchema = loadJson(new URL("../../schemas/tools/get-session-status.input.schema.json", import.meta.url));
const getOpenMapsInputSchema = loadJson(new URL("../../schemas/tools/get-open-maps.input.schema.json", import.meta.url));
const openMapsSchema = loadJson(new URL("../../schemas/state/open-maps.schema.json", import.meta.url));
const openLibraryImageInputSchema = loadJson(new URL("../../schemas/tools/open-library-image.input.schema.json", import.meta.url));
const openLibraryImageResultSchema = loadJson(new URL("../../schemas/state/open-library-image-result.schema.json", import.meta.url));
const listCampaignsInputSchema = loadJson(new URL("../../schemas/tools/list-campaigns.input.schema.json", import.meta.url));
const campaignListSchema = loadJson(new URL("../../schemas/state/campaign-list.schema.json", import.meta.url));
const getConnectionStatusInputSchema = loadJson(new URL("../../schemas/tools/get-connection-status.input.schema.json", import.meta.url));
const connectionStatusSchema = loadJson(new URL("../../schemas/state/connection-status.schema.json", import.meta.url));
const selectCampaignInputSchema = loadJson(new URL("../../schemas/tools/select-campaign.input.schema.json", import.meta.url));
const campaignSelectionSchema = loadJson(new URL("../../schemas/state/campaign-selection.schema.json", import.meta.url));

export function createFantasyGroundsCapabilities(bridge) {
  const capabilities = [
    {
      name: "get_campaign_summary",
      title: "Get Campaign Summary",
      description:
        "Read the authoritative identity and high-level activity state of the connected Fantasy Grounds campaign.",
      access: "read",
      destructive: false,
      idempotent: true,
      inputSchema,
      dataSchema: campaignSummarySchema,
      outputSchema: createResultSchema(campaignSummarySchema),
      execute: (_args, context) => bridge.getCampaignSummary(context)
    },
    {
      name: "get_combat_tracker",
      title: "Get Combat Tracker",
      description:
        "Read the authoritative Fantasy Grounds combat order, active turn, health state, and effects visible to the GM.",
      access: "read",
      destructive: false,
      idempotent: true,
      inputSchema: combatTrackerInputSchema,
      dataSchema: combatTrackerSchema,
      outputSchema: createResultSchema(combatTrackerSchema),
      execute: (_args, context) => bridge.getCombatTracker(context)
    },
    {
      name: "get_party",
      title: "Get Party",
      description:
        "Read the authoritative Fantasy Grounds party roster and compact character state visible to the GM.",
      access: "read",
      destructive: false,
      idempotent: true,
      inputSchema: partyInputSchema,
      dataSchema: partySchema,
      outputSchema: createResultSchema(partySchema),
      execute: (_args, context) => bridge.getParty(context)
    },
    {
      name: "get_character",
      title: "Get Character",
      description: "Read one authoritative Fantasy Grounds character sheet by its stable character ID.",
      access: "read",
      destructive: false,
      idempotent: true,
      inputSchema: characterInputSchema,
      dataSchema: characterSchema,
      outputSchema: createResultSchema(characterSchema),
      execute: (args, context) => bridge.getCharacter(args.id, context)
    },
    {
      name: "get_current_encounter",
      title: "Get Current Encounter",
      description: "Read a compact summary of the authoritative active Fantasy Grounds combat encounter.",
      access: "read",
      destructive: false,
      idempotent: true,
      inputSchema: currentEncounterInputSchema,
      dataSchema: currentEncounterSchema,
      outputSchema: createResultSchema(currentEncounterSchema),
      execute: (_args, context) => bridge.getCurrentEncounter(context)
    },
    {
      name: "get_recent_events",
      title: "Get Recent Events",
      description: "Read Pulse's bounded semantic Fantasy Grounds event feed, optionally filtered by event type and cursor.",
      access: "read",
      destructive: false,
      idempotent: true,
      inputSchema: recentEventsInputSchema,
      dataSchema: recentEventsSchema,
      outputSchema: createResultSchema(recentEventsSchema),
      execute: (args, context) => bridge.getRecentEvents(args, context)
    },
    {
      name: "get_dm_briefing",
      title: "Get DM Briefing",
      description:
        "Read one cursor-aware, authoritative Fantasy Grounds briefing containing campaign, encounter, combat, party, active approval policy, and new Pulse events for DM reasoning.",
      access: "read",
      destructive: false,
      idempotent: true,
      inputSchema: dmBriefingInputSchema,
      dataSchema: dmBriefingSchema,
      outputSchema: createResultSchema(dmBriefingSchema),
      execute: (args, context) => bridge.getDmBriefing(args, context)
    },
    {
      name: "run_dm_cycle",
      title: "Run DM Cycle",
      description:
        "Read the next session-scoped DM briefing and automatically advance this AI host session's Pulse cursor. Returns no duplicate events across successful calls; reset starts a fresh bounded observation.",
      access: "read",
      destructive: false,
      idempotent: false,
      inputSchema: runDmCycleInputSchema,
      dataSchema: dmBriefingSchema,
      outputSchema: createResultSchema(dmBriefingSchema),
      execute: async ({ eventLimit = 25, reset = false }, context) => {
        const cursorKey = "fantasyGrounds.dmCycleCursor";
        if (reset) delete context.session.state[cursorKey];
        const briefing = await bridge.getDmBriefing(
          { cursor: context.session.state[cursorKey], eventLimit },
          context
        );
        context.session.state[cursorKey] = structuredClone(briefing.nextCursor);
        return briefing;
      }
    },
    {
      name: "wait_for_events",
      title: "Wait for Fantasy Grounds Events",
      description:
        "Wait up to 55 seconds for a new Pulse event without consuming the DM briefing cursor. Returns immediately on a new event or stream reset and reports clean timeouts.",
      access: "read",
      destructive: false,
      idempotent: false,
      inputSchema: waitForEventsInputSchema,
      dataSchema: eventWaitSchema,
      outputSchema: createResultSchema(eventWaitSchema),
      execute: async ({ eventLimit = 25, timeoutSeconds = 30, reset = false }, context) => {
        const cursorKey = "fantasyGrounds.eventWaitCursor";
        if (reset) delete context.session.state[cursorKey];
        const result = await bridge.waitForEvents({
          cursor: context.session.state[cursorKey],
          eventLimit,
          timeoutMs: timeoutSeconds * 1000,
          replayExisting: reset
        }, context);
        context.session.state[cursorKey] = structuredClone(result.nextCursor);
        return result;
      }
    },
    {
      name: "search_library",
      title: "Search Campaign Library",
      description:
        "Search the bounded index of loaded Fantasy Grounds campaign and module records by title, type, and module provenance.",
      access: "read",
      destructive: false,
      idempotent: true,
      inputSchema: searchLibraryInputSchema,
      dataSchema: librarySearchSchema,
      outputSchema: createResultSchema(librarySearchSchema),
      execute: (args, context) => bridge.searchLibrary(args, context)
    },
    {
      name: "get_library_record",
      title: "Get Campaign Library Record",
      description:
        "Read one indexed Fantasy Grounds story, table, item, NPC, encounter, quest, or image-metadata record by its stable library ID.",
      access: "read",
      destructive: false,
      idempotent: true,
      inputSchema: getLibraryRecordInputSchema,
      dataSchema: libraryRecordSchema,
      outputSchema: createResultSchema(libraryRecordSchema),
      execute: (args, context) => bridge.getLibraryRecord(args.id, context)
    },
    {
      name: "get_manual_adjudications", title: "Get Manual Adjudications",
      description: "Read persistent pending prose-only rules adjudications from the Fantasy Grounds campaign.",
      access: "read", destructive: false, idempotent: true,
      inputSchema: getManualAdjudicationsInputSchema, dataSchema: manualAdjudicationsSchema,
      outputSchema: createResultSchema(manualAdjudicationsSchema),
      execute: (_args, context) => bridge.getManualAdjudications(context)
    },
    {
      name: "get_session_status", title: "Get Live Session Status",
      description: "Read the campaign-backed Nerve live-session state, Hold status, table readiness counts, unresolved work, and bounded action telemetry.",
      access: "read", destructive: false, idempotent: true,
      inputSchema: getSessionStatusInputSchema, dataSchema: sessionOperationsSchema,
      outputSchema: createResultSchema(sessionOperationsSchema),
      execute: (_args, context) => bridge.getSessionStatus(context)
    },
    {
      name: "get_session_continuity", title: "Get Session Continuity",
      description: "Read the latest durable narrative handoff and bounded prior-session checkpoint history.",
      access: "read", destructive: false, idempotent: true,
      inputSchema: getSessionContinuityInputSchema, dataSchema: sessionContinuitySchema,
      outputSchema: createResultSchema(sessionContinuitySchema),
      execute: (_args, context) => bridge.getSessionContinuity(context)
    },
    {
      name: "get_open_maps", title: "Get Open Maps",
      description: "Read the exact Fantasy Grounds image records currently open on the GM host, including current-map and native sharing state.",
      access: "read", destructive: false, idempotent: true,
      inputSchema: getOpenMapsInputSchema, dataSchema: openMapsSchema,
      outputSchema: createResultSchema(openMapsSchema),
      execute: (_args, context) => bridge.getOpenMaps(context)
    },
    {
      name: "get_map_scene", title: "Get Current Map Scene",
      description: "Read current scene style, map/grid/viewport metadata, native sharing, and bounded token positions without changing Fantasy Grounds.",
      access: "read", destructive: false, idempotent: true,
      inputSchema: getMapSceneInputSchema, dataSchema: mapSceneSchema,
      outputSchema: createResultSchema(mapSceneSchema),
      execute: (_args, context) => bridge.getMapScene(context)
    },
    {
      name: "get_session_preflight", title: "Get Session Preflight",
      description: "Read a compact Session 0/1 readiness packet covering connection, players, party, combat, pending adjudications, and loaded library.",
      access: "read", destructive: false, idempotent: true,
      inputSchema: getSessionPreflightInputSchema, dataSchema: sessionPreflightSchema,
      outputSchema: createResultSchema(sessionPreflightSchema),
      execute: async (_args, context) => {
        const [summary, party, tracker, adjudications, library, sessionStatus, scene, continuity] = await Promise.all([
          bridge.getCampaignSummary(context), bridge.getParty(context), bridge.getCombatTracker(context),
          bridge.getManualAdjudications(context), bridge.searchLibrary({ limit: 1 }, context), bridge.getSessionStatus(context),
          bridge.getMapScene(context), bridge.getSessionContinuity(context)
        ]);
        const check = (key, pass, good, warning) => ({ key, status: pass ? "pass" : "warn", summary: pass ? good : warning });
        return {
          campaign: summary.name, ruleset: summary.ruleset, connectedPlayers: summary.connectedPlayers,
          partyMembers: party.members.map((member) => member.name), combatants: tracker.combatants.length,
          inCombat: summary.inCombat, pendingManualAdjudications: adjudications.tasks.length,
          libraryIndexed: library.indexed, playStyle: scene.playStyle,
          currentMapName: scene.recordId ? scene.name : null, mapShareMode: scene.shareMode,
          continuityAvailable: continuity.available, continuitySource: continuity.latest?.source ?? null,
          checks: [
            check("party", party.members.length > 0, `${party.members.length} party member(s) ready.`, "No party members are present."),
            check("players", summary.connectedPlayers > 0, `${summary.connectedPlayers} player connection(s) active.`, "No remote players are connected yet."),
            check("library", library.indexed > 0, `${library.indexed} loaded library record(s) indexed.`, "The loaded library index is empty."),
            check("adjudications", adjudications.tasks.length === 0, "No manual adjudications are pending.", `${adjudications.tasks.length} manual adjudication(s) need review.`),
            check("hold", !sessionStatus.held, "Nerve is available for approved actions.", "Nerve is on Hold; AI mutations are blocked."),
            { key: "scene", status: "info", summary: scene.recordId ? `${scene.playStyle} scene: ${scene.name}; shared ${scene.shareMode}.` : `${scene.playStyle} scene style; no map is currently open.` },
            { key: "session", status: "info", summary: sessionStatus.status === "active" ? "Optional session tracking is active." : "Session tracking is optional; approvals remain available." },
            { key: "continuity", status: continuity.available ? "pass" : "warn", summary: continuity.available ? `Prior-session continuity is available (${continuity.latest.source}).` : "No prior-session narrative continuity checkpoint is available." }
          ],
          observedAt: summary.observedAt
        };
      }
    },
    {
      name: "record_session_continuity",
      title: "Record Session Continuity",
      description: "Persist a confirmed narrative handoff for the current tracked session, including party origin and purpose, locations, NPC meetings, conversations, discoveries, objectives, unresolved threads, and the next-session opening.",
      access: "write", destructive: false, idempotent: false, requiresConfirmation: true,
      inputSchema: recordSessionContinuityInputSchema,
      dataSchema: sessionContinuityCheckpointSchema,
      outputSchema: createResultSchema(sessionContinuityCheckpointSchema),
      execute: (args, context) => bridge.recordSessionContinuity(args, context)
    },
    {
      name: "send_chat",
      title: "Send Chat",
      description: "Queue a Nerve-authored public, GM-only, or recipient-routed chat message in the persistent Fantasy Grounds Action Inbox.",
      access: "write",
      destructive: false,
      idempotent: false,
      requiresConfirmation: true,
      inputSchema: sendChatInputSchema,
      dataSchema: sendChatResultSchema,
      outputSchema: createResultSchema(sendChatResultSchema),
      execute: (args, context) => bridge.sendChat(args, context)
    },
    {
      name: "request_vote",
      title: "Request Vote",
      description: "Prepare a native yes/no/abstain FGU vote; after Action Inbox approval, the GM presses Enter in chat and Nerve verifies the opened poll.",
      access: "write",
      destructive: false,
      idempotent: false,
      requiresConfirmation: true,
      inputSchema: requestVoteInputSchema,
      dataSchema: requestVoteResultSchema,
      outputSchema: createResultSchema(requestVoteResultSchema),
      execute: (args, context) => bridge.requestVote(args, context)
    },
    {
      name: "request_player_input",
      title: "Request Player Input",
      description: "Open a private native Fantasy Grounds response window for the GM, named connected players, or all connected players. Responses return later through private Pulse events.",
      access: "write",
      destructive: false,
      idempotent: false,
      requiresConfirmation: true,
      inputSchema: requestPlayerInputSchema,
      dataSchema: requestPlayerInputResultSchema,
      outputSchema: createResultSchema(requestPlayerInputResultSchema),
      execute: (args, context) => bridge.requestPlayerInput(args, context)
    },
    {
      name: "request_player_roll",
      title: "Request Player Roll",
      description: "Open a private Fantasy Grounds request that lets the recipient roll a native 5E ability check, skill check, saving throw, or initiative roll. The correlated result returns later through a GM-private Pulse event.",
      access: "write",
      destructive: false,
      idempotent: false,
      requiresConfirmation: true,
      inputSchema: requestPlayerRollSchema,
      dataSchema: requestPlayerRollResultSchema,
      outputSchema: createResultSchema(requestPlayerRollResultSchema),
      execute: (args, context) => bridge.requestPlayerRoll(args, context)
    },
    {
      name: "proxy_character_roll",
      title: "Proxy Character Roll",
      description: "Roll a native 5E check, save, skill, or initiative from the GM host for a specific character when Nerve Entity Proxy is enabled.",
      access: "write",
      destructive: true,
      idempotent: false,
      requiresConfirmation: true,
      inputSchema: proxyCharacterRollSchema,
      dataSchema: proxyCharacterRollResultSchema,
      outputSchema: createResultSchema(proxyCharacterRollResultSchema),
      execute: (args, context) => bridge.proxyCharacterRoll(args, context)
    },
    {
      name: "set_spell_slot_usage",
      title: "Set Spell Slot Usage",
      description: "Set one character's used spell slots at a specified level, rejecting the action if the current usage differs from the expected value.",
      access: "write",
      destructive: true,
      idempotent: true,
      requiresConfirmation: true,
      inputSchema: setSpellSlotUsageSchema,
      dataSchema: setSpellSlotUsageResultSchema,
      outputSchema: createResultSchema(setSpellSlotUsageResultSchema),
      execute: (args, context) => bridge.setSpellSlotUsage(args, context)
    },
    {
      name: "proxy_character_power_action",
      title: "Proxy Character Power Action",
      description: "Execute one existing 5E character-sheet power action through Fantasy Grounds' native automation, with explicit Combat Tracker targets, optional concurrency-safe spell-slot consumption, and required one-time outcome contexts for attack/save follow-ups.",
      access: "write",
      destructive: true,
      idempotent: false,
      requiresConfirmation: true,
      inputSchema: proxyCharacterPowerActionSchema,
      dataSchema: proxyCharacterPowerActionResultSchema,
      outputSchema: createResultSchema(proxyCharacterPowerActionResultSchema),
      execute: (args, context) => bridge.proxyCharacterPowerAction(args, context)
    },
    {
      name: "proxy_combatant_action",
      title: "Proxy Combatant Action",
      description: "Execute one parsed NPC/monster Combat Tracker ability through Fantasy Grounds native automation, with explicit targets and one-time correlated contexts for attack/save follow-ups.",
      access: "write",
      destructive: true,
      idempotent: false,
      requiresConfirmation: true,
      inputSchema: proxyCombatantActionSchema,
      dataSchema: proxyCombatantActionResultSchema,
      outputSchema: createResultSchema(proxyCombatantActionResultSchema),
      execute: (args, context) => bridge.proxyCombatantAction(args, context)
    },
    {
      name: "add_library_npc",
      title: "Add Library NPC to Combat Tracker",
      description: "Add a bounded number of copies of one exact loaded-library NPC to the Fantasy Grounds Combat Tracker through native ruleset automation.",
      access: "write",
      destructive: true,
      idempotent: false,
      requiresConfirmation: true,
      inputSchema: addLibraryNpcSchema,
      dataSchema: addLibraryNpcResultSchema,
      outputSchema: createResultSchema(addLibraryNpcResultSchema),
      execute: (args, context) => bridge.addLibraryNpc(args, context)
    },
    {
      name: "add_library_encounter",
      title: "Add Library Encounter to Combat Tracker",
      description: "Add one exact prepared encounter from the loaded Fantasy Grounds library to the Combat Tracker through native ruleset automation.",
      access: "write",
      destructive: true,
      idempotent: false,
      requiresConfirmation: true,
      inputSchema: addLibraryEncounterSchema,
      dataSchema: addLibraryEncounterResultSchema,
      outputSchema: createResultSchema(addLibraryEncounterResultSchema),
      execute: (args, context) => bridge.addLibraryEncounter(args, context)
    },
    {
      name: "begin_story_encounter",
      title: "Begin Grounded Story Encounter",
      description: "Atomically add one to four exact prepared encounters activated by a current-area story trigger, stage their hostile tokens toward the party, reveal established contact, roll native initiative, and activate the first turn.",
      access: "write",
      destructive: true,
      idempotent: false,
      requiresConfirmation: true,
      inputSchema: beginStoryEncounterSchema,
      dataSchema: beginStoryEncounterResultSchema,
      outputSchema: createResultSchema(beginStoryEncounterResultSchema),
      execute: (args, context) => bridge.beginStoryEncounter(args, context)
    },
    {
      name: "begin_story_npc_encounter",
      title: "Begin Exact Story NPC Encounter",
      description: "Atomically add exact loaded-module NPC or trap records explicitly named by a grounded story trigger, roll initiative, and activate the first turn without requiring a prepared Battle record or map.",
      access: "write",
      destructive: true,
      idempotent: false,
      requiresConfirmation: true,
      inputSchema: beginStoryNpcEncounterSchema,
      dataSchema: beginStoryNpcEncounterResultSchema,
      outputSchema: createResultSchema(beginStoryNpcEncounterResultSchema),
      execute: (args, context) => bridge.beginStoryNpcEncounter(args, context)
    },
    {
      name: "create_quest",
      title: "Create Native Quest",
      description: "Create one accepted or active campaign-local Fantasy Grounds Quest record with explicit provenance after checking the current quest log for duplicates.",
      access: "write", destructive: true, idempotent: false, requiresConfirmation: true,
      inputSchema: createQuestSchema, dataSchema: questResultSchema,
      outputSchema: createResultSchema(questResultSchema),
      execute: (args, context) => bridge.createQuest(args, context)
    },
    {
      name: "update_quest",
      title: "Update Native Quest",
      description: "Update the lifecycle and progress summary of one exact campaign-local Fantasy Grounds Quest using optimistic expected status.",
      access: "write", destructive: true, idempotent: false, requiresConfirmation: true,
      inputSchema: updateQuestSchema, dataSchema: questResultSchema,
      outputSchema: createResultSchema(questResultSchema),
      execute: (args, context) => bridge.updateQuest(args, context)
    },
    {
      name: "open_library_image",
      title: "Open Exact Library Image",
      description: "Open one exact loaded-library image on the GM host and optionally share it to every connected player through Fantasy Grounds' native image sharing.",
      access: "write",
      destructive: false,
      idempotent: false,
      requiresConfirmation: true,
      inputSchema: openLibraryImageInputSchema,
      dataSchema: openLibraryImageResultSchema,
      outputSchema: createResultSchema(openLibraryImageResultSchema),
      execute: (args, context) => bridge.openLibraryImage(args, context)
    },
    {
      name: "start_encounter",
      title: "Start Encounter and Roll Initiative",
      description: "Verify the exact current Combat Tracker roster, roll native 5E initiative for every participant without changing player visibility, and activate the first actor.",
      access: "write",
      destructive: true,
      idempotent: false,
      requiresConfirmation: true,
      inputSchema: startEncounterInputSchema,
      dataSchema: startEncounterResultSchema,
      outputSchema: createResultSchema(startEncounterResultSchema),
      execute: (args, context) => bridge.startEncounter(args, context)
    },
    {
      name: "advance_turn",
      title: "Advance Turn",
      description: "Advance combat from the expected active combatant, optionally skipping defeated or unconscious entries in one bounded operation.",
      access: "write",
      destructive: true,
      idempotent: false,
      requiresConfirmation: true,
      inputSchema: advanceTurnInputSchema,
      dataSchema: advanceTurnResultSchema,
      outputSchema: createResultSchema(advanceTurnResultSchema),
      execute: (args, context) => bridge.advanceTurn(args, context)
    },
    {
      name: "apply_effect",
      title: "Apply Effect",
      description: "Apply a bounded effect to a combatant through the Fantasy Grounds Action Inbox.",
      access: "write",
      destructive: true,
      idempotent: false,
      requiresConfirmation: true,
      inputSchema: applyEffectInputSchema,
      dataSchema: applyEffectResultSchema,
      outputSchema: createResultSchema(applyEffectResultSchema),
      execute: (args, context) => bridge.applyEffect(args, context)
    },
    {
      name: "remove_effect",
      title: "Remove Effect",
      description: "Remove one exact Combat Tracker effect by combatant ID and effect ID, rejecting the action if its observed label changed.",
      access: "write",
      destructive: true,
      idempotent: false,
      requiresConfirmation: true,
      inputSchema: removeEffectInputSchema,
      dataSchema: removeEffectResultSchema,
      outputSchema: createResultSchema(removeEffectResultSchema),
      execute: (args, context) => bridge.removeEffect(args, context)
    },
    {
      name: "remove_combatant",
      title: "Remove Exact Combatant",
      description: "Permanently remove one exact Combat Tracker entry after verifying its current ID, name, and faction. Defeat alone never authorizes removal.",
      access: "write",
      destructive: true,
      idempotent: false,
      requiresConfirmation: true,
      inputSchema: removeCombatantInputSchema,
      dataSchema: removeCombatantResultSchema,
      outputSchema: createResultSchema(removeCombatantResultSchema),
      execute: (args, context) => bridge.removeCombatant(args, context)
    },
    {
      name: "resolve_manual_adjudication", title: "Resolve Manual Adjudication",
      description: "Mark one exact persistent manual-adjudication task applied or waived without applying any rules effect.",
      access: "write", destructive: true, idempotent: false, requiresConfirmation: true,
      inputSchema: resolveManualAdjudicationInputSchema, dataSchema: resolveManualAdjudicationResultSchema,
      outputSchema: createResultSchema(resolveManualAdjudicationResultSchema),
      execute: (args, context) => bridge.resolveManualAdjudication(args, context)
    },
    {
      name: "set_combatant_visibility",
      title: "Set Combatant Player Visibility",
      description: "Reveal or hide one exact Combat Tracker combatant after verifying current visibility and recording native vision, detection, or explicit GM override as the discovery basis.",
      access: "write",
      destructive: true,
      idempotent: true,
      requiresConfirmation: true,
      inputSchema: setCombatantVisibilityInputSchema,
      dataSchema: setCombatantVisibilityResultSchema,
      outputSchema: createResultSchema(setCombatantVisibilityResultSchema),
      execute: (args, context) => bridge.setCombatantVisibility(args, context)
    },
    {
      name: "set_combatant_threat",
      title: "Set Combatant Threat",
      description: "Deactivate or restore a combatant as an active threat without deleting its Combat Tracker record. The GM must approve it in Fantasy Grounds.",
      access: "write",
      destructive: true,
      idempotent: true,
      requiresConfirmation: true,
      inputSchema: setCombatantThreatInputSchema,
      dataSchema: setCombatantThreatResultSchema,
      outputSchema: createResultSchema(setCombatantThreatResultSchema),
      execute: (args, context) => bridge.setCombatantThreat(args, context)
    }
  ];
  if (typeof bridge.listCampaigns === "function") {
    capabilities.unshift({
      name: "list_campaigns",
      title: "List Fantasy Grounds Campaigns",
      description: "List Fantasy Grounds campaigns that currently publish readable Nerve snapshots.",
      access: "read",
      destructive: false,
      idempotent: true,
      inputSchema: listCampaignsInputSchema,
      dataSchema: campaignListSchema,
      outputSchema: createResultSchema(campaignListSchema),
      execute: (_args, context) => bridge.listCampaigns(context)
    });
    capabilities.unshift({
      name: "get_connection_status",
      title: "Get Fantasy Grounds Connection Status",
      description: "Report which Fantasy Grounds campaign the Nerve bridge currently targets.",
      access: "read",
      destructive: false,
      idempotent: true,
      inputSchema: getConnectionStatusInputSchema,
      dataSchema: connectionStatusSchema,
      outputSchema: createResultSchema(connectionStatusSchema),
      execute: (_args, context) => bridge.getConnectionStatus(context)
    });
    capabilities.push({
      name: "select_campaign",
      title: "Select Fantasy Grounds Campaign",
      description: "Retarget Nerve to another campaign with a readable snapshot without restarting the MCP server.",
      access: "write",
      destructive: false,
      idempotent: true,
      requiresConfirmation: true,
      inputSchema: selectCampaignInputSchema,
      dataSchema: campaignSelectionSchema,
      outputSchema: createResultSchema(campaignSelectionSchema),
      execute: async (args, context) => {
        const result = await bridge.selectCampaign(args, context);
        delete context.session.state["fantasyGrounds.dmCycleCursor"];
        delete context.session.state["fantasyGrounds.eventWaitCursor"];
        return result;
      }
    });
  }
  return capabilities;
}

export function createFantasyGroundsAdapter(bridge, { journal, clock = () => new Date() } = {}) {
  const capabilities = createFantasyGroundsCapabilities(bridge);
  if (journal) capabilities.push(createDmDecisionCapability({ journal, clock }));
  return defineAdapter({
    id: "fantasy-grounds-unity",
    title: "Fantasy Grounds Unity",
    version: "0.48.3",
    bridge,
    instructions: "For active play, wait_for_events wakes the host and run_dm_cycle returns authoritative delta state, including durable session continuity. On a new tracked session, ground the opening in sessionContinuity.latest and its factual handoff; never invent details missing from that checkpoint or current state. Use stable IDs from current reads and explicit targets. Native vision is authoritative; map coordinates do not prove perception, reach, adjacency, or route continuity, and starting an encounter never reveals hidden creatures. A confirmed narrative checkpoint improves the next opening; End Session always preserves or refreshes authoritative factual continuity. Attack/save follow-ups require matching outcome contexts. Put narration and the next player instruction in one prompt when possible. Every write remains subject to Nerve Guard, confirmed input, and Fantasy Grounds approval.",
    capabilities
  });
}

function loadJson(url) {
  return JSON.parse(readFileSync(fileURLToPath(url), "utf8"));
}
