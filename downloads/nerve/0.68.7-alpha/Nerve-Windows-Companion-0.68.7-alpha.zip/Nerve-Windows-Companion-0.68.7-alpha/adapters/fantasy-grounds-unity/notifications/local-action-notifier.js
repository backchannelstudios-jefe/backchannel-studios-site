import { spawn } from "node:child_process";

const CAPABILITY_LABELS = {
  send_chat: "Chat message",
  request_vote: "Party vote",
  request_player_input: "Private player prompt",
  request_player_roll: "Private player roll",
  proxy_character_roll: "Proxy character roll",
  proxy_character_power_action: "Proxy character power",
  proxy_combatant_action: "Proxy NPC action",
  add_library_npc: "Add library NPC",
  add_library_encounter: "Add prepared encounter",
  begin_story_encounter: "Begin story encounter",
  open_library_image: "Open or share map",
  set_spell_slot_usage: "Spell slot change",
  advance_turn: "Combat turn change",
  apply_effect: "Combat effect",
  remove_effect: "Effect removal",
  remove_combatant: "Combatant removal",
  resolve_manual_adjudication: "Adjudication resolution",
  set_combatant_threat: "Threat-state change",
  set_combatant_visibility: "Combatant visibility change",
  start_encounter: "Start encounter initiative"
};

export class LocalActionNotifier {
  constructor({
    enabled = true,
    platform = process.platform,
    spawnProcess = spawn
  } = {}) {
    this.enabled = enabled;
    this.platform = platform;
    this.spawnProcess = spawnProcess;
  }

  notifyActionWaiting({ capability, campaign }) {
    if (!this.enabled || this.platform !== "win32") return false;

    const action = CAPABILITY_LABELS[capability] ?? "Guarded action";
    const title = "Nerve action waiting";
    const body = `${action} for ${campaign}. Click the amber NERVE control in Fantasy Grounds.`;
    const script = windowsAlertScript(title, body);
    const encoded = Buffer.from(script, "utf16le").toString("base64");

    try {
      const child = this.spawnProcess("powershell.exe", [
        "-NoLogo",
        "-NoProfile",
        "-NonInteractive",
        "-Sta",
        "-EncodedCommand", encoded
      ], {
        detached: true,
        stdio: "ignore"
      });
      child.once?.("error", () => {});
      child.unref?.();
      return true;
    } catch {
      return false;
    }
  }
}

function windowsAlertScript(title, body) {
  return [
    "Add-Type -TypeDefinition 'using System; using System.Runtime.InteropServices; public static class NerveNativeWindow { [DllImport(\"kernel32.dll\")] public static extern IntPtr GetConsoleWindow(); [DllImport(\"user32.dll\")] public static extern bool ShowWindow(IntPtr hWnd, int nCmdShow); }'",
    "$nerveConsole = [NerveNativeWindow]::GetConsoleWindow()",
    "if ($nerveConsole -ne [IntPtr]::Zero) { [void][NerveNativeWindow]::ShowWindow($nerveConsole, 0) }",
    "Add-Type -AssemblyName System.Windows.Forms",
    "Add-Type -AssemblyName System.Drawing",
    "$nerveForm = New-Object System.Windows.Forms.Form",
    `$nerveForm.Text = '${escapePowerShellLiteral(title)}'`,
    "$nerveForm.Size = New-Object System.Drawing.Size(390,145)",
    "$nerveForm.StartPosition = 'Manual'",
    "$nerveTarget = Get-Process -Name 'FantasyGrounds' -ErrorAction SilentlyContinue | Where-Object { $_.MainWindowHandle -ne 0 } | Select-Object -First 1",
    "if ($nerveTarget) { $nerveArea = [System.Windows.Forms.Screen]::FromHandle($nerveTarget.MainWindowHandle).WorkingArea } else { $nerveArea = [System.Windows.Forms.Screen]::FromPoint([System.Windows.Forms.Cursor]::Position).WorkingArea }",
    "$nerveForm.Location = New-Object System.Drawing.Point(($nerveArea.Right - $nerveForm.Width - 20), ($nerveArea.Bottom - $nerveForm.Height - 20))",
    "$nerveForm.TopMost = $true",
    "$nerveForm.ShowInTaskbar = $false",
    "$nerveForm.FormBorderStyle = 'FixedToolWindow'",
    "$nerveLabel = New-Object System.Windows.Forms.Label",
    `$nerveLabel.Text = '${escapePowerShellLiteral(body)}'`,
    "$nerveLabel.AutoSize = $false",
    "$nerveLabel.Location = New-Object System.Drawing.Point(18,18)",
    "$nerveLabel.Size = New-Object System.Drawing.Size(345,55)",
    "$nerveForm.Controls.Add($nerveLabel)",
    "$nerveButton = New-Object System.Windows.Forms.Button",
    "$nerveButton.Text = 'Dismiss'",
    "$nerveButton.Location = New-Object System.Drawing.Point(278,76)",
    "$nerveButton.Add_Click({ $nerveForm.Close() })",
    "$nerveForm.Controls.Add($nerveButton)",
    "$nerveTimer = New-Object System.Windows.Forms.Timer",
    "$nerveTimer.Interval = 15000",
    "$nerveTimer.Add_Tick({ $nerveTimer.Stop(); $nerveForm.Close() })",
    "$nerveTimer.Start()",
    "[void]$nerveForm.ShowDialog()"
  ].join("\n");
}

function escapePowerShellLiteral(value) {
  return String(value).replaceAll("'", "''");
}
