import { readFile, readdir } from "node:fs/promises";
import { join, resolve } from "node:path";

const SUPPORTED_CAPABILITIES = new Set([
  "send_chat", "request_vote", "request_player_input", "request_player_roll", "proxy_character_roll", "proxy_character_power_action", "proxy_combatant_action", "add_library_npc", "add_library_encounter", "begin_story_encounter", "open_library_image", "set_spell_slot_usage", "start_encounter", "advance_turn", "apply_effect", "remove_effect", "remove_combatant", "resolve_manual_adjudication", "set_combatant_threat", "set_combatant_visibility"
]);

export class ActionInboxWatcher {
  constructor({ fguDataPath, notifier, intervalMs = 750, clock = () => new Date(), onError = () => {}, onNotification = () => {} }) {
    this.campaignsPath = join(resolve(fguDataPath), "campaigns");
    this.notifier = notifier;
    this.intervalMs = intervalMs;
    this.clock = clock;
    this.onError = onError;
    this.onNotification = onNotification;
    this.notifiedRequestIds = new Set();
  }

  async scanOnce() {
    let campaigns;
    try {
      campaigns = await readdir(this.campaignsPath, { withFileTypes: true });
    } catch (error) {
      this.onError(error);
      return 0;
    }

    let notified = 0;
    for (const entry of campaigns) {
      if (!entry.isDirectory()) continue;
      const command = await readCommand(join(this.campaignsPath, entry.name, "nerve-command.json"), this.onError);
      if (!isNotifiableCommand(command, this.clock()) || this.notifiedRequestIds.has(command.requestId)) continue;
      this.notifiedRequestIds.add(command.requestId);
      trimSet(this.notifiedRequestIds, 512);
      try {
        await this.notifier.notifyActionWaiting({ capability: command.capability, campaign: entry.name });
        this.onNotification({ requestId: command.requestId, capability: command.capability, campaign: entry.name });
      } catch (error) {
        this.onError(error);
      }
      notified += 1;
    }
    return notified;
  }

  async run({ signal } = {}) {
    while (!signal?.aborted) {
      await this.scanOnce();
      await delay(this.intervalMs, signal);
    }
  }
}

async function readCommand(path, onError) {
  try {
    const text = await readFile(path, "utf8");
    return JSON.parse(text.charCodeAt(0) === 0xfeff ? text.slice(1) : text);
  } catch (error) {
    if (error.code !== "ENOENT" && !(error instanceof SyntaxError)) onError(error);
    return null;
  }
}

function isNotifiableCommand(command, now) {
  return command?.schemaVersion === "0.1" &&
    typeof command.requestId === "string" && command.requestId.length > 0 &&
    SUPPORTED_CAPABILITIES.has(command.capability) &&
    Number(command.expiresAtEpoch) >= Math.floor(now.getTime() / 1000);
}

function trimSet(values, maximum) {
  while (values.size > maximum) values.delete(values.values().next().value);
}

function delay(milliseconds, signal) {
  if (signal?.aborted) return Promise.resolve();
  return new Promise((resolveDelay) => {
    const timer = setTimeout(resolveDelay, milliseconds);
    signal?.addEventListener("abort", () => {
      clearTimeout(timer);
      resolveDelay();
    }, { once: true });
  });
}
