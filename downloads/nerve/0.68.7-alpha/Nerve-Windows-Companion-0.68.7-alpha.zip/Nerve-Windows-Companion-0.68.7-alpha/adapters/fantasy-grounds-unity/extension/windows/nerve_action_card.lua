function onInit()
  refresh()
end

function refresh()
  local hasPending = NerveAdapter.hasPendingCommand()
  local pendingCapability = NerveAdapter.getPendingCommandCapability()
  local held = NerveAdapter.isNerveHeld()
  local chatGrantActive = NerveAdapter.isChatSessionGrantActive()
  local proxyGrantActive = NerveAdapter.isProxyActionSessionGrantActive()
  local combatGrantActive = NerveAdapter.isCombatPacingSessionGrantActive()
  title.setValue(hasPending and "Nerve Action — Approval Required" or "Nerve Action Inbox")
  pending_summary.setValue(NerveAdapter.getPendingCommandSummary())
  local heldMetadataApproval = held and pendingCapability == "record_session_continuity"
  approve.setVisible(hasPending and (not held or heldMetadataApproval))
  deny.setVisible(hasPending)
  local isNarrativeFlow = pendingCapability == "send_chat" or pendingCapability == "request_player_input" or
    pendingCapability == "request_player_roll"
  allow_chat.setVisible(hasPending and not held and isNarrativeFlow and not chatGrantActive)
  local isProxyAction = pendingCapability == "proxy_character_roll" or
    pendingCapability == "proxy_character_power_action" or pendingCapability == "proxy_combatant_action"
  local isCombatPacing = pendingCapability == "start_encounter" or pendingCapability == "advance_turn"
  allow_proxy.setVisible(hasPending and not held and isProxyAction and not proxyGrantActive)
  allow_combat.setVisible(hasPending and not held and isCombatPacing and not combatGrantActive)
end
