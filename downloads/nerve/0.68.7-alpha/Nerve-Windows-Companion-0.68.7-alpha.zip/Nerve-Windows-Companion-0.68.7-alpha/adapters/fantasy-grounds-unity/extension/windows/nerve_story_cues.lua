function onInit()
  title.setValue("Nerve Story Cue Tower")
  refresh()
end

function refresh()
  cue_list.setValue(NerveAdapter.getStoryCueText())
  lifetime.setText(NerveAdapter.getStoryCueLifetimeText())
end

function onDrop(x, y, draginfo)
  if not draginfo or draginfo.getType() ~= "shortcut" then return false end
  local recordType, recordId = draginfo.getShortcutData()
  local accepted = NerveAdapter.addStoryCue(recordType, recordId)
  refresh()
  return accepted
end
