local modeOrder = { "connector", "local", "api", "manual", "offline" }
local modeIndex = 1
local providerOrder = { "openai", "anthropic", "gemini", "xai" }
local providerIndex = 1
local appOrder = { "codex", "antigravity", "claude", "grok", "custom" }
local appIndex = 1
local appLabels = { codex = "Codex / ChatGPT", antigravity = "Gemini (Antigravity)", claude = "Claude", grok = "Grok", custom = "Custom AI App — Experimental" }
local allowWrites = true
local liveCheck = false
local statusPollOpen = true
local statusPollWaiting = false

function startStatusPoll()
  if not statusPollOpen or statusPollWaiting then return end
  if NerveAdapter.getControllerSupervisorState().status ~= "online" then return end
  statusPollWaiting = true
  Interface.openURL("http://127.0.0.1:47831/nerve-flow-wait?setup=1", function()
    statusPollWaiting = false
    if statusPollOpen then refresh() end
  end)
end

function onClose()
  statusPollOpen = false
end

local function defaults()
  return NerveAdapter.getAiProviderDefaults()
end

local function currentMode()
  return modeOrder[modeIndex]
end

local function currentProvider()
  return providerOrder[providerIndex]
end

local function currentApp()
  return appOrder[appIndex]
end

local function setProvider(provider, replaceModel)
  if provider == "ollama" then
    local info = defaults().ollama
    provider_button.setText(info.label)
    if replaceModel then model_value.setValue(info.model or "") end
    return
  end
  for index, value in ipairs(providerOrder) do
    if value == provider then providerIndex = index; break end
  end
  local info = defaults()[currentProvider()]
  provider_button.setText(info.label)
  if replaceModel then model_value.setValue(info.model or "") end
end

local function setMode(mode)
  for index, value in ipairs(modeOrder) do
    if value == mode then modeIndex = index; break end
  end
  local direct = currentMode() == "api"
  local connector = currentMode() == "connector"
  local manual = currentMode() == "manual"
  local localAi = currentMode() == "local"
  local offline = currentMode() == "offline"
  mode_button.setText(connector and "AI App Connector" or (manual and "Manual Handoff (Fallback)" or (direct and "Direct API (Advanced)" or (localAi and "Ollama Local AI" or "Offline Test"))))
  mode_note.setValue(connector and
    "Choose an AI app, install and sign in if needed, then follow the numbered button below. Test + Use makes a small provider request and saves your choice only after success. Start becomes available afterward." or
    (manual and "Compatibility fallback only. Opens a guided window and requires copying the AI response back to Nerve." or
    (direct and "Fully automatic background connection. Requires the provider's API key and may create separate usage charges. The key is never stored in the campaign or Fantasy Grounds chat." or
    (localAi and "Runs a model through Ollama on this computer. No API key, provider bill, or automatic paid fallback. Install Ollama and the named model first; local responses may be slower." or
    "No account, key, or network request. Useful for installation checks; responses are scripted and not a live AI."))))
  if localAi then setProvider("ollama", true) end
  provider_label.setVisible(direct or localAi)
  provider_label.setVisible(direct or localAi or connector)
  provider_label.setValue(connector and "AI App" or "AI Provider")
  provider_button.setVisible(direct or connector)
  if connector then provider_button.setText(appLabels[currentApp()]) end
  provider_next.setVisible(direct or connector)
  model_label.setVisible(direct or localAi)
  model_value.setVisible(direct or localAi)
  app_status.setVisible(connector)
  install_app.setVisible(connector)
  signin_app.setVisible(connector)
  test_app.setVisible(connector)
  permissions_label.setVisible(direct or localAi or connector)
  guarded_button.setVisible(direct or localAi or connector)
  live_button.setVisible(direct or localAi)
  save_setup.setText(connector and ("Use " .. appLabels[currentApp()]) or (manual and "Use Manual Fallback" or (direct and "Save + Enter API Key" or (localAi and "Use Ollama Local AI" or "Use Offline Test"))))
  setSize(560, 590)
end

function onInit()
  title.setValue("Nerve Settings")
  local state = NerveAdapter.getControllerSupervisorState()
  if type(state.allowWrites) == "boolean" then allowWrites = state.allowWrites end
  for index, value in ipairs(appOrder) do if value == (NerveAdapter.getSetupDraftApp() or state.appConnector) then appIndex = index; break end end
  local selectedProvider = type(state.provider) == "string" and defaults()[state.provider] and state.provider or "openai"
  if selectedProvider ~= "companion" and selectedProvider ~= "fake" then setProvider(selectedProvider, true) end
  if type(state.model) == "string" and state.model ~= "" then model_value.setValue(state.model) end
  local selectedMode = state.configured == false and "connector" or state.connectionMode
  if selectedMode == "companion" then selectedMode = "manual" end
  if selectedProvider == "ollama" then selectedMode = "local" elseif selectedProvider == "fake" then selectedMode = "offline" end
  if selectedMode ~= "connector" and selectedMode ~= "manual" and selectedMode ~= "api" and selectedMode ~= "local" and selectedMode ~= "offline" then
    selectedMode = selectedProvider == "connector" and "connector" or ((selectedProvider == "manual" or selectedProvider == "companion") and "manual" or (selectedProvider == "fake" and "offline" or (selectedProvider == "ollama" and "local" or "connector")))
  end
  setMode(selectedMode)
  refresh()
end

function refresh()
  setup_status.setValue(NerveAdapter.getAiSetupStatusText())
  app_status.setValue(currentMode() == "connector" and NerveAdapter.getAppConnectorStatusText(currentApp()) or "")
  guarded_button.setText(allowWrites and "Guarded Actions: ON" or "Guarded Actions: OFF")
  local localAi = currentMode() == "local"
  live_button.setText((localAi and "Local Connection Check: " or "Billed Connection Check: ") .. (liveCheck and "ON" or "OFF"))
  if currentMode() == "connector" then
    local state = NerveAdapter.getControllerSupervisorState()
    local app = (state.appConnectors or {})[currentApp()] or {}
    local running = state.controllerStatus == "running" or state.controllerStatus == "starting"
    local busy = state.setupBusy == true or state.controllerStatus == "stopping" or NerveAdapter.hasPendingNerveRequest("nerve-setup-control.json")
    local saved = state.appConnector == currentApp() and state.connectionVerified == true and state.allowWrites == allowWrites
    save_setup.setText(state.status ~= "online" and "1. Connect Nerve" or (busy and "Please wait..." or (running and "Stop Nerve to change AI" or (not app.installed and "2. Install AI App" or (not saved and "3. Test + Use AI" or "4. Begin Session + AI")))))
    install_app.setVisible(state.status == "online" and not running and not busy)
    signin_app.setVisible(state.status == "online" and not running and not busy)
    test_app.setVisible(false)
    local activeLabel = appLabels[state.appConnector] or "None"
    local nextText = state.status ~= "online" and "Connect Nerve first." or (busy and "Wait for the current step to finish." or (running and "Stop the running connection before changing setup." or (not saved and "Sign in if needed, then Test + Use AI. The saved app changes only after the test passes." or "Saved and verified. Begin Session + AI when ready; it starts the connection automatically.")))
    setup_status.setValue("Chosen: " .. appLabels[currentApp()] .. ". Saved: " .. activeLabel .. ". " .. nextText)
  end
  startStatusPoll()
end

function installSelectedApp()
  if NerveAdapter.requestAppConnectorOperation("install", currentApp()) then
    app_status.setValue("AI app install queued. Press Refresh to check progress. The installer asks before downloading provider software.")
  else refresh() end
end

function signInSelectedApp()
  if NerveAdapter.requestAppConnectorOperation("signin", currentApp()) then
    app_status.setValue("Sign-in queued. Press Refresh to check progress. The AI app opens first; a browser appears only if authorization is needed.")
  else refresh() end
end

function testSelectedApp()
  if NerveAdapter.requestAppConnectorOperation("test", currentApp()) then
    app_status.setValue("Connection test queued. Press Refresh for the result, then click Use " .. appLabels[currentApp()] .. " after a successful test.")
  else refresh() end
end

function reconnectBridge()
  NerveAdapter.reconnectNerveBridge()
  refresh()
end

function cycleMode()
  modeIndex = modeIndex % #modeOrder + 1
  setMode(currentMode())
  refresh()
end

function cycleProvider()
  if currentMode() == "connector" then
    appIndex = appIndex % #appOrder + 1
    NerveAdapter.setSetupDraftApp(currentApp())
    provider_button.setText(appLabels[currentApp()])
    save_setup.setText("Use " .. appLabels[currentApp()])
    refresh()
    return
  end
  providerIndex = providerIndex % #providerOrder + 1
  setProvider(currentProvider(), true)
  refresh()
end

function toggleGuardedActions()
  allowWrites = not allowWrites
  refresh()
end

function toggleLiveCheck()
  liveCheck = not liveCheck
  refresh()
end

function saveConfiguration()
  if currentMode() == "connector" then
    local state = NerveAdapter.getControllerSupervisorState()
    local app = (state.appConnectors or {})[currentApp()] or {}
    if state.status ~= "online" then reconnectBridge(); return end
    if state.setupBusy == true or state.controllerStatus == "stopping" or NerveAdapter.hasPendingNerveRequest("nerve-setup-control.json") then refresh(); return end
    if state.controllerStatus == "running" or state.controllerStatus == "starting" then
      NerveAdapter.requestControllerOperation("stop")
    elseif not app.installed then
      NerveAdapter.requestAppConnectorOperation("install", currentApp())
    elseif state.appConnector ~= currentApp() or state.connectionVerified ~= true or state.allowWrites ~= allowWrites then
      NerveAdapter.requestAppConnectorOperation("connect", currentApp(), allowWrites)
    elseif NerveAdapter.isNerveSessionActive() then
      NerveAdapter.requestControllerOperation("start")
    else
      NerveAdapter.beginNerveSession()
    end
    refresh()
    return
  end
  local provider = currentMode() == "connector" and "connector" or (currentMode() == "manual" and "manual" or (currentMode() == "offline" and "fake" or (currentMode() == "local" and "ollama" or currentProvider())))
  local model = (currentMode() == "api" or currentMode() == "local") and (model_value.getValue() or "") or ""
  local modelMode = currentMode() == "api" or currentMode() == "local"
  if NerveAdapter.requestAiConfiguration(provider, model, (modelMode or currentMode() == "connector") and allowWrites, modelMode and liveCheck, currentMode() == "connector" and currentApp() or nil) then
    setup_status.setValue(currentMode() == "connector" and "Saving AI App Connector..." or (currentMode() == "manual" and "Saving manual fallback..." or (currentMode() == "offline" and "Saving offline test mode..." or (currentMode() == "local" and "Saving Ollama local AI..." or "Waiting for the secure API-key window..."))))
  end
end
