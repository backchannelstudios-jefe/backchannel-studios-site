local options = {}
local selectedIndex = 0
local creativeAuthority = "bounded_improvisation"

function onInit()
  options = NerveAdapter.getAdventureSourceOptions() or {}
  local state = NerveAdapter.getAdventureSourceState() or {}
  creativeAuthority = state.creativeAuthority == "module_strict" and "module_strict" or "bounded_improvisation"
  for index, option in ipairs(options) do
    if option.moduleId == state.activeAdventureModule then selectedIndex = index break end
    if selectedIndex == 0 and option.moduleId == state.suggestedModule then selectedIndex = index end
  end
  if selectedIndex == 0 and #options > 0 then selectedIndex = 1 end
  refresh()
end

function refresh()
  local option = options[selectedIndex]
  if not option then
    source_button.setText("No adventure modules found")
    source_status.setValue("Load an adventure module in Fantasy Grounds, then reopen this window.")
    save_source.setVisible(false)
    return
  end
  source_button.setText(option.displayName)
  source_status.setValue(tostring(option.recordCount or 0) .. " story, encounter, and map records available\nFantasy Grounds module: " .. option.moduleId)
  authority_button.setText(creativeAuthority == "bounded_improvisation" and "Bounded Improv" or "Module Strict")
  authority_status.setValue(creativeAuthority == "bounded_improvisation"
    and "Fills source gaps with minor, consistent details; never major treasure, rules, or quest-critical facts."
    or "Asks the GM whenever the selected adventure does not supply a story fact.")
  save_source.setVisible(true)
end

function cycleAuthority()
  creativeAuthority = creativeAuthority == "bounded_improvisation" and "module_strict" or "bounded_improvisation"
  refresh()
end

function cycleSource()
  if #options == 0 then return end
  selectedIndex = (selectedIndex % #options) + 1
  refresh()
end

function saveSource()
  local option = options[selectedIndex]
  if option and NerveAdapter.setAdventureSource(option.moduleId, option.displayName, creativeAuthority) then window.close() end
end

function clearSource()
  if NerveAdapter.setAdventureSource("", "", creativeAuthority) then window.close() end
end
