local checkpointIndex = 1
local journeyView = false

function onInit()
  refresh()
end

function refresh()
  if title and title.setValue then title.setValue("Nerve Campaign Memory") end
  local count = NerveAdapter.getCampaignMemoryCheckpointCount()
  if count < 1 then checkpointIndex = 1
  elseif checkpointIndex > count then checkpointIndex = count end

  current_state.setValue(NerveAdapter.getCampaignMemoryCurrentStateText())
  checkpoint_position.setValue(count > 0 and ("Checkpoint " .. tostring(checkpointIndex) .. " of " .. tostring(count)) or "No checkpoints yet")
  checkpoint_meta.setValue(NerveAdapter.getCampaignMemoryCheckpointMetaText(checkpointIndex))
  briefing.setValue(journeyView and NerveAdapter.getCampaignMemoryJourneyText(checkpointIndex) or NerveAdapter.getCampaignMemoryBriefingText(checkpointIndex))
  view_mode.setText(journeyView and "Show Overview" or "Show Journey")
  interactions.setValue(NerveAdapter.getCampaignMemoryInteractionText())
  older.setVisible(count > 0 and checkpointIndex < count)
  newer.setVisible(count > 0 and checkpointIndex > 1)
end

function toggleView()
  journeyView = not journeyView
  refresh()
end

function showOlder()
  local count = NerveAdapter.getCampaignMemoryCheckpointCount()
  if checkpointIndex < count then checkpointIndex = checkpointIndex + 1 end
  refresh()
end

function showNewer()
  if checkpointIndex > 1 then checkpointIndex = checkpointIndex - 1 end
  refresh()
end
