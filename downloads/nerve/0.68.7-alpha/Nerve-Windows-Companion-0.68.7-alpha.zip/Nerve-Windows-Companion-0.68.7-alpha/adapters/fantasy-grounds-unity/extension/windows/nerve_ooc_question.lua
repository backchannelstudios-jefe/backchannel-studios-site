function onInit()
  if title and title.setValue then title.setValue("Ask Nerve — Out of Character") end
end

function submit()
  local question = question_text.getValue() or ""
  if NerveAdapter.submitOocQuestion(question) then close() end
end
