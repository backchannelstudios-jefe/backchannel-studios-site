function onInit()
  title.setValue("Nerve Manual Adjudication")
  details.setValue(NerveAdapter.getActiveManualAdjudicationText())
end
