local choices = {}

local function getChoiceLabel(choice)
  if type(choice) == "table" then return choice.label or "" end
  return type(choice) == "string" and choice or ""
end

local function getChoiceDescription(choice)
  if type(choice) == "table" then return choice.description or "" end
  return ""
end

function onInit()
  refresh()
end

function refresh()
  local prompt = NerveAdapter.getActivePlayerPrompt()
  if not prompt then return end
  choices = prompt.choices or {}
  title.setValue("Nerve Private Prompt")
  prompt_text.setValue(prompt.prompt or "")
  deadline_text.setValue("Respond by " .. os.date("%H:%M:%S", prompt.deadlineEpoch))

  local isAck = prompt.responseType == "acknowledge"
  local isYesNo = prompt.responseType == "yes_no"
  local isText = prompt.responseType == "short_text"
  local isChoice = prompt.responseType == "multiple_choice"
  local isRoll = prompt.responseType == "roll"
  acknowledge.setVisible(isAck)
  yes.setVisible(isYesNo)
  no.setVisible(isYesNo)
  answer.setVisible(isText)
  submit_text.setVisible(isText)
  roll_details.setVisible(isRoll)
  roll_action.setVisible(isRoll)
  if isRoll then
    local roll = prompt.roll or {}
    local label = roll.rollType or "roll"
    if prompt.characterName and prompt.characterName ~= "" then label = "Assigned to " .. prompt.characterName .. " | " .. label end
    if roll.ability and roll.ability ~= "" then label = label .. ": " .. roll.ability end
    if roll.skill and roll.skill ~= "" then label = label .. ": " .. roll.skill end
    if roll.dc then label = label .. " vs. DC " .. tostring(roll.dc) end
    label = label .. " | " .. (roll.rollMode or "normal")
    label = label .. " | " .. (roll.visibility == "gm" and "dice tower / GM" or "public")
    roll_details.setValue(label)
  end
  local choiceControls = { choice1, choice2, choice3, choice4, choice5, choice6 }
  local descriptionControls = {
    choice_description1, choice_description2, choice_description3,
    choice_description4, choice_description5, choice_description6
  }
  for index, control in ipairs(choiceControls) do
    local choice = choices[index]
    local visible = isChoice and choice ~= nil
    control.setVisible(visible)
    descriptionControls[index].setVisible(visible)
    if choice then
      control.setText(getChoiceLabel(choice))
      descriptionControls[index].setValue(getChoiceDescription(choice))
    end
  end
end

function submitChoice(index)
  local label = getChoiceLabel(choices[index])
  if label ~= "" then NerveAdapter.submitPlayerPromptResponse("choice", label) end
end

function submitRoll()
  NerveAdapter.performRequestedPlayerRoll()
end
