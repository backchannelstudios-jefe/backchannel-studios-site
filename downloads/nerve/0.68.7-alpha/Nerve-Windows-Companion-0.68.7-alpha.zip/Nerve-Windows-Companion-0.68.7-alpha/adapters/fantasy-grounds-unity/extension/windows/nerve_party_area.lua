function onInit()
  area_value.setValue(NerveAdapter.getPartyAreaKey())
end

function saveArea()
  if NerveAdapter.setPartyAreaKey(area_value.getValue() or "") then close() end
end

function clearArea()
  if NerveAdapter.setPartyAreaKey("") then close() end
end
