function onInit()
  refresh()
end

function refresh()
  if call_nerve and call_nerve.setStateText then
    call_nerve.setStateText(0, NerveAdapter.getAiCueButtonText())
  end
end
