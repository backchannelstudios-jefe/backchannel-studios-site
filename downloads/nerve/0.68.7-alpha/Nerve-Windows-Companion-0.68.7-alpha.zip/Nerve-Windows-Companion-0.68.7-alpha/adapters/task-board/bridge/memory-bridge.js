import { NerveError } from "../../../core/errors.js";

export class MemoryTaskBoardBridge {
  constructor({ clock = () => new Date(), boardId = "demo-board", name = "Nerve Portability Board", tasks = [] } = {}) {
    this.clock = clock;
    this.boardId = boardId;
    this.name = name;
    this.tasks = tasks.map((task) => ({ ...task }));
    this.sequence = this.tasks.length;
  }

  async getTaskBoard() {
    return {
      boardId: this.boardId,
      name: this.name,
      tasks: this.tasks.map((task) => ({ ...task })),
      observedAt: this.clock().toISOString()
    };
  }

  async addTask({ title }) {
    const task = { id: `task-${++this.sequence}`, title, status: "todo" };
    this.tasks.push(task);
    return { ...task, changedAt: this.clock().toISOString() };
  }

  async setTaskStatus({ id, status }) {
    const task = this.tasks.find((item) => item.id === id);
    if (!task) throw new NerveError("TASK_NOT_FOUND", `Task not found: ${id}`, { id });
    task.status = status;
    return { ...task, changedAt: this.clock().toISOString() };
  }
}
