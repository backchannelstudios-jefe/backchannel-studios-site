import { defineAdapter } from "../../core/adapter-contract.js";
import { createResultSchema } from "../../core/result-schema.js";

const emptyInput = { type: "object", additionalProperties: false, properties: {} };
const taskSchema = {
  type: "object",
  additionalProperties: false,
  required: ["id", "title", "status"],
  properties: {
    id: { type: "string", minLength: 1 },
    title: { type: "string", minLength: 1, maxLength: 200 },
    status: { type: "string", enum: ["todo", "doing", "done"] }
  }
};
const boardSchema = {
  type: "object",
  additionalProperties: false,
  required: ["boardId", "name", "tasks", "observedAt"],
  properties: {
    boardId: { type: "string", minLength: 1 },
    name: { type: "string", minLength: 1 },
    tasks: { type: "array", items: taskSchema },
    observedAt: { type: "string", minLength: 1 }
  }
};
const changedTaskSchema = {
  ...taskSchema,
  required: [...taskSchema.required, "changedAt"],
  properties: { ...taskSchema.properties, changedAt: { type: "string", minLength: 1 } }
};
const addTaskInput = {
  type: "object",
  additionalProperties: false,
  required: ["title", "confirmed"],
  properties: {
    title: { type: "string", minLength: 1, maxLength: 200 },
    confirmed: { const: true }
  }
};
const setStatusInput = {
  type: "object",
  additionalProperties: false,
  required: ["id", "status", "confirmed"],
  properties: {
    id: { type: "string", minLength: 1 },
    status: { type: "string", enum: ["todo", "doing", "done"] },
    confirmed: { const: true }
  }
};

export function createTaskBoardAdapter(bridge) {
  return defineAdapter({
    id: "task-board",
    title: "Task Board",
    version: "0.1.0",
    bridge,
    instructions: "Read the current board before changing tasks. Use stable task IDs from get_task_board and do not claim a mutation succeeded unless the tool returns success.",
    capabilities: [
      capability({
        name: "get_task_board",
        title: "Get Task Board",
        description: "Read the authoritative task-board state.",
        access: "read",
        idempotent: true,
        inputSchema: emptyInput,
        dataSchema: boardSchema,
        execute: (_args, context) => bridge.getTaskBoard(context)
      }),
      capability({
        name: "add_task",
        title: "Add Task",
        description: "Add a task to the board after explicit confirmation.",
        access: "write",
        idempotent: false,
        requiresConfirmation: true,
        inputSchema: addTaskInput,
        dataSchema: changedTaskSchema,
        execute: (args, context) => bridge.addTask(args, context)
      }),
      capability({
        name: "set_task_status",
        title: "Set Task Status",
        description: "Change a task's workflow status after explicit confirmation.",
        access: "write",
        idempotent: true,
        requiresConfirmation: true,
        inputSchema: setStatusInput,
        dataSchema: changedTaskSchema,
        execute: (args, context) => bridge.setTaskStatus(args, context)
      })
    ]
  });
}

function capability(definition) {
  return {
    destructive: false,
    ...definition,
    outputSchema: createResultSchema(definition.dataSchema)
  };
}
