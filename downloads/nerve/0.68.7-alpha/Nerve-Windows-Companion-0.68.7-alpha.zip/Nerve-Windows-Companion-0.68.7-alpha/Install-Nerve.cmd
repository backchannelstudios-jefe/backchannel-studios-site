@echo off
setlocal
call "%~dp0scripts\Install-Nerve.cmd" %*
exit /b %ERRORLEVEL%

