import { inspectNerveExtensions } from "./extension-installation.js";
import { access, readFile, readdir, stat } from "node:fs/promises";
import { constants } from "node:fs";
import { join, resolve } from "node:path";

export function defaultFguDataPath(environment = process.env) {
  if (environment.NERVE_FGU_DATA_PATH) return resolve(environment.NERVE_FGU_DATA_PATH);
  if (environment.APPDATA) return join(environment.APPDATA, "SmiteWorks", "Fantasy Grounds");
  return null;
}

export function campaignPaths({ fguDataPath, campaign }) {
  if (!fguDataPath) throw new Error("Fantasy Grounds data path is required.");
  if (!isSafeCampaignName(campaign)) throw new Error("Campaign name is invalid.");
  const campaignDirectory = join(resolve(fguDataPath), "campaigns", campaign);
  return {
    campaignDirectory,
    snapshotPath: join(campaignDirectory, "nerve-state.json"),
    libraryPath: join(campaignDirectory, "nerve-library.json"),
    controllerStatusPath: join(campaignDirectory, "nerve-controller-status.json"),
    controllerStopPath: join(campaignDirectory, "nerve-controller-stop.json"),
    controllerTelemetryPath: join(campaignDirectory, "nerve-controller-telemetry.ndjson"),
    connectorStatusPath: join(campaignDirectory, "nerve-connector-status.json"),
    supervisorControlPath: join(campaignDirectory, "nerve-supervisor-control.json"),
    supervisorStatusPath: join(campaignDirectory, "nerve-supervisor-status.json"),
    hostStatusPath: join(campaignDirectory, "nerve-host-status.json")
  };
}

export async function discoverCampaigns(fguDataPath) {
  const campaignsDirectory = join(resolveRequiredPath(fguDataPath), "campaigns");
  let entries;
  try {
    entries = await readdir(campaignsDirectory, { withFileTypes: true });
  } catch (error) {
    throw new Error(`Unable to read Fantasy Grounds campaigns: ${error.message}`);
  }

  const campaigns = [];
  for (const entry of entries.filter((item) => item.isDirectory())) {
    const paths = campaignPaths({ fguDataPath, campaign: entry.name });
    const campaignXmlPath = join(paths.campaignDirectory, "campaign.xml");
    if (!(await exists(campaignXmlPath))) continue;
    const snapshot = await readSnapshotMetadata(paths.snapshotPath);
    campaigns.push({
      name: entry.name,
      path: paths.campaignDirectory,
      snapshotAvailable: snapshot !== null,
      adapterVersion: snapshot?.adapterVersion ?? null,
      generatedAt: snapshot?.generatedAt ?? null
    });
  }
  return campaigns.sort((left, right) => left.name.localeCompare(right.name));
}

export async function diagnoseCampaign({ fguDataPath, campaign, now = Date.now() }) {
  const paths = campaignPaths({ fguDataPath, campaign });
  const snapshot = await readSnapshotMetadata(paths.snapshotPath);
  const extensionManifest = join(resolve(fguDataPath), "extensions", "Nerve", "extension.xml");
  const campaignExists = await exists(join(paths.campaignDirectory, "campaign.xml"));
  const extensionState = await inspectNerveExtensions(fguDataPath);
  const extensionInstalled = extensionState.archives.length === 1 && !extensionState.localPresent
    || extensionState.archives.length === 0 && await exists(extensionManifest);
  const ageSeconds = snapshot?.generatedAt
    ? Math.max(0, Math.floor((now - Date.parse(snapshot.generatedAt)) / 1000))
    : null;
  return {
    ok: campaignExists && extensionInstalled && snapshot !== null,
    campaign,
    campaignDirectory: paths.campaignDirectory,
    snapshotPath: paths.snapshotPath,
    campaignExists,
    extensionInstalled,
    snapshotAvailable: snapshot !== null,
    adapterVersion: snapshot?.adapterVersion ?? null,
    snapshotSchemaVersion: snapshot?.schemaVersion ?? null,
    generatedAt: snapshot?.generatedAt ?? null,
    snapshotAgeSeconds: Number.isFinite(ageSeconds) ? ageSeconds : null,
    ruleset: snapshot?.campaignSummary?.ruleset ?? null,
    pulseStreamId: snapshot?.recentEvents?.streamId ?? null,
    pulseLatestSequence: snapshot?.recentEvents?.latestSequence ?? null
  };
}

export async function assertReadableSnapshot(snapshotPath) {
  await access(snapshotPath, constants.R_OK);
  for (let attempt = 0; attempt < 10; attempt += 1) {
    const snapshot = await readSnapshotMetadata(snapshotPath);
    if (snapshot) return snapshot;
    if (attempt < 9) await new Promise((resolveDelay) => setTimeout(resolveDelay, 25));
  }
  throw new Error(`Snapshot is not valid JSON: ${snapshotPath}`);
}

async function readSnapshotMetadata(snapshotPath) {
  try {
    const text = await readFile(snapshotPath, "utf8");
    return JSON.parse(text.charCodeAt(0) === 0xfeff ? text.slice(1) : text);
  } catch (error) {
    if (error.code === "ENOENT" || error instanceof SyntaxError) return null;
    throw error;
  }
}

async function exists(path) {
  try {
    await stat(path);
    return true;
  } catch (error) {
    if (error.code === "ENOENT") return false;
    throw error;
  }
}

function isSafeCampaignName(value) {
  return typeof value === "string" && value.length > 0 && value !== "." && value !== ".." && !/[\\/]/.test(value);
}

function resolveRequiredPath(value) {
  if (!value) throw new Error("Fantasy Grounds data path was not found. Use --fgu-data <path>.");
  return resolve(value);
}
