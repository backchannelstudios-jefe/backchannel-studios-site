import {readFile, readdir, access} from 'node:fs/promises';
import {join} from 'node:path';
import {inflateRawSync} from 'node:zlib';

// Read only the root manifest; never extract an extension onto disk.
export function readExtensionManifest(zip) {
  if (zip.length > 64 * 1024 * 1024) throw new Error('Extension archive exceeds inspection limit');
  let end = zip.length - 22;
  while (end >= Math.max(0, zip.length - 65557) && zip.readUInt32LE(end) !== 0x06054b50) end--;
  if (end < Math.max(0, zip.length - 65557)) throw new Error('Invalid ZIP directory');
  const count = zip.readUInt16LE(end + 10);
  let cursor = zip.readUInt32LE(end + 16);
  for (let i=0;i<count;i++) {
    if (zip.readUInt32LE(cursor)!==0x02014b50) throw new Error('Invalid ZIP entry');
    const method=zip.readUInt16LE(cursor+10), packed=zip.readUInt32LE(cursor+20), size=zip.readUInt32LE(cursor+24);
    const nameLength=zip.readUInt16LE(cursor+28), extra=zip.readUInt16LE(cursor+30), comment=zip.readUInt16LE(cursor+32);
    const name=zip.subarray(cursor+46,cursor+46+nameLength).toString('utf8');
    const local=zip.readUInt32LE(cursor+42);
    cursor+=46+nameLength+extra+comment;
    if(name!=='extension.xml') continue;
    if(size>65536 || zip.readUInt32LE(local)!==0x04034b50) throw new Error('Invalid extension manifest');
    const start=local+30+zip.readUInt16LE(local+26)+zip.readUInt16LE(local+28);
    if(start+packed>zip.length) throw new Error('Truncated manifest');
    const payload=zip.subarray(start,start+packed);
    const text=(method===0 ? payload : method===8 ? inflateRawSync(payload,{maxOutputLength:65536}) : Buffer.alloc(0)).toString('utf8');
    if(text.includes('<!DOCTYPE')) throw new Error('DTD not permitted');
    return text;
  }
  return null;
}
export async function inspectNerveExtensions(dataRoot) {
  const root=join(dataRoot,'extensions');
  let localPresent=false;
  try {await access(join(root,'Nerve'));localPresent=true;} catch(error){if(error.code!=='ENOENT')throw error;}
  let entries=[];
  try {entries=await readdir(root,{withFileTypes:true});} catch(error){if(error.code!=='ENOENT')throw error;}
  const archives=[];
  for(const entry of entries.filter(e=>e.isFile() && e.name.toLowerCase().endsWith('.ext'))) {
    try {
      const text=readExtensionManifest(await readFile(join(root,entry.name)));
      if(!/<name>\s*Nerve Adapter for Fantasy Grounds Unity\s*<\/name>/.test(text||''))continue;
      archives.push({path:join(root,entry.name),version:text.match(/<version>([^<]+)<\/version>/)?.[1]??null});
    } catch { /* Other extensions and unreadable archives are not a verified Nerve install. */ }
  }
  return {localPresent,archives};
}
