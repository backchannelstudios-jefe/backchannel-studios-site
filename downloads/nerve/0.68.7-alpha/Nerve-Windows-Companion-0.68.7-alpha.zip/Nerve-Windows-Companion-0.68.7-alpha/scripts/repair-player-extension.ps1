[CmdletBinding()]
param(
  [string]$FantasyGroundsData,
  [string]$BackupRoot,
  [switch]$ConfirmRepair,
  [switch]$NoPause
)

$ErrorActionPreference = "Stop"
function Wait-ForEnter([string]$Text) { if (-not $NoPause) { Read-Host $Text | Out-Null } }

try {
  Write-Host "NERVE PLAYER EXTENSION REPAIR" -ForegroundColor Cyan
  if (Get-Process -Name "FantasyGrounds" -ErrorAction SilentlyContinue) {
    throw "Fantasy Grounds is running. Close it completely, then run this repair again."
  }
  if (-not $FantasyGroundsData) {
    if (-not $env:APPDATA) { throw "Fantasy Grounds data could not be located." }
    $FantasyGroundsData = Join-Path $env:APPDATA "SmiteWorks\Fantasy Grounds"
  }
  $FantasyGroundsData = [IO.Path]::GetFullPath($FantasyGroundsData)
  $campaignRoot = Join-Path $FantasyGroundsData "campaigns"
  $hosted = @()
  if (Test-Path -LiteralPath $campaignRoot -PathType Container) {
    $hosted = @(Get-ChildItem -LiteralPath $campaignRoot -Directory -ErrorAction SilentlyContinue | Where-Object {
      Test-Path -LiteralPath (Join-Path $_.FullName "campaign.xml") -PathType Leaf
    })
  }
  if ($hosted.Count -gt 0) {
    throw "This computer has locally hosted campaigns and appears to be a GM workstation. The player-only repair made no changes."
  }
  $extensionPath = Join-Path $FantasyGroundsData "extensions\Nerve"
  if (-not (Test-Path -LiteralPath $extensionPath -PathType Container)) {
    Write-Host "No locally installed Nerve extension folder was found. Clear the campaign cache and reconnect to the GM." -ForegroundColor Green
    Wait-ForEnter "Press Enter to close"
    exit 0
  }
  if (-not $ConfirmRepair -and -not $NoPause) {
    $answer = (Read-Host "Move the player computer's local Nerve extension to a recoverable backup? [Y/n]").Trim().ToLowerInvariant()
    if ($answer -and $answer -notin @("y", "yes")) { throw "Repair cancelled; no files were changed." }
  } elseif (-not $ConfirmRepair) {
    throw "Non-interactive repair requires -ConfirmRepair."
  }
  $backupRoot = if ($BackupRoot) { [IO.Path]::GetFullPath($BackupRoot) } elseif ($env:LOCALAPPDATA) { Join-Path $env:LOCALAPPDATA "Nerve\Backups" } else { Join-Path $env:USERPROFILE "Documents\Nerve\Backups" }
  $backupPath = Join-Path $backupRoot ("player-extension-{0}" -f (Get-Date -Format "yyyyMMdd-HHmmss"))
  $resolvedBackupRoot = [IO.Path]::GetFullPath($backupRoot).TrimEnd('\')
  $resolvedBackupPath = [IO.Path]::GetFullPath($backupPath)
  if (-not $resolvedBackupPath.StartsWith($resolvedBackupRoot + '\', [StringComparison]::OrdinalIgnoreCase)) {
    throw "The player extension backup path was not safely contained under the backup directory."
  }
  New-Item -ItemType Directory -Path $backupPath -Force | Out-Null
  Move-Item -LiteralPath $extensionPath -Destination (Join-Path $backupPath "Nerve")
  Write-Host "PASS  Local player extension moved to: $backupPath" -ForegroundColor Green
  Write-Host "Next: clear this campaign's cache on Join Campaign, then reconnect. The GM will supply the current Nerve extension."
} catch {
  Write-Host "Nerve player repair did not run." -ForegroundColor Red
  Write-Host $_.Exception.Message -ForegroundColor Red
  Wait-ForEnter "Press Enter to close"
  exit 1
}

Wait-ForEnter "Press Enter to close"
exit 0
