[CmdletBinding()]
param([string]$ConfigRoot, [string]$Campaign, [string]$FantasyGroundsData, [switch]$NoPause)
$ErrorActionPreference = "Stop"
$runtimeRoot = Split-Path -Parent $PSScriptRoot
$entryPoint = Join-Path $runtimeRoot "bin\nerve.js"
$configRoot = if ($ConfigRoot) { [IO.Path]::GetFullPath($ConfigRoot) } elseif ($env:LOCALAPPDATA) { Join-Path $env:LOCALAPPDATA "Nerve\Config" } else { Join-Path $env:USERPROFILE "Documents\Nerve\Config" }
$profilePath = Join-Path $configRoot "provider.json"
function Wait-ForEnter([string]$Text) { if (-not $NoPause) { Read-Host $Text | Out-Null } }
function Resolve-ActiveCampaign([string]$FguData, [string]$CampaignHint) {
  $campaignsRoot = Join-Path $FguData "campaigns"
  if (-not (Test-Path -LiteralPath $campaignsRoot -PathType Container)) { return $CampaignHint }
  $running = foreach ($directory in Get-ChildItem -LiteralPath $campaignsRoot -Directory -ErrorAction SilentlyContinue) {
    $statusPath = Join-Path $directory.FullName "nerve-host-status.json"
    if (-not (Test-Path -LiteralPath $statusPath -PathType Leaf)) { continue }
    try { $status = Get-Content -Raw -LiteralPath $statusPath | ConvertFrom-Json } catch { continue }
    if ($status.status -eq "running") {
      [pscustomobject]@{ name = $directory.Name; updated = (Get-Item -LiteralPath $statusPath).LastWriteTimeUtc }
    }
  }
  $selected = $running | Sort-Object updated -Descending | Select-Object -First 1
  if ($selected) { return [string]$selected.name }
  return $CampaignHint
}
try {
  if (-not (Test-Path -LiteralPath $profilePath)) { throw "No Nerve provider profile was found." }
  $profile = Get-Content -Raw -LiteralPath $profilePath | ConvertFrom-Json
  if ($Campaign) { $profile | Add-Member -NotePropertyName campaign -NotePropertyValue $Campaign -Force }
  if ($FantasyGroundsData) { $profile | Add-Member -NotePropertyName fantasyGroundsData -NotePropertyValue ([IO.Path]::GetFullPath($FantasyGroundsData)) -Force }
  if (-not $Campaign) {
    $activeCampaign = Resolve-ActiveCampaign ([string]$profile.fantasyGroundsData) ([string]$profile.campaign)
    $profile | Add-Member -NotePropertyName campaign -NotePropertyValue $activeCampaign -Force
  }
  $node = Get-Command node -ErrorAction SilentlyContinue
  if (-not $node) { throw "Node.js was not found." }
  & $node.Source $entryPoint controller-stop --campaign $profile.campaign --fgu-data $profile.fantasyGroundsData
  if ($LASTEXITCODE -ne 0) { throw "Nerve could not request a clean controller stop." }
} catch {
  Write-Host "Nerve could not stop cleanly." -ForegroundColor Red
  Write-Host $_.Exception.Message -ForegroundColor Red
  Wait-ForEnter "Press Enter to close"
  exit 1
}
Wait-ForEnter "Press Enter to close"
exit 0
