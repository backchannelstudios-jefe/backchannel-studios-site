[CmdletBinding()]
param(
  [string]$Campaign,
  [string]$FantasyGroundsData,
  [string]$OutputFolder,
  [string]$ConfigRoot,
  [switch]$NoPause
)

$ErrorActionPreference = "Stop"
$repositoryRoot = Split-Path -Parent $PSScriptRoot
$entryPoint = Join-Path $repositoryRoot "bin\nerve.js"
$node = Get-Command node -ErrorAction Stop
$configRoot = if ($ConfigRoot) { [IO.Path]::GetFullPath($ConfigRoot) } elseif ($env:LOCALAPPDATA) { Join-Path $env:LOCALAPPDATA "Nerve\Config" } else { Join-Path $env:USERPROFILE "Documents\Nerve\Config" }
$installationPath = Join-Path $configRoot "installation.json"
if (Test-Path -LiteralPath $installationPath) {
  $installation = Get-Content -Raw -LiteralPath $installationPath | ConvertFrom-Json
  if (-not $Campaign) { $Campaign = $installation.campaign }
  if (-not $FantasyGroundsData) { $FantasyGroundsData = $installation.fantasyGroundsData }
}
if (-not $FantasyGroundsData) { $FantasyGroundsData = Join-Path $env:APPDATA "SmiteWorks\Fantasy Grounds" }
$FantasyGroundsData = [IO.Path]::GetFullPath($FantasyGroundsData)
$stamp = Get-Date -Format "yyyyMMdd-HHmmss"
if (-not $OutputFolder) {
  $supportRoot = Join-Path $env:USERPROFILE "Documents\Nerve Support"
  $OutputFolder = Join-Path $supportRoot ("Nerve-Support-{0}" -f $stamp)
}
$OutputFolder = [IO.Path]::GetFullPath($OutputFolder)
$zipPath = "$OutputFolder.zip"

function Wait-ForEnter([string]$Text) { if (-not $NoPause) { Read-Host $Text | Out-Null } }
function Redact-Line([string]$Line) {
  $value = $Line -replace '(?i)[A-Z]:\\Users\\[^\\\s]+', '<USER>'
  $value = $value -replace '(?i)[A-Z]:\\[^\r\n]*', '<LOCAL_PATH>'
  $value = $value -replace '\b(?:\d{1,3}\.){3}\d{1,3}\b', '<IP_ADDRESS>'
  $value = $value -replace '[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}', '<EMAIL>'
  return $value
}

try {
  Write-Host "NERVE ONE-CLICK SUPPORT BUNDLE" -ForegroundColor Cyan
  New-Item -ItemType Directory -Path $OutputFolder -Force | Out-Null
  if (-not $Campaign) {
    $campaignJson = & $node.Source $entryPoint campaigns --fgu-data $FantasyGroundsData --json
    if ($LASTEXITCODE -ne 0) { throw "Nerve could not list campaigns." }
    $parsedCampaigns = ($campaignJson -join [Environment]::NewLine) | ConvertFrom-Json
    $campaigns = @()
    foreach ($candidate in $parsedCampaigns) { if ($candidate.snapshotAvailable -eq $true) { $campaigns += $candidate } }
    if ($campaigns.Count -eq 0) { throw "No Nerve-enabled campaign was found. Load the campaign in Fantasy Grounds and try again." }
    if ($campaigns.Count -eq 1) { $Campaign = $campaigns[0].name }
    else {
      for ($index = 0; $index -lt $campaigns.Count; $index += 1) { Write-Host ("{0}. {1}" -f ($index + 1), $campaigns[$index].name) }
      $selection = [int](Read-Host "Enter the campaign number")
      if ($selection -lt 1 -or $selection -gt $campaigns.Count) { throw "That campaign selection is not valid." }
      $Campaign = $campaigns[$selection - 1].name
    }
  }

  & $node.Source $entryPoint diagnostics --campaign $Campaign --fgu-data $FantasyGroundsData --output (Join-Path $OutputFolder "nerve-diagnostics.json")
  if ($LASTEXITCODE -ne 0) { throw "Redacted diagnostics could not be created." }
  & $node.Source $entryPoint doctor --campaign $Campaign --fgu-data $FantasyGroundsData --json | Set-Content -LiteralPath (Join-Path $OutputFolder "campaign-doctor.json") -Encoding UTF8
  & $node.Source $entryPoint provider-acceptance --json | Set-Content -LiteralPath (Join-Path $OutputFolder "provider-acceptance.json") -Encoding UTF8

  $consolePath = Join-Path $FantasyGroundsData "console.log"
  $filteredPath = Join-Path $OutputFolder "fantasy-grounds-errors-redacted.txt"
  if (Test-Path -LiteralPath $consolePath -PathType Leaf) {
    $patterns = 'Script Error|failed to load script buffer|Nerve Adapter v|Nerve.*loaded|error|exception'
    $filtered = Get-Content -LiteralPath $consolePath -Tail 4000 | Where-Object { $_ -match $patterns } | Select-Object -Last 300
    @($filtered | ForEach-Object { Redact-Line $_ }) | Set-Content -LiteralPath $filteredPath -Encoding UTF8
  } else {
    "Fantasy Grounds console.log was not found." | Set-Content -LiteralPath $filteredPath -Encoding UTF8
  }

  $providerSetupLog = Join-Path $configRoot "provider-setup-last.log"
  if (Test-Path -LiteralPath $providerSetupLog -PathType Leaf) {
    $setupLines = Get-Content -LiteralPath $providerSetupLog -Tail 300
    @($setupLines | ForEach-Object { Redact-Line $_ }) | Set-Content -LiteralPath (Join-Path $OutputFolder "provider-setup-redacted.txt") -Encoding UTF8
  }

  @(
    "Nerve support bundle"
    ("Generated: {0}" -f (Get-Date).ToString("F"))
    "Contents are limited to redacted operational diagnostics, campaign doctor metadata, offline provider acceptance, provider setup results when available, and filtered Fantasy Grounds error lines."
    "Review the files before sharing. The bundle intentionally excludes campaign databases, narrative text, journals, action arguments, API keys, and passwords."
  ) | Set-Content -LiteralPath (Join-Path $OutputFolder "READ-ME-FIRST.txt") -Encoding UTF8

  Compress-Archive -Path (Join-Path $OutputFolder "*") -DestinationPath $zipPath -CompressionLevel Optimal -Force
  Write-Host ""
  Write-Host "Support bundle created. Send this one file:" -ForegroundColor Green
  Write-Host $zipPath -ForegroundColor Green
} catch {
  Write-Host "Support collection stopped: $($_.Exception.Message)" -ForegroundColor Red
  Wait-ForEnter "Press Enter to close"
  exit 1
}

Wait-ForEnter "Press Enter to close"
exit 0
