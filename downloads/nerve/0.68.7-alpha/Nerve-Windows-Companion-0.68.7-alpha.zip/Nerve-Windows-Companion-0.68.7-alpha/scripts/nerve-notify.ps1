param(
  [string]$FguDataPath = (Join-Path $env:APPDATA 'SmiteWorks\Fantasy Grounds'),
  [int]$PollMilliseconds = 750
)

$ErrorActionPreference = 'Stop'

Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;
public static class NerveNativeWindow {
  [DllImport("kernel32.dll")]
  public static extern IntPtr GetConsoleWindow();
  [DllImport("user32.dll")]
  public static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);
}
'@
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

$nerveConsole = [NerveNativeWindow]::GetConsoleWindow()
if ($nerveConsole -ne [IntPtr]::Zero) {
  [void][NerveNativeWindow]::ShowWindow($nerveConsole, 0)
}

$nerveCampaignsPath = Join-Path ([IO.Path]::GetFullPath($FguDataPath)) 'campaigns'
$nerveCapabilities = @{
  send_chat = 'Chat message'
  request_vote = 'Party vote'
  request_player_input = 'Private player prompt'
  request_player_roll = 'Private player roll'
  proxy_character_roll = 'Proxy character roll'
  proxy_character_power_action = 'Proxy character power'
  proxy_combatant_action = 'Proxy NPC action'
  add_library_npc = 'Add library NPC'
  add_library_encounter = 'Add prepared encounter'
  set_spell_slot_usage = 'Spell slot change'
  advance_turn = 'Combat turn change'
  apply_effect = 'Combat effect'
  remove_effect = 'Effect removal'
  remove_combatant = 'Combatant removal'
  resolve_manual_adjudication = 'Adjudication resolution'
  set_combatant_threat = 'Threat-state change'
}
$nerveSeen = [Collections.Generic.HashSet[string]]::new()

function Show-NerveAlert {
  param([string]$Campaign, [string]$Capability)

  $nerveForm = New-Object System.Windows.Forms.Form
  $nerveForm.Text = 'Nerve action waiting'
  $nerveForm.Size = New-Object System.Drawing.Size(390,145)
  $nerveForm.StartPosition = 'Manual'
  $nerveTarget = Get-Process -Name 'FantasyGrounds' -ErrorAction SilentlyContinue |
    Where-Object { $_.MainWindowHandle -ne 0 } |
    Select-Object -First 1
  if ($nerveTarget) {
    $nerveArea = [System.Windows.Forms.Screen]::FromHandle($nerveTarget.MainWindowHandle).WorkingArea
  } else {
    $nerveArea = [System.Windows.Forms.Screen]::FromPoint([System.Windows.Forms.Cursor]::Position).WorkingArea
  }
  $nerveForm.Location = New-Object System.Drawing.Point(
    ($nerveArea.Right - $nerveForm.Width - 20),
    ($nerveArea.Bottom - $nerveForm.Height - 20)
  )
  $nerveForm.TopMost = $true
  $nerveForm.ShowInTaskbar = $false
  $nerveForm.FormBorderStyle = 'FixedToolWindow'

  $nerveLabel = New-Object System.Windows.Forms.Label
  $nerveLabel.Text = "$($nerveCapabilities[$Capability]) for $Campaign.`r`nClick the amber NERVE control in Fantasy Grounds."
  $nerveLabel.AutoSize = $false
  $nerveLabel.Location = New-Object System.Drawing.Point(18,18)
  $nerveLabel.Size = New-Object System.Drawing.Size(345,55)
  $nerveForm.Controls.Add($nerveLabel)

  $nerveButton = New-Object System.Windows.Forms.Button
  $nerveButton.Text = 'Dismiss'
  $nerveButton.Location = New-Object System.Drawing.Point(278,76)
  $nerveButton.Add_Click({ $nerveForm.Close() })
  $nerveForm.Controls.Add($nerveButton)

  $nerveTimer = New-Object System.Windows.Forms.Timer
  $nerveTimer.Interval = 15000
  $nerveTimer.Add_Tick({ $nerveTimer.Stop(); $nerveForm.Close() })
  $nerveTimer.Start()
  [void]$nerveForm.ShowDialog()
  $nerveTimer.Dispose()
  $nerveForm.Dispose()
}

while ($true) {
  Get-ChildItem -LiteralPath $nerveCampaignsPath -Directory -ErrorAction SilentlyContinue | ForEach-Object {
    $nerveCommandPath = Join-Path $_.FullName 'nerve-command.json'
    if (-not (Test-Path -LiteralPath $nerveCommandPath)) { return }
    try {
      $nerveCommand = Get-Content -Raw -LiteralPath $nerveCommandPath | ConvertFrom-Json
      $nerveRequestId = [string]$nerveCommand.requestId
      $nerveCapability = [string]$nerveCommand.capability
      $nerveExpiry = [long]$nerveCommand.expiresAtEpoch
      $nerveNow = [DateTimeOffset]::UtcNow.ToUnixTimeSeconds()
      if ($nerveCommand.schemaVersion -ne '0.1' -or
          [string]::IsNullOrWhiteSpace($nerveRequestId) -or
          -not $nerveCapabilities.ContainsKey($nerveCapability) -or
          $nerveExpiry -lt $nerveNow -or
          $nerveSeen.Contains($nerveRequestId)) {
        return
      }
      [void]$nerveSeen.Add($nerveRequestId)
      Show-NerveAlert -Campaign $_.Name -Capability $nerveCapability
    } catch {
      # A partial or malformed file is ignored; the persistent inbox remains authoritative.
    }
  }
  Start-Sleep -Milliseconds $PollMilliseconds
}
