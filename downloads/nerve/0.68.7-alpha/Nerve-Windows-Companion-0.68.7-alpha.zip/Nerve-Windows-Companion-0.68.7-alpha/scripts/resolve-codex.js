import { findCodexExecutable } from "../ai/codex-app-listener.js";
try { console.log(await findCodexExecutable()); } catch (error) { console.error(error.code || error.message); process.exitCode = 1; }
