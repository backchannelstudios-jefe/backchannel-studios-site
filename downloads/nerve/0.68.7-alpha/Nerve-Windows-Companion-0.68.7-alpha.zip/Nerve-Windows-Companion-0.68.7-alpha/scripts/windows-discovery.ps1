# Read-only discovery shared by setup entry points. Explicit paths never fall back.
function Resolve-NerveDataPath {
  param([string]$ExplicitPath, [string]$ConfigRoot, [switch]$Interactive)
  if ($ExplicitPath) {
    $resolved = [IO.Path]::GetFullPath([Environment]::ExpandEnvironmentVariables($ExplicitPath.Trim('"')))
    if (-not (Test-Path -LiteralPath $resolved -PathType Container)) { throw "Fantasy Grounds data directory was not found: $resolved" }
    return $resolved
  }
  $candidates = @()
  # FGU's own current setting takes precedence over a stale Nerve installation.
  $fg = Get-ItemProperty -LiteralPath 'HKCU:\SOFTWARE\SmiteWorks\Fantasy Grounds' -ErrorAction SilentlyContinue
  if ($fg -and $fg.DataDir) { $candidates += [string]$fg.DataDir }
  if ($ConfigRoot) {
    foreach ($name in @('installation.json', 'provider.json')) {
      $path = Join-Path $ConfigRoot $name
      if (Test-Path -LiteralPath $path -PathType Leaf) {
        try { $saved = Get-Content -LiteralPath $path -Raw | ConvertFrom-Json; if ($saved.fantasyGroundsData) { $candidates += [string]$saved.fantasyGroundsData } } catch { }
      }
    }
  }
  if ($env:APPDATA) { $candidates += (Join-Path $env:APPDATA 'SmiteWorks\Fantasy Grounds') }
  foreach ($candidate in $candidates) {
    try {
      $resolved = [IO.Path]::GetFullPath([Environment]::ExpandEnvironmentVariables($candidate))
      if ((Test-Path -LiteralPath $resolved -PathType Container) -and ((Test-Path -LiteralPath (Join-Path $resolved 'campaigns')) -or (Test-Path -LiteralPath (Join-Path $resolved 'extensions')))) { return $resolved }
    } catch { }
  }
  if ($Interactive) {
    Write-Host 'Open the Fantasy Grounds launcher data-folder button and copy that folder path.'
    $selected = Read-Host 'Fantasy Grounds data folder'
    if ($selected) { return Resolve-NerveDataPath -ExplicitPath $selected }
  }
  throw 'Fantasy Grounds data folder could not be detected. Run Install-Nerve.cmd -FantasyGroundsData "D:\your FG data folder".'
}

function Resolve-NervePowerShell {
  $native = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
  if (Test-Path -LiteralPath $native -PathType Leaf) { return $native }
  foreach ($command in @(Get-Command powershell.exe -All -ErrorAction SilentlyContinue)) {
    if ($command.Source -and (Test-Path -LiteralPath $command.Source -PathType Leaf)) { return $command.Source }
  }
  throw 'POWERSHELL_NOT_FOUND'
}
