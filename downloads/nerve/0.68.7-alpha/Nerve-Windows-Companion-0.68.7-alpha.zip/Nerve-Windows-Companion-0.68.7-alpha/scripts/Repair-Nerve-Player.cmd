@echo off
setlocal
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0repair-player-extension.ps1" %*
exit /b %ERRORLEVEL%
