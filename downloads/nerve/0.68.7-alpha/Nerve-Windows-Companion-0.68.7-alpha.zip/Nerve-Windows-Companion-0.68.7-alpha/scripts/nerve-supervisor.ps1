[CmdletBinding()]
param(
  [string]$ConfigRoot,
  [ValidateRange(1, 30)][int]$PollSeconds = 2,
  [ValidateRange(1024, 65535)][int]$WakePort = 47831,
  [switch]$Once
)

$ErrorActionPreference = "Stop"
$runtimeRoot = Split-Path -Parent $PSScriptRoot
. (Join-Path $PSScriptRoot "extension-ownership.ps1")
. (Join-Path $PSScriptRoot "windows-discovery.ps1")
$configRoot = if ($ConfigRoot) { [IO.Path]::GetFullPath($ConfigRoot) } elseif ($env:LOCALAPPDATA) { Join-Path $env:LOCALAPPDATA "Nerve\Config" } else { Join-Path $env:USERPROFILE "Documents\Nerve\Config" }
$profilePath = Join-Path $configRoot "provider.json"
$installPath = Join-Path $configRoot "installation.json"
$mutexHasher = [Security.Cryptography.SHA256]::Create()
try { $mutexHash = [BitConverter]::ToString($mutexHasher.ComputeHash([Text.Encoding]::UTF8.GetBytes($configRoot))).Replace("-", "").Substring(0, 16) }
finally { $mutexHasher.Dispose() }
$createdMutex = $false
$mutex = New-Object Threading.Mutex($true, "Local\NerveSupervisor-$mutexHash", [ref]$createdMutex)
if (-not $createdMutex) { exit 0 }
$wakeListener = $null
if (-not $Once) {
  try {
    $wakeListener = New-Object Net.Sockets.TcpListener([Net.IPAddress]::Loopback, $WakePort)
    $wakeListener.Start()
  } catch {
    $wakeListener = $null
  }
}

function Read-JsonFile([string]$Path) {
  if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) { return $null }
  try {
    $text = (Get-Content -Raw -LiteralPath $Path).Trim()
    if ($text.Length -gt 0 -and $text[0] -eq [char]0xFEFF) { $text = $text.Substring(1).Trim() }
    if (-not $text) { return $null }
    return $text | ConvertFrom-Json
  } catch { return $null }
}

function Write-JsonAtomic([string]$Path, [object]$Value) {
  $temporary = "$Path.tmp"
  $json = $Value | ConvertTo-Json -Depth 8
  [IO.File]::WriteAllText($temporary, $json + [Environment]::NewLine, (New-Object Text.UTF8Encoding($false)))
  Move-Item -Force -LiteralPath $temporary -Destination $Path
}

function Get-CampaignDirectories([string]$FantasyGroundsData) {
  if (-not $FantasyGroundsData) { return @() }
  $campaignsRoot = [IO.Path]::GetFullPath((Join-Path $FantasyGroundsData "campaigns")).TrimEnd('\')
  if (-not (Test-Path -LiteralPath $campaignsRoot -PathType Container)) { return @() }
  return @(Get-ChildItem -LiteralPath $campaignsRoot -Directory -ErrorAction SilentlyContinue)
}

function Get-ActiveCampaignName([string]$FantasyGroundsData, [string]$CampaignHint = "") {
  $directories = @(Get-CampaignDirectories $FantasyGroundsData)
  if ($directories.Count -eq 0) { return $null }

  $pending = foreach ($directory in $directories) {
    foreach ($name in @("nerve-setup-control.json", "nerve-supervisor-control.json")) {
      $path = Join-Path $directory.FullName $name
      if (Test-Path -LiteralPath $path -PathType Leaf) {
        [pscustomobject]@{ name = $directory.Name; updated = (Get-Item -LiteralPath $path).LastWriteTimeUtc }
      }
    }
  }
  $selected = $pending | Sort-Object updated -Descending | Select-Object -First 1
  if ($selected) { return [string]$selected.name }

  $running = foreach ($directory in $directories) {
    $path = Join-Path $directory.FullName "nerve-host-status.json"
    $status = Read-JsonFile $path
    if ($status -and $status.status -eq "running") {
      [pscustomobject]@{ name = $directory.Name; updated = (Get-Item -LiteralPath $path).LastWriteTimeUtc }
    }
  }
  $selected = $running | Sort-Object updated -Descending | Select-Object -First 1
  if ($selected) { return [string]$selected.name }

  $snapshots = foreach ($directory in $directories) {
    $path = Join-Path $directory.FullName "nerve-state.json"
    if (Test-Path -LiteralPath $path -PathType Leaf) {
      [pscustomobject]@{ name = $directory.Name; updated = (Get-Item -LiteralPath $path).LastWriteTimeUtc }
    }
  }
  $selected = $snapshots | Sort-Object updated -Descending | Select-Object -First 1
  if ($selected) { return [string]$selected.name }

  if ($CampaignHint -and ($directories.Name -contains $CampaignHint)) { return $CampaignHint }
  return $null
}

function Resolve-ProfileState {
  $profile = Read-JsonFile $profilePath
  $configured = $true
  if (-not $profile -or -not $profile.fantasyGroundsData) {
    $installation = Read-JsonFile $installPath
    if (-not $installation -or -not $installation.fantasyGroundsData) { return $null }
    $profile = [pscustomobject]@{
      campaign = [string]$installation.campaign
      fantasyGroundsData = [string]$installation.fantasyGroundsData
      provider = $null
      model = $null
    }
    $configured = $false
  }
  $campaignHint = if ($profile.campaign) { [string]$profile.campaign } else { "" }
  $campaign = Get-ActiveCampaignName ([string]$profile.fantasyGroundsData) $campaignHint
  if (-not $campaign) { return $null }
  $profile | Add-Member -NotePropertyName campaign -NotePropertyValue $campaign -Force
  $campaignsRoot = [IO.Path]::GetFullPath((Join-Path $profile.fantasyGroundsData "campaigns")).TrimEnd('\')
  $campaignDirectory = [IO.Path]::GetFullPath((Join-Path $campaignsRoot $campaign))
  if (-not $campaignDirectory.StartsWith($campaignsRoot + '\', [StringComparison]::OrdinalIgnoreCase)) { return $null }
  if (-not (Test-Path -LiteralPath $campaignDirectory -PathType Container)) { return $null }
  return [ordered]@{
    profile = $profile
    configured = $configured
    campaignDirectory = $campaignDirectory
    controlPath = Join-Path $campaignDirectory "nerve-supervisor-control.json"
    setupControlPath = Join-Path $campaignDirectory "nerve-setup-control.json"
    statusPath = Join-Path $campaignDirectory "nerve-supervisor-status.json"
    controllerStatusPath = Join-Path $campaignDirectory "nerve-controller-status.json"
    snapshotPath = Join-Path $campaignDirectory "nerve-state.json"
    commandPath = Join-Path $campaignDirectory "nerve-command.json"
  }
}

function Get-ConnectionMode([object]$state) {
  if (-not $state.configured) { return "connector" }
  if ($state.profile.connectionMode -eq "companion") { return "manual" }
  if ($state.profile.connectionMode) { return [string]$state.profile.connectionMode }
  if ($state.profile.provider -eq "companion") { return "manual" }
  if ($state.profile.provider -eq "manual") { return "manual" }
  if ($state.profile.provider -eq "connector") { return "connector" }
  if ($state.profile.provider -in @("fake", "ollama")) { return "local" }
  return "api"
}

function Controller-State([object]$state) {
  $controller = Read-JsonFile $state.controllerStatusPath
  if (-not $controller) { return "stopped" }
  if ($controller.status -in @("starting", "running", "stopping")) {
    $controllerPid = 0
    if (-not [int]::TryParse([string]$controller.pid, [ref]$controllerPid) -or $controllerPid -le 0 -or
        -not (Get-Process -Id $controllerPid -ErrorAction SilentlyContinue)) {
      return "stopped"
    }
  }
  if ($controller.status -in @("starting", "running", "stopping", "failed", "stopped")) { return [string]$controller.status }
  return "stopped"
}

function Get-InstalledNerveHealth([object]$state) {
  $expectedVersion = $null
  $runtimeVersion = $null
  $extensionVersion = $null
  $adapterVersion = $null
  $nodeVersion = $null
  try {
    $runtimePackage = Read-JsonFile (Join-Path $runtimeRoot "package.json")
    if ($runtimePackage.version) {
      $runtimeVersion = [string]$runtimePackage.version
      $expectedVersion = $runtimeVersion
    }
  } catch { }
  try {
    $extensionState = Get-NerveExtensionInstall ([string]$state.profile.fantasyGroundsData)
    if ($extensionState.archives.Count -eq 1 -and -not $extensionState.localPresent) {
      $extensionVersion = $extensionState.archives[0].version
    } elseif ($extensionState.archives.Count -eq 0) {
      $extensionVersion = $extensionState.localVersion
    }
  } catch { }
  try {
    $snapshot = Read-JsonFile $state.snapshotPath
    if ($snapshot.adapterVersion) { $adapterVersion = [string]$snapshot.adapterVersion }
  } catch { }
  try {
    $node = Get-Command node -ErrorAction SilentlyContinue
    if ($node) { $nodeVersion = (& $node.Source --version).Trim() }
  } catch { }

  $health = "ready"
  $code = "INSTALL_READY"
  if (-not $runtimeVersion -or -not $extensionVersion -or -not $nodeVersion) {
    $health = "repair_required"
    $code = "INSTALL_COMPONENT_MISSING"
  } elseif ($extensionVersion -ne $expectedVersion) {
    $health = "repair_required"
    $code = "INSTALL_VERSION_MISMATCH"
  } elseif (-not $adapterVersion -or $adapterVersion -ne $expectedVersion) {
    $health = "reload_required"
    $code = "FANTASY_GROUNDS_RELOAD_REQUIRED"
  }
  return [ordered]@{
    status = $health
    code = $code
    expectedVersion = $expectedVersion
    runtimeVersion = $runtimeVersion
    extensionVersion = $extensionVersion
    loadedAdapterVersion = $adapterVersion
    nodeVersion = $nodeVersion
    updateComponent = if ($health -eq "repair_required" -and $runtimeVersion -and $extensionVersion) {
      try {
        if ([version]$runtimeVersion -lt [version]$extensionVersion) { "companion" }
        elseif ([version]$extensionVersion -lt [version]$runtimeVersion) { "extension" }
        else { "installation" }
      } catch { "installation" }
    } else { $null }
    checkedAt = (Get-Date).ToUniversalTime().ToString("o")
  }
}

function Test-AppCommand([string]$Name, [string[]]$Candidates = @()) {
  foreach ($candidate in $Candidates) {
    if ($candidate -and (Test-Path -LiteralPath $candidate -PathType Leaf)) { return $true }
  }
  return [bool](Get-Command $Name -ErrorAction SilentlyContinue)
}

function Get-AppConnectorStates {
  $profileRoot = if ($env:USERPROFILE) { $env:USERPROFILE } else { "" }
  $localRoot = if ($env:LOCALAPPDATA) { $env:LOCALAPPDATA } else { "" }
  $last = Read-JsonFile (Join-Path $configRoot "app-connector-status.json")
  $definitions = [ordered]@{
    codex = [ordered]@{ label = "Codex / ChatGPT"; installed = Test-AppCommand "codex" @($(if ($profileRoot) { Join-Path $profileRoot ".codex\plugins\.plugin-appserver\codex.exe" }), $(if ($profileRoot) { Join-Path $profileRoot ".codex\.sandbox-bin\codex.exe" })) }
    antigravity = [ordered]@{ label = "Gemini (Antigravity)"; installed = Test-AppCommand "agy" @($(if ($localRoot) { Join-Path $localRoot "agy\bin\agy.exe" })) }
    claude = [ordered]@{ label = "Claude"; installed = Test-AppCommand "claude" }
    grok = [ordered]@{ label = "Grok"; installed = Test-AppCommand "grok" }
    custom = [ordered]@{ label = "Custom AI App (Experimental)"; installed = Test-Path -LiteralPath (Join-Path $configRoot "custom-ai-app.json") -PathType Leaf }
  }
  foreach ($entry in $definitions.GetEnumerator()) {
    $entry.Value.lastOperation = if ($last -and $last.appConnector -eq $entry.Key) { [string]$last.operation } else { $null }
    $entry.Value.lastStatus = if ($last -and $last.appConnector -eq $entry.Key) { [string]$last.status } else { $null }
    $entry.Value.lastCode = if ($last -and $last.appConnector -eq $entry.Key -and $last.code) { [string]$last.code } else { $null }
    $entry.Value.lastMessage = if ($last -and $last.appConnector -eq $entry.Key -and $last.message) { [string]$last.message } else { $null }
    if ($entry.Value.lastOperation -eq "test" -and $entry.Value.lastStatus -eq "working" -and -not (Get-SetupBusy)) {
      $entry.Value.lastStatus = "failed"
      $entry.Value.lastCode = "SETUP_TIMED_OUT"
      $entry.Value.lastMessage = "The test did not finish. Retry Test + Use."
    }
    $entry.Value.ready = [bool]($entry.Value.installed -and $entry.Value.lastStatus -eq "ready")
  }
  return $definitions
}

function Get-SetupBusy {
  $activeSetup = Read-JsonFile (Join-Path $configRoot "app-connector-status.json")
  try { return [bool]($activeSetup -and $activeSetup.operation -eq "test" -and $activeSetup.status -eq "working" -and ([DateTime]::UtcNow - [DateTime]::Parse($activeSetup.updatedAt).ToUniversalTime()).TotalSeconds -lt 180) }
  catch { return $false }
}

function Write-SupervisorStatus([object]$state, [string]$lastRequestId = "", [string]$errorCode = "", [string]$message = "", [string]$setupStatus = "idle") {
  $profile = $state.profile
  $controller = Read-JsonFile $state.controllerStatusPath
  $listenerLastSeenAtEpoch = if ($controller -and $controller.listenerLastSeenAtEpoch) { [long]$controller.listenerLastSeenAtEpoch } else { 0 }
  $listenerAgeSeconds = if ($listenerLastSeenAtEpoch -gt 0) { [Math]::Max(0, [DateTimeOffset]::UtcNow.ToUnixTimeSeconds() - $listenerLastSeenAtEpoch) } else { $null }
  $listenerState = if ($controller -and $controller.status -eq "running" -and $listenerAgeSeconds -ne $null -and $listenerAgeSeconds -le 45) { "connected" } else { "not_connected" }
  $cueClaimedAtEpoch = if ($controller -and $controller.lastCueClaimedAtEpoch) { [long]$controller.lastCueClaimedAtEpoch } else { 0 }
  $cueClaimAgeSeconds = if ($cueClaimedAtEpoch -gt 0) { [Math]::Max(0, [DateTimeOffset]::UtcNow.ToUnixTimeSeconds() - $cueClaimedAtEpoch) } else { $null }
  $aiResponseState = if ($controller -and $controller.status -eq "running" -and $controller.connectorState -eq "cue_claimed") {
    if ($cueClaimAgeSeconds -ne $null -and $cueClaimAgeSeconds -le 120) { "responding" } else { "overdue" }
  } elseif ($controller -and $controller.connectorState -eq "awaiting_approval") { "awaiting_approval" } else { "idle" }
  $installHealth = Get-InstalledNerveHealth $state
  Write-JsonAtomic $state.statusPath ([ordered]@{
    schemaVersion = "0.1"
    supervisorVersion = "0.68.7"
    status = "online"
    controllerStatus = Controller-State $state
    campaign = [string]$profile.campaign
    provider = [string]$profile.provider
    connectionMode = Get-ConnectionMode $state
    appConnector = if ($profile.appConnector) { [string]$profile.appConnector } else { $null }
    appConnectors = Get-AppConnectorStates
    listenerState = $listenerState
    listenerKind = if ($controller -and $controller.listenerKind) { [string]$controller.listenerKind } else { $null }
    listenerName = if ($controller -and $controller.listenerName) { [string]$controller.listenerName } else { $null }
    listenerPhase = if ($controller -and $controller.listenerPhase) { [string]$controller.listenerPhase } else { $null }
    listenerErrorCode = if ($controller -and $controller.listenerErrorCode) { [string]$controller.listenerErrorCode } else { $null }
    listenerMessage = if ($controller -and $controller.listenerMessage) { [string]$controller.listenerMessage } else { $null }
    listenerLastSeenAt = if ($controller -and $controller.listenerLastSeenAt) { [string]$controller.listenerLastSeenAt } else { $null }
    listenerAgeSeconds = $listenerAgeSeconds
    connectorState = if ($controller -and $controller.connectorState) { [string]$controller.connectorState } else { $null }
    aiResponseState = $aiResponseState
    cueClaimAgeSeconds = $cueClaimAgeSeconds
    model = if ($controller -and $controller.model) { [string]$controller.model } elseif ($profile.model) { [string]$profile.model } else { $null }
    usage = if ($controller -and $controller.usage) { $controller.usage } else { $null }
    lastResult = if ($controller -and $controller.lastResult) { $controller.lastResult } else { $null }
    budgets = if ($controller -and $controller.budgets) { $controller.budgets } else { $null }
    installHealth = $installHealth
    configured = [bool]$state.configured
    connectionVerified = [bool]$profile.connectionVerified
    allowWrites = [bool]$profile.allowWrites
    setupBusy = Get-SetupBusy
    setupStatus = $setupStatus
    lastRequestId = $lastRequestId
    errorCode = $errorCode
    message = $message
    updatedAt = (Get-Date).ToUniversalTime().ToString("o")
    updatedAtEpoch = [DateTimeOffset]::UtcNow.ToUnixTimeSeconds()
  })
}

function Quote-ProcessArgument([string]$Value) {
  return '"' + $Value.Replace('"', '\"') + '"'
}

function Send-FlowWakeSignal([object]$state) {
  if (-not $wakeListener) { return }
  try {
    if ($wakeListener.Pending()) {
      $client = $wakeListener.AcceptTcpClient()
      try {
        $client.ReceiveTimeout = 2000
        $stream = $client.GetStream()
        $requestBuffer = New-Object byte[] 4096
        $read = $stream.Read($requestBuffer, 0, $requestBuffer.Length)
        $requestLine = if ($read -gt 0) { [Text.Encoding]::ASCII.GetString($requestBuffer, 0, $read).Split("`n")[0].Trim() } else { "" }
        $authorizedPath = $requestLine -match '^GET /nerve-flow-wait(?:\?[^ ]*)? HTTP/'
        $deadline = [DateTime]::UtcNow.AddSeconds(4)
        while ($authorizedPath -and [DateTime]::UtcNow -lt $deadline) {
          if ((Test-Path -LiteralPath $state.commandPath -PathType Leaf) -and (Get-Item -LiteralPath $state.commandPath).Length -gt 0) { break }
          Start-Sleep -Milliseconds 200
        }
        $hasAction = $authorizedPath -and (Test-Path -LiteralPath $state.commandPath -PathType Leaf) -and (Get-Item -LiteralPath $state.commandPath).Length -gt 0
        $body = if ($hasAction) { '{"schemaVersion":"0.1","status":"action"}' } else { '{"schemaVersion":"0.1","status":"idle"}' }
        $bodyBytes = [Text.Encoding]::UTF8.GetBytes($body)
        $httpStatus = if ($authorizedPath) { "200 OK" } else { "404 Not Found" }
        $headers = "HTTP/1.1 $httpStatus`r`nContent-Type: application/json`r`nContent-Length: $($bodyBytes.Length)`r`nCache-Control: no-store`r`nConnection: close`r`n`r`n"
        $headerBytes = [Text.Encoding]::ASCII.GetBytes($headers)
        $stream.Write($headerBytes, 0, $headerBytes.Length)
        $stream.Write($bodyBytes, 0, $bodyBytes.Length)
        $stream.Flush()
      } finally {
        $client.Dispose()
      }
    }
  } catch {
    # The loopback wake signal is advisory. File-based control remains available.
  }
}

function Find-PendingCompanionCue([object]$state) {
  $snapshot = Read-JsonFile $state.snapshotPath
  $events = @($snapshot.recentEvents.events)
  $requested = $events | Where-Object { $_.type -eq "ai.cue_requested" -and $_.subjectId } | Sort-Object { [long]$_.sequence } -Descending | Select-Object -First 1
  if (-not $requested) { return $null }
  $terminal = $events | Where-Object {
    [long]$_.sequence -gt [long]$requested.sequence -and $_.type -in @("ai.cue_answered", "ai.cue_failed")
  } | Select-Object -First 1
  if ($terminal) { return $null }
  return [string]$requested.subjectId
}

function Open-CompanionWindow([object]$state) {
  $companionScript = Join-Path $runtimeRoot "scripts\nerve-companion.ps1"
  $arguments = @(
    "-NoProfile", "-WindowStyle", "Hidden", "-ExecutionPolicy", "Bypass", "-File", (Quote-ProcessArgument $companionScript),
    "-Campaign", (Quote-ProcessArgument ([string]$state.profile.campaign)),
    "-FantasyGroundsData", (Quote-ProcessArgument ([string]$state.profile.fantasyGroundsData)),
    "-ConfigRoot", (Quote-ProcessArgument $configRoot)
  )
  Start-Process -FilePath (Resolve-NervePowerShell) -ArgumentList $arguments -WindowStyle Hidden | Out-Null
}

function Start-LocalConnector([object]$state) {
  $node = Get-Command node -ErrorAction SilentlyContinue
  if (-not $node) { throw "NODE_NOT_FOUND" }
  $tokenPath = Join-Path $configRoot "Secrets\connector.token"
  $appConnector = if ($state.profile.appConnector) { [string]$state.profile.appConnector } else { "codex" }
  $arguments = @(
    (Quote-ProcessArgument (Join-Path $runtimeRoot "bin\nerve.js")), "connector-serve",
    "--campaign", (Quote-ProcessArgument ([string]$state.profile.campaign)),
    "--fgu-data", (Quote-ProcessArgument ([string]$state.profile.fantasyGroundsData)),
    "--token-file", (Quote-ProcessArgument $tokenPath),
    "--app-listener", $appConnector
  )
  if ($state.profile.model) { $arguments += @("--model", (Quote-ProcessArgument ([string]$state.profile.model))) }
  if ($appConnector -eq "custom") { $arguments += @("--app-listener-config", (Quote-ProcessArgument (Join-Path $configRoot "custom-ai-app.json"))) }
  if ($state.profile.allowWrites) { $arguments += @("--expose-writes", "--allow-writes") }
  Start-Process -FilePath $node.Source -ArgumentList $arguments -WindowStyle Hidden | Out-Null
}

function Stop-LocalConnector([object]$state) {
  $controller = Read-JsonFile $state.controllerStatusPath
  if (-not $controller -or -not $controller.sessionId) { return }
  Write-JsonAtomic (Join-Path $state.campaignDirectory "nerve-controller-stop.json") ([ordered]@{
    schemaVersion = "0.1"
    sessionId = [string]$controller.sessionId
    requestedAt = (Get-Date).ToUniversalTime().ToString("o")
    requestedByPid = $PID
  })
}

function Invoke-SetupOperation([object]$request, [object]$state) {
  if ($request.schemaVersion -ne "0.1") { throw "SETUP_VERSION_UNSUPPORTED" }
  if ($request.campaign -ne $state.profile.campaign) { throw "CAMPAIGN_MISMATCH" }
  if ($request.operation -notin @("configure", "app_install", "app_signin", "app_test", "app_connect")) { throw "SETUP_OPERATION_NOT_ALLOWED" }
  if (-not $request.expiresAtEpoch -or [long]$request.expiresAtEpoch -lt [DateTimeOffset]::UtcNow.ToUnixTimeSeconds()) { throw "SETUP_REQUEST_EXPIRED" }
  if ((Controller-State $state) -in @("starting", "running", "stopping")) { throw "STOP_CONTROLLER_BEFORE_SETUP" }
  if (Get-SetupBusy) { throw "SETUP_ALREADY_RUNNING" }
  if ($request.operation -ne "configure") {
    if ($request.appConnector -notin @("codex", "antigravity", "claude", "grok", "custom")) { throw "APP_CONNECTOR_NOT_ALLOWED" }
    $manager = Join-Path $runtimeRoot "scripts\manage-app-connector.ps1"
    $operation = ([string]$request.operation).Substring(4)
    if ($operation -eq "connect") { $operation = "test" }
    $arguments = @(
      "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", (Quote-ProcessArgument $manager),
      "-Operation", $operation, "-AppConnector", ([string]$request.appConnector),
      "-ConfigRoot", (Quote-ProcessArgument $configRoot)
    )
    if ($request.operation -eq "app_connect") {
      if ($request.allowWrites -isnot [bool]) { throw "SETUP_OPTIONS_INVALID" }
      $arguments += @("-SaveAfterTest", "-Campaign", (Quote-ProcessArgument ([string]$state.profile.campaign)), "-FantasyGroundsData", (Quote-ProcessArgument ([string]$state.profile.fantasyGroundsData)), "-GuardedActions", $(if ($request.allowWrites) { "allow" } else { "deny" }))
    }
    if ($operation -eq "test") {
      $arguments += "-NoPause"
      $operationStatusPath = Join-Path $configRoot "app-connector-status.json"
      $pendingStatus = [ordered]@{ schemaVersion = "0.1"; appConnector = [string]$request.appConnector; operation = "test"; status = "working"; message = "Testing the selected AI before saving."; code = ""; updatedAt = [DateTime]::UtcNow.ToString("o"); operationId = [DateTime]::UtcNow.Ticks }
      Write-JsonAtomic $operationStatusPath $pendingStatus
      try { Start-Process -FilePath (Resolve-NervePowerShell) -ArgumentList $arguments -WindowStyle Hidden | Out-Null }
      catch { $pendingStatus.status = "failed"; $pendingStatus.code = "SETUP_LAUNCH_FAILED"; Write-JsonAtomic $operationStatusPath $pendingStatus; throw }
    }
    else { Start-Process -FilePath (Resolve-NervePowerShell) -ArgumentList $arguments -WindowStyle Normal | Out-Null }
    return
  }
  if ($request.provider -notin @("connector", "manual", "companion", "fake", "ollama", "openai", "anthropic", "gemini", "xai")) { throw "PROVIDER_NOT_ALLOWED" }
  if ($request.provider -eq "connector" -and $request.appConnector -notin @("codex", "antigravity", "claude", "grok", "custom")) { throw "APP_CONNECTOR_NOT_ALLOWED" }
  if ($request.provider -notin @("connector", "manual", "fake", "companion") -and ([string]$request.model -notmatch '^[A-Za-z0-9._:-]{2,128}$')) { throw "MODEL_INVALID" }
  if ($request.allowWrites -isnot [bool] -or $request.liveCheck -isnot [bool]) { throw "SETUP_OPTIONS_INVALID" }

  $configureScript = Join-Path $runtimeRoot "scripts\configure-provider.ps1"
  $arguments = @(
    "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", (Quote-ProcessArgument $configureScript),
    "-Campaign", (Quote-ProcessArgument ([string]$state.profile.campaign)),
    "-FantasyGroundsData", (Quote-ProcessArgument ([string]$state.profile.fantasyGroundsData)),
    "-ConfigRoot", (Quote-ProcessArgument $configRoot),
    "-Provider", ([string]$request.provider),
    "-GuardedActions", $(if ($request.allowWrites) { "allow" } else { "deny" }),
    "-ConnectionCheck", $(if ($request.liveCheck) { "run" } else { "skip" })
  )
  if ($request.provider -eq "connector") { $arguments += @("-AppConnector", ([string]$request.appConnector)) }
  if ($request.provider -notin @("connector", "manual", "fake", "companion")) {
    $arguments += @("-Model", ([string]$request.model))
    if ($request.provider -eq "ollama") {
      $arguments += "-NoPause"
      $process = Start-Process -FilePath (Resolve-NervePowerShell) -ArgumentList $arguments -WindowStyle Hidden -Wait -PassThru
      if ($process.ExitCode -ne 0) { throw "BACKGROUND_SETUP_FAILED" }
    } else {
      Start-Process -FilePath (Resolve-NervePowerShell) -ArgumentList $arguments -WindowStyle Normal
    }
    return
  }
  $arguments += "-NoPause"
  $process = Start-Process -FilePath (Resolve-NervePowerShell) -ArgumentList $arguments -WindowStyle Hidden -Wait -PassThru
  if ($process.ExitCode -ne 0) { throw "BACKGROUND_SETUP_FAILED" }
}

function Invoke-ControllerOperation([string]$Operation, [object]$state) {
  if ($Operation -eq "system_check") { return }
  if ($Operation -eq "collect_support") {
    & (Join-Path $runtimeRoot "scripts\collect-support.ps1") `
      -Campaign ([string]$state.profile.campaign) `
      -FantasyGroundsData ([string]$state.profile.fantasyGroundsData) `
      -ConfigRoot $configRoot -NoPause
    if ($LASTEXITCODE -ne 0) { throw "SUPPORT_COLLECTION_FAILED" }
    return
  }
  if ($Operation -eq "open_companion") {
    if ((Get-ConnectionMode $state) -ne "manual") { throw "MANUAL_MODE_NOT_ACTIVE" }
    Open-CompanionWindow $state
    return
  }
  $current = Controller-State $state
  if ($Operation -eq "start" -and $current -in @("starting", "running")) { return }
  if ($Operation -eq "stop" -and $current -in @("stopped", "failed")) { return }
  if ($Operation -eq "start") {
    $savedProfile = Read-JsonFile $profilePath
    if ($savedProfile) { $savedProfile | Add-Member -NotePropertyName campaign -NotePropertyValue $state.profile.campaign -Force; $state.profile = $savedProfile }
    if ((Get-ConnectionMode $state) -eq "connector" -and -not $state.profile.connectionVerified) { throw "TEST_AND_SAVE_AI_FIRST" }
    if (Test-Path -LiteralPath $state.setupControlPath) { throw "WAIT_FOR_SETUP_TO_FINISH" }
    if (Get-SetupBusy) { throw "WAIT_FOR_SETUP_TO_FINISH" }
    $health = Get-InstalledNerveHealth $state
    if ($health.status -ne "ready") { throw ([string]$health.code) }
    if ((Get-ConnectionMode $state) -eq "connector") { Start-LocalConnector $state; return }
    & (Join-Path $runtimeRoot "scripts\start-nerve.ps1") -ConfigRoot $configRoot `
      -Campaign ([string]$state.profile.campaign) -FantasyGroundsData ([string]$state.profile.fantasyGroundsData) -NoPause
    if ($LASTEXITCODE -ne 0) { throw "START_FAILED" }
    return
  }
  if ($Operation -eq "stop") {
    if ((Get-ConnectionMode $state) -eq "connector") { Stop-LocalConnector $state; return }
    & (Join-Path $runtimeRoot "scripts\stop-nerve.ps1") -ConfigRoot $configRoot `
      -Campaign ([string]$state.profile.campaign) -FantasyGroundsData ([string]$state.profile.fantasyGroundsData) -NoPause
    if ($LASTEXITCODE -ne 0) { throw "STOP_FAILED" }
    return
  }
  throw "OPERATION_NOT_ALLOWED"
}

try {
  $lastRequestId = ""
  $lastSetupRequestId = ""
  $lastErrorCode = ""
  $lastMessage = ""
  $setupStatus = "idle"
  $lastCampaign = ""
  do {
    $state = Resolve-ProfileState
    if ($state) {
      $activeCampaign = [string]$state.profile.campaign
      if ($activeCampaign -ne $lastCampaign) {
        $lastCampaign = $activeCampaign
        $lastRequestId = ""
        $lastSetupRequestId = ""
        $lastErrorCode = ""
        $lastMessage = ""
        $setupStatus = "idle"
      }
      $setupRequest = Read-JsonFile $state.setupControlPath
      if ($setupRequest -and $setupRequest.requestId -and $setupRequest.requestId -ne $lastSetupRequestId) {
        $lastSetupRequestId = [string]$setupRequest.requestId
        $lastErrorCode = ""
        $lastMessage = ""
        try {
          Invoke-SetupOperation $setupRequest $state
          if ($setupRequest.operation -eq "configure") {
            $setupStatus = if ($setupRequest.provider -eq "connector") { "connector_ready" } elseif ($setupRequest.provider -in @("manual", "companion")) { "manual_ready" } elseif ($setupRequest.provider -eq "fake") { "offline_ready" } elseif ($setupRequest.provider -eq "ollama") { "local_ai_ready" } else { "secure_prompt_opened" }
            $lastMessage = if ($setupRequest.provider -eq "connector") { "Automatic connector saved; finish installation and sign-in in Nerve Settings." } elseif ($setupRequest.provider -in @("manual", "companion")) { "Manual compatibility fallback saved." } elseif ($setupRequest.provider -eq "fake") { "Offline provider saved silently." } elseif ($setupRequest.provider -eq "ollama") { "Ollama local AI saved. Install Ollama and the selected model before starting Nerve." } else { "Secure credential setup opened on the GM host." }
          } else {
            $setupStatus = "app_operation_started"
            $lastMessage = "Nerve started the requested AI app setup step."
          }
        } catch {
          $setupStatus = "failed"
          $lastErrorCode = if ($_.Exception.Message -match '^[A-Z0-9_]+$') { $_.Exception.Message } else { "SETUP_OPERATION_FAILED" }
          $lastMessage = "Nerve could not open the requested AI setup."
        } finally {
          Remove-Item -Force -LiteralPath $state.setupControlPath -ErrorAction SilentlyContinue
        }
        Write-SupervisorStatus $state $lastSetupRequestId $lastErrorCode $lastMessage $setupStatus
      }
      $request = Read-JsonFile $state.controlPath
      if ($request -and $request.requestId -and $request.requestId -ne $lastRequestId) {
        $lastRequestId = [string]$request.requestId
        $lastErrorCode = ""
        $lastMessage = ""
        try {
          $now = [DateTimeOffset]::UtcNow.ToUnixTimeSeconds()
          if ($request.schemaVersion -ne "0.1") { throw "CONTROL_VERSION_UNSUPPORTED" }
          if ($request.campaign -ne $state.profile.campaign) { throw "CAMPAIGN_MISMATCH" }
          if ($request.operation -notin @("start", "stop", "open_companion", "collect_support", "system_check")) { throw "OPERATION_NOT_ALLOWED" }
          if (-not $request.expiresAtEpoch -or [long]$request.expiresAtEpoch -lt $now) { throw "CONTROL_REQUEST_EXPIRED" }
          Invoke-ControllerOperation ([string]$request.operation) $state
          if ($request.operation -eq "open_companion") { $lastMessage = "Nerve Companion opened." }
          elseif ($request.operation -eq "collect_support") { $lastMessage = "Redacted support bundle saved in Documents\Nerve Support." }
          elseif ($request.operation -eq "system_check") {
            $health = Get-InstalledNerveHealth $state
            if ($health.status -eq "ready") { $lastMessage = "System check passed. Runtime, extension, and loaded adapter are v$($health.expectedVersion)." }
            elseif ($health.status -eq "reload_required") { $lastMessage = "System check: Fantasy Grounds must reload to activate Nerve v$($health.expectedVersion)." }
            else { $lastMessage = "System check found an installation mismatch. Use the verified installer to repair Nerve." }
          }
          else { $lastMessage = "Nerve $($request.operation) request accepted." }
        } catch {
          $lastErrorCode = if ($_.Exception.Message -match '^[A-Z0-9_]+$') { $_.Exception.Message } else { "CONTROL_OPERATION_FAILED" }
          if ($lastErrorCode -eq "FANTASY_GROUNDS_RELOAD_REQUIRED") {
            $lastMessage = "Nerve did not start. Close and reload Fantasy Grounds so the installed Nerve extension matches the companion."
          } elseif ($lastErrorCode -in @("INSTALL_VERSION_MISMATCH", "INSTALL_COMPONENT_MISSING")) {
            $health = Get-InstalledNerveHealth $state
            $target = if ($health.updateComponent -eq "extension") { "extension" } elseif ($health.updateComponent -eq "companion") { "companion software" } else { "installation" }
            $lastMessage = "Nerve did not start. Extension v$($health.extensionVersion) and companion v$($health.runtimeVersion) must match; update the $target."
          } else {
            $lastMessage = "Nerve could not complete the requested controller operation."
          }
        } finally {
          Remove-Item -Force -LiteralPath $state.controlPath -ErrorAction SilentlyContinue
        }
        Write-SupervisorStatus $state $lastRequestId $lastErrorCode $lastMessage $setupStatus
      } else {
        Write-SupervisorStatus $state $lastRequestId $lastErrorCode $lastMessage $setupStatus
      }
    }
    Send-FlowWakeSignal $state
    if (-not $Once) { Start-Sleep -Seconds $PollSeconds }
  } while (-not $Once)
} finally {
  if ($wakeListener) { $wakeListener.Stop() }
  if ($createdMutex) { $mutex.ReleaseMutex() }
  $mutex.Dispose()
}
