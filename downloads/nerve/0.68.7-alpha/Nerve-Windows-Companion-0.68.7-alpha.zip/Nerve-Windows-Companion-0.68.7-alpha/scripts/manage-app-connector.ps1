[CmdletBinding()]
param(
  [Parameter(Mandatory = $true)]
  [ValidateSet("install", "signin", "test")]
  [string]$Operation,
  [Parameter(Mandatory = $true)]
  [ValidateSet("codex", "antigravity", "claude", "grok", "custom")]
  [string]$AppConnector,
  [string]$ConfigRoot,
  [string]$Model,
  [switch]$SaveAfterTest,
  [string]$Campaign,
  [string]$FantasyGroundsData,
  [ValidateSet("allow", "deny")][string]$GuardedActions = "deny",
  [switch]$NoPause
)

$ErrorActionPreference = "Stop"
$runtimeRoot = Split-Path -Parent $PSScriptRoot
$configRoot = if ($ConfigRoot) { [IO.Path]::GetFullPath($ConfigRoot) } elseif ($env:LOCALAPPDATA) { Join-Path $env:LOCALAPPDATA "Nerve\Config" } else { Join-Path $env:USERPROFILE "Documents\Nerve\Config" }
$statusPath = Join-Path $configRoot "app-connector-status.json"
$operationId = [DateTime]::UtcNow.Ticks

function Write-Status([string]$Status, [string]$Message, [string]$Code = "") {
  $directory = Split-Path -Parent $statusPath
  New-Item -ItemType Directory -Force -Path $directory | Out-Null
  if (Test-Path -LiteralPath $statusPath) {
    try {
      $existing = Get-Content -Raw -LiteralPath $statusPath | ConvertFrom-Json
      if ($existing.operationId -and [long]$existing.operationId -gt $operationId) { return }
    } catch { }
  }
  $value = [ordered]@{
    operationId = $operationId
    schemaVersion = "0.1"
    appConnector = $AppConnector
    operation = $Operation
    status = $Status
    code = $Code
    message = $Message
    updatedAt = (Get-Date).ToUniversalTime().ToString("o")
  }
  $temporary = "$statusPath.tmp"
  [IO.File]::WriteAllText($temporary, (($value | ConvertTo-Json -Depth 5) + [Environment]::NewLine), (New-Object Text.UTF8Encoding($false)))
  Move-Item -Force -LiteralPath $temporary -Destination $statusPath
}

function Confirm-Install([string]$Name, [string]$Source) {
  Write-Host ""
  Write-Host "NERVE PROVIDER INSTALL" -ForegroundColor Cyan
  Write-Host "Nerve will install $Name from its official publisher:"
  Write-Host $Source -ForegroundColor Yellow
  Write-Host "Nerve will not receive or store your provider password or OAuth token."
  $answer = Read-Host "Type YES to continue"
  if ($answer -cne "YES") { throw "INSTALL_CANCELLED" }
}

function Require-Command([string]$Name) {
  $command = Get-Command $Name -ErrorAction SilentlyContinue
  if (-not $command) { throw "${Name}_NOT_FOUND".ToUpperInvariant() }
  return $command.Source
}

function Resolve-ClaudeExecutable {
  if ($env:APPDATA) {
    $native = Join-Path $env:APPDATA "npm\node_modules\@anthropic-ai\claude-code\bin\claude.exe"
    if (Test-Path -LiteralPath $native) { return $native }
  }
  return Require-Command "claude"
}

try {
  Write-Status "working" "Nerve is preparing $Operation for $AppConnector."
  if ($Operation -eq "install") {
    if ($AppConnector -eq "codex") {
      Write-Status "needs_user" "Codex is supplied by the ChatGPT/Codex desktop installation. Install or update that app, then return to Nerve Settings."
      Start-Process "https://openai.com/codex/" | Out-Null
    } elseif ($AppConnector -eq "antigravity") {
      $source = "https://antigravity.google/cli/install.ps1"
      Confirm-Install "Google Antigravity CLI" $source
      $download = Join-Path ([IO.Path]::GetTempPath()) "nerve-antigravity-install.ps1"
      Invoke-WebRequest -UseBasicParsing -Uri $source -OutFile $download
      & powershell.exe -NoProfile -ExecutionPolicy Bypass -File $download
      if ($LASTEXITCODE -ne 0) { throw "ANTIGRAVITY_INSTALL_FAILED" }
      Write-Status "installed" "Google Antigravity is installed. Use Sign In next."
    } elseif ($AppConnector -eq "claude") {
      Confirm-Install "Claude Code" "npm package @anthropic-ai/claude-code"
      $npm = Require-Command "npm"
      & $npm install -g '@anthropic-ai/claude-code'
      if ($LASTEXITCODE -ne 0) { throw "CLAUDE_INSTALL_FAILED" }
      Write-Status "installed" "Claude is installed. Use Sign In next."
    } elseif ($AppConnector -eq "grok") {
      Confirm-Install "Grok Build" "npm package @xai-official/grok"
      $npm = Require-Command "npm"
      & $npm install -g '@xai-official/grok'
      if ($LASTEXITCODE -ne 0) { throw "GROK_INSTALL_FAILED" }
      Write-Status "installed" "Grok is installed. Use Sign In next."
    } else {
      & (Join-Path $runtimeRoot "Configure-Nerve-Custom-App.cmd")
      if ($LASTEXITCODE -ne 0) { throw "CUSTOM_APP_SETUP_FAILED" }
      Write-Status "installed" "The experimental custom connector is configured. Use Test Connection next."
    }
  } elseif ($Operation -eq "signin") {
    if ($AppConnector -eq "codex") {
      $node = Require-Command "node"
      # Use the exact resolver used by the running connector, including desktop bundles.
      $resolver = Join-Path $PSScriptRoot "resolve-codex.js"
      $codex = (& $node $resolver | Out-String).Trim()
      if ($LASTEXITCODE -ne 0 -or -not $codex) { throw "CODEX_NOT_FOUND" }
      & $codex login
    } elseif ($AppConnector -eq "antigravity") {
      $agy = if ($env:LOCALAPPDATA -and (Test-Path -LiteralPath (Join-Path $env:LOCALAPPDATA "agy\bin\agy.exe"))) { Join-Path $env:LOCALAPPDATA "agy\bin\agy.exe" } else { Require-Command "agy" }
      & $agy
    } elseif ($AppConnector -eq "claude") {
      $claude = Resolve-ClaudeExecutable
      & $claude auth login --claudeai
    } elseif ($AppConnector -eq "grok") {
      $grok = Require-Command "grok"
      & $grok login
    } else {
      & (Join-Path $runtimeRoot "Configure-Nerve-Custom-App.cmd")
    }
    if ($LASTEXITCODE -ne 0) { throw "APP_SIGNIN_FAILED" }
    Write-Status "signin_complete" "Provider sign-in finished. Use Test Connection to verify Nerve can receive a structured response."
  } else {
    $node = Require-Command "node"
    if ($AppConnector -eq "codex" -and -not $Model) {
      $savedPath = Join-Path $configRoot "provider.json"
      if (Test-Path -LiteralPath $savedPath) {
        $prior = Get-Content -LiteralPath $savedPath -Raw | ConvertFrom-Json
        if ($prior.appConnector -eq "codex") { $Model = [string]$prior.model }
      }
    }
    $arguments = @((Join-Path $runtimeRoot "bin\nerve.js"), "app-connector-check", "--app-listener", $AppConnector, "--json")
    if ($AppConnector -eq "codex" -and $Model) { $arguments += @("--model", $Model) }
    if ($AppConnector -eq "custom") { $arguments += @("--app-listener-config", (Join-Path $configRoot "custom-ai-app.json")) }
    $savedErrorPreference = $ErrorActionPreference
    $ErrorActionPreference = "Continue"
    $output = & $node @arguments 2>&1
    $testExitCode = $LASTEXITCODE
    $ErrorActionPreference = $savedErrorPreference
    if ($testExitCode -ne 0) {
      $failureText = ($output | Out-String)
      if ($failureText -match "APP_LISTENER_START_FAILED|could not start|ENOENT") { throw "APP_LISTENER_START_FAILED" }
      if ($failureText -match "not signed in|LOGIN_REQUIRED|SIGNIN_REQUIRED") { throw "APP_SIGNIN_REQUIRED" }
      throw "APP_CONNECTION_TEST_FAILED"
    }
    $report = ($output | Out-String).Trim() | ConvertFrom-Json
    if (-not $report.connected) { throw "APP_CONNECTION_TEST_FAILED" }
    if ($SaveAfterTest) {
      if (-not $Campaign -or -not $FantasyGroundsData) { throw "SETUP_CAMPAIGN_REQUIRED" }
      Write-Status "working" "Connection passed. Saving the selected AI app..."
      & (Join-Path $PSScriptRoot "configure-provider.ps1") -Provider connector -AppConnector $AppConnector -Model $Model -Campaign $Campaign -FantasyGroundsData $FantasyGroundsData -ConfigRoot $configRoot -GuardedActions $GuardedActions -ConnectionCheck skip -VerifiedConnection -NoPause
      if ($LASTEXITCODE -ne 0) { throw "APP_SAVE_FAILED" }
      $saved = Get-Content -Raw -LiteralPath (Join-Path $configRoot "provider.json") | ConvertFrom-Json
      if ($saved.appConnector -ne $AppConnector -or -not $saved.connectionVerified) { throw "APP_SAVE_NOT_CONFIRMED" }
    }
    Write-Status "ready" "$($report.label) answered Nerve's structured connection test successfully."
  }
} catch {
  $code = if ($_.Exception.Message -match '^[A-Z0-9_]+$') { $_.Exception.Message } else { "APP_CONNECTOR_OPERATION_FAILED" }
  Write-Status "failed" "Nerve could not complete $Operation for $AppConnector." $code
  Write-Host "Nerve setup could not finish: $code" -ForegroundColor Red
  if (-not $NoPause) { Read-Host "Press Enter to close" | Out-Null }
  exit 1
}

if (-not $NoPause -and $Operation -ne "signin") { Read-Host "Press Enter to close" | Out-Null }
