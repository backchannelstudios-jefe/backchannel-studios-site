[CmdletBinding()]
param(
  [Parameter(ValueFromRemainingArguments = $true)]
  [string[]]$NerveArguments
)

$ErrorActionPreference = "Stop"
$repositoryRoot = Split-Path -Parent $PSScriptRoot
$entryPoint = Join-Path $repositoryRoot "bin\nerve.js"
$nodeCommand = Get-Command node -ErrorAction Stop

& $nodeCommand.Source $entryPoint @NerveArguments
exit $LASTEXITCODE
