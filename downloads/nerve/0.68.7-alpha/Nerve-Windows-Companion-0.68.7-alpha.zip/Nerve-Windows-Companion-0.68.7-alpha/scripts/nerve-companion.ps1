[CmdletBinding()]
param(
  [string]$Campaign,
  [string]$FantasyGroundsData,
  [string]$ConfigRoot
)

$ErrorActionPreference = "Stop"
$runtimeRoot = Split-Path -Parent $PSScriptRoot
$entryPoint = Join-Path $runtimeRoot "bin\nerve.js"
$configRoot = if ($ConfigRoot) { [IO.Path]::GetFullPath($ConfigRoot) } elseif ($env:LOCALAPPDATA) { Join-Path $env:LOCALAPPDATA "Nerve\Config" } else { Join-Path $env:USERPROFILE "Documents\Nerve\Config" }
$installPath = Join-Path $configRoot "installation.json"

function Read-JsonFile([string]$Path) {
  if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) { return $null }
  $text = (Get-Content -Raw -LiteralPath $Path).Trim()
  if ($text.Length -gt 0 -and $text[0] -eq [char]0xFEFF) { $text = $text.Substring(1).Trim() }
  if (-not $text) { return $null }
  return $text | ConvertFrom-Json
}

function Show-CompanionError([string]$Message) {
  Add-Type -AssemblyName System.Windows.Forms
  [Windows.Forms.MessageBox]::Show($Message, "Nerve AI Companion", "OK", "Error") | Out-Null
}

try {
  if ((-not $Campaign -or -not $FantasyGroundsData) -and (Test-Path -LiteralPath $installPath)) {
    $installation = Read-JsonFile $installPath
    if (-not $Campaign) { $Campaign = [string]$installation.campaign }
    if (-not $FantasyGroundsData) { $FantasyGroundsData = [string]$installation.fantasyGroundsData }
  }
  if (-not $Campaign -or -not $FantasyGroundsData) { throw "Nerve could not identify the active Fantasy Grounds campaign. Run Install-Nerve once." }
  $node = Get-Command node -ErrorAction SilentlyContinue
  if (-not $node) { throw "Node.js was not found. Run Install-Nerve again." }

  $prepareOutput = @(& $node.Source $entryPoint companion-prepare --campaign $Campaign --fgu-data $FantasyGroundsData --json 2>&1)
  if ($LASTEXITCODE -ne 0) { throw (($prepareOutput | ForEach-Object { "$_" }) -join [Environment]::NewLine) }
  $handoff = (($prepareOutput | ForEach-Object { "$_" }) -join [Environment]::NewLine) | ConvertFrom-Json

  Add-Type -AssemblyName System.Windows.Forms
  Add-Type -AssemblyName System.Drawing
  [Windows.Forms.Application]::EnableVisualStyles()

  $form = New-Object Windows.Forms.Form
  $form.Text = "Nerve AI Companion"
  $form.Size = New-Object Drawing.Size(760, 650)
  $form.MinimumSize = New-Object Drawing.Size(680, 560)
  $form.StartPosition = "CenterScreen"
  $form.TopMost = $true
  $form.Font = New-Object Drawing.Font("Segoe UI", 10)

  $title = New-Object Windows.Forms.Label
  $title.Text = "Call Nerve with the AI app you already use"
  $title.Font = New-Object Drawing.Font("Segoe UI Semibold", 15)
  $title.AutoSize = $true
  $title.Location = New-Object Drawing.Point(20, 18)
  $form.Controls.Add($title)

  $intro = New-Object Windows.Forms.Label
  $intro.Text = "No API key is needed. Nerve prepares a limited snapshot of the current scene. You decide when to copy it to your AI app."
  $intro.Location = New-Object Drawing.Point(22, 55)
  $intro.Size = New-Object Drawing.Size(700, 48)
  $form.Controls.Add($intro)

  $providerLabel = New-Object Windows.Forms.Label
  $providerLabel.Text = "AI app"
  $providerLabel.Location = New-Object Drawing.Point(22, 110)
  $providerLabel.AutoSize = $true
  $form.Controls.Add($providerLabel)

  $provider = New-Object Windows.Forms.ComboBox
  $provider.DropDownStyle = "DropDownList"
  $provider.Location = New-Object Drawing.Point(92, 106)
  $provider.Size = New-Object Drawing.Size(220, 28)
  [void]$provider.Items.Add("ChatGPT")
  [void]$provider.Items.Add("Claude")
  [void]$provider.Items.Add("Gemini")
  [void]$provider.Items.Add("Grok")
  [void]$provider.Items.Add("Codex or another AI app")
  $provider.SelectedIndex = 0
  $form.Controls.Add($provider)

  $promptInfo = New-Object Windows.Forms.Label
  $promptInfo.Text = "Prepared context: about $($handoff.approximatePromptTokens) tokens. It expires after 30 minutes."
  $promptInfo.Location = New-Object Drawing.Point(330, 110)
  $promptInfo.Size = New-Object Drawing.Size(390, 28)
  $form.Controls.Add($promptInfo)

  $copyButton = New-Object Windows.Forms.Button
  $copyButton.Text = "1. Copy Prompt + Open AI"
  $copyButton.Location = New-Object Drawing.Point(22, 150)
  $copyButton.Size = New-Object Drawing.Size(300, 38)
  $form.Controls.Add($copyButton)

  $responseLabel = New-Object Windows.Forms.Label
  $responseLabel.Text = "After the AI answers, copy its entire response and paste it here:"
  $responseLabel.Location = New-Object Drawing.Point(22, 207)
  $responseLabel.Size = New-Object Drawing.Size(700, 26)
  $form.Controls.Add($responseLabel)

  $responseBox = New-Object Windows.Forms.TextBox
  $responseBox.Multiline = $true
  $responseBox.ScrollBars = "Vertical"
  $responseBox.AcceptsReturn = $true
  $responseBox.Location = New-Object Drawing.Point(22, 238)
  $responseBox.Size = New-Object Drawing.Size(700, 250)
  $responseBox.Anchor = "Top,Bottom,Left,Right"
  $form.Controls.Add($responseBox)

  $pasteButton = New-Object Windows.Forms.Button
  $pasteButton.Text = "2. Paste AI Response"
  $pasteButton.Location = New-Object Drawing.Point(22, 503)
  $pasteButton.Size = New-Object Drawing.Size(220, 38)
  $pasteButton.Anchor = "Bottom,Left"
  $form.Controls.Add($pasteButton)

  $sendButton = New-Object Windows.Forms.Button
  $sendButton.Text = "3. Send to Fantasy Grounds"
  $sendButton.Location = New-Object Drawing.Point(252, 503)
  $sendButton.Size = New-Object Drawing.Size(260, 38)
  $sendButton.Anchor = "Bottom,Left"
  $form.Controls.Add($sendButton)

  $closeButton = New-Object Windows.Forms.Button
  $closeButton.Text = "Close"
  $closeButton.Location = New-Object Drawing.Point(602, 503)
  $closeButton.Size = New-Object Drawing.Size(120, 38)
  $closeButton.Anchor = "Bottom,Right"
  $form.Controls.Add($closeButton)

  $status = New-Object Windows.Forms.Label
  $status.Text = "Ready. Step 1 copies only when you click it."
  $status.Location = New-Object Drawing.Point(22, 556)
  $status.Size = New-Object Drawing.Size(700, 42)
  $status.Anchor = "Bottom,Left,Right"
  $form.Controls.Add($status)

  $copyButton.Add_Click({
    try {
      [Windows.Forms.Clipboard]::SetText([string]$handoff.prompt)
      $urls = @{
        "ChatGPT" = "https://chatgpt.com/"
        "Claude" = "https://claude.ai/new"
        "Gemini" = "https://gemini.google.com/app"
        "Grok" = "https://grok.com/"
      }
      $selected = [string]$provider.SelectedItem
      if ($urls.ContainsKey($selected)) { Start-Process $urls[$selected] }
      $status.Text = "Prompt copied. Paste it into $selected, send it, then copy the AI's full response."
    } catch { Show-CompanionError $_.Exception.Message }
  })

  $pasteButton.Add_Click({
    try {
      if (-not [Windows.Forms.Clipboard]::ContainsText()) { throw "The clipboard does not contain text yet." }
      $responseBox.Text = [Windows.Forms.Clipboard]::GetText()
      $status.Text = "Response pasted. Review it if you wish, then send it to Fantasy Grounds."
    } catch { Show-CompanionError $_.Exception.Message }
  })

  $sendButton.Add_Click({
    $responsePath = $null
    try {
      if ([string]::IsNullOrWhiteSpace($responseBox.Text)) { throw "Paste the AI response before sending it." }
      New-Item -ItemType Directory -Path $configRoot -Force | Out-Null
      $safeCue = ([string]$handoff.cue.cueId) -replace '[^A-Za-z0-9._-]', '_'
      $responsePath = Join-Path $configRoot "companion-response-$safeCue.json"
      [IO.File]::WriteAllText($responsePath, $responseBox.Text, (New-Object Text.UTF8Encoding($false)))
      $sendButton.Enabled = $false
      $status.Text = "Validating and sending through Nerve Guard..."
      $form.Refresh()
      $submitOutput = @(& $node.Source $entryPoint companion-submit --campaign $Campaign --fgu-data $FantasyGroundsData --cue-id ([string]$handoff.cue.cueId) --response-file $responsePath --expose-writes --allow-writes --json 2>&1)
      if ($LASTEXITCODE -ne 0) { throw (($submitOutput | ForEach-Object { "$_" }) -join [Environment]::NewLine) }
      $result = (($submitOutput | ForEach-Object { "$_" }) -join [Environment]::NewLine) | ConvertFrom-Json
      $message = if ($result.status -eq "action_queued") { "The response is safely queued. Return to Fantasy Grounds and click Check for Action once. Flow Mode will process routine actions; guarded actions still need GM approval." } else { "The AI response was accepted. Return to Fantasy Grounds." }
      [Windows.Forms.MessageBox]::Show($message, "Nerve AI Companion", "OK", "Information") | Out-Null
      $form.Close()
    } catch {
      $status.Text = "The response was not sent. Correct it or ask the AI to return only the requested JSON."
      Show-CompanionError $_.Exception.Message
      $sendButton.Enabled = $true
    } finally {
      if ($responsePath) { Remove-Item -Force -LiteralPath $responsePath -ErrorAction SilentlyContinue }
    }
  })

  $closeButton.Add_Click({ $form.Close() })
  $form.AcceptButton = $sendButton
  $form.CancelButton = $closeButton
  [void]$form.ShowDialog()
} catch {
  Show-CompanionError $_.Exception.Message
  exit 1
}

exit 0
