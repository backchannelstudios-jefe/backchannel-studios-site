[CmdletBinding()]
param([string]$ConfigRoot, [switch]$NoPause)

$ErrorActionPreference = "Stop"
$configRoot = if ($ConfigRoot) { [IO.Path]::GetFullPath($ConfigRoot) } elseif ($env:LOCALAPPDATA) { Join-Path $env:LOCALAPPDATA "Nerve\Config" } else { Join-Path $env:USERPROFILE "Documents\Nerve\Config" }
$configPath = Join-Path $configRoot "custom-ai-app.json"

function Pause-Nerve([string]$Text) { if (-not $NoPause) { Read-Host $Text | Out-Null } }

try {
  Write-Host "NERVE CUSTOM AI APP — EXPERIMENTAL" -ForegroundColor Yellow
  Write-Host "This option runs a program you choose. Nerve will not install it, update it, supply credentials, or use a command shell."
  Write-Host "The program receives the private Nerve prompt on standard input and must return one JSON decision on standard output."
  Write-Host "Use only software you trust. Support and risk for third-party programs remain with you."
  Write-Host ""
  $ack = (Read-Host "Type I UNDERSTAND to continue").Trim()
  if ($ack -ne "I UNDERSTAND") { throw "Risk acknowledgement was not accepted." }
  $executable = [IO.Path]::GetFullPath((Read-Host "Absolute path to the AI app executable").Trim().Trim('"'))
  if (-not [IO.Path]::IsPathRooted($executable) -or -not (Test-Path -LiteralPath $executable -PathType Leaf)) { throw "The executable path was not found." }
  $argumentsText = (Read-Host 'Optional arguments as a JSON array, for example ["--json"] (press Enter for none)').Trim()
  $arguments = if ($argumentsText) { @($argumentsText | ConvertFrom-Json) } else { @() }
  if (@($arguments | Where-Object { $_ -isnot [string] }).Count -gt 0 -or $arguments.Count -gt 32) { throw "Arguments must be a JSON array containing no more than 32 strings." }
  $timeoutText = (Read-Host "Timeout seconds [300]").Trim()
  $timeoutSeconds = if ($timeoutText) { [int]$timeoutText } else { 300 }
  if ($timeoutSeconds -lt 10 -or $timeoutSeconds -gt 600) { throw "Timeout must be from 10 to 600 seconds." }
  $config = [ordered]@{
    schemaVersion = "0.1"; acknowledgedRisk = $true; executable = $executable; args = $arguments
    inputMode = "stdin"; outputMode = "json"; timeoutSeconds = $timeoutSeconds
    configuredAt = (Get-Date).ToUniversalTime().ToString("o")
  }
  New-Item -ItemType Directory -Path $configRoot -Force | Out-Null
  $config | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath $configPath -Encoding UTF8
  Write-Host "Custom AI App configuration saved." -ForegroundColor Green
  Write-Host "Return to Nerve AI Setup and select Custom AI App — Experimental."
} catch {
  Write-Host "Custom AI App setup did not finish: $($_.Exception.Message)" -ForegroundColor Red
  Pause-Nerve "Press Enter to close"
  exit 1
}
Pause-Nerve "Press Enter to close"
