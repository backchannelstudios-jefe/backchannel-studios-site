@echo off
setlocal
title Stop Nerve
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0stop-nerve.ps1" %*
exit /b %ERRORLEVEL%

