@echo off
setlocal
title Start Nerve
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0start-nerve.ps1" %*
exit /b %ERRORLEVEL%

