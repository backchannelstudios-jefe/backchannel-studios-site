from pathlib import Path

from docx import Document
from docx.enum.section import WD_SECTION
from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Inches, Pt, RGBColor


ROOT = Path(__file__).resolve().parents[1]
OUTPUT = ROOT / "dist" / "Nerve_Clean_Install_Test_Guide.docx"

NAVY = "0B2545"
BLUE = "2E74B5"
DARK_BLUE = "1F4D78"
PALE_BLUE = "E8EEF5"
PALE_GOLD = "FFF4D6"
GOLD = "7A5A00"
GRAY = "5E6872"
LIGHT_GRAY = "F2F4F7"
WHITE = "FFFFFF"
BLACK = "000000"


def set_cell_shading(cell, fill):
    tc_pr = cell._tc.get_or_add_tcPr()
    shd = tc_pr.find(qn("w:shd"))
    if shd is None:
        shd = OxmlElement("w:shd")
        tc_pr.append(shd)
    shd.set(qn("w:fill"), fill)


def set_cell_margins(cell, top=100, start=120, bottom=100, end=120):
    tc_pr = cell._tc.get_or_add_tcPr()
    tc_mar = tc_pr.first_child_found_in("w:tcMar")
    if tc_mar is None:
        tc_mar = OxmlElement("w:tcMar")
        tc_pr.append(tc_mar)
    for tag, value in (("top", top), ("start", start), ("bottom", bottom), ("end", end)):
        node = tc_mar.find(qn(f"w:{tag}"))
        if node is None:
            node = OxmlElement(f"w:{tag}")
            tc_mar.append(node)
        node.set(qn("w:w"), str(value))
        node.set(qn("w:type"), "dxa")


def set_table_geometry(table, widths_dxa, indent_dxa=120):
    table.autofit = False
    tbl_pr = table._tbl.tblPr
    tbl_w = tbl_pr.find(qn("w:tblW"))
    if tbl_w is None:
        tbl_w = OxmlElement("w:tblW")
        tbl_pr.append(tbl_w)
    tbl_w.set(qn("w:w"), str(sum(widths_dxa)))
    tbl_w.set(qn("w:type"), "dxa")
    tbl_ind = tbl_pr.find(qn("w:tblInd"))
    if tbl_ind is None:
        tbl_ind = OxmlElement("w:tblInd")
        tbl_pr.append(tbl_ind)
    tbl_ind.set(qn("w:w"), str(indent_dxa))
    tbl_ind.set(qn("w:type"), "dxa")
    grid = table._tbl.tblGrid
    for child in list(grid):
        grid.remove(child)
    for width in widths_dxa:
        col = OxmlElement("w:gridCol")
        col.set(qn("w:w"), str(width))
        grid.append(col)
    for row in table.rows:
        for idx, cell in enumerate(row.cells):
            width = widths_dxa[idx]
            tc_w = cell._tc.get_or_add_tcPr().find(qn("w:tcW"))
            if tc_w is None:
                tc_w = OxmlElement("w:tcW")
                cell._tc.get_or_add_tcPr().append(tc_w)
            tc_w.set(qn("w:w"), str(width))
            tc_w.set(qn("w:type"), "dxa")
            set_cell_margins(cell)


def set_run(run, font="Calibri", size=11, color=BLACK, bold=False, italic=False):
    run.font.name = font
    run._element.get_or_add_rPr().rFonts.set(qn("w:ascii"), font)
    run._element.get_or_add_rPr().rFonts.set(qn("w:hAnsi"), font)
    run.font.size = Pt(size)
    run.font.color.rgb = RGBColor.from_string(color)
    run.bold = bold
    run.italic = italic
    return run


def add_page_field(paragraph):
    run = paragraph.add_run()
    fld_char = OxmlElement("w:fldChar")
    fld_char.set(qn("w:fldCharType"), "begin")
    instr = OxmlElement("w:instrText")
    instr.set(qn("xml:space"), "preserve")
    instr.text = " PAGE "
    sep = OxmlElement("w:fldChar")
    sep.set(qn("w:fldCharType"), "separate")
    text = OxmlElement("w:t")
    text.text = "1"
    end = OxmlElement("w:fldChar")
    end.set(qn("w:fldCharType"), "end")
    for node in (fld_char, instr, sep, text, end):
        run._r.append(node)
    set_run(run, size=9, color=GRAY)


def add_footer(section):
    p = section.footer.paragraphs[0]
    p.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    p.paragraph_format.space_before = Pt(0)
    p.paragraph_format.space_after = Pt(0)
    set_run(p.add_run("Nerve clean-install test  |  Page "), size=9, color=GRAY)
    add_page_field(p)


def add_header(section):
    p = section.header.paragraphs[0]
    p.alignment = WD_ALIGN_PARAGRAPH.LEFT
    p.paragraph_format.space_after = Pt(0)
    set_run(p.add_run("NERVE  /  DEVELOPER PREVIEW"), size=9, color=GRAY, bold=True)


def add_heading(doc, text, level=1):
    p = doc.add_paragraph(text, style=f"Heading {level}")
    p.paragraph_format.keep_with_next = True
    return p


def add_body(doc, text, bold_lead=None):
    p = doc.add_paragraph()
    if bold_lead and text.startswith(bold_lead):
        set_run(p.add_run(bold_lead), bold=True)
        set_run(p.add_run(text[len(bold_lead):]))
    else:
        set_run(p.add_run(text))
    return p


def add_bullet(doc, text):
    p = doc.add_paragraph(style="List Bullet")
    p.paragraph_format.left_indent = Inches(0.375)
    p.paragraph_format.first_line_indent = Inches(-0.188)
    p.paragraph_format.space_after = Pt(4)
    p.paragraph_format.line_spacing = 1.25
    set_run(p.add_run(text))
    return p


def add_number(doc, title, detail):
    p = doc.add_paragraph(style="List Number")
    p.paragraph_format.left_indent = Inches(0.375)
    p.paragraph_format.first_line_indent = Inches(-0.188)
    p.paragraph_format.space_after = Pt(4)
    p.paragraph_format.line_spacing = 1.25
    set_run(p.add_run(title + " "), bold=True)
    set_run(p.add_run(detail))
    return p


def add_code(doc, command):
    p = doc.add_paragraph(style="Code Block")
    p.paragraph_format.keep_together = True
    set_run(p.add_run(command), font="Consolas", size=9, color=NAVY)
    return p


def add_callout(doc, label, text, fill=PALE_BLUE, label_color=NAVY):
    p = doc.add_paragraph()
    p.paragraph_format.left_indent = Inches(0.08)
    p.paragraph_format.right_indent = Inches(0.08)
    p.paragraph_format.space_before = Pt(4)
    p.paragraph_format.space_after = Pt(9)
    p.paragraph_format.line_spacing = 1.15
    p_pr = p._p.get_or_add_pPr()
    shd = OxmlElement("w:shd")
    shd.set(qn("w:fill"), fill)
    p_pr.append(shd)
    borders = OxmlElement("w:pBdr")
    left = OxmlElement("w:left")
    left.set(qn("w:val"), "single")
    left.set(qn("w:sz"), "16")
    left.set(qn("w:space"), "8")
    left.set(qn("w:color"), label_color)
    borders.append(left)
    p_pr.append(borders)
    set_run(p.add_run(label + "  "), color=label_color, bold=True)
    set_run(p.add_run(text), color=BLACK)


def add_label_value(doc, label, value):
    p = doc.add_paragraph()
    p.paragraph_format.space_after = Pt(4)
    set_run(p.add_run(label + ": "), bold=True, color=DARK_BLUE)
    set_run(p.add_run(value))


def configure_styles(doc):
    styles = doc.styles
    normal = styles["Normal"]
    normal.font.name = "Calibri"
    normal._element.rPr.rFonts.set(qn("w:ascii"), "Calibri")
    normal._element.rPr.rFonts.set(qn("w:hAnsi"), "Calibri")
    normal.font.size = Pt(11)
    normal.paragraph_format.space_before = Pt(0)
    normal.paragraph_format.space_after = Pt(6)
    normal.paragraph_format.line_spacing = 1.25

    heading_tokens = {
        "Heading 1": (16, BLUE, 18, 10),
        "Heading 2": (13, BLUE, 14, 7),
        "Heading 3": (12, DARK_BLUE, 10, 5),
    }
    for name, (size, color, before, after) in heading_tokens.items():
        style = styles[name]
        style.font.name = "Calibri"
        style._element.rPr.rFonts.set(qn("w:ascii"), "Calibri")
        style._element.rPr.rFonts.set(qn("w:hAnsi"), "Calibri")
        style.font.size = Pt(size)
        style.font.bold = True
        style.font.color.rgb = RGBColor.from_string(color)
        style.paragraph_format.space_before = Pt(before)
        style.paragraph_format.space_after = Pt(after)
        style.paragraph_format.keep_with_next = True

    for name in ("List Bullet", "List Number"):
        style = styles[name]
        style.font.name = "Calibri"
        style._element.rPr.rFonts.set(qn("w:ascii"), "Calibri")
        style._element.rPr.rFonts.set(qn("w:hAnsi"), "Calibri")
        style.font.size = Pt(11)

    code = styles.add_style("Code Block", 1)
    code.font.name = "Consolas"
    code._element.rPr.rFonts.set(qn("w:ascii"), "Consolas")
    code._element.rPr.rFonts.set(qn("w:hAnsi"), "Consolas")
    code.font.size = Pt(9)
    code.paragraph_format.left_indent = Inches(0.18)
    code.paragraph_format.right_indent = Inches(0.12)
    code.paragraph_format.space_before = Pt(3)
    code.paragraph_format.space_after = Pt(7)
    code.paragraph_format.line_spacing = 1.0
    p_pr = code.element.get_or_add_pPr()
    shd = OxmlElement("w:shd")
    shd.set(qn("w:fill"), LIGHT_GRAY)
    p_pr.append(shd)
    borders = OxmlElement("w:pBdr")
    left = OxmlElement("w:left")
    left.set(qn("w:val"), "single")
    left.set(qn("w:sz"), "12")
    left.set(qn("w:space"), "6")
    left.set(qn("w:color"), BLUE)
    borders.append(left)
    p_pr.append(borders)


def build():
    doc = Document()
    doc.core_properties.title = "Nerve Clean Install Test Guide"
    doc.core_properties.subject = "Developer preview installation and smoke test"
    doc.core_properties.author = "Nerve Project"
    doc.core_properties.keywords = "Nerve, Fantasy Grounds, clean install, test"

    section = doc.sections[0]
    section.page_width = Inches(8.5)
    section.page_height = Inches(11)
    section.top_margin = Inches(1)
    section.right_margin = Inches(1)
    section.bottom_margin = Inches(1)
    section.left_margin = Inches(1)
    section.header_distance = Inches(0.492)
    section.footer_distance = Inches(0.492)
    add_header(section)
    add_footer(section)
    configure_styles(doc)

    # Editorial-cover opening, scaled for a practical field guide.
    spacer = doc.add_paragraph()
    spacer.paragraph_format.space_after = Pt(54)
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_after = Pt(14)
    set_run(p.add_run("CLEAN INSTALL + SMOKE TEST"), size=10, color=GOLD, bold=True)
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_after = Pt(8)
    set_run(p.add_run("Nerve Developer Preview"), size=28, color=NAVY, bold=True)
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_after = Pt(28)
    set_run(p.add_run("Windows + Fantasy Grounds Unity"), size=15, color=DARK_BLUE)
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_after = Pt(48)
    set_run(p.add_run("Release-readiness build  |  August 20, 2026"), size=10.5, color=GRAY, italic=True)

    add_callout(
        doc,
        "GOAL",
        "Prove that a fresh Windows workstation can verify the package, install the Fantasy Grounds extension, discover a campaign, pass local diagnostics, and expose a usable Nerve configuration without relying on the development computer.",
    )
    add_heading(doc, "Files to transfer", 2)
    add_bullet(doc, "nerve-developer-preview-release-readiness.zip")
    add_bullet(doc, "nerve-developer-preview-release-readiness.zip.sha256")
    add_bullet(doc, "Nerve_Clean_Install_Test_Guide.docx (this guide)")
    add_callout(
        doc,
        "SAFE DEFAULT",
        "Use the built-in fake provider for this clean-install test. Setup and controller preflight make no AI-provider network request and spend no model credits.",
        fill=PALE_GOLD,
        label_color=GOLD,
    )

    doc.add_page_break()
    add_heading(doc, "1. Prepare the clean workstation", 1)
    add_heading(doc, "Prerequisites", 2)
    add_bullet(doc, "Windows 10 or Windows 11.")
    add_bullet(doc, "Fantasy Grounds Unity installed and able to open a local campaign.")
    add_bullet(doc, "Node.js 22 or newer. No npm package installation is required.")
    add_bullet(doc, "The ZIP, checksum sidecar, and this guide downloaded into the same folder.")

    add_heading(doc, "Confirm Node.js", 2)
    add_body(doc, "Open PowerShell and run:")
    add_code(doc, "node --version")
    add_body(doc, "Expected: a version beginning with v22 or higher. If Windows cannot find node, install a current Node.js release, close PowerShell, and open a new PowerShell window.")

    add_heading(doc, "Verify the downloaded ZIP", 2)
    add_body(doc, "In PowerShell, change to the download folder and calculate the archive hash:")
    add_code(doc, 'Set-Location "C:\\Path\\To\\Your\\Download\\Folder"')
    add_code(doc, 'Get-FileHash ".\\nerve-developer-preview-release-readiness.zip" -Algorithm SHA256')
    add_label_value(doc, "Expected SHA-256", "02f0f0c807f186293003b6c20b2625f0743b16739cbc97800e2034d8e6d0e23a")
    add_callout(doc, "STOP IF DIFFERENT", "Do not run an archive whose hash differs from the expected value. Download or copy both package files again.", fill=PALE_GOLD, label_color=GOLD)

    add_heading(doc, "Extract into a new folder", 2)
    add_code(doc, 'Expand-Archive -LiteralPath ".\\nerve-developer-preview-release-readiness.zip" -DestinationPath ".\\NerveCleanTest"')
    add_code(doc, 'Set-Location ".\\NerveCleanTest\\nerve-developer-preview-release-readiness"')
    add_body(doc, "Do not merge this folder with an older Nerve checkout. A clean directory is part of the test.")

    doc.add_page_break()
    add_heading(doc, "2. Verify and install Nerve", 1)
    add_heading(doc, "Run the package self-verifier", 2)
    add_code(doc, 'node .\\bin\\nerve.js package-verify --input "..\\..\\nerve-developer-preview-release-readiness.zip"')
    add_body(doc, "Expected: verification succeeds for the ZIP and its adjacent .sha256 file. The verifier checks safe paths, duplicate entries, required files, the manifest, sizes, and SHA-256 hashes.")

    add_heading(doc, "Run first-stage Windows setup", 2)
    add_code(doc, 'powershell -ExecutionPolicy Bypass -File .\\scripts\\setup-windows.ps1')
    add_body(doc, "This command checks Node, finds the standard Fantasy Grounds data folder, installs or refreshes the Nerve Adapter extension, lists campaigns, and reports provider readiness. It does not contact an AI provider.")

    add_heading(doc, "Enable Nerve in Fantasy Grounds", 2)
    add_number(doc, "Start Fantasy Grounds Unity.", "Open the campaign selection screen.")
    add_number(doc, "Choose a test campaign.", "Prefer a disposable or copied campaign rather than a valuable live campaign.")
    add_number(doc, "Enable Nerve Adapter.", "Select it in the campaign's Extensions list before loading.")
    add_number(doc, "Load the campaign.", "Wait for the chat window to report that the Nerve Adapter loaded.")
    add_number(doc, "Confirm the sidebar.", "A NERVE category and NERVE CONTROL entry should be visible.")

    add_heading(doc, "Run campaign-aware setup", 2)
    add_body(doc, "Close or leave Fantasy Grounds open, return to PowerShell in the extracted Nerve folder, and replace the placeholder with the campaign's exact name:")
    add_code(doc, 'powershell -ExecutionPolicy Bypass -File .\\scripts\\setup-windows.ps1 -Campaign "Your Campaign" -SkipExtensionInstall')
    add_body(doc, "Expected: campaign doctor passes, the snapshot and Pulse stream are readable, and the fake-provider controller preflight passes without a network request.")

    doc.add_page_break()
    add_heading(doc, "3. Perform the smoke test", 1)
    add_heading(doc, "Command-line checks", 2)
    add_code(doc, '.\\scripts\\nerve.ps1 playtest-readiness --campaign "Your Campaign"')
    add_code(doc, '.\\scripts\\nerve.ps1 map-report --campaign "Your Campaign"')
    add_code(doc, '.\\scripts\\nerve.ps1 continuity-report --campaign "Your Campaign"')
    add_body(doc, "The first command should summarize readiness. Map and continuity reports may contain limited data in a new campaign, but they should complete without a crash.")

    add_heading(doc, "Fantasy Grounds checks", 2)
    add_number(doc, "Open Nerve Control.", "Confirm the panel opens and its labels are readable.")
    add_number(doc, "Inspect session state.", "Start Tracking should be available when no session is active. If a session is already active, End Session and begin a fresh tracked test.")
    add_number(doc, "Start Tracking.", "Confirm the panel reports an active session and the current scene/map when available.")
    add_number(doc, "Test Hold and Resume.", "Hold Nerve should revoke session grants; Resume Nerve should restore the ordinary approval policy.")
    add_number(doc, "Check the Action Inbox.", "Use the amber NERVE chat control, Check for Action, or /nerve. An empty inbox is acceptable when no action is pending.")
    add_number(doc, "Inspect Flow Mode and Entity Proxy.", "Confirm their controls do not overlap and that their current state is clearly displayed. Do not enable Entity Proxy unless you intend to test character or combatant actions.")
    add_number(doc, "Inspect the current map.", "If a map is open, confirm Nerve identifies the correct current map and does not treat distant enemies as adjacent to the party.")
    add_number(doc, "End Session.", "Confirm the session ends, grants are revoked, and a continuity checkpoint remains available for the next session briefing.")

    add_callout(
        doc,
        "APPROVAL MODEL",
        "Flow Mode may automate narration, bounded player prompts and native roll requests, Entity Proxy actions, exact-roster encounter start, and stale-checked turn advancement. Players may decline or time out. Sensitive state changes remain individually approved. Hold, End Session, reload, or Revoke Session Grants returns the policy to manual.",
    )

    add_heading(doc, "Generate an AI-host configuration", 2)
    add_code(doc, '.\\scripts\\nerve.ps1 config --campaign "Your Campaign" --expose-writes --allow-writes')
    add_body(doc, "Save the printed configuration for the later Codex, Claude Code, Gemini CLI, or Grok CLI compatibility test. Generating it does not start an AI model or spend credits.")

    doc.add_page_break()
    add_heading(doc, "4. Record the result", 1)
    add_heading(doc, "Pass criteria", 2)
    add_bullet(doc, "The downloaded ZIP hash matches the expected SHA-256 value.")
    add_bullet(doc, "The package self-verifier passes.")
    add_bullet(doc, "Windows setup installs the extension and lists campaigns.")
    add_bullet(doc, "Fantasy Grounds reports Nerve Adapter loaded and shows Nerve Control.")
    add_bullet(doc, "Campaign doctor and zero-network controller preflight pass.")
    add_bullet(doc, "Nerve Control can start, hold, resume, and end a tracked session.")
    add_bullet(doc, "Map and continuity reports complete without errors.")
    add_bullet(doc, "An AI-host configuration is generated successfully.")

    add_heading(doc, "If anything fails", 2)
    add_body(doc, "Keep the PowerShell window open and copy the full error text. Then create a privacy-reduced diagnostics file:")
    add_code(doc, '.\\scripts\\nerve.ps1 diagnostics --campaign "Your Campaign" --output ".\\nerve-diagnostics.json"')
    add_body(doc, "The diagnostics export excludes campaign prose, event text, character and map names, action arguments, credentials, and API-key values. Review it before sharing anyway.")

    add_heading(doc, "Return this test record", 2)
    add_label_value(doc, "Computer / Windows version", "________________________________________")
    add_label_value(doc, "Node.js version", "________________________________________")
    add_label_value(doc, "Fantasy Grounds version", "________________________________________")
    add_label_value(doc, "Campaign name", "________________________________________")
    add_label_value(doc, "Package verification", "PASS / FAIL")
    add_label_value(doc, "Extension visible and loaded", "PASS / FAIL")
    add_label_value(doc, "Campaign doctor", "PASS / FAIL")
    add_label_value(doc, "Controller preflight", "PASS / FAIL")
    add_label_value(doc, "Nerve Control smoke test", "PASS / FAIL")
    add_label_value(doc, "Unexpected behavior", "________________________________________")
    add_label_value(doc, "Error text / screenshot names", "________________________________________")

    add_callout(
        doc,
        "DO NOT SEND",
        "API keys, private campaign passwords, provider credentials, or an unreviewed Fantasy Grounds campaign folder.",
        fill=PALE_GOLD,
        label_color=GOLD,
    )

    OUTPUT.parent.mkdir(parents=True, exist_ok=True)
    doc.save(OUTPUT)
    print(OUTPUT)


if __name__ == "__main__":
    build()
