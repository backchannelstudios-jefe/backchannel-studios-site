@echo off
setlocal
title Nerve Support Bundle
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0collect-support.ps1" %*
exit /b %ERRORLEVEL%
