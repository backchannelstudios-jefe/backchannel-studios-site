@echo off
setlocal
title Configure Nerve AI
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0configure-provider.ps1" %*
exit /b %ERRORLEVEL%

