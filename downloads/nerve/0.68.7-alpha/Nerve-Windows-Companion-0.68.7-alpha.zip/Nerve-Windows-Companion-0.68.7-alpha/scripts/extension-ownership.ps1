# Shared by installer and supervisor. Inspect manifests without extracting archives.
function Get-NerveExtensionInstall([string]$DataRoot) {
  $directory = Join-Path $DataRoot 'extensions'
  $localManifest = Join-Path $directory 'Nerve\extension.xml'
  $localVersion = $null
  if (Test-Path -LiteralPath $localManifest) {
    $text = Get-Content -LiteralPath $localManifest -Raw
    if ($text -match '<version>([^<]+)</version>') { $localVersion = $Matches[1] }
  }
  Add-Type -AssemblyName System.IO.Compression.FileSystem
  $archives = @()
  foreach ($file in @(Get-ChildItem -LiteralPath $directory -Filter '*.ext' -File -ErrorAction SilentlyContinue)) {
    $zip = $null
    try {
      $zip = [IO.Compression.ZipFile]::OpenRead($file.FullName)
      $entry = $zip.GetEntry('extension.xml')
      if (-not $entry -or $entry.Length -gt 65536) { continue }
      $reader = New-Object IO.StreamReader($entry.Open())
      try { $text = $reader.ReadToEnd() } finally { $reader.Dispose() }
      # Reject DTDs; only inspect Nerve's exact product identity.
      if ($text -match '<!DOCTYPE') { continue }
      [xml]$xml = $text
      if ([string]$xml.root.properties.name -ne 'Nerve Adapter for Fantasy Grounds Unity') { continue }
      $archives += [pscustomobject]@{ path=$file.FullName; version=[string]$xml.root.properties.version }
    } catch { } finally { if ($zip) { $zip.Dispose() } }
  }
  return [pscustomobject]@{ localPresent=(Test-Path -LiteralPath (Join-Path $directory 'Nerve')); localVersion=$localVersion; archives=$archives }
}
function Get-NerveExtensionOwner([string]$RuntimeRoot) {
  $path = Join-Path $RuntimeRoot 'distribution.json'
  if (-not (Test-Path -LiteralPath $path)) { return 'companion' }
  $data = Get-Content -LiteralPath $path -Raw | ConvertFrom-Json
  if ($data.extensionOwner -notin @('forge','companion')) { throw 'Invalid extension ownership in distribution.json' }
  return [string]$data.extensionOwner
}
