@echo off
setlocal
call "%~dp0scripts\Stop-Nerve.cmd" %*
exit /b %ERRORLEVEL%

