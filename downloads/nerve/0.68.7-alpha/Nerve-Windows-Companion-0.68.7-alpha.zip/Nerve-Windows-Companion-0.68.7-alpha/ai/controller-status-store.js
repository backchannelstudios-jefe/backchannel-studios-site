import { mkdir, readFile, unlink, writeFile } from "node:fs/promises";
import { dirname } from "node:path";

export class ControllerStatusStore {
  constructor({ statusPath, stopPath, clock = () => new Date() }) {
    this.statusPath = statusPath;
    this.stopPath = stopPath;
    this.clock = clock;
  }

  async write(status) {
    await mkdir(dirname(this.statusPath), { recursive: true });
    const value = {
      schemaVersion: "0.1",
      ...structuredClone(status),
      updatedAt: this.clock().toISOString()
    };
    await writeFile(this.statusPath, `${JSON.stringify(value, null, 2)}\n`, "utf8");
    return value;
  }

  async read() {
    return readJson(this.statusPath);
  }

  async requestStop({ sessionId, requestedByPid = process.pid }) {
    await mkdir(dirname(this.stopPath), { recursive: true });
    const value = {
      schemaVersion: "0.1",
      sessionId,
      requestedAt: this.clock().toISOString(),
      requestedByPid
    };
    await writeFile(this.stopPath, `${JSON.stringify(value, null, 2)}\n`, "utf8");
    return value;
  }

  async readStopRequest() {
    return readJson(this.stopPath);
  }

  async stopRequested(sessionId) {
    const request = await this.readStopRequest();
    return Boolean(request && request.sessionId === sessionId);
  }

  async clearStopRequest() {
    try {
      await unlink(this.stopPath);
    } catch (error) {
      if (error.code !== "ENOENT") throw error;
    }
  }
}

async function readJson(path) {
  try {
    return JSON.parse(await readFile(path, "utf8"));
  } catch (error) {
    if (error.code === "ENOENT") return null;
    if (error instanceof SyntaxError) throw new Error(`Controller state is invalid JSON: ${path}`);
    throw error;
  }
}

