export async function checkProviderConnection(provider) {
  if (!provider?.generateDecision || typeof provider.id !== "string") {
    throw new TypeError("Provider connection check requires a configured AI provider.");
  }
  const startedAt = Date.now();
  const response = await provider.generateDecision({
    schemaVersion: "0.1", sessionId: "provider-connection-check", sequence: 1, baseline: true,
    state: {
      campaignSummary: { ruleset: "connection-check", inCombat: false },
      sessionOperations: { status: "held" }
    },
    events: [{ sequence: 1, type: "system.connection-check", summary: "Return a hold decision. Do not propose an action." }],
    omittedUnchanged: [], inputBytes: 256, approximateInputTokens: 64
  });
  return {
    schemaVersion: "0.1", provider: provider.id, model: provider.model ?? null,
    connected: true, networkCalled: provider.id !== "fake", decision: response.decision,
    maxOutputTokens: provider.maxOutputTokens ?? 0,
    elapsedMs: Date.now() - startedAt,
    usage: response.usage ?? { inputTokens: 0, cachedInputTokens: 0, outputTokens: 0, reasoningTokens: 0, costMicros: 0 }
  };
}
