import { NerveError } from "../core/errors.js";
import { defineAiProvider } from "./provider-contract.js";
import {
  createProviderInput,
  NERVE_DECISION_SCHEMA,
  NERVE_PROVIDER_INSTRUCTIONS,
  normalizeDecisionEnvelope,
  parseJsonText
} from "./provider-prompt.js";

export function createOllamaAiProvider({
  model,
  fetchImpl = globalThis.fetch,
  endpoint = "http://127.0.0.1:11434/api/chat",
  timeoutMs = 180000,
  maxOutputTokens = 800,
  contextTokens = 16384
} = {}) {
  if (typeof model !== "string" || model.trim().length === 0) {
    throw new NerveError("AI_MODEL_REQUIRED", "Ollama requires an installed local model ID.");
  }
  if (typeof fetchImpl !== "function") throw new NerveError("AI_FETCH_UNAVAILABLE", "This Node runtime does not provide fetch.");
  if (!/^http:\/\/(?:127\.0\.0\.1|localhost):11434\/api\/chat$/.test(endpoint)) {
    throw new NerveError("OLLAMA_ENDPOINT_INVALID", "Ollama must use Nerve's local loopback endpoint.");
  }
  if (!Number.isInteger(maxOutputTokens) || maxOutputTokens <= 0 || maxOutputTokens > 100000) {
    throw new NerveError("AI_OUTPUT_LIMIT_INVALID", "maxOutputTokens must be an integer from 1 to 100000.");
  }
  if (!Number.isInteger(contextTokens) || contextTokens < 4096 || contextTokens > 131072) {
    throw new NerveError("OLLAMA_CONTEXT_INVALID", "Ollama contextTokens must be an integer from 4096 to 131072.");
  }

  return defineAiProvider({
    id: "ollama",
    model,
    maxOutputTokens,
    async generateDecision(packet) {
      let response;
      try {
        response = await fetchImpl(endpoint, {
          method: "POST",
          headers: { "content-type": "application/json" },
          body: JSON.stringify({
            model,
            stream: false,
            keep_alive: "10m",
            format: NERVE_DECISION_SCHEMA,
            messages: [
              { role: "system", content: NERVE_PROVIDER_INSTRUCTIONS },
              { role: "user", content: createProviderInput(packet) }
            ],
            options: { temperature: 0, num_ctx: contextTokens, num_predict: maxOutputTokens }
          }),
          signal: AbortSignal.timeout(timeoutMs)
        });
      } catch (error) {
        throw new NerveError("AI_PROVIDER_UNREACHABLE", `Ollama is not reachable on this computer: ${error.message}`);
      }
      let payload;
      try { payload = await response.json(); } catch { payload = null; }
      if (!response.ok) {
        const message = payload?.error ?? `${response.status} ${response.statusText}`;
        throw new NerveError("AI_PROVIDER_HTTP_ERROR", `Ollama rejected the local request: ${message}`, {
          provider: "ollama", status: response.status
        });
      }
      const text = payload?.message?.content;
      let envelope;
      try { envelope = parseJsonText(text); }
      catch (error) { throw new NerveError("AI_PROVIDER_INVALID_RESPONSE", `Ollama returned invalid decision JSON: ${error.message}`); }
      return {
        ...normalizeDecisionEnvelope(envelope),
        usage: {
          inputTokens: safeTokenCount(payload?.prompt_eval_count),
          cachedInputTokens: 0,
          outputTokens: safeTokenCount(payload?.eval_count),
          reasoningTokens: 0,
          costMicros: 0
        }
      };
    }
  });
}

function safeTokenCount(value) {
  const number = Number(value ?? 0);
  return Number.isInteger(number) && number >= 0 ? number : 0;
}
