import { defineAiProvider } from "./provider-contract.js";

export class FakeAiProvider {
  constructor(responses = [], maxOutputTokens = 0) {
    this.responses = responses.map((response) => structuredClone(response));
    this.requests = [];
    this.id = "fake";
    this.maxOutputTokens = maxOutputTokens;
  }

  async generateDecision(packet, context = {}) {
    this.requests.push({ packet: structuredClone(packet), context: structuredClone(context) });
    return this.responses.shift() ?? {
      decision: "hold",
      summary: "No scripted provider response was queued.",
      rationale: "The deterministic fake provider fails closed when its response queue is empty.",
      usage: { inputTokens: packet.approximateInputTokens, outputTokens: 20 }
    };
  }
}

export function createFakeAiProvider(responses = [], maxOutputTokens = 0) {
  return defineAiProvider(new FakeAiProvider(responses, maxOutputTokens));
}
