export async function fetchWithTransientRetry(fetchImpl, url, options = {}, {
  attempts = 3, delayMs = 250, onRetry = async () => {}
} = {}) {
  let lastError;
  for (let attempt = 1; attempt <= attempts; attempt += 1) {
    try {
      const response = await fetchImpl(url, options);
      if (response.status < 500 || attempt === attempts) return response;
      lastError = new Error(`Temporary connector response (${response.status}).`);
    } catch (error) {
      if (options.signal?.aborted || error?.name === "AbortError") throw error;
      lastError = error;
      if (attempt === attempts) throw error;
    }
    await onRetry({ attempt, error: lastError });
    await new Promise((resolve, reject) => {
      const timer = setTimeout(resolve, delayMs * attempt);
      options.signal?.addEventListener("abort", () => { clearTimeout(timer); reject(options.signal.reason || new DOMException("Aborted", "AbortError")); }, { once: true });
    });
  }
  throw lastError;
}
