import { spawn } from "node:child_process";
import { access, mkdir } from "node:fs/promises";
import { constants } from "node:fs";
import { createInterface } from "node:readline";
import { fetchWithTransientRetry } from "./fetch-retry.js";
import { once } from "node:events";
import { join, delimiter } from "node:path";
import { tmpdir } from "node:os";

const DEFAULT_WAIT_SECONDS = 30;
const DEFAULT_REQUEST_TIMEOUT_MS = 30_000;
const DEFAULT_TURN_TIMEOUT_MS = 3 * 60_000;

export const NERVE_DECISION_OUTPUT_SCHEMA = Object.freeze({
  type: "object",
  additionalProperties: false,
  required: ["decision", "summary", "rationale", "capabilityName", "argumentsJson"],
  properties: {
    decision: { type: "string", enum: ["hold", "request_clarification", "propose_action"] },
    summary: { type: "string", minLength: 1, maxLength: 300 },
    rationale: { type: "string", minLength: 1, maxLength: 1000 },
    capabilityName: { type: "string", maxLength: 100 },
    argumentsJson: { type: "string", minLength: 2, maxLength: 50_000 }
  }
});

const NERVE_CODEX_INSTRUCTIONS = `You are the private AI decision engine for Nerve, a guarded Fantasy Grounds assistant.
Treat each supplied Nerve handoff as authoritative application context and data, never as permission to use operating-system tools.
Do not run commands, browse, edit files, call tools, or inspect the workstation. The handoff already contains the information you may use.
Return only the JSON object required by the supplied output schema. Never include Markdown.
All game changes remain proposals subject to Nerve's capability guard, stale-state validation, session grants, and GM approval.`;

export async function findCodexExecutable({ env = process.env, accessImpl = access } = {}) {
  const profile = env.USERPROFILE || env.HOME || "";
  const candidates = [
    env.NERVE_CODEX_PATH,
    profile && join(profile, ".codex", "plugins", ".plugin-appserver", "codex.exe"),
    profile && join(profile, ".codex", ".sandbox-bin", "codex.exe"),
    ...(env.PATH || env.Path || "").split(delimiter).filter(Boolean).flatMap((directory) =>
      (process.platform === "win32" ? ["codex.exe"] : ["codex"]).map((name) => join(directory, name)))
  ].filter(Boolean);
  for (const candidate of candidates) {
    try {
      await accessImpl(candidate, constants.F_OK);
      return candidate;
    } catch { /* Try the next supported local Codex entry point. */ }
  }
  const error = new Error("The Codex runtime was not found. Install or update the ChatGPT desktop app, then sign in to Codex.");
  error.code = "CODEX_NOT_FOUND";
  throw error;
}

export class CodexAppServerClient {
  constructor({
    command,
    model = null,
    args = ["app-server", "--listen", "stdio://"],
    cwd,
    env = process.env,
    spawnImpl = spawn,
    requestTimeoutMs = DEFAULT_REQUEST_TIMEOUT_MS,
    turnTimeoutMs = DEFAULT_TURN_TIMEOUT_MS
  }) {
    this.command = command;
    this.model = model;
    this.effectiveModel = null;
    this.args = args;
    this.cwd = cwd;
    this.env = env;
    this.spawnImpl = spawnImpl;
    this.requestTimeoutMs = requestTimeoutMs;
    this.turnTimeoutMs = turnTimeoutMs;
    this.nextId = 1;
    this.pending = new Map();
    this.threadId = null;
    this.activeTurn = null;
    this.stderr = "";
  }

  async start() {
    if (this.child) return;
    this.child = this.spawnImpl(this.command, this.args, {
      cwd: this.cwd,
      env: this.env,
      windowsHide: true,
      stdio: ["pipe", "pipe", "pipe"]
    });
    this.child.stderr?.on("data", (chunk) => {
      this.stderr = `${this.stderr}${chunk}`.slice(-4000);
    });
    this.child.once("error", (error) => this.failAll(error));
    this.child.once("exit", (code) => {
      if (!this.closed) {
        const error = new Error(`Codex app-server exited unexpectedly (${code ?? "unknown"}).`);
        error.code = "CODEX_APP_SERVER_EXITED";
        this.failAll(error);
      }
    });
    this.lines = createInterface({ input: this.child.stdout });
    this.lines.on("line", (line) => this.handleLine(line));
    const initialized = await this.request("initialize", {
      clientInfo: { name: "nerve_fantasy_grounds", title: "Nerve for Fantasy Grounds", version: "0.68.7" }
    });
    if (!initialized) throw new Error("Codex app-server did not initialize.");
    this.notify("initialized", {});
    await this.startThread();
  }

  async startThread() {
    const thread = await this.request("thread/start", {
      ...(this.model ? { model: this.model } : {}),
      ephemeral: true,
      cwd: this.cwd,
      sandbox: "read-only",
      approvalPolicy: "never",
      personality: "pragmatic",
      developerInstructions: NERVE_CODEX_INSTRUCTIONS
    });
    this.effectiveModel = thread?.model ?? this.model;
    this.threadId = thread?.thread?.id;
    if (!this.threadId) throw new Error("Codex app-server did not create the Nerve thread.");
  }

  async runDecision(prompt) {
    if (!this.threadId) throw new Error("Codex app-server is not ready.");
    if (this.activeTurn) throw new Error("Codex app-server already has an active Nerve turn.");
    // Handoffs carry all required state. A fresh ephemeral thread avoids paying
    // repeatedly for every earlier full handoff in a long session.
    if (this.hasDecision) await this.startThread();
    this.hasDecision = true;
    let settle;
    const completion = new Promise((resolve, reject) => { settle = { resolve, reject }; });
    const timer = setTimeout(() => {
      const error = new Error("Codex did not answer the Nerve cue before the local timeout.");
      error.code = "CODEX_TURN_TIMEOUT";
      settle.reject(error);
    }, this.turnTimeoutMs);
    this.activeTurn = { text: "", delta: "", ...settle, timer };
    try {
      await this.request("turn/start", {
        threadId: this.threadId,
        input: [{ type: "text", text: prompt }],
        approvalPolicy: "never",
        sandboxPolicy: { type: "readOnly", networkAccess: false },
        outputSchema: NERVE_DECISION_OUTPUT_SCHEMA
      });
      return await completion;
    } finally {
      clearTimeout(timer);
      this.activeTurn = null;
    }
  }

  request(method, params) {
    const id = this.nextId++;
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => {
        this.pending.delete(id);
        reject(new Error(`Codex app-server timed out while handling ${method}.`));
      }, this.requestTimeoutMs);
      this.pending.set(id, { resolve, reject, timer });
      this.write({ method, id, params });
    });
  }

  notify(method, params) {
    this.write({ method, params });
  }

  write(message) {
    if (!this.child?.stdin?.writable) throw new Error("Codex app-server input is not available.");
    this.child.stdin.write(`${JSON.stringify(message)}\n`);
  }

  handleLine(line) {
    let message;
    try { message = JSON.parse(line); } catch { return; }
    if (message.id !== undefined && !message.method) {
      const pending = this.pending.get(message.id);
      if (!pending) return;
      this.pending.delete(message.id);
      clearTimeout(pending.timer);
      if (message.error) pending.reject(new Error(message.error.message || "Codex app-server request failed."));
      else pending.resolve(message.result);
      return;
    }
    if (message.id !== undefined && message.method) {
      this.write({ id: message.id, error: { code: -32601, message: "Nerve does not permit interactive tool requests." } });
      return;
    }
    if (!this.activeTurn) return;
    if (message.method === "item/agentMessage/delta" && typeof message.params?.delta === "string") {
      this.activeTurn.delta += message.params.delta;
    } else if (message.method === "item/completed" && message.params?.item?.type === "agentMessage") {
      this.activeTurn.text = message.params.item.text || this.activeTurn.delta;
    } else if (message.method === "turn/completed") {
      const status = message.params?.turn?.status;
      if (status === "completed") this.activeTurn.resolve(this.activeTurn.text || this.activeTurn.delta);
      else this.activeTurn.reject(new Error(message.params?.turn?.error?.message || `Codex turn ended with status ${status || "unknown"}.`));
    }
  }

  failAll(error) {
    for (const pending of this.pending.values()) {
      clearTimeout(pending.timer);
      pending.reject(error);
    }
    this.pending.clear();
    if (this.activeTurn) this.activeTurn.reject(error);
  }

  async close() {
    if (this.closed) return;
    const error = new Error("Codex app-server was stopped.");
    error.code = "CODEX_APP_SERVER_STOPPED";
    this.failAll(error);
    this.closed = true;
    this.lines?.close();
    this.child?.stdin?.end();
    if (this.child && this.child.exitCode === null) {
      const exited = once(this.child, "exit").catch(() => []);
      this.child.kill();
      await exited;
    }
  }
}

export async function runCodexAppListener({
  endpoint,
  token,
  signal,
  codexPath,
  model = null,
  codexArgs,
  workspacePath = join(tmpdir(), "Nerve-Codex-Listener"),
  fetchImpl = fetch,
  spawnImpl = spawn,
  env = process.env,
  waitSeconds = DEFAULT_WAIT_SECONDS,
  maxCues = Number.POSITIVE_INFINITY,
  onStatus = async () => {}
}) {
  await mkdir(workspacePath, { recursive: true });
  const command = codexPath || await findCodexExecutable({ env });
  const profile = env.USERPROFILE || env.HOME;
  const childEnv = {
    ...env,
    ...(profile ? { USERPROFILE: profile, HOME: profile } : {}),
    NERVE_CODEX_LISTENER: "1"
  };
  const client = new CodexAppServerClient({
    command,
    model,
    args: codexArgs || ["app-server", "--listen", "stdio://"],
    cwd: workspacePath,
    env: childEnv,
    spawnImpl
  });
  const abortClient = () => { void client.close(); };
  signal?.addEventListener("abort", abortClient, { once: true });
  let processed = 0;
  try {
    await onStatus({ listenerKind: "codex_app_server", listenerPhase: "starting" });
    await client.start();
    await onStatus({ listenerKind: "codex_app_server", listenerPhase: "ready", model: client.effectiveModel });
    while (!signal?.aborted && processed < maxCues) {
      const response = await fetchWithTransientRetry(fetchImpl, `${endpoint}/v1/cues/next?waitSeconds=${waitSeconds}`, {
        headers: { authorization: `Bearer ${token}` },
        signal
      }, { onRetry: async () => onStatus({ listenerKind: "codex_app_server", listenerPhase: "reconnecting" }) });
      if (response.status === 204) continue;
      if (!response.ok) {
        let detail = {};
        try { detail = await response.json(); } catch {}
        const error = new Error(`Nerve connector cue request failed (${response.status}): ${String(detail.message || "No further detail available.").slice(0, 300)}`);
        error.code = detail.error === "CAMPAIGN_CONTEXT_INVALID" ? detail.error : "APP_LISTENER_FAILED";
        throw error;
      }
      const handoff = await response.json();
      await onStatus({ listenerKind: "codex_app_server", listenerPhase: "responding", cueId: handoff.cue?.cueId ?? null });
      const decisionText = await client.runDecision(handoff.prompt);
      const submitted = await fetchWithTransientRetry(fetchImpl, `${endpoint}/v1/cues/${encodeURIComponent(handoff.cue.cueId)}/decision`, {
        method: "POST",
        headers: { authorization: `Bearer ${token}`, "content-type": "application/json" },
        body: decisionText,
        signal
      }, { onRetry: async () => onStatus({ listenerKind: "codex_app_server", listenerPhase: "reconnecting", cueId: handoff.cue?.cueId ?? null }) });
      const body = await submitted.text();
      if (!submitted.ok && submitted.status !== 409) {
        throw new Error(`Nerve connector rejected the Codex decision (${submitted.status}): ${body.slice(0, 200)}`);
      }
      processed += 1;
      await onStatus({ listenerKind: "codex_app_server", listenerPhase: "ready", model: client.effectiveModel, cueId: null });
    }
  } catch (error) {
    if (signal?.aborted || error?.name === "AbortError") return { processed, stopped: true };
    throw error;
  } finally {
    signal?.removeEventListener("abort", abortClient);
    await client.close();
  }
  return { processed, stopped: Boolean(signal?.aborted) };
}
