import { bindNativeFollowUp } from "./native-followups.js";
import { adaptDecisionForLocalCharacterPlay } from "./companion-handoff.js";
import { SessionContextReducer } from "./context-delta.js";
import { validateProviderResponse } from "./provider-contract.js";
import { UsageLedger } from "./usage-ledger.js";

const DEFAULT_TRIGGER_TYPES = new Set([
  "ai.cue_requested",
  "ooc.question",
  "player.chat_message",
  "gm.guidance",
  "player.prompt_response",
  "player.roll_response",
  "player.roll_declined",
  "player.prompt_timeout",
  "player.roll_timeout",
  "combat.turn_started",
  "roll.attack",
  "combat.damage_resolved",
  "roll.save",
  "roll.skill",
  "roll.check",
  "roll.table",
  "power.action_outcome",
  "combatant.action_outcome"
]);

export const OBSERVATION_ONLY_EVENT_TYPES = Object.freeze([
  "combat.damage", "combat.healing", "roll.damage", "roll.heal", "roll.initiative",
  "combat.changed", "party.changed", "character.changed", "users.changed", "map.tokens_changed", "map.area_keyed"
]);

export class AiSessionController {
  constructor({
    runtime,
    provider,
    journal,
    contextReducer = new SessionContextReducer(),
    usageLedger = new UsageLedger(),
    triggerTypes = DEFAULT_TRIGGER_TYPES,
    clock = () => new Date(),
    delay = abortableDelay
  }) {
    if (!runtime?.call || !provider?.generateDecision || !journal?.append) {
      throw new TypeError("AiSessionController requires runtime, provider, and journal.");
    }
    this.runtime = runtime;
    this.provider = provider;
    this.journal = journal;
    this.contextReducer = contextReducer;
    this.usageLedger = usageLedger;
    this.triggerTypes = new Set(triggerTypes);
    this.clock = clock;
    if (typeof delay !== "function") throw new TypeError("AiSessionController delay must be a function.");
    this.delay = delay;
  }

  async run({
    sessionId,
    signal,
    timeoutSeconds = 30,
    eventLimit = 25,
    maxCycles = Number.POSITIVE_INFINITY,
    onResult = null,
    maxConsecutiveProviderFailures = 3,
    lifecycleProbe = null,
    bootstrapPendingCue = false
  }) {
    if (!Number.isInteger(maxCycles) && maxCycles !== Number.POSITIVE_INFINITY) {
      throw new TypeError("maxCycles must be a positive integer or Infinity.");
    }
    if (maxCycles <= 0) throw new TypeError("maxCycles must be positive.");
    if (!Number.isInteger(maxConsecutiveProviderFailures) || maxConsecutiveProviderFailures <= 0) {
      throw new TypeError("maxConsecutiveProviderFailures must be a positive integer.");
    }
    const summary = {
      sessionId,
      cycles: 0,
      idle: 0,
      observed: 0,
      providerCalls: 0,
      completed: 0,
      queued: 0,
      rejected: 0,
      blocked: 0,
      failures: 0,
      consecutiveProviderFailures: 0,
      transientProviderFailures: 0,
      providerBackoffs: 0,
      lastProviderBackoffMs: 0,
      lifecycleWaits: 0,
      stopped: false,
      stopReason: null
    };
    let pendingProviderPacket = null;
    let bootstrapPending = bootstrapPendingCue;
    let rateLimitRetriesForPacket = 0;

    while (!signal?.aborted && summary.cycles < maxCycles) {
      const lifecycle = lifecycleProbe ? await lifecycleProbe() : null;
      if (lifecycle?.stop) {
        summary.stopped = true;
        summary.stopReason = lifecycle.reason ?? "lifecycle_stopped";
        if (onResult) await onResult({
          status: "lifecycle_stopped", providerCalled: false, reason: summary.stopReason
        }, structuredClone(summary));
        break;
      }
      if (lifecycle?.wait) {
        summary.lifecycleWaits += 1;
        const retryAfterMs = boundedDelay(lifecycle.retryAfterMs, 1000);
        if (onResult) await onResult({
          status: "lifecycle_waiting", providerCalled: false,
          reason: lifecycle.reason ?? "lifecycle_waiting", retryAfterMs
        }, structuredClone(summary));
        await this.delay(retryAfterMs, signal);
        continue;
      }
      const result = pendingProviderPacket
        ? await this.processPacket({ sessionId, packet: pendingProviderPacket })
        : bootstrapPending
          ? await this.processPendingCue({ sessionId, eventLimit })
          : await this.processNext({ sessionId, timeoutSeconds, eventLimit });
      bootstrapPending = false;
      summary.cycles += 1;
      if (result.status === "idle") summary.idle += 1;
      else if (result.status === "observed") summary.observed += 1;
      else if (result.status === "lifecycle_stopped") summary.stopReason = result.reason ?? "session_ended";
      else if (result.status === "completed") summary.completed += 1;
      else if (result.status === "action_queued") summary.queued += 1;
      else if (result.status === "action_rejected") summary.rejected += 1;
      else if (result.status === "budget_blocked") summary.blocked += 1;
      else summary.failures += 1;
      if (result.status === "provider_failed") summary.consecutiveProviderFailures += 1;
      else if (result.providerCalled) summary.consecutiveProviderFailures = 0;
      const transientProviderFailure = isTransientProviderFailure(result);
      if (transientProviderFailure) {
        result.transient = true;
        const rateLimited = result.error?.details?.status === 429;
        if (rateLimited) rateLimitRetriesForPacket += 1;
        result.retryAfterMs = providerRetryDelayMs(result, summary.consecutiveProviderFailures);
        summary.transientProviderFailures += 1;
        summary.providerBackoffs += 1;
        summary.lastProviderBackoffMs = result.retryAfterMs;
        if (rateLimited && rateLimitRetriesForPacket > 1) {
          result.status = "provider_rate_limited";
          result.transient = false;
        }
      } else if (result.providerCalled) {
        summary.lastProviderBackoffMs = 0;
      }
      if (result.providerCalled) summary.providerCalls += 1;
      if (onResult) await onResult(result, structuredClone(summary));
      if (result.status === "lifecycle_stopped") {
        summary.stopped = true;
        summary.stopReason = result.reason ?? "session_ended";
        break;
      }
      if (result.status === "budget_blocked") break;
      if (result.status === "action_queued") break;
      if (result.status === "provider_rate_limited") break;
      if (transientProviderFailure) {
        pendingProviderPacket = result.packet ?? pendingProviderPacket;
        await this.delay(result.retryAfterMs, signal);
        continue;
      }
      pendingProviderPacket = null;
      rateLimitRetriesForPacket = 0;
      if (result.status === "provider_failed" && summary.consecutiveProviderFailures >= maxConsecutiveProviderFailures) break;
      if (result.status.endsWith("_failed") && result.status !== "provider_failed") break;
    }
    summary.stopped = summary.stopped || Boolean(signal?.aborted);
    if (signal?.aborted && !summary.stopReason) summary.stopReason = "stop_requested";
    summary.usage = this.usageLedger.get(sessionId);
    return summary;
  }

  async processPendingCue({ sessionId, eventLimit = 25 }) {
    const cycle = await this.runtime.call({
      capabilityName: "run_dm_cycle",
      sessionId,
      arguments: { eventLimit, reset: false },
      metadata: { controller: this.provider.id, bootstrap: true }
    });
    if (!cycle.ok) return this.#failure("briefing_failed", cycle);
    if (cycle.data.sessionOperations?.status === "ended") {
      return { status: "lifecycle_stopped", providerCalled: false, reason: "session_ended", cycle };
    }
    if (cycle.data.aiCue?.status !== "called" || !cycle.data.aiCue?.cueId) {
      return { status: "observed", providerCalled: false, cycle, observedEventCount: 0 };
    }
    if (cycle.data.cursorReset) this.contextReducer.reset(sessionId);
    const packet = this.contextReducer.build({
      sessionId,
      briefing: cycle.data,
      generatedAt: this.clock().toISOString()
    });
    return this.processPacket({ sessionId, packet });
  }

  async processNext({ sessionId, timeoutSeconds = 30, eventLimit = 25, reset = false }) {
    const wait = await this.runtime.call({
      capabilityName: "wait_for_events",
      sessionId,
      arguments: { timeoutSeconds, eventLimit, reset },
      metadata: { controller: this.provider.id }
    });
    if (!wait.ok) return this.#failure("wait_failed", wait);

    const observedEvents = wait.data.recentEvents.events;
    if (wait.data.timedOut && observedEvents.length === 0) {
      return { status: "idle", providerCalled: false, wait };
    }
    if (!reset && !observedEvents.some((event) => this.triggerTypes.has(event.type))) {
      return { status: "observed", providerCalled: false, wait, observedEventCount: observedEvents.length };
    }

    if (observedEvents.some(event => new Set(["roll.attack", "roll.table", "combat.damage_resolved", "combatant.action_outcome", "power.action_outcome"]).has(event.type))) {
      await this.delay(2000);
    }

    const cycle = await this.runtime.call({
      capabilityName: "run_dm_cycle",
      sessionId,
      arguments: { eventLimit, reset },
      metadata: { controller: this.provider.id }
    });
    if (!cycle.ok) return this.#failure("briefing_failed", cycle);
    if (cycle.data.sessionOperations?.status === "ended") {
      return { status: "lifecycle_stopped", providerCalled: false, reason: "session_ended", cycle };
    }

    if (cycle.data.cursorReset) this.contextReducer.reset(sessionId);
    const packet = this.contextReducer.build({
      sessionId,
      briefing: cycle.data,
      generatedAt: this.clock().toISOString()
    });
    return this.processPacket({ sessionId, packet });
  }

  async processPacket({ sessionId, packet }) {
    const authorization = this.usageLedger.authorize(sessionId, packet.approximateInputTokens, this.provider.maxOutputTokens ?? 0);
    if (!authorization.allowed) {
      await this.journal.append({
        event: "ai.controller.budget_blocked",
        sessionId,
        provider: this.provider.id,
        reason: authorization.reason,
        usage: authorization.usage,
        timestamp: this.clock().toISOString()
      });
      return { status: "budget_blocked", providerCalled: false, reason: authorization.reason, packet, usage: authorization.usage };
    }

    await this.journal.append({
      event: "ai.provider.requested",
      sessionId,
      provider: this.provider.id,
      packetSequence: packet.sequence,
      inputBytes: packet.inputBytes,
      approximateInputTokens: packet.approximateInputTokens,
      timestamp: this.clock().toISOString()
    });

    let response;
    try {
      response = validateProviderResponse(await this.provider.generateDecision(packet, {
        sessionId,
        usage: authorization.usage
      }));
    } catch (error) {
      await this.journal.append({
        event: "ai.provider.failed",
        sessionId,
        provider: this.provider.id,
        message: error.message,
        timestamp: this.clock().toISOString()
      });
      return {
        status: "provider_failed", providerCalled: true, packet,
        error: { code: error.code ?? "AI_PROVIDER_ERROR", message: error.message, ...(error.details ? { details: error.details } : {}) }
      };
    }

    response = adaptDecisionForLocalCharacterPlay({ snapshot: { ...packet.state, recentEvents: { events: packet.events } }, decision: response });
    response = bindNativeFollowUp(response, packet.events, this.clock().getTime() / 1000);
    const usage = this.usageLedger.record(sessionId, response.usage);
    await this.journal.append({
      event: "ai.provider.completed",
      sessionId,
      provider: this.provider.id,
      decision: response.decision,
      usage: response.usage,
      cumulativeUsage: usage,
      timestamp: this.clock().toISOString()
    });
    await this.journal.append({
      event: "ai.decision.recorded",
      sessionId,
      provider: this.provider.id,
      cursor: packet.cursor,
      decision: response.decision,
      summary: response.summary,
      rationale: response.rationale,
      ...(response.action ? { proposedCapability: response.action.capabilityName } : {}),
      timestamp: this.clock().toISOString()
    });

    let actionResult = null;
    if (response.decision === "propose_action") {
      actionResult = await this.runtime.call({
        capabilityName: response.action.capabilityName,
        sessionId,
        // A provider proposal is permission to queue the action at Nerve Guard;
        // Fantasy Grounds remains the final manual/session-grant boundary. Keep
        // this protocol flag out of model-dependent behavior.
        arguments: { ...response.action.arguments, confirmed: true },
        metadata: { controller: this.provider.id, packetSequence: packet.sequence, decisionCursor: packet.cursor }
      });
    }

    const actionPersisted = actionResult?.error?.details?.persistent === true;
    return {
      status: actionPersisted ? "action_queued" : (actionResult && !actionResult.ok ? "action_rejected" : "completed"),
      providerCalled: true,
      packet,
      response,
      usage,
      actionResult
    };
  }

  #failure(status, result) {
    return { status, providerCalled: false, error: result.error, result };
  }
}

export function isTransientProviderFailure(result) {
  if (result?.status !== "provider_failed") return false;
  if (result.error?.code === "AI_PROVIDER_UNREACHABLE") return true;
  if (result.error?.code === "AI_PROVIDER_INVALID_RESPONSE") return true;
  if (result.error?.code !== "AI_PROVIDER_HTTP_ERROR") return false;
  return new Set([408, 425, 429, 500, 502, 503, 504]).has(result.error?.details?.status);
}

export function providerBackoffMs(consecutiveFailures) {
  const count = Number.isInteger(consecutiveFailures) && consecutiveFailures > 0 ? consecutiveFailures : 1;
  return Math.min(60000, 10000 * (2 ** Math.min(3, count - 1)));
}

export function providerRetryDelayMs(result, consecutiveFailures) {
  if (result?.error?.details?.status === 429) {
    const hinted = Number(result.error?.details?.retryAfterMs);
    const withMargin = Number.isFinite(hinted) && hinted >= 0 ? Math.ceil(hinted) + 5000 : 0;
    return Math.min(120000, Math.max(65000, withMargin));
  }
  return providerBackoffMs(consecutiveFailures);
}

function boundedDelay(value, fallback) {
  return Number.isInteger(value) && value >= 0 && value <= 120000 ? value : fallback;
}

function abortableDelay(milliseconds, signal) {
  if (milliseconds <= 0 || signal?.aborted) return Promise.resolve();
  return new Promise((resolve) => {
    const timer = setTimeout(done, milliseconds);
    signal?.addEventListener("abort", done, { once: true });
    function done() {
      clearTimeout(timer);
      signal?.removeEventListener("abort", done);
      resolve();
    }
  });
}
