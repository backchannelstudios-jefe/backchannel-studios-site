export class UsageLedger {
  #sessions = new Map();

  constructor({ warningTokens = null, hardTokens = null, hardCostMicros = null } = {}) {
    this.limits = Object.freeze({ warningTokens, hardTokens, hardCostMicros });
    for (const [name, value] of Object.entries(this.limits)) {
      if (value !== null && (!Number.isInteger(value) || value <= 0)) {
        throw new TypeError(`${name} must be a positive integer or null.`);
      }
    }
  }

  authorize(sessionId, estimatedInputTokens, reservedOutputTokens = 0) {
    const usage = this.get(sessionId);
    if (!Number.isInteger(estimatedInputTokens) || estimatedInputTokens < 0 || !Number.isInteger(reservedOutputTokens) || reservedOutputTokens < 0) {
      throw new TypeError("Estimated input and reserved output tokens must be non-negative integers.");
    }
    if (this.limits.hardTokens !== null && usage.totalTokens + estimatedInputTokens + reservedOutputTokens > this.limits.hardTokens) {
      return { allowed: false, reason: "token_budget", usage };
    }
    if (this.limits.hardCostMicros !== null && usage.costMicros >= this.limits.hardCostMicros) {
      return { allowed: false, reason: "cost_budget", usage };
    }
    return { allowed: true, usage, reservedTokens: estimatedInputTokens + reservedOutputTokens };
  }

  record(sessionId, providerUsage) {
    const current = this.get(sessionId);
    const next = {
      calls: current.calls + 1,
      inputTokens: current.inputTokens + providerUsage.inputTokens,
      cachedInputTokens: current.cachedInputTokens + providerUsage.cachedInputTokens,
      outputTokens: current.outputTokens + providerUsage.outputTokens,
      reasoningTokens: current.reasoningTokens + providerUsage.reasoningTokens,
      costMicros: current.costMicros + providerUsage.costMicros
    };
    next.totalTokens = next.inputTokens + next.outputTokens + next.reasoningTokens;
    next.warning = this.limits.warningTokens !== null && next.totalTokens >= this.limits.warningTokens;
    this.#sessions.set(sessionId, next);
    return structuredClone(next);
  }

  get(sessionId) {
    return structuredClone(this.#sessions.get(sessionId) ?? {
      calls: 0,
      inputTokens: 0,
      cachedInputTokens: 0,
      outputTokens: 0,
      reasoningTokens: 0,
      totalTokens: 0,
      costMicros: 0,
      warning: false
    });
  }
}
