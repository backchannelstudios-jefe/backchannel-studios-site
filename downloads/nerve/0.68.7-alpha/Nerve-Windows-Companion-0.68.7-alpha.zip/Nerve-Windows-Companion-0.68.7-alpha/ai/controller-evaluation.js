import { AiSessionController } from "./session-controller.js";
import { createFakeAiProvider } from "./fake-provider.js";
import { MemoryJournal } from "../core/journal.js";

const SCENARIOS = [
  scenario("opening-narration", "ai.cue_requested", action("send_chat", { text: "The ruined gate opens before you.", visibility: "all" })),
  scenario("rules-neutral-choice", "player.prompt_response", action("send_chat", { text: "You can scout, negotiate, or press onward.", visibility: "all" })),
  scenario("skill-roll-request", "ai.cue_requested", action("request_player_roll", {
    prompt: "Make a Perception check.", rollType: "skill_check", skill: "Perception", dc: 13,
    audience: "all_players", rollMode: "normal", visibility: "public", timeoutSeconds: 120
  })),
  scenario("library-grounded-lookup", "ai.cue_requested", action("search_library", { query: "ruined gate", recordTypes: ["story"] })),
  scenario("encounter-start", "ai.cue_requested", action("start_encounter", { encounterId: "encounter.ruined-gate" })),
  scenario("no-map-targeting", "combat.turn_started", action("send_chat", { text: "Choose the nearest visible foe; theater-of-the-mind distances apply.", visibility: "all" })),
  scenario("hit-miss-follow-up", "roll.attack", action("send_chat", { text: "The attack hits. Roll damage.", visibility: "all" })),
  scenario("successful-save-no-damage", "roll.save", hold("The save succeeded and the effect specifies no damage on success."), { forbiddenCapability: "apply_damage" }),
  scenario("enemy-proxy-turn", "combat.turn_started", action("proxy_combatant_action", { combatantId: "npc-1", action: "attack" })),
  scenario("session-close-report", "ai.cue_requested", action("send_chat", { text: "Session complete. The party secured the ruined gate.", visibility: "all" }))
];

export async function runControllerEvaluation({ provider = null, providerId = "fake" } = {}) {
  const scriptedProvider = provider ?? createFakeAiProvider(SCENARIOS.map((item) => item.response));
  const runtime = evaluationRuntime(SCENARIOS);
  const journal = new MemoryJournal();
  const controller = new AiSessionController({ runtime, provider: scriptedProvider, journal, clock: fixedClock });
  const results = [];
  for (const expected of SCENARIOS) {
    const result = await controller.processNext({ sessionId: "controller-evaluation", timeoutSeconds: 1 });
    results.push(scoreScenario(expected, result, runtime.actions));
  }
  const usage = controller.usageLedger.get("controller-evaluation");
  const passedCount = results.filter((item) => item.passed).length;
  return {
    schemaVersion: "0.1",
    evaluation: "nerve-controller-ten-scenario",
    provider: scriptedProvider.id ?? providerId,
    generatedAt: fixedClock().toISOString(),
    passed: passedCount === SCENARIOS.length,
    passedCount,
    scenarioCount: SCENARIOS.length,
    failedCount: SCENARIOS.length - passedCount,
    baselinePackets: results.filter((item) => item.packet.baseline).length,
    deltaPackets: results.filter((item) => !item.packet.baseline).length,
    totalInputBytes: results.reduce((sum, item) => sum + item.packet.inputBytes, 0),
    usage,
    journalEntries: journal.entries.length,
    scenarios: results
  };
}

function evaluationRuntime(scenarios) {
  let index = 0;
  let active = null;
  const actions = [];
  return {
    actions,
    async call({ capabilityName, arguments: args }) {
      const current = scenarios[index];
      if (capabilityName === "wait_for_events") {
        return { ok: true, data: waitEvent(index + 1, current.triggerType) };
      }
      if (capabilityName === "run_dm_cycle") {
        active = current;
        index += 1;
        return { ok: true, data: briefing(index, current) };
      }
      actions.push({ scenarioId: active.id, capabilityName, arguments: structuredClone(args) });
      return { ok: true, data: { accepted: true, capabilityName } };
    }
  };
}

function scoreScenario(expected, result, actions) {
  const scenarioActions = actions.filter((item) => item.scenarioId === expected.id);
  const proposed = result.response?.action?.capabilityName ?? null;
  const forbiddenObserved = expected.forbiddenCapability
    ? scenarioActions.some((item) => item.capabilityName === expected.forbiddenCapability)
    : false;
  const expectedDecision = expected.response.decision;
  const passed = result.status === "completed"
    && result.response?.decision === expectedDecision
    && (expectedDecision !== "propose_action" || proposed === expected.response.action.capabilityName)
    && !forbiddenObserved;
  return {
    id: expected.id,
    passed,
    expectedDecision,
    actualDecision: result.response?.decision ?? null,
    proposedCapability: proposed,
    forbiddenCapabilityObserved: forbiddenObserved,
    actionAccepted: result.actionResult ? Boolean(result.actionResult.ok) : null,
    packet: {
      sequence: result.packet.sequence,
      baseline: result.packet.baseline,
      inputBytes: result.packet.inputBytes,
      approximateInputTokens: result.packet.approximateInputTokens,
      changedSections: Object.keys(result.packet.state),
      omittedUnchanged: result.packet.omittedUnchanged
    },
    usage: result.response?.usage ?? null
  };
}

function scenario(id, triggerType, response, extra = {}) { return { id, triggerType, response, ...extra }; }
function action(capabilityName, args) {
  return {
    decision: "propose_action",
    summary: `Propose ${capabilityName}.`,
    rationale: "Deterministic evaluation response.",
    action: { capabilityName, arguments: args },
    usage: { inputTokens: 80, cachedInputTokens: 0, outputTokens: 18, reasoningTokens: 4, costMicros: 0 }
  };
}
function hold(summary) {
  return { decision: "hold", summary, rationale: "Deterministic safety evaluation response.", usage: { inputTokens: 70, cachedInputTokens: 0, outputTokens: 14, reasoningTokens: 3, costMicros: 0 } };
}
function waitEvent(sequence, type) {
  const events = [{ sequence, type, occurredAt: fixedClock().toISOString(), visibility: "gm", data: { scenario: SCENARIOS[sequence - 1].id } }];
  return { recentEvents: { streamId: "evaluation", latestSequence: sequence, events }, cursorReset: false, timedOut: false, waitedMs: 1, nextCursor: { streamId: "evaluation", sequence } };
}
function briefing(sequence, current) {
  return {
    campaignSummary: { campaignId: "evaluation", name: "Nerve Evaluation", ruleset: "5E" },
    currentEncounter: { active: sequence >= 5 && sequence < 10, id: sequence >= 5 ? "encounter.ruined-gate" : null },
    combatTracker: { round: sequence >= 5 ? Math.ceil((sequence - 4) / 3) : 0, combatants: sequence >= 5 ? [{ id: "pc-1", name: "Test Hero" }, { id: "npc-1", name: "Gate Warden" }] : [] },
    party: { members: [{ id: "pc-1", name: "Test Hero", classLevel: "Fighter 1" }] },
    mapScene: { playStyle: "theater_of_the_mind", tokens: [] },
    sessionContinuity: { available: false, latest: null, history: [] },
    sessionOperations: { status: "active", held: false, approvalPolicy: { mode: "manual", automaticCapabilities: [], alwaysManualCapabilities: [] } },
    recentEvents: { streamId: "evaluation", latestSequence: sequence, events: [{ sequence, type: current.triggerType, occurredAt: fixedClock().toISOString(), visibility: "gm", data: { scenario: current.id } }] },
    cursorReset: false,
    nextCursor: { streamId: "evaluation", sequence }
  };
}
function fixedClock() { return new Date("2026-08-19T12:00:00.000Z"); }
