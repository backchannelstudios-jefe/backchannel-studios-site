const list = value => Array.isArray(value) ? value : value && typeof value === "object" ? Object.values(value) : [];
const compact = e => ({ type: e.type ?? "chat.message", actor: e.actor ?? "", text: String(e.text ?? "").slice(0, 600), visibility: e.visibility ?? "gm", timestamp: e.timestamp ?? e.createdAt ?? "", data: Object.fromEntries(["outcome","total","dc","rollType","skill","success"].filter(k => e.data?.[k] !== undefined).map(k => [k,e.data[k]])) });

export function buildSceneBriefing(briefing, previous = []) {
  const checkpoint = briefing.sessionContinuity?.latest;
  const handoff = checkpoint?.facts?.handoff ?? {};
  const events = [...list(handoff.recentInteractions), ...list(checkpoint?.facts?.recentEvents), ...previous, ...list(briefing.recentEvents?.events)]
    .filter(e => e?.text && (e.type === "gm.guidance" || e.type === "player.chat_message" || e.actor === "Nerve" || /^(roll\.|power\.|combatant\.)/.test(e.type ?? "")))
    .map(compact);
  const unique = new Map(events.map(e => [JSON.stringify(e), e]));
  const timeline = [...unique.values()].sort((a,b) => a.timestamp.localeCompare(b.timestamp)).slice(-30);
  const last = predicate => [...timeline].reverse().find(predicate) ?? null;
  const gm = last(e => e.type === "gm.guidance");
  const savedGm = handoff.lastGMGuidance;
  return {
    timeline: timeline.slice(-12),
    currentMap: briefing.mapScene?.name || null,
    confirmedAreaKey: briefing.mapScene?.areaContinuity?.currentAreaKey || null,
    checkpointSituation: checkpoint?.currentSituation ?? null,
    lastGMGuidance: gm && (!savedGm?.timestamp || gm.timestamp >= savedGm.timestamp) ? gm : savedGm ?? null,
    lastPlayerAction: last(e => e.type === "player.chat_message"),
    lastResolution: last(e => /^(roll\.|power\.|combatant\.)/.test(e.type)) ?? handoff.lastResolvedCheck ?? null,
    recentNarration: last(e => e.actor === "Nerve" && e.type === "chat.message"),
    activeQuests: list(briefing.questLog?.quests).filter(q => ["accepted","active"].includes(q.status)),
    bookkeepingEvidence: list(handoff.bookkeepingEvidence),
    interpretation: "Evidence, not a new scene. A Story pin is reference material, never location or permission to transition. Preserve the last player action and resolved checks; newer explicit GM corrections override conflicting narration. Bookkeeping evidence requires verification, not automatic replay."
  };
}
