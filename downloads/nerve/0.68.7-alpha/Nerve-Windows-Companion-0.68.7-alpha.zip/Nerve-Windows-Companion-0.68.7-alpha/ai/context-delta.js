import { buildSceneBriefing } from "./scene-briefing.js";

const STATE_SECTIONS = [
  "campaignSummary",
  "currentEncounter",
  "combatTracker",
  "party",
  "campaignFocus",
  "storyCues",
  "actionContext",
  "questLog",
  "mapScene",
  "sessionContinuity",
  "sessionOperations"
];

// Every handoff is self-contained: CLI and direct API providers do not retain
// previous packets. Omitting an unchanged party/focus made real campaigns appear
// empty. Reduce payload size through projection, never by dropping these anchors.
const ALWAYS_INCLUDED_SECTIONS = new Set(STATE_SECTIONS);

export class SessionContextReducer {
  #sessions = new Map();

  build({ sessionId, briefing, generatedAt = new Date().toISOString() }) {
    const previous = this.#sessions.get(sessionId) ?? { sequence: 0, serialized: new Map() };
    const state = {};
    const omittedUnchanged = [];
    const serialized = new Map(previous.serialized);

    for (const section of STATE_SECTIONS) {
      const value = projectSection(section, briefing[section]);
      const current = JSON.stringify(value);
      if (ALWAYS_INCLUDED_SECTIONS.has(section) || !previous.serialized.has(section) || previous.serialized.get(section) !== current) {
        state[section] = structuredClone(value);
        serialized.set(section, current);
      } else {
        omittedUnchanged.push(section);
      }
    }

    const sceneContinuity = buildSceneBriefing(briefing, previous.timeline);
    const packet = {
      schemaVersion: "0.1",
      sessionId,
      sequence: previous.sequence + 1,
      generatedAt,
      baseline: previous.sequence === 0,
      cursorReset: briefing.cursorReset,
      cursor: structuredClone(briefing.nextCursor),
      state,
      sceneContinuity,
      omittedUnchanged,
      events: structuredClone(briefing.recentEvents?.events ?? [])
    };
    if (Array.isArray(briefing.narrativeReferences)) packet.narrativeReferences = structuredClone(briefing.narrativeReferences);
    const bytes = Buffer.byteLength(JSON.stringify(packet), "utf8") + 80;
    packet.inputBytes = bytes;
    packet.approximateInputTokens = Math.ceil(bytes / 4);

    this.#sessions.set(sessionId, { sequence: packet.sequence, serialized, timeline: sceneContinuity.timeline });
    return packet;
  }

  reset(sessionId) {
    this.#sessions.delete(sessionId);
  }
}

function projectSection(section, value) {
  if (value == null) return value;
  let projected;
  if (section === "combatTracker") projected = projectCombatTracker(value);
  else if (section === "party") projected = projectParty(value);
  else if (section === "mapScene") projected = projectMapScene(value);
  else if (section === "sessionContinuity") projected = projectContinuity(value);
  else projected = structuredClone(value);
  return stripVolatileObservationTimes(projected);
}

function projectCombatTracker(value) {
  const combatants = asArray(value.combatants).slice(0, 60);
  const strandedEncounter = Number(value.round || 0) > 0 && !combatants.some((combatant) => combatant.active === true);
  return {
    ...structuredClone(value),
    combatants: combatants.map((combatant) => ({
      ...pick(combatant, ["id", "name", "type", "faction", "initiative", "active", "status", "disposition", "threat", "playerVisible", "hp"]),
      effects: asArray(combatant.effects).slice(0, 30).map((effect) => pick(effect, ["id", "label", "duration", "active", "gmOnly"])),
      actions: (combatant.active === true || (strandedEncounter && combatant.faction === "foe" && combatant.threat !== false)) ? asArray(combatant.actions).slice(0, 30).map((action) => ({
        ...pick(action, ["section", "id", "name", "manualAdjudicationOnFailure", "usage"]),
        abilities: asArray(action.abilities).slice(0, 20).map((ability) => pick(ability, ["index", "type", "summary"]))
      })) : []
    }))
  };
}

function projectParty(value) {
  return {
    ...structuredClone(value),
    members: asArray(value.members).slice(0, 20).map((member) =>
      pick(member, ["id", "name", "race", "classLevel", "ac", "passivePerception", "hp", "senses"])
    )
  };
}

function projectMapScene(value) {
  const projected = {
    ...structuredClone(value),
    recordLinks: asArray(value.recordLinks).slice(0, 50).map((item) => structuredClone(item)),
    tokens: asArray(value.tokens).slice(0, 100).map((item) => structuredClone(item))
  };
  projected.narrativeGrounding = deriveNarrativeGrounding(projected);
  return projected;
}

function deriveNarrativeGrounding(scene) {
  const spatial = scene.spatial ?? {};
  const partyAreas = new Set(asArray(spatial.partyAreaCandidates).map((item) => item?.key).filter(Boolean));
  const foeAreas = new Set(asArray(spatial.foeAreaCandidates).map((item) => item?.key).filter(Boolean));
  const sharedAreas = [...partyAreas].filter((key) => foeAreas.has(key));
  const warnings = asArray(spatial.placementWarnings).map(String);
  const differentAreas = partyAreas.size > 0 && foeAreas.size > 0 && sharedAreas.length === 0;
  const nearestDistance = spatial.nearestVisibleHostile?.distanceGridUnits ?? null;
  let status = "contact_not_established";
  if ((spatial.partyTokenCount ?? 0) === 0) status = "party_location_unknown";
  else if ((spatial.foeTokenCount ?? 0) === 0) status = "no_hostile_tokens";
  else if (differentAreas) status = "different_area_candidates";
  else if (typeof nearestDistance === "number" && nearestDistance > 12) status = "hostiles_distant";
  else if (typeof nearestDistance === "number") status = "distance_observed_contact_unconfirmed";
  return {
    status,
    immediateContactEstablished: false,
    nearestVisibleHostileDistanceGridUnits: typeof nearestDistance === "number" ? nearestDistance : null,
    partyAreaCandidateKeys: [...partyAreas].slice(0, 10),
    foeAreaCandidateKeys: [...foeAreas].slice(0, 10),
    sharedAreaCandidateKeys: sharedAreas.slice(0, 10),
    instructions: [
      "Coordinates and linked-area candidates never prove discovery, line of sight, adjacency, a valid route, or encounter activation.",
      differentAreas
        ? "Party and hostile area candidates differ; do not narrate immediate hostile contact or awareness without an explicit event establishing it."
        : "Do not narrate immediate hostile contact from map placement alone; require an explicit visibility, turn, attack, or action-outcome event.",
      ...warnings.slice(0, 5)
    ]
  };
}

function projectContinuity(value) {
  const projected = structuredClone(value);
  // Current mechanical state and handoff evidence already have dedicated sections.
  // Keep narrative memory but transmit each historical fact only once.
  const seen = new Set();
  const compact = checkpoint => {
    if (!checkpoint) return checkpoint;
    const result = { ...checkpoint };
    delete result.facts;
    const evidence = asArray(checkpoint.facts?.recentEvents)
      .filter(event => event.text && (event.type === "gm.guidance" || event.type === "player.chat_message" || event.type === "chat.message"))
      .map(event => pick(event, ["type", "actor", "text", "visibility"]));
    for (const [key, items] of Object.entries(result)) {
      if (typeof items === "string" && !["id", "sessionId", "createdAt", "source"].includes(key)) {
        const identity = key + items;
        if (seen.has(identity)) delete result[key];
        else seen.add(identity);
      }
      if (!Array.isArray(items)) continue;
      result[key] = items.filter(item => {
        const identity = key + JSON.stringify(item);
        if (seen.has(identity)) return false;
        seen.add(identity); return true;
      });
    }
    result.facts = { recentEvents: evidence.filter(event => {
      const identity = JSON.stringify(event);
      if (seen.has(identity)) return false;
      seen.add(identity); return true;
    }) };
    return result;
  };
  projected.latest = compact(projected.latest);
  projected.history = asArray(projected.history).filter(c => !projected.latest?.id || c.id !== projected.latest.id)
    .slice(0, 10).map(compact);
  return projected;
}

function pick(value, keys) {
  const result = {};
  for (const key of keys) if (value?.[key] !== undefined) result[key] = structuredClone(value[key]);
  return result;
}

function asArray(value) {
  if (Array.isArray(value)) return value;
  if (value && typeof value === "object") return Object.values(value);
  return [];
}

function stripVolatileObservationTimes(value) {
  if (Array.isArray(value)) return value.map(stripVolatileObservationTimes);
  if (!value || typeof value !== "object") return value;
  return Object.fromEntries(Object.entries(value)
    .filter(([key]) => key !== "observedAt")
    .map(([key, item]) => [key, stripVolatileObservationTimes(item)]));
}
