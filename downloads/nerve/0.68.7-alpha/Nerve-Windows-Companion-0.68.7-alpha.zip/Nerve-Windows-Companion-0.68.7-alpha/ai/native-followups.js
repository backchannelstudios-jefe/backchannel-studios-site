// Recover a missing correlation only from the latest matching native outcome.
// Never guess a target, action, correlation ID or extend native authorization.
export function bindNativeFollowUp(decision, events, nowEpoch = Date.now() / 1000) {
  if (decision?.decision !== "propose_action") return decision;
  const { capabilityName, arguments: args } = decision.action ?? {};
  if (!args || args.followUpContexts?.length || !args.targetCombatantIds?.length) return decision;
  const npc = capabilityName === "proxy_combatant_action";
  if (!npc && capabilityName !== "proxy_character_power_action") return decision;
  const stream = Array.isArray(events) ? events : [];
  const contexts = [];
  for (const target of args.targetCombatantIds) {
    const outcome = [...stream].reverse().find(event =>
      event.type === (npc ? "combatant.action_outcome" : "power.action_outcome") &&
      event.data?.targetCombatantId === target &&
      (npc ? event.data.combatantId === args.combatantId : event.data.characterId === args.characterId));
    const data = outcome?.data;
    if (!data?.correlationId || !(data.followUpExpiresAtEpoch > nowEpoch)) return decision;
    if (stream.some(event => event.sequence > outcome.sequence && event.type === "combat.turn_started")) return decision;
    const matches = npc
      ? data.section === args.section && data.actionRecordId === args.actionId && data.followUpActions?.some(action => action.abilityIndex === args.abilityIndex)
      : data.powerId === args.powerId && data.followUpActions?.some(action => action.id === args.actionId);
    if (!matches) return decision;
    contexts.push({ correlationId: data.correlationId, targetCombatantId: target });
  }
  return { ...decision, action: { capabilityName, arguments: { ...args, followUpContexts: contexts } } };
}
