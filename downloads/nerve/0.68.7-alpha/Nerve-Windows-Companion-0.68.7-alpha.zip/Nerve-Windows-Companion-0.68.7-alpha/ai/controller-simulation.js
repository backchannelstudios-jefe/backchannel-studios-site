import { AiSessionController } from "./session-controller.js";
import { createFakeAiProvider } from "./fake-provider.js";
import { MemoryJournal } from "../core/journal.js";

export async function runControllerSimulation() {
  const firstEvents = [event(1, "chat.message"), event(2, "ai.cue_requested")];
  const secondEvents = [event(3, "combat.turn_started")];
  const firstBriefing = briefing(firstEvents, 2);
  const secondBriefing = structuredClone(firstBriefing);
  secondBriefing.recentEvents = { streamId: "simulation", latestSequence: 3, events: secondEvents };
  secondBriefing.nextCursor = { streamId: "simulation", sequence: 3 };
  const runtime = simulationRuntime({
    waits: [wait([], true, 0), wait(firstEvents, false, 2), wait(secondEvents, false, 3)],
    cycles: [firstBriefing, secondBriefing]
  });
  const provider = createFakeAiProvider([hold("Opening cue acknowledged."), hold("Turn change observed.")]);
  const journal = new MemoryJournal();
  const controller = new AiSessionController({ runtime, provider, journal });
  const summary = await controller.run({ sessionId: "offline-simulation", timeoutSeconds: 1, maxCycles: 3 });
  const packets = provider.requests.map((request) => request.packet);
  return {
    passed: summary.failures === 0 && summary.providerCalls === 2,
    provider: provider.id,
    ...summary,
    baselineBytes: packets[0]?.inputBytes ?? 0,
    deltaBytes: packets[1]?.inputBytes ?? 0,
    unchangedSectionsOmitted: packets[1]?.omittedUnchanged.length ?? 0,
    journalEntries: journal.entries.length
  };
}

function simulationRuntime({ waits, cycles }) {
  return {
    async call({ capabilityName }) {
      if (capabilityName === "wait_for_events") return { ok: true, data: waits.shift() };
      if (capabilityName === "run_dm_cycle") return { ok: true, data: cycles.shift() };
      throw new Error(`Simulation does not execute ${capabilityName}.`);
    }
  };
}

function wait(events, timedOut, sequence) {
  return {
    recentEvents: { streamId: "simulation", latestSequence: sequence, events },
    cursorReset: false,
    timedOut,
    waitedMs: timedOut ? 1000 : 10,
    nextCursor: { streamId: "simulation", sequence }
  };
}

function briefing(events, sequence) {
  return {
    campaignSummary: { campaignId: "simulation", name: "Offline Simulation", ruleset: "5E" },
    currentEncounter: { active: false, activeCombatantId: null },
    combatTracker: { round: 0, combatants: [] },
    party: { members: [{ id: "pc-1", name: "Test Hero", classLevel: "Fighter 1" }] },
    mapScene: { playStyle: "theater_of_the_mind", tokens: [] },
    sessionContinuity: { available: false, latest: null, history: [] },
    sessionOperations: { status: "active", held: false, approvalPolicy: { mode: "manual", automaticCapabilities: [], alwaysManualCapabilities: [] } },
    recentEvents: { streamId: "simulation", latestSequence: sequence, events },
    cursorReset: false,
    nextCursor: { streamId: "simulation", sequence }
  };
}

function event(sequence, type) {
  return { sequence, type, occurredAt: "2026-08-19T12:00:00.000Z", visibility: "gm", data: {} };
}

function hold(summary) {
  return {
    decision: "hold",
    summary,
    rationale: "The offline fake provider never proposes an application mutation.",
    usage: { inputTokens: 100, cachedInputTokens: 0, outputTokens: 12, reasoningTokens: 4, costMicros: 0 }
  };
}
