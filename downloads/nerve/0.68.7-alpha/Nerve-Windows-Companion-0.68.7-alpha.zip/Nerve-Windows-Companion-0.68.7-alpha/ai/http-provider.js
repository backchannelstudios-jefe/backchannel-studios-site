import { NerveError } from "../core/errors.js";
import { defineAiProvider } from "./provider-contract.js";
import {
  createProviderInput,
  NERVE_DECISION_SCHEMA,
  NERVE_PROVIDER_INSTRUCTIONS,
  normalizeDecisionEnvelope,
  parseJsonText
} from "./provider-prompt.js";

const PROVIDER_SPECS = Object.freeze({
  openai: { apiKeyEnvironment: "OPENAI_API_KEY", endpoint: "https://api.openai.com/v1/responses" },
  anthropic: { apiKeyEnvironment: "ANTHROPIC_API_KEY", endpoint: "https://api.anthropic.com/v1/messages" },
  gemini: { apiKeyEnvironment: "GEMINI_API_KEY", endpoint: "https://generativelanguage.googleapis.com/v1beta/models" },
  xai: { apiKeyEnvironment: "XAI_API_KEY", endpoint: "https://api.x.ai/v1/responses" }
});

export function createHttpAiProvider({
  id,
  model,
  apiKey,
  fetchImpl = globalThis.fetch,
  timeoutMs = 60000,
  maxOutputTokens = 1200
}) {
  const spec = PROVIDER_SPECS[id];
  if (!spec) throw new NerveError("UNKNOWN_AI_PROVIDER", `Unknown AI provider: ${id}`);
  if (typeof model !== "string" || model.trim().length === 0) throw new NerveError("AI_MODEL_REQUIRED", `${id} requires an explicit model ID.`);
  if (typeof apiKey !== "string" || apiKey.length === 0) throw new NerveError("AI_API_KEY_REQUIRED", `${spec.apiKeyEnvironment} is not set.`);
  if (typeof fetchImpl !== "function") throw new NerveError("AI_FETCH_UNAVAILABLE", "This Node runtime does not provide fetch.");
  if (!Number.isInteger(maxOutputTokens) || maxOutputTokens <= 0 || maxOutputTokens > 100000) throw new NerveError("AI_OUTPUT_LIMIT_INVALID", "maxOutputTokens must be an integer from 1 to 100000.");

  return defineAiProvider({
    id,
    model,
    maxOutputTokens,
    async generateDecision(packet) {
      const request = createRequest({ id, spec, model, apiKey, packet, maxOutputTokens });
      let response;
      try {
        response = await fetchImpl(request.url, {
          method: "POST",
          headers: request.headers,
          body: JSON.stringify(request.body),
          signal: AbortSignal.timeout(timeoutMs)
        });
      } catch (error) {
        throw new NerveError("AI_PROVIDER_UNREACHABLE", `${id} request failed: ${error.message}`);
      }
      const payload = await readPayload(response, id);
      const envelope = extractEnvelope(id, payload);
      return { ...normalizeDecisionEnvelope(envelope), usage: extractUsage(id, payload) };
    }
  });
}

export function providerSpecifications() {
  return structuredClone(PROVIDER_SPECS);
}

function createRequest({ id, spec, model, apiKey, packet, maxOutputTokens }) {
  const input = createProviderInput(packet);
  if (id === "anthropic") {
    return {
      url: spec.endpoint,
      headers: { "content-type": "application/json", "x-api-key": apiKey, "anthropic-version": "2023-06-01" },
      body: {
        model, max_tokens: maxOutputTokens, system: NERVE_PROVIDER_INSTRUCTIONS,
        messages: [{ role: "user", content: input }],
        tools: [{ name: "submit_nerve_decision", description: "Submit exactly one supervised Nerve DM decision.", input_schema: NERVE_DECISION_SCHEMA }],
        tool_choice: { type: "tool", name: "submit_nerve_decision" }
      }
    };
  }
  if (id === "gemini") {
    const modelPath = model.replace(/^models\//, "");
    const generationConfig = {
      // Use the GenerateContent JSON fields directly. The newer responseFormat
      // field exposes mimeType as an enum over raw REST, so the SDK-style
      // "application/json" value is rejected by the v1beta endpoint.
      responseMimeType: "application/json",
      responseJsonSchema: geminiDecisionSchema(),
      maxOutputTokens
    };
    // Gemini 3 defaults to a larger thinking budget. Nerve decisions are small,
    // structured control replies, so LOW keeps the check and live turns quick and
    // leaves the configured output budget available for the required JSON.
    if (/^gemini-3(?:[.-]|$)/i.test(modelPath)) {
      generationConfig.thinkingConfig = { thinkingLevel: "LOW" };
    }
    return {
      url: `${spec.endpoint}/${encodeURIComponent(modelPath)}:generateContent`,
      headers: { "content-type": "application/json", "x-goog-api-key": apiKey },
      body: {
        systemInstruction: { parts: [{ text: NERVE_PROVIDER_INSTRUCTIONS }] },
        contents: [{ role: "user", parts: [{ text: input }] }],
        generationConfig
      }
    };
  }
  return {
    url: spec.endpoint,
    headers: { "content-type": "application/json", authorization: `Bearer ${apiKey}` },
    body: {
      model, instructions: NERVE_PROVIDER_INSTRUCTIONS,
      input: [{ role: "user", content: [{ type: "input_text", text: input }] }],
      max_output_tokens: maxOutputTokens, store: false,
      text: { format: { type: "json_schema", name: "nerve_dm_decision", strict: true, schema: NERVE_DECISION_SCHEMA } }
    }
  };
}

function geminiDecisionSchema() {
  // Gemini accepts a documented subset of JSON Schema. Local response
  // normalization still enforces the string bounds omitted here.
  return {
    type: NERVE_DECISION_SCHEMA.type,
    additionalProperties: NERVE_DECISION_SCHEMA.additionalProperties,
    required: [...NERVE_DECISION_SCHEMA.required],
    properties: Object.fromEntries(Object.entries(NERVE_DECISION_SCHEMA.properties).map(([name, property]) => [name, {
      type: property.type,
      ...(property.enum ? { enum: [...property.enum] } : {})
    }]))
  };
}

async function readPayload(response, id) {
  let payload;
  try { payload = await response.json(); } catch { payload = null; }
  if (!response.ok) {
    const message = payload?.error?.message ?? payload?.message ?? `${response.status} ${response.statusText}`;
    const retryAfterMs = providerRetryAfterMs(response, payload, message);
    throw new NerveError("AI_PROVIDER_HTTP_ERROR", `${id} rejected the request: ${message}`, {
      provider: id,
      status: response.status,
      ...(retryAfterMs !== null ? { retryAfterMs } : {})
    });
  }
  if (!payload || typeof payload !== "object") throw new NerveError("AI_PROVIDER_INVALID_RESPONSE", `${id} returned an invalid response body.`);
  return payload;
}

export function providerRetryAfterMs(response, payload, message = "") {
  const headerValue = response?.headers?.get?.("retry-after");
  const headerSeconds = Number(headerValue);
  if (Number.isFinite(headerSeconds) && headerSeconds >= 0) return Math.ceil(headerSeconds * 1000);
  if (typeof headerValue === "string" && headerValue.trim()) {
    const headerDate = Date.parse(headerValue);
    if (Number.isFinite(headerDate)) return Math.max(0, headerDate - Date.now());
  }
  const details = Array.isArray(payload?.error?.details) ? payload.error.details : [];
  const retryDelay = details.find((item) => typeof item?.retryDelay === "string")?.retryDelay;
  const structured = durationMs(retryDelay);
  if (structured !== null) return structured;
  const match = String(message).match(/retry\s+in\s+([0-9]+(?:\.[0-9]+)?)\s*s(?:econds?)?/i);
  return match ? Math.ceil(Number(match[1]) * 1000) : null;
}

function durationMs(value) {
  const match = typeof value === "string" ? value.match(/^([0-9]+(?:\.[0-9]+)?)s$/i) : null;
  return match ? Math.ceil(Number(match[1]) * 1000) : null;
}

function extractEnvelope(id, payload) {
  if (id === "anthropic") {
    const tool = payload.content?.find((item) => item.type === "tool_use" && item.name === "submit_nerve_decision");
    if (!tool?.input) throw new NerveError("AI_PROVIDER_INVALID_RESPONSE", "Anthropic returned no Nerve decision tool result.");
    return tool.input;
  }
  if (id === "gemini") {
    const text = payload.candidates?.[0]?.content?.parts?.map((part) => part.text ?? "").join("");
    try { return parseJsonText(text); } catch (error) { throw new NerveError("AI_PROVIDER_INVALID_RESPONSE", `Gemini returned invalid decision JSON: ${error.message}`); }
  }
  const text = payload.output_text ?? payload.output?.flatMap((item) => item.content ?? []).find((item) => item.type === "output_text")?.text;
  try { return parseJsonText(text); } catch (error) { throw new NerveError("AI_PROVIDER_INVALID_RESPONSE", `${id} returned invalid decision JSON: ${error.message}`); }
}

function extractUsage(id, payload) {
  if (id === "anthropic") {
    return usage({
      inputTokens: payload.usage?.input_tokens,
      cachedInputTokens: payload.usage?.cache_read_input_tokens,
      outputTokens: payload.usage?.output_tokens
    });
  }
  if (id === "gemini") {
    return usage({
      inputTokens: payload.usageMetadata?.promptTokenCount,
      cachedInputTokens: payload.usageMetadata?.cachedContentTokenCount,
      outputTokens: payload.usageMetadata?.candidatesTokenCount,
      reasoningTokens: payload.usageMetadata?.thoughtsTokenCount
    });
  }
  return usage({
    inputTokens: payload.usage?.input_tokens,
    cachedInputTokens: payload.usage?.input_tokens_details?.cached_tokens,
    outputTokens: payload.usage?.output_tokens,
    reasoningTokens: payload.usage?.output_tokens_details?.reasoning_tokens
  });
}

function usage(value) {
  const result = { costMicros: 0 };
  for (const key of ["inputTokens", "cachedInputTokens", "outputTokens", "reasoningTokens"]) {
    const amount = Number(value[key] ?? 0);
    result[key] = Number.isInteger(amount) && amount >= 0 ? amount : 0;
  }
  return result;
}
