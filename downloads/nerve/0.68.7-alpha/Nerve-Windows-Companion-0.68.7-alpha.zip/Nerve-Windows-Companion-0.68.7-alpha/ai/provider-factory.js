import { NerveError } from "../core/errors.js";
import { createFakeAiProvider } from "./fake-provider.js";
import { createHttpAiProvider, providerSpecifications } from "./http-provider.js";
import { createOllamaAiProvider } from "./ollama-provider.js";

const ALIASES = Object.freeze({ chatgpt: "openai", claude: "anthropic", grok: "xai" });
const GUIDANCE = Object.freeze({
  openai: { displayName: "OpenAI / ChatGPT", recommendedModel: "gpt-5.6-luna", apiKeyUrl: "https://platform.openai.com/api-keys" },
  anthropic: { displayName: "Anthropic / Claude", recommendedModel: "claude-sonnet-5", apiKeyUrl: "https://console.anthropic.com/settings/keys" },
  gemini: { displayName: "Google Gemini", recommendedModel: "gemini-3.7-flash", apiKeyUrl: "https://aistudio.google.com/app/apikey" },
  xai: { displayName: "xAI / Grok", recommendedModel: "grok-4.6", apiKeyUrl: "https://console.x.ai/" },
  ollama: { displayName: "Ollama (local AI)", recommendedModel: "qwen3:4b", apiKeyUrl: null }
});

export function createConfiguredAiProvider({ provider = "fake", model, env = process.env, fetchImpl, timeoutMs, maxOutputTokens } = {}) {
  const id = ALIASES[provider] ?? provider;
  if (id === "fake") return createFakeAiProvider([], maxOutputTokens ?? 0);
  if (id === "ollama") return createOllamaAiProvider({
    model,
    ...(fetchImpl ? { fetchImpl } : {}), ...(timeoutMs ? { timeoutMs } : {}), ...(maxOutputTokens ? { maxOutputTokens } : {})
  });
  const spec = providerSpecifications()[id];
  if (!spec) throw new NerveError("UNKNOWN_AI_PROVIDER", `Unknown AI provider: ${provider}`);
  return createHttpAiProvider({
    id, model, apiKey: env[spec.apiKeyEnvironment],
    ...(fetchImpl ? { fetchImpl } : {}), ...(timeoutMs ? { timeoutMs } : {}), ...(maxOutputTokens ? { maxOutputTokens } : {})
  });
}

export function listConfiguredAiProviders(env = process.env) {
  return [
    { id: "fake", displayName: "Offline test (no AI charges)", aliases: [], apiKeyEnvironment: null, configured: true, modelRequired: false, recommendedModel: null, apiKeyUrl: null },
    { id: "ollama", ...GUIDANCE.ollama, aliases: [], apiKeyEnvironment: null, configured: true, modelRequired: true },
    ...Object.entries(providerSpecifications()).map(([id, spec]) => ({
      id,
      ...GUIDANCE[id],
      aliases: Object.entries(ALIASES).filter(([, target]) => target === id).map(([alias]) => alias),
      apiKeyEnvironment: spec.apiKeyEnvironment,
      configured: Boolean(env[spec.apiKeyEnvironment]),
      modelRequired: true
    }))
  ];
}
