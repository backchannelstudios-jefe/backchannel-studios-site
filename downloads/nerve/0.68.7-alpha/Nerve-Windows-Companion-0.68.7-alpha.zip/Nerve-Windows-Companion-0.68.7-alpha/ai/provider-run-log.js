import { appendFile, mkdir, readFile, writeFile } from "node:fs/promises";
import { dirname } from "node:path";

export class ProviderRunLog {
  #pending = Promise.resolve();
  constructor(path, { clock = () => new Date() } = {}) { this.path = path; this.clock = clock; }
  append(value) {
    const entry = { timestamp: this.clock().toISOString() };
    // Never store prompts, response prose, credentials or character data.
    for (const key of ["sessionId","cueId","provider","model","phase","errorCode","failureDomain","capability","inputBytes","approximateInputTokens","retryCount","nativeSuccess","requestedAt"]) {
      if (value[key] !== undefined) entry[key] = value[key];
    }
    const operation = this.#pending.catch(() => {}).then(async () => {
      await mkdir(dirname(this.path),{recursive:true});
      await appendFile(this.path,JSON.stringify(entry)+"\n","utf8");
      const entries = (await readFile(this.path,"utf8")).trim().split(/\r?\n/).slice(-10000).map(line=>JSON.parse(line));
      await writeFile(this.path.replace(/\.ndjson$/, "-summary.json"),JSON.stringify(summarizeProviderRuns(entries),null,2)+"\n");
    });
    this.#pending = operation;
    return operation;
  }
}

export function summarizeProviderRuns(entries) {
  const runs = new Map();
  for (const e of entries) {
    if (!e.cueId) continue;
    const key = `${e.sessionId}:${e.cueId}`;
    const run = runs.get(key) ?? { provider:e.provider ?? "unknown", model:e.model ?? null, phases:{}, retries:0, failures:[] };
    run.phases[e.phase] ??= e.timestamp;
    if(e.phase === "retry") run.retries++;
    if(e.errorCode) run.failures.push({domain:e.failureDomain ?? "unknown",code:e.errorCode});
    if(e.nativeSuccess !== undefined) run.nativeSuccess=e.nativeSuccess;
    runs.set(key,run);
  }
  const groups = new Map();
  for(const run of runs.values()) {
    const key=JSON.stringify([run.provider,run.model]);
    const group=groups.get(key) ?? {provider:run.provider,model:run.model,samples:0,completedResponses:0,incompleteResponses:0,retries:0,nativeSuccesses:0,nativeFailures:0,providerFailures:0,listenerFailures:0,nerveFailures:0,cancellations:0,responseSeconds:[]};
    group.samples++; group.retries+=run.retries;
    const start=run.phases.provider_started ?? run.phases.claimed;
    const end=run.phases.decision_received;
    if(start && end) {group.completedResponses++;group.responseSeconds.push(Math.max(0,(Date.parse(end)-Date.parse(start))/1000));}
    else group.incompleteResponses++;
    if(run.nativeSuccess===true)group.nativeSuccesses++;
    if(run.nativeSuccess===false)group.nativeFailures++;
    if(run.phases.cancelled)group.cancellations++;
    for(const f of run.failures) {if(f.domain === "provider")group.providerFailures++;else if(f.domain === "nerve")group.nerveFailures++;else if(f.domain === "listener")group.listenerFailures++;}
    groups.set(key,group);
  }
  return {schemaVersion:"0.1", timing:"AI/connector response time ends before human approval; unknown models remain null. Quality requires playtest review.",providers:[...groups.values()].map(g=>{
    const sorted=g.responseSeconds.sort((a,b)=>a-b),n=sorted.length;
    const median=n ? (sorted[Math.floor((n-1)/2)]+sorted[Math.floor(n/2)])/2 : null;
    const p95=n ? sorted[Math.max(0,Math.ceil(n*.95)-1)] : null;
    const {responseSeconds,...rest}=g;return {...rest,medianResponseSeconds:median,p95ResponseSeconds:p95};
  })};
}
