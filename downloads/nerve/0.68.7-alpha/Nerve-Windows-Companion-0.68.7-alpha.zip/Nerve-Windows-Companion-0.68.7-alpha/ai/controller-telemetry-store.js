import { appendFile, mkdir, readFile } from "node:fs/promises";
import { dirname } from "node:path";

export class ControllerTelemetryStore {
  constructor(path, { clock = () => new Date() } = {}) {
    if (!path) throw new TypeError("ControllerTelemetryStore requires a path.");
    this.path = path;
    this.clock = clock;
  }

  async appendResult({ sessionId, campaign, provider, model = null, result, progress }) {
    const entry = redactResult({
      schemaVersion: "0.1",
      timestamp: this.clock().toISOString(),
      sessionId,
      campaign,
      provider,
      model,
      result,
      progress
    });
    await mkdir(dirname(this.path), { recursive: true });
    await appendFile(this.path, `${JSON.stringify(entry)}\n`, "utf8");
    return entry;
  }

  async readAll() {
    let text;
    try {
      text = await readFile(this.path, "utf8");
    } catch (error) {
      if (error.code === "ENOENT") return [];
      throw error;
    }
    return text.split(/\r?\n/).filter(Boolean).map((line) => JSON.parse(line));
  }

  async summarize() {
    const entries = await this.readAll();
    const totals = { cycles: entries.length, providerCalls: 0, completed: 0, queued: 0, rejected: 0, blocked: 0, failures: 0 };
    const sessions = new Map();
    for (const entry of entries) {
      if (entry.providerCalled) totals.providerCalls += 1;
      if (entry.status === "completed") totals.completed += 1;
      else if (entry.status === "action_queued") totals.queued += 1;
      else if (entry.status === "action_rejected") totals.rejected += 1;
      else if (entry.status === "budget_blocked") totals.blocked += 1;
      else if (entry.status.endsWith("_failed")) totals.failures += 1;
      const session = sessions.get(entry.sessionId) ?? {
        sessionId: entry.sessionId, provider: entry.provider, model: entry.model ?? null,
        cycles: 0, providerCalls: 0, completed: 0, queued: 0, rejected: 0, blocked: 0, failures: 0,
        usage: null, startedAt: entry.timestamp, updatedAt: entry.timestamp
      };
      session.cycles += 1;
      if (entry.providerCalled) session.providerCalls += 1;
      if (entry.status === "completed") session.completed += 1;
      else if (entry.status === "action_queued") session.queued += 1;
      else if (entry.status === "action_rejected") session.rejected += 1;
      else if (entry.status === "budget_blocked") session.blocked += 1;
      else if (entry.status.endsWith("_failed")) session.failures += 1;
      session.usage = entry.usage ?? session.usage;
      session.updatedAt = entry.timestamp;
      sessions.set(entry.sessionId, session);
    }
    const latestUsage = [...entries].reverse().find((entry) => entry.usage)?.usage ?? null;
    return {
      schemaVersion: "0.1",
      path: this.path,
      ...totals,
      latest: entries.at(-1) ?? null,
      usage: latestUsage,
      recent: entries.slice(-20),
      sessionCount: sessions.size,
      sessions: [...sessions.values()].slice(-20)
    };
  }
}

function redactResult({ schemaVersion, timestamp, sessionId, campaign, provider, model, result, progress }) {
  return {
    schemaVersion,
    timestamp,
    sessionId,
    campaign,
    provider,
    model,
    status: result.status,
    providerCalled: result.providerCalled,
    ...(result.packet ? {
      packet: {
        sequence: result.packet.sequence,
        baseline: result.packet.baseline,
        inputBytes: result.packet.inputBytes,
        approximateInputTokens: result.packet.approximateInputTokens,
        eventCount: result.packet.events.length,
        changedSections: Object.keys(result.packet.state),
        omittedUnchanged: result.packet.omittedUnchanged
      }
    } : {}),
    ...(result.response ? {
      decision: result.response.decision,
      proposedCapability: result.response.action?.capabilityName ?? null,
      providerUsage: result.response.usage
    } : {}),
    ...(result.actionResult ? {
      actionAccepted: Boolean(result.actionResult.ok) || result.status === "action_queued",
      actionQueued: result.status === "action_queued",
      actionErrorCode: result.actionResult.error?.code ?? null,
      actionValidationErrors: safeValidationErrors(result.actionResult.error?.details?.errors)
    } : {}),
    ...(result.error ? {
      errorCode: result.error.code,
      errorHttpStatus: safeHttpStatus(result.error.details?.status),
      validationErrors: safeValidationErrors(result.error.details?.errors)
    } : {}),
    ...(result.transient ? { transient: true, retryAfterMs: result.retryAfterMs } : {}),
    ...(result.status === "lifecycle_waiting" ? { retryAfterMs: result.retryAfterMs } : {}),
    ...(result.reason ? { stopReason: result.reason } : {}),
    usage: result.usage ?? null,
    progress
  };
}

function safeHttpStatus(value) {
  return Number.isInteger(value) && value >= 100 && value <= 599 ? value : null;
}

function safeValidationErrors(value) {
  if (!Array.isArray(value)) return [];
  return value.slice(0, 10).filter((item) => typeof item === "string").map((item) => item.slice(0, 240));
}
