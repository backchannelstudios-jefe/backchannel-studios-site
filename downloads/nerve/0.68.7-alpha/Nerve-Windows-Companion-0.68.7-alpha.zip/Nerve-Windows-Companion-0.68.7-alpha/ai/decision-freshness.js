// Pulse housekeeping must not invalidate an answer, but a newer player choice,
// native roll or turn must. Apply again at native execution after GM approval.
export const DECISION_INVALIDATING_EVENTS = new Set([
  "combat.turn_started", "combat.damage", "combat.damage_resolved", "combat.resolved", "combat.healing", "combat.changed",
  "roll.attack", "roll.damage", "roll.heal", "roll.save", "roll.skill", "roll.check",
  "power.action_outcome", "combatant.action_outcome", "player.chat_message",
  "gm.guidance", "player.roll_response", "player.prompt_response", "session.ended"
]);

export function isDecisionStale(cursor, recentEvents) {
  if (!cursor || !recentEvents) return false;
  if (cursor.streamId && recentEvents.streamId && cursor.streamId !== recentEvents.streamId) return true;
  const sequence = Number(cursor.sequence);
  if (!Number.isFinite(sequence)) return true;
  const events = Array.isArray(recentEvents.events) ? recentEvents.events : [];
  if (events.length && Number(events[0].sequence) > sequence + 1) return true;
  return events.some((event) => Number(event.sequence) > sequence && DECISION_INVALIDATING_EVENTS.has(event.type));
}
