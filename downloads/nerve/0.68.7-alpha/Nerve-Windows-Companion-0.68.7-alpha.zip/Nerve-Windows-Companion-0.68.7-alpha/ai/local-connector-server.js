import { ProviderRunLog } from "./provider-run-log.js";
import { createServer } from "node:http";
import { timingSafeEqual } from "node:crypto";
import { mkdir, readFile, unlink, writeFile } from "node:fs/promises";
import { dirname, join } from "node:path";
import { randomUUID } from "node:crypto";
import { assertReadableSnapshot, campaignPaths } from "../cli/paths.js";
import { createNerve } from "../core/create-nerve.js";
import {
  findPendingAiCue,
  parseCompanionDecisionText,
  prepareCompanionHandoff,
  submitCompanionDecision
} from "./companion-handoff.js";
import { ControllerStatusStore } from "./controller-status-store.js";
import { createFguControllerLifecycleProbe } from "../adapters/fantasy-grounds-unity/bridge/controller-lifecycle.js";
import { SessionContextReducer } from "./context-delta.js";
import { APP_CONNECTORS, normalizeAppConnector, runConfiguredAppListener } from "./app-listeners.js";

const MAX_BODY_BYTES = 50_000;
const MAX_CUE_WAIT_SECONDS = 30;

export async function runLocalConnector({
  campaign,
  fguDataPath,
  token,
  host = "127.0.0.1",
  port = 47832,
  allowWrites = false,
  autoCodexListener = false,
  model = null,
  appConnector = null,
  customConfigPath = null,
  codexPath = null,
  stopPollMs = 1000,
  runAppListener = runConfiguredAppListener
}) {
  if (!token || Buffer.byteLength(token, "utf8") < 24) throw new Error("Connector token must be at least 24 bytes.");
  const paths = campaignPaths({ fguDataPath, campaign });
  const statusStore = new ControllerStatusStore({
    statusPath: paths.controllerStatusPath,
    stopPath: paths.controllerStopPath
  });
  const sessionId = `connector-${randomUUID()}`;
  const nerve = createNerve({
    toolProfile: "session",
    enableWriteCapabilities: allowWrites,
    allowWrite: allowWrites,
    snapshotPath: paths.snapshotPath
  });
  const runLog = new ProviderRunLog(join(dirname(paths.snapshotPath), "nerve-provider-runs.ndjson"));
  const logRun = (phase, details = {}) => runLog.append({sessionId, cueId: statusDetails.cueId ?? cached?.cue?.cueId, provider: appConnector ?? (autoCodexListener ? "codex" : "external"), model: statusDetails.model ?? null, phase, ...details}).catch(() => {});
  const contextReducer = new SessionContextReducer();
  const lifecycleProbe = createFguControllerLifecycleProbe(paths);
  let cached = null;
  let completedCueId = null;
  let submittingCueId = null;
  const pendingNative = new Map();
  let stopReason = "stop_requested";
  let closing = false;
  let statusWrite = Promise.resolve();
  let statusDetails = { connectorState: "starting", cueId: null };
  let listenerTask = null;
  const listenerAbort = new AbortController();

  const writeStatus = async (status, extra = {}) => {
    if (closing && status === "running") return;
    statusDetails = { ...statusDetails, ...extra };
    const nextStatus = {
      status,
      sessionId,
      campaign,
      provider: "connector",
      connectionMode: "connector",
      model,
      maxOutputTokens: 0,
      endpoint: `http://${host}:${port}`,
      allowWrites,
      ...statusDetails
    };
    statusWrite = statusWrite.catch(() => {}).then(() => statusStore.write(nextStatus));
    return statusWrite;
  };

  const readiness = await nerve.runtime.call({ capabilityName: "run_dm_cycle", sessionId: `${sessionId}-preflight`, arguments: { eventLimit: 1 } });
  if (!readiness.ok) {
    await writeStatus("failed", {
      connectorState: "failed", listenerPhase: "failed", listenerErrorCode: "CAMPAIGN_CONTEXT_INVALID",
      listenerMessage: `Campaign data could not be prepared: ${readiness.error?.details?.errors?.[0] || readiness.error?.message || "unknown error"}`.slice(0, 500)
    });
    return;
  }

  const noteListener = async () => {
    const now = new Date();
    await writeStatus("running", {
      listenerState: "connected",
      listenerProtocol: "long_poll_v1",
      listenerLastSeenAt: now.toISOString(),
      listenerLastSeenAtEpoch: Math.floor(now.getTime() / 1000)
    });
  };

  const server = createServer(async (request, response) => {
    try {
      const requestUrl = new URL(request.url ?? "/", `http://${host}:${port}`);
      response.setHeader("Cache-Control", "no-store");
      response.setHeader("Content-Type", "application/json; charset=utf-8");
      response.setHeader("X-Content-Type-Options", "nosniff");
      if (!authorized(request.headers.authorization, token)) return send(response, 401, { error: "UNAUTHORIZED" });
      if (request.method === "GET" && requestUrl.pathname === "/v1/status") {
        const snapshot = await assertReadableSnapshot(paths.snapshotPath);
        return send(response, 200, {
          schemaVersion: "0.1", status: "ready", campaign,
          pendingCue: Boolean(findPendingAiCue(snapshot)), allowWrites
        });
      }
      if (request.method === "GET" && requestUrl.pathname === "/v1/cues/next") {
        const waitSeconds = boundedCueWait(requestUrl.searchParams.get("waitSeconds"));
        await noteListener();
        const { snapshot, cue } = await waitForPendingCue(paths.snapshotPath, waitSeconds, request, completedCueId);
        if (!cue) return send(response, 204, null);
        if (!cached || cached.cue.cueId !== cue.cueId) {
          cached = await prepareCompanionHandoff({
            nerve, snapshot, campaign, sessionId,
            contextReducer, libraryPath: paths.libraryPath
          });
          await logRun("claimed", {cueId:cue.cueId,requestedAt:cue.requestedAt,inputBytes:cached.promptBytes,approximateInputTokens:cached.approximatePromptTokens});
        }
        await writeStatus("running", {
          connectorState: "cue_claimed",
          cueId: cue.cueId,
          lastCueClaimedAt: new Date().toISOString(),
          lastCueClaimedAtEpoch: Math.floor(Date.now() / 1000)
        });
        return send(response, 200, cached);
      }
      const decisionMatch = request.method === "POST" && requestUrl.pathname.match(/^\/v1\/cues\/([^/]+)\/decision$/);
      if (decisionMatch) {
        const cueId = decodeURIComponent(decisionMatch[1]);
        if (completedCueId === cueId || submittingCueId === cueId) return send(response,409,{error:"CUE_ALREADY_COMPLETED",message:"This cue is already submitted; check its existing result or approval."});
        const body = await readBody(request);
        const decision = parseCompanionDecisionText(body);
        const snapshot = await assertReadableSnapshot(paths.snapshotPath);
        await logRun("decision_received", {cueId,capability:decision.action?.capabilityName ?? null});
        if (decision.decision === "propose_action") await writeStatus("running", {connectorState:"awaiting_approval",listenerPhase:"awaiting_approval",decisionReceivedAt:new Date().toISOString()});
        if (completedCueId === cueId || submittingCueId === cueId) return send(response,409,{error:"CUE_ALREADY_COMPLETED"});
        submittingCueId = cueId;
        let result;
        try { result = await submitCompanionDecision({ nerve, snapshot, cueId, sessionId, decision, decisionCursor: cached?.decisionCursor }); }
        finally { submittingCueId = null; }
        if (closing) return;
        if (result.status === "action_queued" && result.actionResult?.requestId) pendingNative.set(result.actionResult.requestId, {cueId,capability:decision.action?.capabilityName});
        await logRun(result.status, {cueId,capability:decision.action?.capabilityName ?? null,
          ...(result.actionResult ? {nativeSuccess: result.status === "action_queued" ? undefined : result.actionResult.ok} : {}),
          errorCode:result.actionResult?.error?.code,failureDomain:result.status === "action_rejected" ? "nerve" : undefined});
        cached = null;
        const completedAt = new Date().toISOString();
        completedCueId = cueId;
        await writeStatus("running", {
          connectorState: "ready", cueId: null,
          lastCueClaimedAtEpoch: null,
          lastResult: {
            status: result.status,
            decision: decision.decision,
            summary: decision.summary ?? null,
            errorCode: result.actionResult?.error?.code ?? null,
            errorMessage: result.actionResult?.error?.message ?? null,
            validationErrors: result.actionResult?.error?.details?.errors?.slice(0, 3) ?? [],
            cueId,
            timestamp: completedAt
          }
        });
        return send(response, result.status === "action_rejected" ? 409 : 200, result);
      }
      return send(response, 404, { error: "NOT_FOUND" });
    } catch (error) {
      await logRun("failed", {errorCode:error.code ?? "CONNECTOR_REQUEST_FAILED",failureDomain:"nerve"});
      const status = error.code === "BODY_TOO_LARGE" ? 413 :
        new Set(["CUE_ALREADY_COMPLETED", "CUE_REPLACED"]).has(error.code) ? 409 : 400;
      return send(response, status, { error: error.code || "CONNECTOR_REQUEST_FAILED", message: error.message });
    }
  });

  await statusStore.clearStopRequest();
  await new Promise((resolve, reject) => {
    server.once("error", reject);
    server.listen(port, host, resolve);
  });
  await writeStatus("running", {
    connectorState: "ready",
    listenerState: "not_connected",
    startedAt: new Date().toISOString(),
    pid: process.pid
  });

  const selectedApp = appConnector || (autoCodexListener ? "codex" : null);
  if (selectedApp) {
    const appId = normalizeAppConnector(selectedApp);
    const app = APP_CONNECTORS[appId];
    listenerTask = runAppListener({
      endpoint: `http://${host}:${port}`,
      token,
      signal: listenerAbort.signal,
      appConnector: appId,
      customConfigPath,
      codexPath,
      model,
      onStatus: async (details) => {
        if (details.listenerPhase === "responding" && statusDetails.listenerPhase !== "responding") await logRun("provider_started", {cueId:details.cueId});
        if (details.listenerPhase === "reconnecting") await logRun("retry");
        await writeStatus("running", details);
      }
    }).catch(async (error) => {
      const code = typeof error?.code === "string" ? error.code : "APP_LISTENER_FAILED";
      const failedCueId = statusDetails.cueId ?? cached?.cue?.cueId ?? null;
      const failedAt = new Date().toISOString();
      const listenerMessage = safeListenerMessage(error, app.label);
      await logRun("failed", {cueId:failedCueId,errorCode:code,failureDomain:code === "CAMPAIGN_CONTEXT_INVALID" ? "nerve" : "listener"});
      if (failedCueId) {
        completedCueId = failedCueId;
        cached = null;
      }
      await writeStatus("running", {
        connectorState: "failed",
        cueId: null,
        lastCueClaimedAt: null,
        lastCueClaimedAtEpoch: null,
        listenerState: "not_connected",
        listenerKind: app.listenerKind,
        listenerName: app.label,
        listenerPhase: "failed",
        listenerErrorCode: code,
        listenerMessage,
        ...(failedCueId ? { lastResult: {
          status: "provider_failed",
          decision: null,
          summary: null,
          errorCode: code,
          errorMessage: listenerMessage,
          validationErrors: [],
          transient: false,
          cueId: failedCueId,
          timestamp: failedAt
        } } : {})
      });
    });
  }

  const stopConnector = () => {
    if (closing) return;
    closing = true;
    void logRun("cancelled");
    listenerAbort.abort();
    server.close();
    server.closeAllConnections();
  };
  const stopTimer = setInterval(async () => {
    try {
      if (pendingNative.size) {
        try {
          const ack = JSON.parse((await readFile(join(dirname(paths.snapshotPath),"nerve-command-result.json"),"utf8")).replace(/^\uFEFF/,""));
          const pending = pendingNative.get(ack.requestId);
          if(pending) { pendingNative.delete(ack.requestId); await logRun("native_completed",{...pending,nativeSuccess:ack.ok === true,errorCode:ack.error?.code,failureDomain:ack.ok === false ? "nerve" : undefined}); }
        } catch { /* A missing/partial acknowledgement is not a failed action. */ }
      }
      if (await statusStore.stopRequested(sessionId)) return stopConnector();
      const lifecycle = await lifecycleProbe();
      if (lifecycle.stop) {
        stopReason = lifecycle.reason;
        stopConnector();
      }
    } catch { /* A transient file read must not terminate the connector. */ }
  }, stopPollMs);
  stopTimer.unref();

  await new Promise((resolve) => server.once("close", resolve));
  clearInterval(stopTimer);
  listenerAbort.abort();
  if (listenerTask) await listenerTask;
  await statusStore.clearStopRequest();
  await writeStatus("stopped", { connectorState: "stopped", stopReason, stoppedAt: new Date().toISOString() });
}

function safeListenerMessage(error, label = "AI app") {
  const fallback = `The signed-in ${label} listener could not start.`;
  const message = String(error?.message || fallback)
    .replace(/[\r\n]+/g, " ")
    .slice(0, 300);
  return /token|secret|authorization|bearer/i.test(message)
    ? fallback
    : message;
}

function boundedCueWait(value) {
  if (value === null || value === "") return 0;
  const seconds = Number(value);
  if (!Number.isInteger(seconds) || seconds < 0 || seconds > MAX_CUE_WAIT_SECONDS) {
    throw new Error(`waitSeconds must be an integer from 0 to ${MAX_CUE_WAIT_SECONDS}.`);
  }
  return seconds;
}

async function waitForPendingCue(snapshotPath, waitSeconds, request, ignoredCueId = null) {
  const deadline = Date.now() + waitSeconds * 1000;
  do {
    const snapshot = await assertReadableSnapshot(snapshotPath);
    const cue = findPendingAiCue(snapshot);
    if ((cue && cue.cueId !== ignoredCueId) || Date.now() >= deadline || request.destroyed) {
      return { snapshot, cue: cue?.cueId === ignoredCueId ? null : cue };
    }
    await new Promise((resolve) => setTimeout(resolve, 250));
  } while (true);
}

export async function ensureConnectorToken(path) {
  try {
    const existing = (await readFile(path, "utf8")).trim();
    if (Buffer.byteLength(existing, "utf8") >= 24) return existing;
  } catch (error) {
    if (error.code !== "ENOENT") throw error;
  }
  const token = randomUUID().replaceAll("-", "") + randomUUID().replaceAll("-", "");
  await mkdir(dirname(path), { recursive: true });
  await writeFile(path, `${token}\n`, { encoding: "utf8", mode: 0o600 });
  return token;
}

function authorized(header, token) {
  const supplied = typeof header === "string" && header.startsWith("Bearer ") ? header.slice(7) : "";
  const left = Buffer.from(supplied, "utf8");
  const right = Buffer.from(token, "utf8");
  return left.length === right.length && timingSafeEqual(left, right);
}

async function readBody(request) {
  const chunks = [];
  let size = 0;
  for await (const chunk of request) {
    size += chunk.length;
    if (size > MAX_BODY_BYTES) {
      const error = new Error("The connector response is too large.");
      error.code = "BODY_TOO_LARGE";
      throw error;
    }
    chunks.push(chunk);
  }
  return Buffer.concat(chunks).toString("utf8");
}

function send(response, status, value) {
  response.statusCode = status;
  if (status === 204) return response.end();
  response.end(`${JSON.stringify(value)}\n`);
}
