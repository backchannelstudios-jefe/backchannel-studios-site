import { NerveError } from "../core/errors.js";

const DECISIONS = new Set(["hold", "request_clarification", "propose_action"]);

export function defineAiProvider(provider) {
  if (!provider || typeof provider !== "object") {
    throw new NerveError("INVALID_AI_PROVIDER", "AI provider must be an object.");
  }
  if (!/^[a-z][a-z0-9-]*$/.test(provider.id ?? "")) {
    throw new NerveError("INVALID_AI_PROVIDER", "AI provider requires a stable lowercase ID.");
  }
  if (typeof provider.generateDecision !== "function") {
    throw new NerveError("INVALID_AI_PROVIDER", "AI provider requires generateDecision(packet, context).");
  }
  return Object.freeze(provider);
}

export function validateProviderResponse(response) {
  if (!isPlainObject(response) || !DECISIONS.has(response.decision)) {
    throw new NerveError("INVALID_AI_RESPONSE", "Provider response has an invalid decision.");
  }
  requireBoundedString(response.summary, "summary", 300);
  requireBoundedString(response.rationale, "rationale", 1000);

  if (response.decision === "propose_action") {
    if (!isPlainObject(response.action) || typeof response.action.capabilityName !== "string") {
      throw new NerveError("INVALID_AI_RESPONSE", "A proposed action requires a capabilityName.");
    }
    if (!isPlainObject(response.action.arguments)) {
      throw new NerveError("INVALID_AI_RESPONSE", "A proposed action requires object arguments.");
    }
  } else if (response.action !== undefined) {
    throw new NerveError("INVALID_AI_RESPONSE", "Only propose_action may include an action.");
  }

  const usage = normalizeUsage(response.usage);
  return {
    decision: response.decision,
    summary: response.summary,
    rationale: response.rationale,
    ...(response.action ? { action: structuredClone(response.action) } : {}),
    usage
  };
}

function normalizeUsage(value = {}) {
  if (!isPlainObject(value)) {
    throw new NerveError("INVALID_AI_RESPONSE", "Provider usage must be an object.");
  }
  const usage = {};
  for (const field of ["inputTokens", "cachedInputTokens", "outputTokens", "reasoningTokens", "costMicros"]) {
    const amount = value[field] ?? 0;
    if (!Number.isInteger(amount) || amount < 0) {
      throw new NerveError("INVALID_AI_RESPONSE", `Provider usage ${field} must be a non-negative integer.`);
    }
    usage[field] = amount;
  }
  return usage;
}

function requireBoundedString(value, name, maximum) {
  if (typeof value !== "string" || value.length < 1 || value.length > maximum) {
    throw new NerveError("INVALID_AI_RESPONSE", `${name} must contain 1-${maximum} characters.`);
  }
}

function isPlainObject(value) {
  return value !== null && typeof value === "object" && !Array.isArray(value);
}
