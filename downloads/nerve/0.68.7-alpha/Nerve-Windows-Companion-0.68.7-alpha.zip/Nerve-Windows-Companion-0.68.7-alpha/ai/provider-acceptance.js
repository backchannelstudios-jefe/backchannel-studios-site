import { createHttpAiProvider } from "./http-provider.js";

const PROVIDERS = ["openai", "anthropic", "gemini", "xai"];
const DECISIONS = [
  { decision: "hold", summary: "No action needed.", rationale: "No meaningful trigger.", capabilityName: "", argumentsJson: "{}" },
  { decision: "request_clarification", summary: "Clarify the intended target.", rationale: "The packet does not establish one.", capabilityName: "", argumentsJson: "{}" },
  { decision: "propose_action", summary: "Offer a concise scene cue.", rationale: "The GM explicitly requested narration.", capabilityName: "send_chat", argumentsJson: "{\"text\":\"The passage waits ahead.\",\"visibility\":\"all\",\"confirmed\":true}" }
];

export async function runProviderAcceptance() {
  const providers = [];
  for (const id of PROVIDERS) providers.push(await evaluateProvider(id));
  return {
    schemaVersion: "0.1", evaluation: "nerve-provider-wire-acceptance", networkCalled: false,
    passed: providers.every((item) => item.passed),
    passedProviders: providers.filter((item) => item.passed).length,
    providerCount: providers.length,
    cases: providers.reduce((sum, item) => sum + item.cases.length, 0),
    providers
  };
}

async function evaluateProvider(id) {
  const requests = [];
  let index = 0;
  const provider = createHttpAiProvider({
    id, model: "acceptance-model", apiKey: "acceptance-secret", maxOutputTokens: 240,
    fetchImpl: async (url, options) => {
      const envelope = DECISIONS[index++];
      requests.push({ url, headers: options.headers, body: JSON.parse(options.body) });
      return responseFor(id, envelope);
    }
  });
  const cases = [];
  for (let caseIndex = 0; caseIndex < DECISIONS.length; caseIndex += 1) {
    try {
      const decision = await provider.generateDecision(packet(caseIndex + 1));
      const expected = DECISIONS[caseIndex];
      const checks = requestChecks(id, requests[caseIndex]);
      const passed = decision.decision === expected.decision
        && (expected.decision !== "propose_action" || decision.action?.capabilityName === expected.capabilityName)
        && checks.every((item) => item.passed);
      cases.push({ id: expected.decision, passed, decision: decision.decision, proposedCapability: decision.action?.capabilityName ?? null, checks });
    } catch (error) {
      cases.push({ id: DECISIONS[caseIndex].decision, passed: false, error: { code: error.code ?? "ERROR", message: error.message }, checks: [] });
    }
  }
  return {
    id,
    aliases: id === "openai" ? ["chatgpt"] : id === "anthropic" ? ["claude"] : id === "xai" ? ["grok"] : [],
    passed: cases.every((item) => item.passed), requestCount: requests.length, cases
  };
}

function requestChecks(id, request) {
  const encoded = JSON.stringify(request.body);
  const checks = [
    check("https-endpoint", request.url.startsWith("https://")),
    check("key-not-in-body", !encoded.includes("acceptance-secret")),
    check("bounded-output", outputLimit(id, request.body) === 240),
    check("decision-schema", hasDecisionSchema(id, request.body))
  ];
  if (id === "openai" || id === "xai") checks.push(check("stateless", request.body.store === false));
  if (id === "anthropic") checks.push(check("forced-tool", request.body.tool_choice?.name === "submit_nerve_decision"));
  if (id === "gemini") checks.push(check("json-response", request.body.generationConfig?.responseMimeType === "application/json"));
  return checks;
}

function outputLimit(id, body) { return id === "anthropic" ? body.max_tokens : id === "gemini" ? body.generationConfig?.maxOutputTokens : body.max_output_tokens; }
function hasDecisionSchema(id, body) {
  if (id === "anthropic") return body.tools?.[0]?.input_schema?.required?.includes("decision") === true;
  if (id === "gemini") return body.generationConfig?.responseJsonSchema?.required?.includes("decision") === true;
  return body.text?.format?.schema?.required?.includes("decision") === true;
}
function check(id, passed) { return { id, passed: Boolean(passed) }; }
function packet(sequence) {
  return { schemaVersion: "0.1", sessionId: "provider-acceptance", sequence, baseline: sequence === 1, state: {}, events: [], omittedUnchanged: [], inputBytes: 256, approximateInputTokens: 64 };
}
function responseFor(id, envelope) {
  const usage = { input_tokens: 64, output_tokens: 20, input_tokens_details: { cached_tokens: 0 }, output_tokens_details: { reasoning_tokens: 0 } };
  let payload;
  if (id === "anthropic") payload = { content: [{ type: "tool_use", name: "submit_nerve_decision", input: envelope }], usage: { input_tokens: 64, output_tokens: 20 } };
  else if (id === "gemini") payload = { candidates: [{ content: { parts: [{ text: JSON.stringify(envelope) }] } }], usageMetadata: { promptTokenCount: 64, candidatesTokenCount: 20 } };
  else payload = { output: [{ content: [{ type: "output_text", text: JSON.stringify(envelope) }] }], usage };
  return { ok: true, status: 200, statusText: "OK", async json() { return payload; } };
}
