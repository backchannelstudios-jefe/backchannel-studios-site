import { UsageLedger } from "./usage-ledger.js";

export async function runControllerWorker({
  nerve,
  provider,
  statusStore,
  campaign,
  sessionId,
  signal,
  timeoutSeconds = 30,
  eventLimit = 25,
  maxCycles = Number.POSITIVE_INFINITY,
  budgets = {},
  telemetryStore = null,
  lifecycleProbe = null
}) {
  const startedAt = new Date().toISOString();
  const controllerSignal = new AbortController();
  const abort = () => controllerSignal.abort();
  signal?.addEventListener("abort", abort, { once: true });

  const baseStatus = {
    sessionId,
    campaign,
    provider: provider.id,
    model: provider.model ?? null,
    maxOutputTokens: provider.maxOutputTokens ?? 0,
    budgets: structuredClone(budgets),
    pid: process.pid,
    startedAt
  };
  let lastResult = null;
  await statusStore.write({ ...baseStatus, status: "starting" });

  try {
    const usageLedger = new UsageLedger(budgets);
    const controller = nerve.createController({ provider, usageLedger });
    await statusStore.write({ ...baseStatus, status: "running", summary: emptySummary(sessionId) });
    const summary = await controller.run({
      sessionId,
      signal: controllerSignal.signal,
      timeoutSeconds,
      eventLimit,
      maxCycles,
      lifecycleProbe,
      bootstrapPendingCue: true,
      onResult: async (result, progress) => {
        if (!new Set(["idle", "observed", "lifecycle_waiting"]).has(result.status)) lastResult = statusResult(result);
        if (telemetryStore) {
          await telemetryStore.appendResult({ sessionId, campaign, provider: provider.id, model: provider.model ?? null, result, progress });
        }
        if (await statusStore.stopRequested(sessionId)) controllerSignal.abort();
        await statusStore.write({
          ...baseStatus,
          status: controllerSignal.signal.aborted ? "stopping" : "running",
          summary: progress,
          usage: usageLedger.get(sessionId),
          lastResult
        });
      }
    });
    await statusStore.clearStopRequest();
    await statusStore.write({
      ...baseStatus,
      status: "stopped",
      stoppedAt: new Date().toISOString(),
      summary,
      usage: summary.usage,
      lastResult
    });
    return summary;
  } catch (error) {
    await statusStore.write({
      ...baseStatus,
      status: "failed",
      stoppedAt: new Date().toISOString(),
      error: { code: error.code ?? "CONTROLLER_FAILED", message: error.message }
    });
    throw error;
  } finally {
    signal?.removeEventListener("abort", abort);
  }
}

function emptySummary(sessionId) {
  return {
    sessionId,
    cycles: 0,
    idle: 0,
    observed: 0,
    providerCalls: 0,
    completed: 0,
    queued: 0,
    rejected: 0,
    blocked: 0,
    failures: 0,
    consecutiveProviderFailures: 0,
    transientProviderFailures: 0,
    providerBackoffs: 0,
    lastProviderBackoffMs: 0,
    lifecycleWaits: 0,
    stopped: false,
    stopReason: null
  };
}

function statusResult(result) {
  return {
    timestamp: new Date().toISOString(),
    status: result.status,
    providerCalled: Boolean(result.providerCalled),
    decision: result.response?.decision ?? null,
    summary: result.response?.summary ?? null,
    proposedCapability: result.response?.action?.capabilityName ?? null,
    errorCode: result.error?.code ?? result.actionResult?.error?.code ?? null,
    queued: result.status === "action_queued",
    httpStatus: safeHttpStatus(result.error?.details?.status),
    validationErrors: safeValidationErrors(result.actionResult?.error?.details?.errors ?? result.error?.details?.errors),
    transient: Boolean(result.transient),
    retryAfterMs: Number.isInteger(result.retryAfterMs) ? result.retryAfterMs : null,
    reason: result.reason ?? null
  };
}

function safeHttpStatus(value) {
  return Number.isInteger(value) && value >= 100 && value <= 599 ? value : null;
}

function safeValidationErrors(value) {
  if (!Array.isArray(value)) return [];
  return value.slice(0, 10).filter((item) => typeof item === "string").map((item) => item.slice(0, 240));
}
