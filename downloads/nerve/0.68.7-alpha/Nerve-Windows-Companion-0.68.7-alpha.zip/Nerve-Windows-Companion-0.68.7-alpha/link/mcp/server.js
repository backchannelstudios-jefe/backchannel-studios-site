#!/usr/bin/env node
import { createInterface } from "node:readline";
import { resolve } from "node:path";
import { fileURLToPath } from "node:url";
import { createNerve } from "../../core/create-nerve.js";
import { createMcpHandler } from "./handler.js";

export async function runMcpServer({ input = process.stdin, output = process.stdout, errorOutput = process.stderr } = {}) {
  const nerve = createNerve();
  const handle = createMcpHandler(nerve);
  const lines = createInterface({ input, crlfDelay: Infinity, terminal: false });

  for await (const line of lines) {
    if (!line.trim()) continue;

    let message;
    try {
      message = JSON.parse(line);
    } catch {
      output.write(`${JSON.stringify({
        jsonrpc: "2.0",
        id: null,
        error: { code: -32700, message: "Parse error" }
      })}\n`);
      continue;
    }

    let response;
    try {
      response = await handle(message);
    } catch (error) {
      errorOutput.write(`Nerve MCP request failed: ${error.message}\n`);
      response = {
        jsonrpc: "2.0",
        id: message?.id ?? null,
        error: { code: -32603, message: "Internal error" }
      };
    }

    if (response !== undefined) {
      output.write(`${JSON.stringify(response)}\n`);
    }
  }
}

if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  await runMcpServer();
}
