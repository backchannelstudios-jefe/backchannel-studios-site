const SUPPORTED_PROTOCOL_VERSION = "2025-11-25";

export function createMcpHandler({ runtime, registry, adapter, serverVersion = "0.1.0" }) {
  let initializeResponded = false;
  let initialized = false;

  return async function handle(message) {
    if (!isRequestOrNotification(message)) {
      return error(null, -32600, "Invalid Request");
    }

    const isNotification = message.id === undefined;

    if (message.method === "initialize") {
      if (isNotification) return undefined;
      initializeResponded = true;
      return success(message.id, {
        protocolVersion: SUPPORTED_PROTOCOL_VERSION,
        capabilities: { tools: { listChanged: false } },
        serverInfo: {
          name: "nerve",
          title: "Nerve Local Middleware",
          version: serverVersion,
          description: "Permissioned AI capabilities for local applications"
        },
        instructions: serverInstructions(adapter, registry)
      });
    }

    if (message.method === "notifications/initialized") {
      if (initializeResponded) initialized = true;
      return undefined;
    }

    if (message.method === "ping") {
      return isNotification ? undefined : success(message.id, {});
    }

    if (!initialized) {
      return isNotification ? undefined : error(message.id, -32002, "Server not initialized");
    }

    if (message.method === "tools/list") {
      return isNotification ? undefined : success(message.id, { tools: registry.toMcpTools() });
    }

    if (message.method === "tools/call") {
      if (isNotification) return undefined;
      const name = message.params?.name;
      const args = message.params?.arguments ?? {};
      if (typeof name !== "string" || !isPlainObject(args)) {
        return error(message.id, -32602, "Invalid tools/call parameters");
      }

      const result = await runtime.call({
        capabilityName: name,
        arguments: args,
        sessionId: `stdio-${process.pid}`,
        metadata: { transport: "stdio" }
      });
      return success(message.id, {
        content: [{ type: "text", text: JSON.stringify(result) }],
        structuredContent: result,
        isError: !result.ok
      });
    }

    return isNotification ? undefined : error(message.id, -32601, "Method not found");
  };
}

function serverInstructions(adapter, registry) {
  const writeState = registry.list().some((capability) => capability.access === "write")
    ? "Write capabilities are enabled and remain subject to Nerve Guard and each capability's confirmation policy."
    : "Write capabilities are disabled for this server.";
  return [adapter?.instructions, writeState].filter(Boolean).join(" ");
}

function isRequestOrNotification(value) {
  return (
    isPlainObject(value) &&
    value.jsonrpc === "2.0" &&
    typeof value.method === "string" &&
    (value.id === undefined || typeof value.id === "string" || typeof value.id === "number")
  );
}

function isPlainObject(value) {
  return value !== null && typeof value === "object" && !Array.isArray(value);
}

function success(id, result) {
  return { jsonrpc: "2.0", id, result };
}

function error(id, code, message) {
  return { jsonrpc: "2.0", id, error: { code, message } };
}
